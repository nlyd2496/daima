﻿using HarmonyLib;
using KSerialization;
using PeterHan.PLib.Options;
using STRINGS;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace H_运输系统_1._0
{
    [SerializationConfig(MemberSerialization.OptIn)]
    public class H003GG1K1 : KMonoBehaviour, IMultiSliderControl
    {
        // 构造函数，初始化滑块控件数组
        public H003GG1K1()
        {
            this.sliderControls = new ISliderControl[]
            {
                new H003GG1K1K1(this), // 初始化1号滑块控件
                new H003GG1K1K2(this), // 初始化2号滑块控件
            };
        }
        string IMultiSliderControl.SidescreenTitleKey => "STRINGS.BUILDINGS.PREFABS.AUTOMINER.NAME"; // 控制器名称
        // 复制设置方法
        internal void OnCopySettings(object data)
        {
            var component = ((GameObject)data).GetComponent<H003GG1K1>();
            if (component == null) return;
            AA = component.AA;
            BB = component.BB;
            Update();
        }
        
        // 滑条
        [MyCmpReq] public AutoMiner autoMiner;
        [Serialize] public float AA = 8f; // 滑条1_初始值
        [Serialize] public float BB = 8f; // 滑条2_初始值

        // 额外组件
        [MyCmpReq] public RangeVisualizer rangeVisualizer; // 范围可视化控件
        [MyCmpReq] public EnergyConsumer energyConsumer; // 能量控件

        // 更新方法，将AA的值赋予源功能组件
        internal void Update()
        {
            autoMiner.height = (int)AA;//建筑功能1接受AA的值
            autoMiner.width = (int)BB;//建筑功能2接受BB的值
            //--------------------------
            //范围显示更新
            this.autoMiner.x = -this.autoMiner.width / 2 + 1;
            this.rangeVisualizer.RangeMin.x = -this.autoMiner.width / 2 + 1;
            this.rangeVisualizer.RangeMin.y = -1;
            this.rangeVisualizer.RangeMax.x = this.rangeVisualizer.RangeMin.x + this.autoMiner.width - 1;
            this.rangeVisualizer.RangeMax.y = this.autoMiner.height - 2;
            //--------------------------
            //能量更新
            bool H000GG1 = SingletonOptions<控制台>.Instance.H000GG1;
            if (H000GG1)
            {
                this.energyConsumer.BaseWattageRating = 1.5f * this.AA * this.BB;
            }
            //--------------------------
        }
        // ----------------
        // ----------------       
        protected ISliderControl[] sliderControls; // 受保护的滑块控件数组
        bool IMultiSliderControl.SidescreenEnabled() => true; // 控制器启用
        [MyCmpAdd] public CopyBuildingSettings copyBuildingSettings; // 复制建筑设置组件                                                      
        protected override void OnSpawn() { base.OnSpawn(); this.Update(); } // OnSpawn方法，在生成时调用
        ISliderControl[] IMultiSliderControl.sliderControls => this.sliderControls; // 滑块控件数组      
        protected override void OnPrefabInit() { base.OnPrefabInit(); base.Subscribe(-905833192, new Action<object>(this.OnCopySettings)); }// OnPrefabInit方法，在预制初始化时调用
        // ----------------
        // ----------------
        // 内部类，1号滑块控件
        public class H003GG1K1K1 : KMonoBehaviour, ISingleSliderControl, ISliderControl
        {
            public string SliderUnits => UI.UNITSUFFIXES.UNIT; // 格
            public string SliderTitleKey => "STRINGS.BUILDINGS.PREFABS.H000GG0.GAO"; // 高
            public float GetSliderMin(int index) => 1; // 最小值           
            public float GetSliderMax(int index) => 32; // 最大值
            public int SliderDecimalPlaces(int index) => 0; // 小数点          
            // ----------------
            public H003GG1K1 target; // 目标对象           
            public string GetSliderTooltip(int index) => ""; // 滑块提示
            public string GetSliderTooltipKey(int index) => ""; // 滑块提示键（空）
            public float GetSliderValue(int index) => this.target.AA; // 获取滑块值
            public H003GG1K1K1(H003GG1K1 target) { this.target = target; } // 构造函数，初始化目标对象
            public void SetSliderValue(float value, int index) { this.target.AA = value; this.target.Update(); } // 设置滑块值
        }
        // 滑条2
        public class H003GG1K1K2 : KMonoBehaviour, ISingleSliderControl, ISliderControl
        {
            public string SliderUnits => UI.UNITSUFFIXES.UNIT; // 格
            public string SliderTitleKey => "STRINGS.BUILDINGS.PREFABS.H000GG0.KUAN"; // 宽
            public float GetSliderMin(int index) => 1; // 最小值
            public float GetSliderMax(int index) => 32; // 最大值
            public int SliderDecimalPlaces(int index) => 0; // 小数点
            // ----------------
            public H003GG1K1 target; // 目标对象           
            public string GetSliderTooltip(int index) => ""; // 滑块提示
            public string GetSliderTooltipKey(int index) => ""; // 滑块提示键（空）
            public float GetSliderValue(int index) => this.target.BB; // 获取滑块值
            public H003GG1K1K2(H003GG1K1 target) { this.target = target; } // 构造函数，初始化目标对象
            public void SetSliderValue(float value, int index) { this.target.BB = value; this.target.Update(); } // 设置滑块值
        } 
    }
}
    