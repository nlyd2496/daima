﻿using KSerialization;
using PeterHan.PLib.Options;
using STRINGS;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace H_运输系统_1._0
{
    public class H005GG1K1 : KMonoBehaviour, ISingleSliderControl, ISliderControl
    {
        public string SliderTitleKey => "STRINGS.BUILDINGS.PREFABS.SOLIDTRANSFERARM.NAME";
        public string GetSliderTooltip(int index) => "";//滑块名称
        public string SliderUnits => UI.UNITSUFFIXES.UNIT; // 格
        public string GetSliderTooltipKey(int index) => "";//空

        public int SliderDecimalPlaces(int index) => 0;//小数点
        public float GetSliderMin(int index) => 1;//最小值
        public float GetSliderMax(int index) => 30;//最大值
        public float GetSliderValue(int index) => this.AA;
        public void SetSliderValue(float value, int index) { this.AA = value; this.Update(); }

        [Serialize] public float AA = 6f;
        [MyCmpReq] public SolidTransferArm solidtransferarm;
        // 额外组件
        [MyCmpReq] public RangeVisualizer rangeVisualizer; // 范围可视化控件
        [MyCmpReq] public EnergyConsumer energyConsumer; // 能量控件

        internal void Update() 
        { 
            this.solidtransferarm.pickupRange = (int)this.AA ; // 赋值
            this.energyConsumer.BaseWattageRating = 18f * this.AA; // 能量
            // 可视化
            rangeVisualizer.RangeMin.x = (int)-AA;
            rangeVisualizer.RangeMin.y = (int)-AA;
            rangeVisualizer.RangeMax.x = (int)AA;
            rangeVisualizer.RangeMax.y = (int)AA;
        } 

        [MyCmpAdd] public CopyBuildingSettings copyBuildingSettings;
        protected override void OnSpawn() { base.OnSpawn(); this.Update(); }

        protected override void OnPrefabInit() { base.OnPrefabInit(); base.Subscribe(-905833192, new Action<object>(this.OnCopySettings)); }
        internal void OnCopySettings(object data) { var component = ((GameObject)data).GetComponent<H005GG1K1>(); if (component == null) return; AA = component.AA; Update(); }

    }
}
