﻿using Newtonsoft.Json;
using PeterHan.PLib.Options;


namespace H_运输系统_1._0
{
    [RestartRequired]
    [JsonObject(MemberSerialization.OptIn)]
    [ConfigFile("H000GG0.json", true, false)]
    [ModInfo("https://space.bilibili.com/30725645", "mmm.png", true)]

    public class 控制台 : SingletonOptions<控制台>
    {
        // 启用能量守恒
        [Option("STRINGS.BUILDINGS.PREFABS.H_UI.H000GG1_UI", null, null)]
        [JsonProperty]
        public bool H000GG1 { get; set; } = false;

        // 启用超次元矿机
        [Option("STRINGS.BUILDINGS.PREFABS.H_UI.H001GG1_UI", null, null)]
        [JsonProperty]
        public bool H001GG1 { get; set; } = true;

        // 启用超级开发者固体泵
        [Option("STRINGS.BUILDINGS.PREFABS.H_UI.H002GG1_UI", null, null)]
        [JsonProperty]
        public bool H002GG1 { get; set; } = true;

        // 启用矿机优化
        [Option("STRINGS.BUILDINGS.PREFABS.H_UI.H003GG1_UI", null, null)]
        [JsonProperty]
        public bool H003GG1 { get; set; } = true;

        // 启用运输轨道容量增加
        [Option("STRINGS.BUILDINGS.PREFABS.H_UI.H004GG1_UI", null, null)]
        [JsonProperty]
        public bool H004GG1 { get; set; } = true;

        // 运输轨道容量
        [Option("STRINGS.BUILDINGS.PREFABS.H_UI.H004GG1X1_UI", null, null, Format = "F0")]
        [Limit(20.0, 1000.0)]
        [JsonProperty]
        public float H004GG1X1 { get; set; } = 100f;

        // 启用自动清扫器优化
        [Option("STRINGS.BUILDINGS.PREFABS.H_UI.H005GG1_UI", null, null)]
        [JsonProperty]
        public bool H005GG1 { get; set; } = true;

        // 启用两格轨桥
        [Option("STRINGS.BUILDINGS.PREFABS.H_UI.H006GG1_UI", null, null)]
        [JsonProperty]
        public bool H006GG1 { get; set; } = true;

        // 启用三格轨桥
        [Option("STRINGS.BUILDINGS.PREFABS.H_UI.H006GG2_UI", null, null)]
        [JsonProperty]
        public bool H006GG2 { get; set; } = true;
    }
}
