﻿using Database;
using System;
using System.Collections.Generic;
using TUNING;
using UnityEngine;

namespace K_医疗系统_1._0
{
    public class K006GG1 : IBuildingConfig
	{       
        public override BuildingDef CreateBuildingDef()
        {
            string id = "K006GG1";
            int width = 1;
            int height = 1;
            string anim = "K006GG1L1_kanim";
            int hitpoints = 30;
            float construction_time = 10f;
            float[] tier = BUILDINGS.CONSTRUCTION_MASS_KG.TIER4;
            string[] raw_MINERALS = MATERIALS.RAW_MINERALS;
            float melting_point = 1600f;
            BuildLocationRule build_location_rule = BuildLocationRule.OnFloor;
            EffectorValues none = NOISE_POLLUTION.NONE;
            BuildingDef buildingDef = BuildingTemplates.CreateBuildingDef(id, width, height, anim, hitpoints, construction_time, tier, raw_MINERALS, melting_point, build_location_rule, new EffectorValues
            {
                amount = 3,
                radius = 3
            }, none, 0.2f);
            buildingDef.Floodable = false;
            buildingDef.AudioCategory = "Metal";
            buildingDef.Overheatable = false;
            //--------------------------
            if (控制台.Instance.K006GG1) { buildingDef.Deprecated = false; } else { buildingDef.Deprecated = true; }
            //--------------------------
            return buildingDef;
        }
        
        public override void ConfigureBuildingTemplate(GameObject go, Tag prefabTag)
        {
            SoundEventVolumeCache.instance.AddVolume("storagelocker_kanim", "StorageLocker_Hit_metallic_low", NOISE_POLLUTION.NOISY.TIER1);
            Prioritizable.AddRef(go);
            Storage storage = go.AddOrGet<Storage>();
            storage.capacityKg = 100f;
            storage.showInUI = true;
            storage.allowItemRemoval = true;
            storage.showDescriptor = true;
            storage.storageFilters = new List<Tag>
            {
                GameTags.MedicalSupplies,GameTags.Medicine
            };
            storage.storageFullMargin = STORAGE.STORAGE_LOCKER_FILLED_MARGIN;
            storage.fetchCategory = Storage.FetchCategory.GeneralStorage;
            go.AddOrGet<CopyBuildingSettings>().copyGroupTag = "asquared31415_ClothingLockerConfig";
            go.AddOrGet<StorageLocker>();
            go.AddOrGet<UserNameable>();
        }
        
        public override void DoPostConfigureComplete(GameObject go)
        {
            go.AddOrGetDef<StorageController.Def>();
        }
        
        public const string ID = "K006GG1";
        
    }
    public static class 蓝图系统K006GG1
    {
        public static void Postfix(BuildingFacades __instance)
        {
            __instance.Add("K006GG1L2", STRINGS.BUILDINGS.PREFABS.K006GG1L2.NAME, STRINGS.BUILDINGS.PREFABS.K006GG1L2.EFFECT, PermitRarity.Universal, "K006GG1", "K006GG1L2_kanim", DlcManager.AVAILABLE_ALL_VERSIONS);
            __instance.Add("K006GG1L3", STRINGS.BUILDINGS.PREFABS.K006GG1L3.NAME, STRINGS.BUILDINGS.PREFABS.K006GG1L3.EFFECT, PermitRarity.Universal, "K006GG1", "K006GG1L3_kanim", DlcManager.AVAILABLE_ALL_VERSIONS);        }
    }
}
