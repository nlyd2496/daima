﻿using HarmonyLib;
using PeterHan.PLib.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace K_医疗系统_1._0
{
    [HarmonyPatch(typeof(MassageTableConfig))]
    [HarmonyPatch("ConfigureBuildingTemplate")]
    public class 高效按摩床
    {
        public static void Postfix(GameObject go)
        {
            bool K002GG1 = SingletonOptions<控制台>.Instance.K002GG1;
            if (K002GG1)
            {
                MassageTable massageTable = go.AddOrGet<MassageTable>();
                massageTable.stressModificationValue = SingletonOptions<控制台>.Instance.K002GG1X1 * -30;
                massageTable.roomStressModificationValue = SingletonOptions<控制台>.Instance.K002GG1X1 * -60;
            }
        }
    }
}
