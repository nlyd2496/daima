﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HarmonyLib;
using STRINGS;
using KMod;
using PeterHan.PLib.Core;
using PeterHan.PLib.Database;
using Klei.AI;
using PeterHan.PLib.Options;

namespace F_站台系统_1._0
{
    // 控制台描述

    public class STRINGS
    {
        public static void DoReplacement()
        {
            LocString.CreateLocStringKeys(typeof(STRINGS), "");
        }
        public class F_UI
        {
            public static LocString F001GG1_UI = "启用智能喷气服";
            public static LocString F001GG1X1_UI = "喷气服石油消耗率";
            public static LocString F002GG1_UI = "启用智能气压服";
            public static LocString F003GG1_UI = "启用智能铅服(DLC限定)";
            public static LocString F004GG1_UI = "启用智能氧气面罩";

        }
    }
}
