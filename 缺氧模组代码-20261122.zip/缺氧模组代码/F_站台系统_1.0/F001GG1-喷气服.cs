﻿using HarmonyLib;
using PeterHan.PLib.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using TUNING;
using UnityEngine;

namespace F_站台系统_1._0
{

    [HarmonyPatch(typeof(JetSuitConfig))]
    [HarmonyPatch("DoPostConfigure")]
    public class 喷气服氧气容量修改
    {
        public static void Postfix(GameObject go)
        {
            bool F001GG1 = SingletonOptions<控制台>.Instance.F001GG1;
            if (F001GG1)
            {
                go.AddOrGet<F001GG1K1>();
            }
        }
    }
    [HarmonyPatch(typeof(JetSuitLockerConfig))]
    [HarmonyPatch("ConfigureBuildingTemplate")]
    public class 喷气服存放柜容量和氧气运输速率修改
    {
        public static void Postfix(GameObject go)
        {
            bool F001GG1 = SingletonOptions<控制台>.Instance.F001GG1;
            if (F001GG1)
            {
                ConduitConsumer conduitConsumer = go.AddOrGet<ConduitConsumer>();
                conduitConsumer.consumptionRate = 100f; //运输速率
                conduitConsumer.capacityKG = 200f; //容量
            }
        } 
    }
    [HarmonyPatch(typeof(JetSuitMarkerConfig))]
    [HarmonyPatch("ConfigureBuildingTemplate")]
    public class 检查站储存衣物_F001GG1
    {
        public static void Postfix(GameObject go)
        {
            bool F001GG1 = SingletonOptions<控制台>.Instance.F001GG1;
            if (F001GG1)
            {
                Prioritizable.AddRef(go);
                SoundEventVolumeCache.instance.AddVolume("storagelocker_kanim", "StorageLocker_Hit_metallic_low", NOISE_POLLUTION.NOISY.TIER1);
                Prioritizable.AddRef(go);
                Storage storage = go.AddOrGet<Storage>();
                storage.capacityKg = 100000f;
                storage.showInUI = true;
                storage.allowItemRemoval = true;
                storage.showDescriptor = true;
                storage.storageFilters = new List<Tag>
                {
                    GameTags.Clothes
                };
                storage.storageFullMargin = STORAGE.STORAGE_LOCKER_FILLED_MARGIN;
                storage.fetchCategory = Storage.FetchCategory.GeneralStorage;
                go.AddOrGet<CopyBuildingSettings>().copyGroupTag = GameTags.StorageLocker;
                go.AddOrGet<StorageLocker>();

                go.AddOrGetDef<StorageController.Def>();

            }
        }
    }
    [HarmonyPatch(typeof(JetSuitMonitor))]
    [HarmonyPatch("Emit")]
    public static class 喷气服石油消耗降低
    {
        private static bool F001GG1 = SingletonOptions<控制台>.Instance.F001GG1;
        private static IEnumerable<CodeInstruction> Transpiler(IEnumerable<CodeInstruction> instructions)
        {
            var codes = new List<CodeInstruction>(instructions);

            // 查找燃料消耗计算位置
            for (int i = 0; i < codes.Count; i++)
            {
                if (codes[i].opcode == OpCodes.Ldc_R4 && (float)codes[i].operand == 0.2f)
                {
                    if (F001GG1)
                    {
                        // 修改燃料计算基数
                        codes[i].operand = SingletonOptions<控制台>.Instance.F001GG1X1;
                    }
                }
            }

            return codes.AsEnumerable();
        }
    }

}