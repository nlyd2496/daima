﻿using Newtonsoft.Json;
using PeterHan.PLib.Options;


namespace F_站台系统_1._0
{
    [RestartRequired]
    [JsonObject(MemberSerialization.OptIn)]
    [ConfigFile("F000GG0.json", true, false)]
    // [ModInfo("https://space.bilibili.com/30725645", "mmm.png", true)]

    public class 控制台 : SingletonOptions<控制台>
    {
        // 喷气服
        [Option("STRINGS.F_UI.F001GG1_UI", null, null)][JsonProperty] public bool F001GG1 { get; set; } = true;
        // 石油消耗量
        [Option("STRINGS.F_UI.F001GG1X1_UI", null, null)][Limit(0, 0.2)][JsonProperty] public float  F001GG1X1 { get; set; } = 0.1f;
        // 气压服
        [Option("STRINGS.F_UI.F002GG1_UI", null, null)][JsonProperty] public bool F001GG2 { get; set; } = true;
        // 铅服
        [Option("STRINGS.F_UI.F003GG1_UI", null, null)][JsonProperty] public bool F001GG3 { get; set; } = true;
        // 氧气面罩
        [Option("STRINGS.F_UI.F004GG1_UI", null, null)][JsonProperty] public bool F001GG4 { get; set; } = true;
    }
}
