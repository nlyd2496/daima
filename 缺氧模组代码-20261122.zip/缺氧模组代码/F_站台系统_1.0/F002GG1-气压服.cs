﻿using HarmonyLib;
using PeterHan.PLib.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TUNING;
using UnityEngine;

namespace F_站台系统_1._0
{
    [HarmonyPatch(typeof(AtmoSuitConfig))]
    [HarmonyPatch("DoPostConfigure")]
    public class 气压服氧气容量修改
    {
        public static void Postfix(GameObject go)
        {
            bool F001GG2 = SingletonOptions<控制台>.Instance.F001GG2;
            if (F001GG2)
            {
                go.AddOrGet<F002GG1K1>();
            }
        }
    }
    [HarmonyPatch(typeof(SuitLockerConfig))]
    [HarmonyPatch("ConfigureBuildingTemplate")]
    public class 气压服存放柜容量和氧气运输速率修改
    {
        public static void Postfix(GameObject go)
        {
            bool F001GG2 = SingletonOptions<控制台>.Instance.F001GG2;
            if (F001GG2)
            {
                ConduitConsumer conduitConsumer = go.AddOrGet<ConduitConsumer>();
                conduitConsumer.consumptionRate = 100f; //运输速率
                conduitConsumer.capacityKG = 200f; //容量
            }
        }
    }
    [HarmonyPatch(typeof(SuitMarkerConfig))]
    [HarmonyPatch("ConfigureBuildingTemplate")]
    public class 检查站储存衣物_F002GG1
    {
        public static void Postfix(GameObject go)
        {
            bool F001GG2 = SingletonOptions<控制台>.Instance.F001GG2;
            if (F001GG2)
            {
                Prioritizable.AddRef(go);
                SoundEventVolumeCache.instance.AddVolume("storagelocker_kanim", "StorageLocker_Hit_metallic_low", NOISE_POLLUTION.NOISY.TIER1);
                Prioritizable.AddRef(go);
                Storage storage = go.AddOrGet<Storage>();
                storage.capacityKg = 100000f;
                storage.showInUI = true;
                storage.allowItemRemoval = true;
                storage.showDescriptor = true;
                storage.storageFilters = new List<Tag>
                {
                    GameTags.Clothes
                };
                storage.storageFullMargin = STORAGE.STORAGE_LOCKER_FILLED_MARGIN;
                storage.fetchCategory = Storage.FetchCategory.GeneralStorage;
                go.AddOrGet<CopyBuildingSettings>().copyGroupTag = GameTags.StorageLocker;
                go.AddOrGet<StorageLocker>();

                go.AddOrGetDef<StorageController.Def>();

            }
        }
    }
}
