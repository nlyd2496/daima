﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HarmonyLib;
using PeterHan.PLib.Options;

namespace P_永不淹没
{
    [HarmonyPatch(typeof(BuildingLoader))]
    [HarmonyPatch("CreateBuildingComplete")]
    public class 永不淹没
    {
        public static void Prefix(ref BuildingDef def)
        {

            // 排除小动物公寓和飞行小动物公寓，保持 Floodable=true 确保组件被创建
            if (def.PrefabID != "CritterCondo" && def.PrefabID != "AirBorneCritterCondo")
            {
                def.Floodable = false;
            }

        }
    }
}
