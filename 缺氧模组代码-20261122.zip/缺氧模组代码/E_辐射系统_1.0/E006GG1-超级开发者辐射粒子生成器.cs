﻿using HarmonyLib;
using PeterHan.PLib.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace E_辐射系统_1._0
{
    [HarmonyPatch(typeof(DevRadiationGeneratorConfig))]
    [HarmonyPatch("CreateBuildingDef")]
    internal class 超级开发者辐射粒子生成器
    {
        public static void Postfix(BuildingDef __result)
        {
            bool E006GG1 = SingletonOptions<控制台>.Instance.E006GG1;
            if (E006GG1)
            {
                __result.DebugOnly = false;//正常模式可使用
                __result.Floodable = false;//可被淹没
                __result.Overheatable = false;//不会过热
                __result.ThermalConductivity = 0f;//导热系数为0
                __result.UseStructureTemperature = false;//使用结构温度
            }
        }
    }
}
