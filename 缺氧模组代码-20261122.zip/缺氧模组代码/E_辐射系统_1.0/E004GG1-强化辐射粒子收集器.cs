﻿using HarmonyLib;
using PeterHan.PLib.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace E_辐射系统_1._0
{
    [HarmonyPatch(typeof(HighEnergyParticleStorage))]
    [HarmonyPatch("Store")]
    public class 辐射粒子收集器粒子收集倍率
    {
        public static void Postfix(HighEnergyParticleStorage __instance, float amount)
        {
            bool E004GG1 = SingletonOptions<控制台>.Instance.E004GG1;
            if (E004GG1)
            {
                float num = __instance.Particles * SingletonOptions<控制台>.Instance.E004GG1X1 ;
                if (num <= 0f)
                {
                    num = 0f;
                }
                Helper.SetPrivateValue<HighEnergyParticleStorage>(__instance, "particles", num);
            }
        }
    }
    
    [HarmonyPatch(typeof(HighEnergyParticleSpawnerConfig))]
    [HarmonyPatch("CreateBuildingDef")]
    public class 辐射粒子收集器功率和发热
    {
        public static void Postfix(ref BuildingDef __result) 
        {
            bool E004GG1 = SingletonOptions<控制台>.Instance.E004GG1;
            if (E004GG1)
            {
                __result.EnergyConsumptionWhenActive = SingletonOptions<控制台>.Instance.E004GG1X2;//功率
                __result.SelfHeatKilowattsWhenActive = SingletonOptions<控制台>.Instance.E004GG1X3;//发热
                __result.ExhaustKilowattsWhenActive = 0f;//喷气功率0
            }
        }
    }
    
    [HarmonyPatch(typeof(HighEnergyParticleSpawnerConfig))]
    [HarmonyPatch("ConfigureBuildingTemplate")]
    public class 辐射粒子收集器发射间隔
    {
        public static void Postfix(GameObject go)
        {
            bool E004GG1 = SingletonOptions<控制台>.Instance.E004GG1;
            if (E004GG1)
            {
                go.AddOrGet<HighEnergyParticleStorage>().capacity = 1000f;//粒子最大储量
                HighEnergyParticleSpawner highEnergyParticleSpawner = go.AddOrGet<HighEnergyParticleSpawner>();
                highEnergyParticleSpawner.minLaunchInterval = SingletonOptions<控制台>.Instance.E004GG1X4;//发射间隔
                highEnergyParticleSpawner.minSlider = 1;
                highEnergyParticleSpawner.maxSlider = 1000;//粒子储量


            }
        }
    }
    
}
