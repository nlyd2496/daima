﻿using PeterHan.PLib.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TUNING;
using UnityEngine;

namespace E_辐射系统_1._0
{
    //核废料处理
    public class E002GG1 : IBuildingConfig
    {
        public override string[] GetDlcIds()
        {
            return DlcManager.AVAILABLE_EXPANSION1_ONLY;
        }
        public override BuildingDef CreateBuildingDef()
        {
            string id = "E002GG1";
            int width = 3;
            int height = 2;
            string anim = "E002GG1_kanim";
            int hitpoints = 30;
            float construction_time = 30f;
            float[] tier = BUILDINGS.CONSTRUCTION_MASS_KG.TIER4;
            
            string[] all_METALS = MATERIALS.ALL_METALS;
            //------------------------------------------
            float melting_point = 1600f;
            BuildLocationRule build_location_rule = BuildLocationRule.OnFloor;
            EffectorValues tier2 = NOISE_POLLUTION.NOISY.TIER3;
            BuildingDef buildingDef = BuildingTemplates.CreateBuildingDef(id, width, height, anim, hitpoints, construction_time, tier, all_METALS, melting_point, build_location_rule, BUILDINGS.DECOR.NONE, tier2, 0.2f);
            BuildingTemplates.CreateElectricalBuildingDef(buildingDef);
            buildingDef.AudioCategory = "Metal";
            buildingDef.AudioSize = "large";
            buildingDef.Floodable = false;//不会被淹没
            buildingDef.EnergyConsumptionWhenActive = 100f;
            buildingDef.ExhaustKilowattsWhenActive = 0f;
            buildingDef.RequiresPowerInput = true;

            buildingDef.SelfHeatKilowattsWhenActive = 10f;
            buildingDef.PowerInputOffset = new CellOffset(0, 0);


            buildingDef.LogicInputPorts = LogicOperationalController.CreateSingleInputPortList(new CellOffset(0, 0));
            buildingDef.PermittedRotations = PermittedRotations.FlipH;
            //--------------------------
            if (控制台.Instance.E002GG2) { buildingDef.Deprecated = false; } else { buildingDef.Deprecated = true; }
            //--------------------------
            return buildingDef;
        }
        public override void ConfigureBuildingTemplate(GameObject go, Tag prefab_tag)
        {

            //-------------------------------------------
            //辐射
            RadiationEmitter radiationEmitter = go.AddComponent<RadiationEmitter>();
            radiationEmitter.emitType = RadiationEmitter.RadiationEmitterType.Constant;
            radiationEmitter.emitRadiusX = 4;
            radiationEmitter.emitRadiusY = 4;
            radiationEmitter.emitRads = 20f;
            //-------------------------------------------


            go.GetComponent<KPrefabID>().AddTag(RoomConstraints.ConstraintTags.IndustrialMachinery, false);

            Polymerizer polymerizer = go.AddOrGet<Polymerizer>();
            polymerizer.emitMass = 30f;
            polymerizer.emitTag = GameTagExtensions.Create(SimHashes.Iron);
            polymerizer.emitOffset = new Vector3(-1.45f, 1f, 0f);

            Storage storage = go.AddOrGet<Storage>();
            storage.capacityKg = 100f;
            storage.SetDefaultStoredItemModifiers(Storage.StandardSealedStorage);
            storage.showInUI = true;
            ManualDeliveryKG manualDeliveryKG = go.AddOrGet<ManualDeliveryKG>();
            manualDeliveryKG.SetStorage(storage);
            manualDeliveryKG.RequestedItemTag = new Tag("NuclearWaste");
            manualDeliveryKG.refillMass = 0.1f;
            manualDeliveryKG.capacity = 1f;
            manualDeliveryKG.choreTypeIDHash = Db.Get().ChoreTypes.MachineFetch.IdHash;
            ElementConverter elementConverter = go.AddOrGet<ElementConverter>();
            elementConverter.consumedElements = new ElementConverter.ConsumedElement[]
            {

            new ElementConverter.ConsumedElement(new Tag("NuclearWaste"), 1f, true)
            };
            elementConverter.outputElements = new ElementConverter.OutputElement[]
            {
            new ElementConverter.OutputElement(0.6f, SimHashes.Iron, 303.15f, false, true, 0f, 0.5f, 1f, byte.MaxValue, 0, true)
            };
            go.AddOrGet<DropAllWorkable>();
            Prioritizable.AddRef(go);
        }
        public override void DoPostConfigureComplete(GameObject go)
        {
            go.AddOrGet<LogicOperationalController>();
            go.AddOrGetDef<PoweredActiveController.Def>();
        }
        public const string ID = "E002GG1";
    }
    
}
