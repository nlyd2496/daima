using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using FMODUnity;
using HarmonyLib;
using Klei.AI;
using KMod;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace PetPal
{
    public class PetView : MonoBehaviour, IPointerClickHandler, IBeginDragHandler, IDragHandler, IEndDragHandler, IPointerDownHandler
    {
        public PetHost host;
        public bool Dragging;
        private Vector2 lastPos;
        private float downAt;
        private bool dragged;
        private bool longSent;

        public void OnPointerDown(PointerEventData e)
        {
            lastPos = e.position;
            downAt = Time.unscaledTime;
            dragged = false;
            longSent = false;
        }

        public void OnBeginDrag(PointerEventData e)
        {
            dragged = true;
            Dragging = true;
        }

        public void OnDrag(PointerEventData e)
        {
            Vector2 d = e.position - lastPos;
            lastPos = e.position;
            float s = 1f;
            var c = transform.parent != null ? transform.parent.GetComponent<Canvas>() : null;
            if (c != null && c.scaleFactor > 0f) s = 1f / c.scaleFactor;
            host.OnDrag(d * s);
        }

        public void OnEndDrag(PointerEventData e)
        {
            Dragging = false;
            host.OnDragEnd();
        }

        public void OnPointerClick(PointerEventData e)
        {
            if (!dragged) host.OnClick();
        }

        public bool ConsumeLongPress()
        {
            if (longSent)
            {
                if (!Input.GetMouseButton(0)) longSent = false;
                return false;
            }
            if (dragged || !Input.GetMouseButton(0)) return false;
            if (Time.unscaledTime - downAt >= 0.6f)
            {
                longSent = true;
                return true;
            }
            return false;
        }
    }
}
