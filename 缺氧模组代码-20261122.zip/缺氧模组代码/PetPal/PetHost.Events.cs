using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using FMODUnity;
using HarmonyLib;
using Klei.AI;
using KMod;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace PetPal
{
    public partial class PetHost : MonoBehaviour
    {
        private static bool IsMilestone(int cycle)
        {
            for (int i = 0; i < Milestones.Length; i++) if (Milestones[i] == cycle) return true;
            return false;
        }

        private void ResolveSaveKey()
        {
            saveKey = "default";
            try
            {
                var sl = SaveLoader.Instance;
                if (sl != null)
                {
                    var pi = sl.GetType().GetProperty("saveGameName",
                        BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                    if (pi != null)
                    {
                        string v = pi.GetValue(sl) as string;
                        if (!string.IsNullOrEmpty(v)) saveKey = v;
                    }
                }
            }
            catch { }
            msDone.Clear();
            for (int i = 0; i < Milestones.Length; i++)
                if (PlayerPrefs.GetInt(MsKey(Milestones[i]), 0) != 0) msDone.Add(Milestones[i]);
        }

        private string MsKey(int n) { return "PetPal.MS." + saveKey + "." + n; }

        private void UpdateEvents()
        {
            if (gameClock == null)
            {
                try { gameClock = GameClock.Instance; speedScreen = SpeedControlScreen.Instance; } catch { }
            }
            if (Time.unscaledTime >= nextCycleCheck)
            {
                nextCycleCheck = Time.unscaledTime + 0.1f;
                bool paused = Time.timeScale <= 0f;
                try { if (speedScreen != null && speedScreen.IsPaused) paused = true; } catch { }
                pausedCache = paused;
            }
            if (!pausedCache) gameTime += Time.unscaledDeltaTime * Mathf.Max(1f, Time.timeScale);

            int cyc = -1;
            try { if (gameClock != null) cyc = gameClock.GetCycle(); } catch { }
            if (cyc < 0) return;

            if (!entered)
            {
                entered = true;
                lastCycle = cyc;
                for (int i = 0; i < Milestones.Length; i++)
                {
                    int m = Milestones[i];
                    if (cyc > m && msDone.Add(m)) PlayerPrefs.SetInt(MsKey(m), 1);
                }
                if (VoiceAllowed) Say("welcome", "happy", PRIO_SELECT);
                StartCoroutine(WarmAudio());
                milestoneCycle = false;
                nextRandomFxAt = gameTime + UnityEngine.Random.Range(30f, 540f);
                PlayerPrefs.Save();
                return;
            }

            if (cyc != lastCycle)
            {
                lastCycle = cyc;
                floatedThisCycle = false;
                if (IsMilestone(cyc))
                {
                    milestoneCycle = true;
                    nextRandomFxAt = float.MaxValue;
                    if (cyc <= 50000 && msDone.Add(cyc))
                    {
                        PlayerPrefs.SetInt(MsKey(cyc), 1);
                        PlayerPrefs.Save();
                        if (VoiceAllowed) Say("ms_" + cyc, "laugh", PRIO_SELECT);
                        if (EffectsAllowed) SpawnFlower(true);
                    }
                }
                else
                {
                    milestoneCycle = false;
                    if (cyc <= 50000 && VoiceAllowed) Say("cycle", "happy", PRIO_SELECT);
                    if (EffectsAllowed) SpawnFlower(false);
                    nextRandomFxAt = gameTime + UnityEngine.Random.Range(30f, 540f);
                }
            }

            if (!milestoneCycle && gameTime >= nextRandomFxAt)
            {
                nextRandomFxAt = float.MaxValue;
                if (EffectsAllowed)
                {
                    SpawnFlower(false);
                }
            }
        }

        private void UpdateUrgent()
        {
            if (Time.unscaledTime < nextUrgentCheck) return;
            nextUrgentCheck = Time.unscaledTime + 0.5f;
            float sum = 0f; int count = 0;
            try
            {
                foreach (MinionIdentity id in Components.LiveMinionIdentities)
                {
                    var a = id.GetAmounts();
                    if (a == null) continue;
                    sum += a.GetValue("Stress");
                    count++;
                }
            }
            catch { }
            bool stress = count > 0 && sum / count > 60f;
            urgentActive = stress;
            if (!stress) return;
            if (Time.unscaledTime < nextUrgentAt) return;
            nextUrgentAt = Time.unscaledTime + UnityEngine.Random.Range(15f, 30f);
            Say("urgent_stress", "stressed", PRIO_URGENT);
        }

        private void UpdateChatter()
        {
            if (urgentActive || lying) return;
            if (Time.unscaledTime < nextChatterAt) return;
            nextChatterAt = Time.unscaledTime + UnityEngine.Random.Range(16f, 32f);
            if (bubbleRect != null && bubbleRect.gameObject.activeSelf) return;
            SayChatter();
        }

        private void UpdateTools()
        {
            if (Time.unscaledTime < nextToolAt) return;
            if (!Input.GetMouseButtonDown(0)) return;
            var pc = PlayerController.Instance;
            if (pc == null || pc.ActiveTool == null) return;
            string tool = pc.ActiveTool.GetType().Name;
            if (string.IsNullOrEmpty(tool) || tool == "SelectTool") return;
            nextToolAt = Time.unscaledTime + 3f;
            string tag = "cmd_other";
            if (tool.Contains("Build")) tag = "cmd_build";
            else if (tool.Contains("Dig")) tag = "cmd_dig";
            else if (tool.Contains("Deconstruct")) tag = "cmd_deconstruct";
            else if (tool.Contains("Mop") || tool.Contains("Clear")) tag = "cmd_clear";
            else if (tool.Contains("Disinfect")) tag = "cmd_disinfect";
            else if (tool.Contains("Prioritize")) tag = "cmd_prioritize";
            else if (tool.Contains("Cancel")) tag = "cmd_cancel";
            else if (tool.Contains("Harvest")) tag = "cmd_harvest";
            else if (tool.Contains("Attack")) tag = "cmd_attack";
            else if (tool.Contains("Capture")) tag = "cmd_capture";
            else if (tool.Contains("EmptyPipe")) tag = "cmd_emptypipe";
            else if (tool.Contains("Disconnect")) tag = "cmd_disconnect";
            Say(tag, "happy");
        }

        private static string SafeProper(KSelectable sel)
        {
            if (sel == null) return null;
            try { return sel.GetProperName(); } catch { return null; }
        }

        private void UpdateSelection()
        {
            if (Time.unscaledTime < nextSelectCheck) return;
            nextSelectCheck = Time.unscaledTime + 0.35f;
            KSelectable sel = null;
            try
            {
                if (SelectField != null && SelectTool.Instance != null)
                    sel = SelectField.GetValue(SelectTool.Instance) as KSelectable;
            }
            catch { }
            if (sel == lastSelected) return;
            lastSelected = sel;
            if (sel == null) { ClearQueue(); return; }

            if (!floatedThisCycle && UnityEngine.Random.value < 0.10f && TryBeginFloat(sel)) return;

            string prefab = null, proper = null;
            try
            {
                var kp = sel.GetComponent<KPrefabID>();
                if (kp != null) prefab = kp.PrefabTag.Name;
            }
            catch { }
            if (string.IsNullOrEmpty(prefab)) { try { prefab = sel.name; } catch { } }
            try { proper = sel.GetProperName(); } catch { }

            string vid = null, vtext = null;
            bool matched = false;
            if (!string.IsNullOrEmpty(prefab) && VoicePack.TryPickByPrefab(prefab, out vid, out vtext)) matched = true;
            else if (!string.IsNullOrEmpty(proper) && VoicePack.TryPickByName(proper, out vid, out vtext)) matched = true;

            if (matched)
            {
                if (Time.unscaledTime < nextNameSpeakAt) return;
                nextNameSpeakAt = Time.unscaledTime + 0.8f;
                SayExact(vid, vtext, "curious");
                return;
            }

            if (Time.unscaledTime < nextSelectAt) return;
            nextSelectAt = Time.unscaledTime + 1.5f;
            string tag = "sel_building";
            try
            {
                if (sel.GetComponent<MinionIdentity>() != null) tag = "sel_dupe";
                else if (sel.GetComponent<CreatureBrain>() != null) tag = "sel_animal";
                else if (sel.GetComponent<Growing>() != null) tag = "sel_plant";
            }
            catch { }
            Say(tag, "curious");
        }

        public void OnGameMessage(string messageType)
        {
            if (!inGame || urgentActive || messageType == null) return;
            if (Time.unscaledTime < nextMsgAt) return;
            nextMsgAt = Time.unscaledTime + 2f;
            string t = messageType.ToLowerInvariant();
            string tag = "msg_default";
            if (t.Contains("death")) tag = "msg_death";
            else if (t.Contains("research")) tag = "msg_research";
            else if (t.Contains("achievement")) tag = "msg_achievement";
            else if (t.Contains("duplicantsleft")) tag = "msg_left";
            else if (t.Contains("worlddetected")) tag = "msg_world";
            else if (t.Contains("codex")) tag = "msg_codex";
            else if (t.Contains("skill")) tag = "msg_skill";
            else if (t.Contains("tutorial")) tag = "msg_tutorial";
            else if (t.Contains("eod")) tag = "msg_eod";
            else if (t.Contains("genetic")) tag = "msg_genetic";
            if (t.Contains("launch")) tag = "rocket_launch";
            else if (t.Contains("land")) tag = "rocket_land";
            else if (t.Contains("load") || t.Contains("board")) tag = "rocket_load";
            else if (t.Contains("unload")) tag = "rocket_unload";
            Say(tag, "surprised");
        }

        // ---------------- 交互 ----------------

        public void OnClick()
        {
            if (lying)
            {
                lying = false;
                lastInputGameTime = gameTime;
                SetExpr("happy");
            }
            float now = Time.unscaledTime;
            if (now - lastClickAt < 0.8f) rapidCount++;
            else rapidCount = 0;
            lastClickAt = now;

            if (rapidCount > 0) Say("rapid", "surprised", PRIO_INTERACT);
            else Say("click", "happy", PRIO_INTERACT);
        }

        public void OnLongPress()
        {
            Say("longpress", "love", PRIO_INTERACT);
        }

        public void OnDrag(Vector2 delta)
        {
            if (root == null) return;
            root.anchoredPosition += delta;
            float w = 860f, h = 450f;
            if (canvas != null)
            {
                var rt = canvas.transform as RectTransform;
                if (rt != null && rt.rect.width > 200f)
                {
                    w = rt.rect.width * 0.5f - 80f;
                    h = rt.rect.height * 0.5f - 80f;
                }
            }
            root.anchoredPosition = new Vector2(
                Mathf.Clamp(root.anchoredPosition.x, -w, w),
                Mathf.Clamp(root.anchoredPosition.y, -h, h));
            SetExpr("drag");
            PositionBubble();
        }

        public void OnDragEnd()
        {
            PlayerPrefs.SetFloat(PrefX, root.anchoredPosition.x);
            PlayerPrefs.SetFloat(PrefY, root.anchoredPosition.y);
            PlayerPrefs.Save();
            SetExpr("idle");
        }

        // ---------------- 气泡 ----------------
    }
}
