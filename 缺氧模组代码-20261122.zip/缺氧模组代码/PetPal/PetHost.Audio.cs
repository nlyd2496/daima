using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using FMODUnity;
using HarmonyLib;
using Klei.AI;
using KMod;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace PetPal
{
    public partial class PetHost : MonoBehaviour
    {
        private IEnumerator WarmAudio()
        {
            if (!fmodReady || voiceDir == null) yield break;
            yield return null; // 让欢迎语音先开始
            try
            {
                bool ok;
                GetSound(Path.Combine(voiceDir, "lines", "W01.mp3"), "l:W01", out ok);
            }
            catch { }
        }

        // ---------------- 语音 ----------------

        private void Say(string tag, string expression, int prio = PRIO_SELECT)
        {
            if (suppressLowVoice && prio < PRIO_URGENT) return;
            if (!VoiceAllowed) return;
            if (tag == null) return;
            if (lastTagAt.TryGetValue(tag, out float t) && Time.unscaledTime - t < 3f) return;
            lastTagAt[tag] = Time.unscaledTime;
            if (!VoicePack.TryPick(tag, out string id, out string text)) return;
            SetExpr(expression);
            Enqueue(id, text, false, prio);
        }

        private void SayExact(string id, string text, string expression, int prio = PRIO_SELECT)
        {
            if (!VoiceAllowed) return;
            if (string.IsNullOrEmpty(id)) return;
            SetExpr(expression);
            Enqueue(id, text, false, prio);
        }

        private void SayChatter()
        {
            if (!VoiceAllowed || lying || urgentActive) return;
            if (!VoicePack.TryPick("chatter", out string id, out string text)) return;
            SetExpr("happy");
            Enqueue(id, text, true, PRIO_CHATTER);
        }

        private void Enqueue(string id, string text, bool connector, int prio)
        {
            if (string.IsNullOrEmpty(id)) return;
            float now = Time.unscaledTime;
            if (lastIdAt.TryGetValue(id, out float t) && now - t < 2f) return;
            lastIdAt[id] = now;

            if (prio >= PRIO_URGENT) { StopVoice(); }
            else if (hasChannel && prio > currentPrio && currentPrio <= PRIO_SELECT) StopCurrent();

            if (pending.Count >= 3)
            {
                int lowest = 0;
                for (int i = 1; i < pending.Count; i++)
                    if (pending[i].Prio < pending[lowest].Prio) lowest = i;
                if (pending[lowest].Prio < prio) pending.RemoveAt(lowest);
                else return;
            }

            pending.Add(new PendingLine { Id = id, Text = text, Connector = connector, Prio = prio });
            if (voiceWorker == null) voiceWorker = StartCoroutine(VoiceWorker());
        }

        private IEnumerator VoiceWorker()
        {
            while (pending.Count > 0)
            {
                PendingLine line = pending[0];
                pending.RemoveAt(0);
                currentPrio = line.Prio;
                ShowBubble(line.Text);
                if (line.Connector && VoicePack.ConnectorCount > 0 && UnityEngine.Random.value < 0.25f)
                {
                    if (VoicePack.TryPickConnector(out string cid, out string ctext))
                    {
                        yield return PlayClip(cid, true);
                        yield return new WaitForSecondsRealtime(0.15f);
                    }
                }
                yield return PlayClip(line.Id, false);
            }
            currentPrio = 0;
            voiceWorker = null;
            if (pending.Count > 0) voiceWorker = StartCoroutine(VoiceWorker());
        }

        private void StopCurrent()
        {
            try
            {
                if (hasChannel) { currentChannel.stop(); hasChannel = false; }
                hasSound = false;
            }
            catch { }
        }

        private void ClearQueue() { pending.Clear(); }

        private void StopVoice()
        {
            StopCurrent();
            ClearQueue();
        }

        private FMOD.Sound GetSound(string path, string key, out bool ok)
        {
            ok = false;
            if (soundCache.TryGetValue(key, out FMOD.Sound cached))
            {
                ok = true;
                return cached;
            }
            if (!File.Exists(path)) return default(FMOD.Sound);
            try
            {
                byte[] data = File.ReadAllBytes(path);
                var system = RuntimeManager.CoreSystem;
                var info = new FMOD.CREATESOUNDEXINFO
                {
                    cbsize = Marshal.SizeOf(typeof(FMOD.CREATESOUNDEXINFO)),
                    length = (uint)data.Length
                };
                FMOD.Sound sound;
                if (system.createSound(data, FMOD.MODE.OPENMEMORY | FMOD.MODE._2D | FMOD.MODE.LOOP_OFF,
                        ref info, out sound) != FMOD.RESULT.OK)
                    return default(FMOD.Sound);
                soundCache[key] = sound;
                soundOrder.Add(key);
                if (soundOrder.Count > 24)
                {
                    int idx = (soundOrder[0] == currentSoundKey && soundOrder.Count > 1) ? 1 : 0;
                    string old = soundOrder[idx];
                    soundOrder.RemoveAt(idx);
                    if (old != currentSoundKey && soundCache.TryGetValue(old, out FMOD.Sound s))
                    {
                        s.release();
                        soundCache.Remove(old);
                    }
                }
                ok = true;
                return sound;
            }
            catch { return default(FMOD.Sound); }
        }

        private IEnumerator PlayClip(string id, bool connector)
        {
            if (!fmodReady || string.IsNullOrEmpty(id) || voiceDir == null) yield break;
            string path = Path.Combine(voiceDir, connector ? "connect" : "lines", id + ".mp3");
            string key = (connector ? "c:" : "l:") + id;
            bool ok;
            FMOD.Sound sound = GetSound(path, key, out ok);
            if (!ok) yield break;

            bool played = false;
            uint ms = 0;
            try
            {
                if (hasChannel) { currentChannel.stop(); hasChannel = false; }
                FMOD.Channel ch;
                if (RuntimeManager.CoreSystem.playSound(sound, group, false, out ch) == FMOD.RESULT.OK)
                {
                    ch.setVolume(0.75f);
                    currentSound = sound;
                    currentChannel = ch;
                    hasSound = true;
                    hasChannel = true;
                    currentSoundKey = key;
                    sound.getLength(out ms, FMOD.TIMEUNIT.MS);
                    played = true;
                }
            }
            catch { }
            if (!played) yield break;

            float until = Time.unscaledTime + ms / 1000f + 0.25f;
            while (hasChannel && Time.unscaledTime < until) yield return null;
            hasChannel = false;
        }

        // ---------------- 触发 ----------------
    }
}
