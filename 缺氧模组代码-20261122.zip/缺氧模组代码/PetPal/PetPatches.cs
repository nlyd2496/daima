using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using FMODUnity;
using HarmonyLib;
using Klei.AI;
using KMod;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace PetPal
{
    public static class PetPatches
    {
        public static void Apply(Harmony harmony)
        {
            try
            {
                MethodInfo target = AccessTools.Method(typeof(Messenger), "QueueMessage", new[] { typeof(Message) }, null);
                if (target != null)
                    harmony.Patch(target, prefix: new HarmonyMethod(typeof(PetPatches), nameof(OnMessage)));

                MethodInfo hover = AccessTools.Method(typeof(SelectToolHoverTextCard), "UpdateHoverElements");
                if (hover != null)
                    harmony.Patch(hover, finalizer: new HarmonyMethod(typeof(PetPatches), nameof(HoverFinalizer)));

                MethodInfo statusName = AccessTools.Method(typeof(StatusItem), "GetName", new[] { typeof(object) });
                if (statusName != null)
                    harmony.Patch(statusName, finalizer: new HarmonyMethod(typeof(PetPatches), nameof(StatusNameFinalizer)));
            }
            catch (Exception e) { Debug.LogWarning("[PetPal] patch fail: " + e.Message); }
        }

        public static Exception HoverFinalizer(Exception __exception) { return null; }

        public static Exception StatusNameFinalizer(Exception __exception) { return null; }

        public static void OnMessage(Message message)
        {
            if (message == null) return;
            PetHost host = PetHost.Instance;
            if (host == null || !host.CanReact) return;
            host.OnGameMessage(message.GetType().Name);
        }
    }
}
