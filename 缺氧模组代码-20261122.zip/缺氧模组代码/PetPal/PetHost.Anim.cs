using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using FMODUnity;
using HarmonyLib;
using Klei.AI;
using KMod;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace PetPal
{
    public partial class PetHost : MonoBehaviour
    {
        private static int SheetSlot(string e)
        {
            switch (e)
            {
                case "idle": return 0;
                case "happy": return 1;
                case "sad": return 2;
                case "worried": return 3;
                case "angry": return 4;
                case "surprised": return 5;
                case "sick": return 6;
                case "love": return 7;
                case "dizzy": return 8;
                case "walk": return 9;
                case "jump": return 10;
                case "roll": return 11;
                case "teleport": return 12;
                case "drag": return 13;
                case "laugh": return 14;
                case "lie": return 11;
                case "cry": return 2;
                case "stressed": return 4;
                case "scared": return 5;
                case "curious": return 3;
                case "thinking": return 0;
                case "sleepy": return 2;
                case "sleep": return 0;
                case "cold": return 2;
                case "hot": return 4;
                case "hungry": return 2;
                case "determined": return 1;
                default: return 0;
            }
        }

        private static int SheetFps(string e)
        {
            switch (e)
            {
                case "idle": return 3;
                case "sleep":
                case "sleepy": return 2;
                case "lie": return 2;
                case "drag": return 4;
                default: return 8;
            }
        }

        private static readonly int[] PatIdle = { 0, 1, 1, 0 };
        private static readonly int[] PatSleep = { 2, 3, 3, 2 };
        private static readonly int[] PatLie = { 1, 2, 2, 1 };
        private static readonly int[] PatNormal = { 0, 1, 2, 3 };

        private static int[] SheetPattern(string e)
        {
            if (e == "idle") return PatIdle;
            if (e == "sleep" || e == "sleepy") return PatSleep;
            if (e == "lie") return PatLie;
            return PatNormal;
        }

        public bool CanReact { get { return inGame && petEnabled; } }

        private void UpdatePerformance()
        {
            if (Time.unscaledTime < nextPerfCheck) return;
            nextPerfCheck = Time.unscaledTime + 0.2f;
            float dt = Time.unscaledDeltaTime;
            if (dt > 0.0001f) fpsSmooth = Mathf.Lerp(fpsSmooth, 1f / dt, 0.2f);
            if (perfOverride > 0) { perfTier = perfOverride; return; }

            int target = perfTier;
            if (fpsSmooth >= 55f) target = 100;
            else if (fpsSmooth >= 30f) target = 75;
            else if (fpsSmooth >= 15f) target = 50;
            else target = 25;

            if (target != perfTier)
            {
                if (Mathf.Approximately(tierSince, 0f)) tierSince = Time.unscaledTime;
                else if (Time.unscaledTime - tierSince > 3f)
                {
                    perfTier = target;
                    tierSince = 0f;
                    Debug.Log("[PetPal] 性能档位 -> " + perfTier);
                }
            }
            else tierSince = 0f;
        }

        private bool EffectsAllowed { get { return perfTier > 25; } }
        private bool VoiceAllowed { get { return perfTier > 25 && voiceEnabled; } }
        private bool BubbleAllowed { get { return perfTier > 25 && bubbleEnabled; } }

        private void ApplyVisual(Vector2 pos, float scale, float rot)
        {
            if (pos != lastPos) { lastPos = pos; visual.anchoredPosition = pos; }
            if (Mathf.Abs(scale - lastScale.x) > 0.0005f)
            {
                lastScale = new Vector3(scale, scale, 1f);
                visual.localScale = lastScale;
            }
            if (Mathf.Abs(rot - lastRot) > 0.01f)
            {
                lastRot = rot;
                visual.localRotation = Quaternion.Euler(0f, 0f, rot);
            }
        }

        private void Animate()
        {
            if (visual == null) return;
            int slot = SheetSlot(expr);
            if (sheetSprites != null && slot >= 0 && sheetSprites[slot * 4] != null)
            {
                float scale = 1f;
                if (perfTier <= 25) scale = 0.5f;
                else if (perfTier <= 50) scale = 0.75f;
                int fps = Mathf.Max(2, Mathf.RoundToInt(SheetFps(expr) * scale));
                int step = (int)((Time.unscaledTime - exprStart) * fps);
                int[] pattern = SheetPattern(expr);
                int frame = pattern[step & 3];
                int idx = slot * 4 + frame;
                if (idx != lastSpriteIndex)
                {
                    lastSpriteIndex = idx;
                    Sprite sp = sheetSprites[idx];
                    if (sp != null) image.sprite = sp;
                }
                ApplyVisual(Vector2.zero, 1f, 0f);
                image.color = Color.white;
                if (effectText != null) effectText.text = "";
                if (expr != "idle" && expr != "walk" && expr != "jump" && expr != "roll" &&
                    expr != "teleport" && expr != "lie" && Time.unscaledTime - exprStart > 2.5f) expr = "idle";
                return;
            }

            float t = Time.unscaledTime;
            float bob = 0f, shake = 0f, s2 = 1f, rot = 0f;
            Color tint = Color.white;
            switch (expr)
            {
                case "happy": bob = Mathf.Abs(Mathf.Sin(t * 6f)) * 12f; s2 = 1.05f; break;
                case "love": s2 = 1.04f + Mathf.Sin(t * 4f) * 0.03f; break;
                case "sad": s2 = 0.97f; tint = new Color(0.78f, 0.82f, 0.92f); break;
                case "angry": shake = Mathf.Sin(t * 42f) * 4f; break;
                default: bob = Mathf.Sin(t * 2f) * 4f; break;
            }
            if (expr != "idle" && Time.unscaledTime - exprStart > 2.5f) expr = "idle";
            ApplyVisual(new Vector2(shake, bob), s2, rot);
            image.color = tint;
        }

        private void UpdateStates()
        {
            if (lying) return;

            if (floating)
            {
                root.anchoredPosition = Vector2.MoveTowards(root.anchoredPosition, floatTo, 420f * Time.unscaledDeltaTime);
                if ((floatTo - root.anchoredPosition).sqrMagnitude <= 9f)
                {
                    floating = false;
                    suppressLowVoice = false;
                    floatLingerUntil = Time.unscaledTime + 5f;
                    nextMoveAt = floatLingerUntil;
                    nextLingerAction = 0f;
                }
                if (bubbleRect != null && bubbleRect.gameObject.activeSelf) PositionBubble();
                return;
            }

            if (Time.unscaledTime < floatLingerUntil)
            {
                if (Time.unscaledTime >= nextLingerAction)
                {
                    nextLingerAction = Time.unscaledTime + 1.5f;
                    string[] pool = { "happy", "love", "curious", "dizzy" };
                    SetExpr(pool[UnityEngine.Random.Range(0, pool.Length)]);
                }
                return;
            }

            if (gameTime - lastInputGameTime > 6000f) BeginLie();
        }

        private bool TryBeginFloat(KSelectable sel)
        {
            if (floatedThisCycle || lying || floating) return false;
            Camera cam = Camera.main;
            if (cam == null || canvas == null) return false;
            Vector3 sp;
            try { sp = cam.WorldToScreenPoint(sel.transform.position); } catch { return false; }
            if (sp.z <= 0f || sp.x < 0f || sp.y < 0f || sp.x > Screen.width || sp.y > Screen.height) return false;

            var canvasRt = canvas.transform as RectTransform;
            if (canvasRt == null) return false;
            Vector2 local;
            if (!RectTransformUtility.ScreenPointToLocalPointInRectangle(canvasRt, sp, null, out local)) return false;

            Vector2 half = canvasRt.rect.size * 0.5f;
            local.x = Mathf.Clamp(local.x + 70f, -half.x + 120f, half.x - 120f);
            local.y = Mathf.Clamp(local.y + 40f, -half.y + 120f, half.y - 120f);

            floating = true;
            suppressLowVoice = true;
            floatedThisCycle = true;
            floatTo = local;
            SetExpr("roll");

            if (VoicePack.TryPickByPrefab(sel.name, out string id, out string text) ||
                VoicePack.TryPickByName(SafeProper(sel), out id, out text))
            {
                Enqueue(id, text, false, PRIO_INTERACT);
            }
            return true;
        }

        private void BeginLie()
        {
            lying = true;
            SetExpr("lie");
        }

        private void UpdateMovement()
        {
            if (root == null || lying || floating || Time.unscaledTime < floatLingerUntil) return;
            float now = Time.unscaledTime;
            if (moveMode == "walk" && now >= nextMoveAt)
            {
                float w = 860f, h = 450f;
                if (canvas != null)
                {
                    var rt = canvas.transform as RectTransform;
                    if (rt != null && rt.rect.width > 200f)
                    {
                        w = rt.rect.width * 0.5f - 140f;
                        h = rt.rect.height * 0.5f - 140f;
                    }
                }
                wanderTarget = new Vector2(UnityEngine.Random.Range(-w, w), UnityEngine.Random.Range(-h, h));
                nextMoveAt = now + UnityEngine.Random.Range(5f, 9f);
                ChooseMode();
            }

            Vector2 pos = root.anchoredPosition;
            switch (moveMode)
            {
                case "jump":
                {
                    float k = Mathf.Clamp01((now - moveStart) / Mathf.Max(0.01f, moveEnd - moveStart));
                    root.anchoredPosition = Vector2.Lerp(moveFrom, moveTo, k) + new Vector2(0f, Mathf.Sin(k * Mathf.PI) * 90f);
                    if (k >= 1f) EndMode();
                    break;
                }
                case "roll":
                {
                    Vector2 next = Vector2.MoveTowards(pos, wanderTarget, 300f * Time.unscaledDeltaTime);
                    root.anchoredPosition = next;
                    if ((wanderTarget - next).sqrMagnitude <= 20f) EndMode();
                    break;
                }
                case "teleport":
                {
                    float k = Mathf.Clamp01((now - moveStart) / 0.35f);
                    if (k >= 1f) EndMode();
                    break;
                }
                default:
                {
                    if ((wanderTarget - pos).sqrMagnitude > 30f)
                    {
                        Vector2 next = Vector2.MoveTowards(pos, wanderTarget, 130f * Time.unscaledDeltaTime);
                        root.anchoredPosition = next;
                        if (expr == "idle") SetExpr("walk");
                    }
                    else if (expr == "walk") SetExpr("idle");
                    break;
                }
            }
            if (bubbleRect != null && bubbleRect.gameObject.activeSelf) PositionBubble();
        }

        private void ChooseMode()
        {
            float r = UnityEngine.Random.value;
            if (r < 0.75f) { moveMode = "walk"; return; }
            if (r < 0.86f)
            {
                moveMode = "jump"; moveStart = Time.unscaledTime; moveEnd = moveStart + 0.55f;
                moveFrom = root.anchoredPosition; moveTo = wanderTarget;
                SetExpr("jump");
            }
            else if (r < 0.94f)
            {
                moveMode = "roll";
                SetExpr("roll");
            }
            else
            {
                moveMode = "teleport"; moveStart = Time.unscaledTime;
                root.anchoredPosition = wanderTarget;
                SetExpr("teleport");
            }
        }

        private void EndMode()
        {
            moveMode = "walk";
            visual.localRotation = Quaternion.identity;
            SetExpr("idle");
            nextMoveAt = Time.unscaledTime + UnityEngine.Random.Range(4f, 8f);
        }

        private void SetExpr(string e)
        {
            expr = e;
            exprStart = Time.unscaledTime;
        }

        // ---------------- 事件 ----------------

        private void LoadNebula(string path)
        {
            try
            {
                if (!File.Exists(path)) return;
                Texture2D tex = LoadTexture(path);
                if (tex == null) return;
                int cell = tex.height;
                int n = tex.width / cell;
                nebulaSprites = new Sprite[n];
                for (int i = 0; i < n; i++)
                    nebulaSprites[i] = Sprite.Create(tex, new Rect(i * cell, 0, cell, cell), new Vector2(0.5f, 0.5f), 100f);
                Debug.Log("[PetPal] 星云帧数：" + n);
            }
            catch (Exception e) { Debug.LogWarning("[PetPal] 星云加载失败：" + e.Message); }
        }

        private void SpawnFlower(bool gold = false, bool force = false)
        {
            if ((!EffectsAllowed && !force) || canvas == null) return;
            StartCoroutine(NebulaFx(gold));
        }

        private IEnumerator NebulaFx(bool gold)
        {
            if (nebulaSprites == null || nebulaSprites.Length == 0 || root == null) yield break;
            var go = new GameObject("PetNebula", typeof(RectTransform), typeof(Image));
            go.transform.SetParent(canvas.transform, false);
            var rt = (RectTransform)go.transform;
            rt.sizeDelta = new Vector2(200f, 200f);
            rt.anchoredPosition = root.anchoredPosition + new Vector2(0f, 120f);
            var img = go.GetComponent<Image>();
            img.sprite = nebulaSprites[0];
            img.raycastTarget = false;
            Color tint = gold ? new Color(1f, 0.85f, 0.55f) : Color.white;
            float t = 0f, dur = 1.1f;
            int n = nebulaSprites.Length;
            float frameDur = dur / n;
            int frame = -1;
            while (t < dur)
            {
                t += Time.unscaledDeltaTime;
                int f = Mathf.Min(n - 1, (int)(t / frameDur));
                if (f != frame) { frame = f; img.sprite = nebulaSprites[f]; }
                img.color = tint;
                rt.localScale = Vector3.one * (0.8f + 0.25f * Mathf.Clamp01(t / dur));
                yield return null;
            }
            UnityEngine.Object.Destroy(go);
        }
    }
}
