using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using FMODUnity;
using HarmonyLib;
using Klei.AI;
using KMod;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace PetPal
{
    public partial class PetHost : MonoBehaviour
    {
        public static PetHost Instance;

        private const string PrefX = "PetPal.X";
        private const string PrefY = "PetPal.Y";

        private string modPath;
        private string voiceDir;
        private Canvas canvas;
        private RectTransform root;
        private RectTransform visual;
        private Image image;
        private Sprite[] sheetSprites;
        private const int SheetCell = 128;
        private int lastSpriteIndex = -1;
        private Vector2 lastPos;
        private Vector3 lastScale = Vector3.one;
        private float lastRot;
        private GameClock gameClock;
        private SpeedControlScreen speedScreen;
        private float nextCycleCheck;
        private bool pausedCache;
        private Text effectText;
        private RectTransform bubbleRect;
        private Text bubbleText;
        private float bubbleHideAt;
        private string lastBubbleText;
        private float lastBubbleWidth;
        private float gameTime;
        private int lastCycle = -1;
        private bool inGame;
        private bool entered;

        private bool voiceEnabled = true;
        private bool bubbleEnabled = true;
        private bool petEnabled = true;
        private int perfTier = 100;
        private int perfOverride;
        private bool perfDebug;
        private float fpsSmooth = 60f;
        private float tierSince;

        private float lastInputGameTime;
        private Vector3 lastMousePos;
        private bool lying;
        private bool milestoneCycle;
        private float nextRandomFxAt = float.MaxValue;

        private Vector2 wanderTarget;
        private float nextMoveAt;
        private string moveMode = "walk";
        private float moveStart, moveEnd;
        private Vector2 moveFrom, moveTo;

        private float nextChatterAt;
        private float nextUrgentAt;
        private float nextMsgAt;
        private float nextToolAt;
        private float nextSelectAt;
        private float nextSelectCheck;
        private string expr = "idle";
        private float exprStart;

        private int rapidCount;
        private float lastClickAt = -10f;
        private KSelectable lastSelected;

        private FMOD.ChannelGroup group;
        private bool fmodReady;
        private FMOD.Sound currentSound;
        private FMOD.Channel currentChannel;
        private bool hasSound, hasChannel;
        private string currentSoundKey;
        private bool urgentActive;
        private readonly Dictionary<string, FMOD.Sound> soundCache = new Dictionary<string, FMOD.Sound>();
        private readonly List<string> soundOrder = new List<string>();

        private GameObject menuRoot;
        private Text menuVoice;
        private Text menuBubble;
        private Text menuPet;
        private GameObject menuButton;
        private GameObject rowVoice;
        private GameObject rowBubble;
        private GameObject rowPet;
        private GameObject rowDebug;
        private float menuHideAt;
        private GameObject debugRoot;
        private readonly List<GameObject> debugPerfRows = new List<GameObject>();
        private bool floatedThisCycle;
        private bool floating;
        private bool suppressLowVoice;
        private Vector2 floatTo;
        private float floatLingerUntil;
        private float nextLingerAction;

        private string saveKey = "default";
        private readonly HashSet<int> msDone = new HashSet<int>();

        private static readonly int[] Milestones = { 10, 100, 500, 1000, 2000, 3000, 5000, 10000, 20000, 30000, 50000 };

        private static readonly FieldInfo SelectField = typeof(SelectTool).GetField(
            "selected", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);

        private static readonly Dictionary<string, float> lastIdAt = new Dictionary<string, float>();
        private static readonly Dictionary<string, float> lastTagAt = new Dictionary<string, float>();

        private class PendingLine
        {
            public string Id;
            public string Text;
            public bool Connector;
            public int Prio;
        }

        private const int PRIO_CHATTER = 0;
        private const int PRIO_SELECT = 1;
        private const int PRIO_INTERACT = 2;
        private const int PRIO_URGENT = 3;

        private readonly List<PendingLine> pending = new List<PendingLine>();
        private Coroutine voiceWorker;
        private int currentPrio;

        private static Sprite petalSprite;
        private Sprite[] nebulaSprites;
        private PetView petView;
        private static Font cachedFont;
        private float nextUrgentCheck;
        private float nextPerfCheck;
        private float nextNameSpeakAt;

        public static void Create(string modDir)
        {
            var go = new GameObject("PetPalHost");
            DontDestroyOnLoad(go);
            go.AddComponent<PetHost>().Init(modDir);
        }

        private void Init(string modDir)
        {
            Instance = this;
            modPath = modDir;
            voiceDir = modDir == null ? null : Path.Combine(modDir, "pet", "voice");
            try { perfDebug = modDir != null && File.Exists(Path.Combine(modDir, "pet", "perf_debug.flag")); } catch { }
            nextChatterAt = Time.unscaledTime + 12f;
            nextUrgentAt = Time.unscaledTime + 10f;
            VoicePack.Load(modDir);
            InitFmod();
            Debug.Log("[PetPal] 初始化完成");
        }

        private void InitFmod()
        {
            try
            {
                if (!RuntimeManager.IsInitialized) return;
                var studio = RuntimeManager.StudioSystem;
                FMOD.Studio.Bus bus;
                studio.getBus("bus:/", out bus);
                if (bus.isValid()) bus.getChannelGroup(out group);
                fmodReady = true;
            }
            catch (Exception e) { Debug.LogWarning("[PetPal] FMOD: " + e.Message); }
        }

        private void Update()
        {
            bool nowInGame = Game.Instance != null;
            if (nowInGame != inGame)
            {
                inGame = nowInGame;
                if (inGame)
                {
                    entered = false;
                    ResolveSaveKey();
                    lastCycle = -1;
                    nextMoveAt = 0f;
                }
                else if (canvas != null)
                {
                    Destroy(canvas.gameObject);
                    canvas = null;
                    menuButton = null;
                    menuRoot = null;
                    debugRoot = null;
                    bubbleRect = null;
                    bubbleText = null;
                    root = null;
                    visual = null;
                    image = null;
                    effectText = null;
                    petEnabled = true;
                }
            }
            if (!inGame) return;

            if (canvas == null) BuildUi();
            if (canvas == null) return;
            if (!petEnabled) return;

            UpdateInputState();
            UpdatePerformance();
            Animate();
            UpdateStates();
            UpdateMovement();
            UpdateEvents();
            UpdateUrgent();
            UpdateChatter();
            UpdateTools();
            UpdateSelection();

            if (petView != null && petView.ConsumeLongPress()) OnLongPress();

            if (bubbleRect != null && bubbleRect.gameObject.activeSelf && Time.unscaledTime > bubbleHideAt)
                bubbleRect.gameObject.SetActive(false);

            if (menuRoot != null && menuRoot.activeSelf && Time.unscaledTime > menuHideAt)
                menuRoot.SetActive(false);

            if (lying) return;
        }

        private void UpdateInputState()
        {
            bool any = Input.anyKey || Input.GetMouseButton(0) || Input.GetMouseButton(1) || Input.GetMouseButton(2);
            Vector3 mp = Input.mousePosition;
            if ((mp - lastMousePos).sqrMagnitude > 1f)
            {
                any = true;
                lastMousePos = mp;
            }
            if (any) lastInputGameTime = gameTime;
        }

        private static Font GetFont()
        {
            if (cachedFont != null) return cachedFont;
            try { cachedFont = Font.CreateDynamicFontFromOSFont(new[] { "Microsoft YaHei", "SimHei", "Arial" }, 17); } catch { }
            if (cachedFont == null)
            {
                try { cachedFont = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf"); } catch { }
            }
            return cachedFont;
        }

        private void OnDestroy()
        {
            try
            {
                if (hasChannel) currentChannel.stop();
                foreach (var kv in soundCache) kv.Value.release();
                soundCache.Clear();
                soundOrder.Clear();
            }
            catch { }
            if (Instance == this) Instance = null;
        }
    }
}
