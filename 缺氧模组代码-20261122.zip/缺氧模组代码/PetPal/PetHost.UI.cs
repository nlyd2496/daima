using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using FMODUnity;
using HarmonyLib;
using Klei.AI;
using KMod;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace PetPal
{
    public partial class PetHost : MonoBehaviour
    {
        private void BuildUi()
        {
            var canvasGo = new GameObject("PetPalCanvas", typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
            canvasGo.transform.SetParent(transform, false);
            canvas = canvasGo.GetComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            canvas.sortingOrder = 90;
            var scaler = canvasGo.GetComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1920f, 1080f);

            var go = new GameObject("Pet", typeof(RectTransform));
            go.transform.SetParent(canvasGo.transform, false);
            root = (RectTransform)go.transform;
            root.sizeDelta = new Vector2(220f, 220f);
            root.anchorMin = root.anchorMax = new Vector2(0.5f, 0.5f);
            root.pivot = new Vector2(0.5f, 0.5f);
            root.anchoredPosition = new Vector2(PlayerPrefs.GetFloat(PrefX, 600f), PlayerPrefs.GetFloat(PrefY, -260f));

            var vis = new GameObject("Visual", typeof(RectTransform), typeof(Image));
            vis.transform.SetParent(go.transform, false);
            visual = (RectTransform)vis.transform;
            visual.anchorMin = Vector2.zero;
            visual.anchorMax = Vector2.one;
            visual.offsetMin = Vector2.zero;
            visual.offsetMax = Vector2.zero;
            image = vis.GetComponent<Image>();
            image.raycastTarget = true;
            image.preserveAspect = true;

            Sprite sprite = LoadSprite(Path.Combine(modPath, "pet", "art", "pet.png"));
            if (sprite != null) image.sprite = sprite;
            LoadSheet(Path.Combine(modPath, "pet", "art", "sheet.png"));
            LoadNebula(Path.Combine(modPath, "pet", "art", "nebula.png"));
            if (sheetSprites != null && sheetSprites[0] != null) image.sprite = sheetSprites[0];

            var eff = new GameObject("Effect", typeof(RectTransform), typeof(Text));
            eff.transform.SetParent(vis.transform, false);
            var ert = (RectTransform)eff.transform;
            ert.anchorMin = ert.anchorMax = new Vector2(1f, 1f);
            ert.pivot = new Vector2(0.5f, 0.5f);
            ert.anchoredPosition = new Vector2(-18f, -18f);
            ert.sizeDelta = new Vector2(80f, 80f);
            effectText = eff.GetComponent<Text>();
            effectText.font = GetFont();
            effectText.fontSize = 40;
            effectText.alignment = TextAnchor.MiddleCenter;
            effectText.raycastTarget = false;
            effectText.text = "";

            var b = new GameObject("Bubble", typeof(RectTransform));
            b.transform.SetParent(canvasGo.transform, false);
            bubbleRect = (RectTransform)b.transform;
            bubbleRect.sizeDelta = new Vector2(200f, 40f);
            bubbleRect.anchorMin = bubbleRect.anchorMax = new Vector2(0.5f, 0.5f);
            bubbleRect.pivot = new Vector2(0.5f, 0f);

            var t = new GameObject("Text", typeof(RectTransform), typeof(Text));
            t.transform.SetParent(b.transform, false);
            var trt = (RectTransform)t.transform;
            trt.anchorMin = Vector2.zero;
            trt.anchorMax = Vector2.one;
            trt.offsetMin = new Vector2(10f, 4f);
            trt.offsetMax = new Vector2(-10f, -4f);
            bubbleText = t.GetComponent<Text>();
            bubbleText.font = GetFont();
            bubbleText.fontSize = 18;
            bubbleText.color = new Color(0.35f, 0.68f, 1f);
            bubbleText.alignment = TextAnchor.MiddleCenter;
            bubbleText.horizontalOverflow = HorizontalWrapMode.Wrap;
            bubbleText.verticalOverflow = VerticalWrapMode.Truncate;
            bubbleText.raycastTarget = false;
            var oln = t.AddComponent<Outline>();
            oln.effectColor = new Color(0.05f, 0.12f, 0.25f, 0.85f);
            oln.effectDistance = new Vector2(1.4f, -1.4f);
            b.SetActive(false);

            BuildControlUi(canvasGo);

            // 预热字体与气泡布局，避免第一次弹气泡时卡顿
            try
            {
                bubbleText.text = "预热";
                bubbleRect.gameObject.SetActive(true);
                float w = bubbleText.preferredWidth;
                bubbleRect.sizeDelta = new Vector2(Mathf.Clamp(w + 24f, 80f, 360f), bubbleText.preferredHeight + 12f);
                bubbleRect.gameObject.SetActive(false);
            }
            catch { }

            petView = go.AddComponent<PetView>();
            petView.host = this;
        }

        private void BuildControlUi(GameObject canvasGo)
        {
            RectTransform row = GetSecondaryRow();
            menuButton = new GameObject("PetMenuButton", typeof(RectTransform), typeof(Image), typeof(Button));
            menuButton.transform.SetParent(row != null ? (Transform)row : canvasGo.transform, false);
            var brt = (RectTransform)menuButton.transform;
            if (row != null)
            {
                brt.anchorMin = brt.anchorMax = new Vector2(0f, 0.5f);
                brt.pivot = new Vector2(0f, 0.5f);
                brt.anchoredPosition = Vector2.zero;
                brt.sizeDelta = new Vector2(30f, 30f);
                var le = menuButton.AddComponent<LayoutElement>();
                le.preferredWidth = 30f;
                le.preferredHeight = 30f;
            }
            else
            {
                brt.anchorMin = brt.anchorMax = new Vector2(0f, 1f);
                brt.pivot = new Vector2(0f, 1f);
                brt.anchoredPosition = new Vector2(16f, -16f);
                brt.sizeDelta = new Vector2(44f, 44f);
            }
            var bimg = menuButton.GetComponent<Image>();
            bimg.sprite = null;
            bimg.color = Color.clear;
            var icon = new GameObject("Icon", typeof(RectTransform), typeof(Image));
            icon.transform.SetParent(menuButton.transform, false);
            var irt = (RectTransform)icon.transform;
            irt.anchorMin = irt.anchorMax = new Vector2(0.5f, 0.5f);
            irt.pivot = new Vector2(0.5f, 0.5f);
            irt.sizeDelta = row != null ? new Vector2(28f, 28f) : new Vector2(38f, 38f);
            var iimg = icon.GetComponent<Image>();
            iimg.raycastTarget = false;
            iimg.preserveAspect = true;
            if (sheetSprites != null && sheetSprites[0] != null) iimg.sprite = sheetSprites[0];
            var btn = menuButton.GetComponent<Button>();
            btn.onClick.AddListener(() =>
            {
                if (!petEnabled) { RestorePet(); return; }
                if (menuRoot.activeSelf) menuRoot.SetActive(false);
                else ShowMenu();
            });

            menuRoot = new GameObject("PetMenu", typeof(RectTransform), typeof(Image));
            menuRoot.transform.SetParent(canvasGo.transform, false);
            var mrt = (RectTransform)menuRoot.transform;
            mrt.anchorMin = mrt.anchorMax = new Vector2(1f, 1f);
            mrt.pivot = new Vector2(1f, 1f);
            mrt.anchoredPosition = new Vector2(-250f, -46f);
            mrt.sizeDelta = new Vector2(170f, 16f + (perfDebug ? 4 : 3) * 34f);
            var mimg = menuRoot.GetComponent<Image>();
            mimg.color = new Color(0.10f, 0.12f, 0.16f, 0.92f);
            menuRoot.SetActive(false);

            rowVoice = MakeRow(mrt, 0, "禁用语音", new System.Action(() => ToggleVoice()), out menuVoice);
            rowBubble = MakeRow(mrt, 1, "禁用气泡", new System.Action(() => ToggleBubble()), out menuBubble);
            rowPet = MakeRow(mrt, 2, "禁用宠物", new System.Action(() => TogglePet()), out menuPet);
            if (perfDebug) rowDebug = MakeRow(mrt, 3, "调试", new System.Action(() => OpenDebug()), out Text dt);

            if (perfDebug) BuildDebugUi(canvasGo);

            PositionControl();
        }

        private GameObject MakeRow(RectTransform parent, int index, string label, System.Action onClick, out Text text)
        {
            var go = new GameObject("Row" + index, typeof(RectTransform), typeof(Image), typeof(Button));
            go.transform.SetParent(parent, false);
            var rt = (RectTransform)go.transform;
            rt.anchorMin = new Vector2(0f, 1f);
            rt.anchorMax = new Vector2(1f, 1f);
            rt.pivot = new Vector2(0.5f, 1f);
            rt.anchoredPosition = new Vector2(0f, -8f - index * 34f);
            rt.sizeDelta = new Vector2(-12f, 28f);
            var img = go.GetComponent<Image>();
            img.color = new Color(0.2f, 0.24f, 0.3f, 0.95f);
            var btn = go.GetComponent<Button>();
            btn.onClick.AddListener(new UnityEngine.Events.UnityAction(() => { onClick(); menuHideAt = Time.unscaledTime + 3f; }));
            var t = new GameObject("Text", typeof(RectTransform), typeof(Text));
            t.transform.SetParent(go.transform, false);
            var trt = (RectTransform)t.transform;
            trt.anchorMin = Vector2.zero; trt.anchorMax = Vector2.one;
            trt.offsetMin = new Vector2(8f, 0f); trt.offsetMax = new Vector2(-8f, 0f);
            text = t.GetComponent<Text>();
            text.font = GetFont();
            text.fontSize = 15;
            text.color = new Color(0.92f, 0.92f, 0.92f);
            text.alignment = TextAnchor.MiddleLeft;
            text.text = label;
            return go;
        }

        private void BuildDebugUi(GameObject canvasGo)
        {
            int rows = 4 + 1 + Milestones.Length + 1;
            debugRoot = new GameObject("PetDebug", typeof(RectTransform), typeof(Image));
            debugRoot.transform.SetParent(canvasGo.transform, false);
            var drt = (RectTransform)debugRoot.transform;
            drt.anchorMin = drt.anchorMax = new Vector2(0.5f, 0.5f);
            drt.pivot = new Vector2(0.5f, 0.5f);
            drt.anchoredPosition = Vector2.zero;
            drt.sizeDelta = new Vector2(260f, 16f + rows * 30f);
            var dimg = debugRoot.GetComponent<Image>();
            dimg.color = new Color(0.08f, 0.09f, 0.12f, 0.96f);
            debugRoot.SetActive(false);

            string[] perf = { "性能 25%", "性能 50%", "性能 75%", "性能 100%" };
            int[] vals = { 25, 50, 75, 100 };
            for (int i = 0; i < 4; i++)
            {
                int v = vals[i];
                int idx = i;
                var go = MakeRow(drt, idx, perf[i], new System.Action(() => { perfOverride = v; perfTier = v; UpdateDebugHighlight(); }), out Text tt);
                debugPerfRows.Add(go);
            }
            MakeRow(drt, 4, "播放星云花环", new System.Action(() => { SpawnFlower(false, true); }), out Text t2);
            for (int i = 0; i < Milestones.Length; i++)
            {
                int n = Milestones[i];
                MakeRow(drt, 5 + i, "里程碑 " + n, new System.Action(() => PlayMilestone(n)), out Text t3);
            }
            MakeRow(drt, 5 + Milestones.Length, "关闭", new System.Action(() => { debugRoot.SetActive(false); }), out Text t4);
        }

        private void OpenDebug()
        {
            if (debugRoot != null) debugRoot.SetActive(true);
            UpdateDebugHighlight();
        }

        private void UpdateDebugHighlight()
        {
            for (int i = 0; i < debugPerfRows.Count; i++)
            {
                var img = debugPerfRows[i].GetComponent<Image>();
                bool on = (i == 0 && perfTier <= 25) || (i == 1 && perfTier > 25 && perfTier <= 50) ||
                          (i == 2 && perfTier > 50 && perfTier <= 75) || (i == 3 && perfTier > 75);
                img.color = on ? new Color(0.55f, 0.38f, 0.12f, 0.98f) : new Color(0.2f, 0.24f, 0.3f, 0.95f);
            }
        }

        private void PlayMilestone(int n)
        {
            string tag = "ms_" + n;
            if (VoicePack.TryPick(tag, out string id, out string text))
                Enqueue(id, text, false, PRIO_URGENT);
            SpawnFlower(true, true);
        }

        private void ToggleVoice()
        {
            voiceEnabled = !voiceEnabled;
            UpdateMenuHighlight();
        }

        private void ToggleBubble()
        {
            bubbleEnabled = !bubbleEnabled;
            if (!bubbleEnabled && bubbleRect != null) bubbleRect.gameObject.SetActive(false);
            UpdateMenuHighlight();
        }

        private void TogglePet()
        {
            petEnabled = false;
            floating = false;
            lying = false;
            StopVoice();
            if (bubbleRect != null) bubbleRect.gameObject.SetActive(false);
            if (root != null) root.gameObject.SetActive(false);
            HideControl();
        }

        private void RestorePet()
        {
            petEnabled = true;
            if (root != null) root.gameObject.SetActive(true);
            PositionControl();
        }

        private void PositionControl()
        {
            if (canvas == null || menuButton == null || menuRoot == null) return;
            var canvasRt = canvas.transform as RectTransform;
            if (canvasRt == null) return;
            Vector3 sp = RectTransformUtility.WorldToScreenPoint(null, menuButton.transform.position);
            Vector2 local;
            if (!RectTransformUtility.ScreenPointToLocalPointInRectangle(canvasRt, sp, null, out local)) return;
            var mrt = menuRoot.transform as RectTransform;
            mrt.anchorMin = mrt.anchorMax = new Vector2(0.5f, 0.5f);
            mrt.pivot = new Vector2(0f, 1f);
            mrt.anchoredPosition = local + new Vector2(0f, -26f);
        }

        private static RectTransform GetSecondaryRow()
        {
            try
            {
                var screen = TopLeftControlScreen.Instance;
                if (screen == null) return null;
                FieldInfo field = typeof(TopLeftControlScreen).GetField("secondaryRow",
                    BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                var row = field != null ? field.GetValue(screen) as RectTransform : null;
                if (row == null || !row.gameObject.activeInHierarchy) return null;
                return row;
            }
            catch { return null; }
        }
        private void HideControl()
        {
            if (menuRoot != null) menuRoot.SetActive(false);
        }

        private void ShowMenu()
        {
            if (menuRoot == null) return;
            PositionControl();
            menuRoot.SetActive(true);
            menuHideAt = Time.unscaledTime + 3f;
            bool low = perfTier <= 25;
            if (rowVoice != null) rowVoice.SetActive(!low);
            if (rowBubble != null) rowBubble.SetActive(!low);
            UpdateMenuHighlight();
        }

        private void ShowControl()
        {
            if (menuButton == null) return;
            PositionControl();
            menuButton.SetActive(true);
            HideControl();
        }

        private void UpdateMenuHighlight()
        {
            if (rowVoice != null) rowVoice.GetComponent<Image>().color = !voiceEnabled ? new Color(0.55f, 0.38f, 0.12f, 0.98f) : new Color(0.2f, 0.24f, 0.3f, 0.95f);
            if (rowBubble != null) rowBubble.GetComponent<Image>().color = !bubbleEnabled ? new Color(0.55f, 0.38f, 0.12f, 0.98f) : new Color(0.2f, 0.24f, 0.3f, 0.95f);
            if (rowPet != null) rowPet.GetComponent<Image>().color = !petEnabled ? new Color(0.55f, 0.38f, 0.12f, 0.98f) : new Color(0.2f, 0.24f, 0.3f, 0.95f);
        }


        private static Sprite LoadSprite(string path)
        {
            try
            {
                Texture2D tex = LoadTexture(path);
                if (tex == null) return null;
                return Sprite.Create(tex, new Rect(0, 0, tex.width, tex.height), new Vector2(0.5f, 0.5f), 100f);
            }
            catch (Exception e)
            {
                Debug.LogWarning("[PetPal] 读取立绘失败：" + e.Message);
                return null;
            }
        }

        private static Texture2D LoadTexture(string path)
        {
            try
            {
                if (string.IsNullOrEmpty(path) || !File.Exists(path)) return null;
                var tex = new Texture2D(2, 2, TextureFormat.RGBA32, false);
                byte[] bytes = File.ReadAllBytes(path);
                bool loaded = false;
                try
                {
                    Type t = Type.GetType("UnityEngine.ImageConversion, UnityEngine.ImageConversionModule");
                    MethodInfo m = t == null ? null : t.GetMethod("LoadImage", new[] { typeof(Texture2D), typeof(byte[]) });
                    if (m != null)
                    {
                        m.Invoke(null, new object[] { tex, bytes });
                        loaded = true;
                    }
                }
                catch { }
                if (!loaded || tex.width <= 2) return null;
                tex.filterMode = FilterMode.Bilinear;
                return tex;
            }
            catch (Exception e)
            {
                Debug.LogWarning("[PetPal] 读取图片失败：" + e.Message);
                return null;
            }
        }

        private void LoadSheet(string path)
        {
            try
            {
                if (!File.Exists(path)) return;
                Texture2D tex = LoadTexture(path);
                if (tex == null) return;
                int cols = tex.width / SheetCell;
                int rows = tex.height / SheetCell;
                sheetSprites = new Sprite[16 * 4];
                for (int slot = 0; slot < 16; slot++)
                {
                    for (int f = 0; f < 4; f++)
                    {
                        int idx = slot * 4 + f;
                        int col = idx % cols;
                        int row = idx / cols;
                        if (row >= rows) continue;
                        float y = tex.height - (row + 1) * SheetCell;
                        sheetSprites[idx] = Sprite.Create(tex,
                            new Rect(col * SheetCell, y, SheetCell, SheetCell),
                            new Vector2(0.5f, 0.5f), 100f);
                    }
                }
                Debug.Log("[PetPal] 雪碧图：" + cols + "x" + rows);
                lastSpriteIndex = -1;
            }
            catch (Exception e)
            {
                Debug.LogWarning("[PetPal] 雪碧图失败：" + e.Message);
                sheetSprites = null;
            }
        }

        private void ShowBubble(string text)
        {
            if (!BubbleAllowed || bubbleText == null) return;
            bool changed = text != lastBubbleText;
            bubbleText.text = text;
            bubbleRect.gameObject.SetActive(true);
            if (changed)
            {
                lastBubbleText = text;
                float w = Mathf.Clamp(bubbleText.preferredWidth + 24f, 80f, 360f);
                lastBubbleWidth = w;
                bubbleRect.sizeDelta = new Vector2(w, bubbleText.preferredHeight + 12f);
            }
            bubbleHideAt = Time.unscaledTime + 3.5f;
            PositionBubble();
        }

        private void PositionBubble()
        {
            if (bubbleRect == null || root == null) return;
            bubbleRect.anchoredPosition = root.anchoredPosition + new Vector2(0f, 150f);
        }

        // ---------------- 特效 ----------------

        private static Sprite GetPetalSprite()
        {
            if (petalSprite != null) return petalSprite;
            int size = 64;
            var tex = new Texture2D(size, size, TextureFormat.RGBA32, false);
            var cols = new Color32[size * size];
            for (int y = 0; y < size; y++)
            {
                for (int x = 0; x < size; x++)
                {
                    float dx = (x - size / 2f) / (size * 0.42f);
                    float dy = (y - size / 2f) / (size * 0.22f);
                    float d = dx * dx + dy * dy;
                    float a = Mathf.Clamp01((1f - d) * 2.2f);
                    cols[y * size + x] = new Color32(255, 255, 255, (byte)(a * 255));
                }
            }
            tex.SetPixels32(cols);
            tex.Apply();
            petalSprite = Sprite.Create(tex, new Rect(0, 0, size, size), new Vector2(0.5f, 0.5f), 100f);
            return petalSprite;
        }
    }
}
