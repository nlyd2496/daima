using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using FMODUnity;
using HarmonyLib;
using Klei.AI;
using KMod;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace PetPal
{
    public class PetMod : UserMod2
    {
        public override void OnLoad(Harmony harmony)
        {
            base.OnLoad(harmony);
            PetHost.Create(ResolveModPath());
            PetPatches.Apply(harmony);
        }

        private string ResolveModPath()
        {
            try { if (!string.IsNullOrEmpty(path) && Directory.Exists(path)) return path; } catch { }
            try { if (mod != null && !string.IsNullOrEmpty(mod.ContentPath) && Directory.Exists(mod.ContentPath)) return mod.ContentPath; } catch { }
            try { return Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location); } catch { return null; }
        }
    }
}
