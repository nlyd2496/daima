using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using FMODUnity;
using HarmonyLib;
using Klei.AI;
using KMod;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace PetPal
{
    public static class VoicePack
    {
        private static readonly Dictionary<string, List<KeyValuePair<string, string>>> tags =
            new Dictionary<string, List<KeyValuePair<string, string>>>();
        private static readonly Dictionary<string, List<KeyValuePair<string, string>>> byName =
            new Dictionary<string, List<KeyValuePair<string, string>>>();
        private static readonly Dictionary<string, string> prefabNames = new Dictionary<string, string>();
        private static readonly Dictionary<string, List<KeyValuePair<string, string>>> prefabLines =
            new Dictionary<string, List<KeyValuePair<string, string>>>();
        private static readonly Dictionary<string, string> alias = new Dictionary<string, string>();
        private static readonly List<KeyValuePair<string, string>> connectors = new List<KeyValuePair<string, string>>();

        public static int Count
        {
            get
            {
                int n = 0;
                foreach (var v in tags.Values) n += v.Count;
                return n;
            }
        }

        public static int ConnectorCount { get { return connectors.Count; } }

        public static void Load(string modPath)
        {
            tags.Clear(); byName.Clear(); prefabNames.Clear(); prefabLines.Clear(); alias.Clear(); connectors.Clear();
            if (modPath == null) return;
            try
            {
                string dir = Path.Combine(modPath, "pet", "voice");
                string lines = Path.Combine(dir, "manifest_lines.tsv");
                if (File.Exists(lines))
                {
                    foreach (string raw in File.ReadAllLines(lines))
                    {
                        if (string.IsNullOrEmpty(raw)) continue;
                        string[] p = raw.Split('\t');
                        if (p.Length < 4) continue;
                        string tag = TagOf(p[1], p[2]);
                        if (tag != null) Add(tag, p[0], p[3]);
                        if (p[1] == "植物" || p[1] == "动物" || p[1] == "建筑") AddName(p[2], p[0], p[3]);
                    }
                }
                string conn = Path.Combine(dir, "manifest_connect.tsv");
                if (File.Exists(conn))
                {
                    foreach (string raw in File.ReadAllLines(conn))
                    {
                        if (string.IsNullOrEmpty(raw)) continue;
                        string[] p = raw.Split('\t');
                        if (p.Length < 3) continue;
                        connectors.Add(new KeyValuePair<string, string>(p[0], p[2]));
                    }
                }
                string names = Path.Combine(dir, "names.tsv");
                if (File.Exists(names))
                {
                    foreach (string raw in File.ReadAllLines(names))
                    {
                        if (string.IsNullOrEmpty(raw)) continue;
                        string[] p = raw.Split('\t');
                        if (p.Length < 2) continue;
                        prefabNames[Normalize(p[0])] = p[1].Trim();
                    }
                }
                string prefabLinesPath = Path.Combine(dir, "prefab_lines.tsv");
                if (File.Exists(prefabLinesPath))
                {
                    foreach (string raw in File.ReadAllLines(prefabLinesPath))
                    {
                        if (string.IsNullOrEmpty(raw)) continue;
                        string[] p = raw.Split('\t');
                        if (p.Length < 3) continue;
                        string key = Normalize(p[0]);
                        if (!prefabLines.TryGetValue(key, out var list))
                        {
                            list = new List<KeyValuePair<string, string>>();
                            prefabLines[key] = list;
                        }
                        list.Add(new KeyValuePair<string, string>(p[1], p[2]));
                    }
                }
                string aliasPath = Path.Combine(dir, "alias.tsv");
                if (File.Exists(aliasPath))
                {
                    foreach (string raw in File.ReadAllLines(aliasPath))
                    {
                        if (string.IsNullOrEmpty(raw)) continue;
                        string[] p = raw.Split('\t');
                        if (p.Length < 2) continue;
                        alias[Normalize(p[0])] = p[1];
                    }
                }
                Debug.Log("[PetPal] 语音包：" + Count + " 条，承接词 " + ConnectorCount);
            }
            catch (Exception e) { Debug.LogWarning("[PetPal] 语音包加载失败：" + e.Message); }
        }

        private static void Add(string tag, string id, string text)
        {
            if (!tags.TryGetValue(tag, out var list))
            {
                list = new List<KeyValuePair<string, string>>();
                tags[tag] = list;
            }
            list.Add(new KeyValuePair<string, string>(id, text));
        }

        private static void AddName(string name, string id, string text)
        {
            if (string.IsNullOrEmpty(name)) return;
            string key = name.Trim();
            if (!byName.TryGetValue(key, out var list))
            {
                list = new List<KeyValuePair<string, string>>();
                byName[key] = list;
            }
            list.Add(new KeyValuePair<string, string>(id, text));
        }

        public static bool TryPick(string tag, out string id, out string text)
        {
            id = null; text = null;
            if (tag == null || !tags.TryGetValue(tag, out var list) || list.Count == 0) return false;
            var pick = list[UnityEngine.Random.Range(0, list.Count)];
            id = pick.Key; text = pick.Value;
            return true;
        }

        public static bool TryPickByName(string name, out string id, out string text)
        {
            id = null; text = null;
            if (string.IsNullOrEmpty(name)) return false;
            if (!byName.TryGetValue(name.Trim(), out var list) || list.Count == 0) return false;
            var pick = list[UnityEngine.Random.Range(0, list.Count)];
            id = pick.Key; text = pick.Value;
            return true;
        }

        public static bool TryPickByPrefab(string prefab, out string id, out string text)
        {
            id = null; text = null;
            string key = Normalize(prefab);
            if (string.IsNullOrEmpty(key)) return false;
            for (int i = 0; i < 3; i++)
            {
                if (!alias.TryGetValue(key, out string next) || string.IsNullOrEmpty(next)) break;
                key = Normalize(next);
            }
            if (prefabLines.TryGetValue(key, out var list) && list.Count > 0)
            {
                var pick = list[UnityEngine.Random.Range(0, list.Count)];
                id = pick.Key; text = pick.Value;
                return true;
            }
            if (prefabNames.TryGetValue(key, out string cn)) return TryPickByName(cn, out id, out text);
            return false;
        }

        public static bool TryPickConnector(out string id, out string text)
        {
            id = null; text = null;
            if (connectors.Count == 0) return false;
            var pick = connectors[UnityEngine.Random.Range(0, connectors.Count)];
            id = pick.Key; text = pick.Value;
            return true;
        }

        private static string Normalize(string s)
        {
            if (string.IsNullOrEmpty(s)) return null;
            s = s.Replace("(Clone)", "").Replace("(clone)", "").Trim();
            return s.ToUpperInvariant();
        }

        private static string TagOf(string type, string obj)
        {
            string o = obj ?? "";
            if (type == "welcome" || type == "cycle") return type;
            if (type != null && type.StartsWith("ms_")) return type;

            switch (type)
            {
                case "宠物交互":
                    if (o.Contains("长按")) return "longpress";
                    if (o.Contains("连续") || o.Contains("多次")) return "rapid";
                    if (o.Contains("单") || o.Contains("点击")) return "click";
                    return null;
                case "玩家操作": return "cmd_" + ToolKey(o);
                case "选中互动":
                    if (o.Contains("复制人")) return "sel_dupe";
                    if (o.Contains("火箭")) return "sel_rocket";
                    if (o.Contains("植物")) return "sel_plant";
                    if (o.Contains("动物")) return "sel_animal";
                    if (o.Contains("建筑")) return "sel_building";
                    return null;
                case "游戏提示": return "msg_" + MsgKey(o);
                case "生存紧迫": return o.Contains("压力") ? "urgent_stress" : "urgent_other";
                case "玩家行为": return o.Contains("优先级") ? "urgent_prio" : "player_behavior";
                case "火箭太空":
                    if (o.Contains("发射")) return "rocket_launch";
                    if (o.Contains("降落")) return "rocket_land";
                    if (o.Contains("装载")) return "rocket_load";
                    if (o.Contains("卸货")) return "rocket_unload";
                    return "rocket_other";
                case "自言自语": return "chatter";
                case "环境时间":
                    if (o.Contains("周期开始")) return "cycle_start";
                    if (o.Contains("周期结束")) return "cycle_end";
                    if (o.Contains("白天")) return "day";
                    if (o.Contains("夜晚")) return "night";
                    if (o.Contains("氧气充足")) return "o2_ok";
                    if (o.Contains("氧气污染")) return "o2_bad";
                    if (o.Contains("冷")) return "cold";
                    if (o.Contains("热")) return "hot";
                    if (o.Contains("太空")) return "space";
                    if (o.Contains("真空")) return "vacuum";
                    if (o.Contains("空闲")) return "idle";
                    if (o.Contains("暂停")) return "pause";
                    if (o.Contains("睡眠")) return "sleep";
                    return null;
                case "植物": return "ent_plant";
                case "动物": return "ent_animal";
                case "建筑": return "ent_building";
                case "基地运行": return "sel_building";
                case "植物状态": return "plant_state";
                case "动物状态": return "animal_state";
                case "宠物移动":
                    if (o.Contains("行走")) return "move_walk";
                    if (o.Contains("跳跃")) return "move_jump";
                    if (o.Contains("翻滚")) return "move_roll";
                    if (o.Contains("瞬移")) return "move_teleport";
                    return null;
                default: return null;
            }
        }

        private static string ToolKey(string o)
        {
            if (o.Contains("建造")) return "build";
            if (o.Contains("挖掘")) return "dig";
            if (o.Contains("拆除")) return "deconstruct";
            if (o.Contains("清扫")) return "clear";
            if (o.Contains("消毒")) return "disinfect";
            if (o.Contains("优先级")) return "prioritize";
            if (o.Contains("取消")) return "cancel";
            if (o.Contains("收获")) return "harvest";
            if (o.Contains("攻击")) return "attack";
            if (o.Contains("捕捉")) return "capture";
            if (o.Contains("排空")) return "emptypipe";
            if (o.Contains("断开")) return "disconnect";
            if (o.Contains("复制设置")) return "copysettings";
            if (o.Contains("移动")) return "move";
            return "other";
        }

        private static string MsgKey(string o)
        {
            if (o.Contains("死亡")) return "death";
            if (o.Contains("研究")) return "research";
            if (o.Contains("成就")) return "achievement";
            if (o.Contains("新复制人")) return "newdupe";
            if (o.Contains("离开")) return "left";
            if (o.Contains("流星")) return "meteor";
            if (o.Contains("世界") || o.Contains("星球")) return "world";
            if (o.Contains("百科")) return "codex";
            if (o.Contains("技能")) return "skill";
            if (o.Contains("教程")) return "tutorial";
            if (o.Contains("日报")) return "eod";
            if (o.Contains("基因")) return "genetic";
            return "default";
        }
    }
}
