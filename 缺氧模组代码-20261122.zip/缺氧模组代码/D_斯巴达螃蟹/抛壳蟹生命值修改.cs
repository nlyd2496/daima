﻿using HarmonyLib;
using PeterHan.PLib.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace D_斯巴达螃蟹
{
    [HarmonyPatch(typeof(CrabConfig))]
    [HarmonyPatch("CreateCrab")]
    public static class 抛壳蟹生命值修改
    {
        private static IEnumerable<CodeInstruction> Transpiler(IEnumerable<CodeInstruction> instructions)
        {
            List<CodeInstruction> list = new List<CodeInstruction>(instructions);
            for (int i = 0; i < list.Count; i++)
            {
                // 匹配生命值 25f 并将其修改为 250f
                bool flag = list[i].opcode == OpCodes.Ldc_R4 && (float)list[i].operand == 25f && list[i + 1].opcode == OpCodes.Ldarg_1;

                if (flag)
                {
                    list[i].operand = 250f;
                }

                // 匹配寿命 100f 并将其减半为 50f
                bool flag2 = list[i].opcode == OpCodes.Ldc_R4 && (float)list[i].operand == 100f && list[i + 1].opcode == OpCodes.Ldarg_1;

                if (flag2)
                {
                    list[i].operand = 50f;
                }
            }
            return list.AsEnumerable<CodeInstruction>();
        }
    }

}
