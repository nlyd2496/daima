﻿using HarmonyLib;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace D_斯巴达螃蟹
{
    
    [HarmonyPatch(typeof(BaseCrabConfig))]
    [HarmonyPatch("BaseCrab")]
    public static class 螃蟹攻击力_攻击对象个数_攻击范围设置
    {
        public static void Postfix(GameObject __result)
        {
            __result.AddWeapon(30f, 60f, AttackProperties.DamageType.Standard, AttackProperties.TargetType.AreaOfEffect, 2, 1f);
        }
    }
    
}
