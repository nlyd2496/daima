﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HarmonyLib;
using UnityEngine;

namespace A_油炸锅自动化_Deepfryer_Automatic
{
    [HarmonyPatch(typeof(DeepfryerConfig), "ConfigureBuildingTemplate")]
    public class 油炸锅自动化_Deepfryer_Automatic
    {
        public static void Postfix(GameObject go)
        {
            go.AddOrGet<BuildingComplete>().isManuallyOperated = false;
            go.AddOrGet<ComplexFabricator>().duplicantOperated = false;
        }
    }
}
