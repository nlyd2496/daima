using System;

namespace P_模组排序
{
    /// <summary>排序方式。</summary>
    public enum SortMethod // 排序方式
    {
        按字母顺序,
        启用优先,
        禁用优先,
        按来源,
        按订阅时间,
        按游戏加载顺序
    }
}
