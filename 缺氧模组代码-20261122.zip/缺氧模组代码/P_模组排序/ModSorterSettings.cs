using Newtonsoft.Json;
using PeterHan.PLib.Options;
using System.Collections.Generic;

namespace P_模组排序
{
    /// <summary>
    /// 排序模组的选项。实现 IOptions 的 OnOptionsChanged()：
    /// 用户在「确定」保存选项后由 PLib 调用，此时 this 就是最终的选项值，
    /// 据此立即重排模组并写入 mods.json。
    /// 排序方式用「复选框」，通过属性 setter 实现互斥单选：
    /// 任何一个被勾选为 true 时，自动取消其它选项（保存后只剩一个被选中）。
    /// </summary>
    [RestartRequired]
    [JsonObject(MemberSerialization.OptIn)]
    [ConfigFile("ModSorter.json", true, false)]
    public class ModSorterSettings : SingletonOptions<ModSorterSettings>, IOptions // 模组分拣设置
    {
        private bool _按字母顺序 = true;
        private bool _启用优先;
        private bool _禁用优先;
        private bool _按来源;
        private bool _按订阅时间;
        private bool _按游戏加载顺序;
        private bool _恢复请求;
        [JsonProperty]
        private List<string> _原始顺序;

        public bool HasOriginalOrder
        {
            get { return _原始顺序 != null && _原始顺序.Count > 0; }
        }

        public void SetOriginalOrder(List<string> order)
        {
            if (HasOriginalOrder || order == null || order.Count == 0)
                return;
            _原始顺序 = new List<string>(order);
        }

        public List<string> GetOriginalOrder()
        {
            return _原始顺序 == null ? null : new List<string>(_原始顺序);
        }

        // "按字母顺序", "按模组显示名称 A→Z 排序（默认）"
        [Option("STRINGS.BUILDINGS.PREFABS.P_模组系统.AZMSX_A", "STRINGS.BUILDINGS.PREFABS.P_模组系统.AZMSX_B", null )]
        [JsonProperty]
        public bool 按字母顺序
        {
            get { return _按字母顺序; }
            set { if (value) ClearAll(); _按字母顺序 = value; }
        }

        // "启用优先", "已启用的模组排在前面"
        [Option("STRINGS.BUILDINGS.PREFABS.P_模组系统.AQYYX_A", "STRINGS.BUILDINGS.PREFABS.P_模组系统.AQYYX_B", null )]
        [JsonProperty]
        public bool 启用优先
        {
            get { return _启用优先; }
            set { if (value) ClearAll(); _启用优先 = value; }
        }

        // "禁用优先", "已禁用的模组排在前面"
        [Option("STRINGS.BUILDINGS.PREFABS.P_模组系统.AJYYX_A", "STRINGS.BUILDINGS.PREFABS.P_模组系统.AJYYX_B", null )]
        [JsonProperty]
        public bool 禁用优先
        {
            get { return _禁用优先; }
            set { if (value) ClearAll(); _禁用优先 = value; }
        }

        // "按来源", "按来源分组：本地 → 工坊 → 开发"
        [Option("STRINGS.BUILDINGS.PREFABS.P_模组系统.ALY_A", "STRINGS.BUILDINGS.PREFABS.P_模组系统.ALY_B", null )]
        [JsonProperty]
        public bool 按来源
        {
            get { return _按来源; }
            set { if (value) ClearAll(); _按来源 = value; }
        }

        // "按订阅时间", "工坊模组按更新时间从新到旧（本地/开发模组排在后面）"
        [Option("STRINGS.BUILDINGS.PREFABS.P_模组系统.ADYSJ_A", "STRINGS.BUILDINGS.PREFABS.P_模组系统.ADYSJ_B", null )]
        [JsonProperty]
        public bool 按订阅时间
        {
            get { return _按订阅时间; }
            set { if (value) ClearAll(); _按订阅时间 = value; }
        }

        [Option("STRINGS.BUILDINGS.PREFABS.P_模组系统.AYXJZ_A", "STRINGS.BUILDINGS.PREFABS.P_模组系统.AYXJZ_B", null )]
        [JsonProperty]
        public bool 按游戏加载顺序
        {
            get { return _按游戏加载顺序; }
            set { if (value) ClearAll(); _按游戏加载顺序 = value; }
        }

        [Option("STRINGS.BUILDINGS.PREFABS.P_模组系统.HFSZ_A", "STRINGS.BUILDINGS.PREFABS.P_模组系统.HFSZ_B", null)]
        public bool 恢复排序前顺序
        {
            get { return _恢复请求; }
            set { _恢复请求 = value; }
        }

        /// <summary>勾选某个排序方式时，取消其它所有排序方式（互斥单选）。</summary>
        private void ClearAll()
        {
            _按字母顺序 = false;
            _启用优先 = false;
            _禁用优先 = false;
            _按来源 = false;
            _按订阅时间 = false;
            _按游戏加载顺序 = false;
        }

        /// <summary>解析当前选中的排序方式。</summary>
        public SortMethod GetSortMethod()
        {
            if (_按订阅时间) return SortMethod.按订阅时间;
            if (_按游戏加载顺序) return SortMethod.按游戏加载顺序;
            if (_按来源) return SortMethod.按来源;
            if (_启用优先) return SortMethod.启用优先;
            if (_禁用优先) return SortMethod.禁用优先;
            return SortMethod.按字母顺序;
        }

        public IEnumerable<IOptionsEntry> CreateOptions()
        {
            // 返回 null，让 PLib 走默认的反射构建（读取 [Option] 属性）
            return null;
        }

        public void OnOptionsChanged()
        {
            if (_恢复请求)
            {
                _恢复请求 = false;
                ModSorterActions.RestoreOriginalOrder(this);
                return;
            }
            ModSorterActions.SortNow(this);
        }
    }
}
