using System;
using System.Collections.Generic;
using System.Reflection;
using HarmonyLib;
using KMod;
using UnityEngine;

namespace P_模组排序
{
    /// <summary>
    /// 访问游戏的 KMod.Manager 与模组界面。
    /// 已针对游戏版本 6000.x（Harmony 2.4.2）验证：
    ///   - Manager 单例为 Global.Instance.modManager
    ///   - Manager.mods 为公开字段 List&lt;Mod&gt;
    ///   - Manager.Save() 把当前 mods 顺序写入 mods.json
    ///   - ModsScreen.BuildDisplay() 依据 Manager.mods 顺序重建显示
    /// </summary>
    public static class ModScreen // 模组屏幕
    {
        private static MonoBehaviour currentScreen;

        public static void SetScreen(MonoBehaviour screen)
        {
            currentScreen = screen;
        }

        /// <summary>取得 KMod.Manager 单例（Global.Instance.modManager）。</summary>
        public static Manager GetManager()
        {
            try
            {
                Type globalType = AccessTools.TypeByName("Global");
                if (globalType == null)
                    return null;

                PropertyInfo instProp = globalType.GetProperty("Instance",
                    BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic);
                object instance = instProp == null ? null : instProp.GetValue(null, null);
                if (instance == null)
                    return null;

                FieldInfo f = globalType.GetField("modManager",
                    BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                return f == null ? null : (Manager)f.GetValue(instance);
            }
            catch
            {
                return null;
            }
        }

        /// <summary>当前内存中的全部模组列表（副本）。</summary>
        public static List<Mod> GetMods()
        {
            Manager m = GetManager();
            if (m == null || m.mods == null)
                return new List<Mod>();
            return new List<Mod>(m.mods);
        }

        /// <summary>把排序结果应用到内存中的模组列表（预览）。</summary>
        public static bool ApplyOrder(List<Mod> ordered)
        {
            Manager m = GetManager();
            if (m == null || m.mods == null)
                return false;
            m.mods.Clear();
            m.mods.AddRange(ordered);
            return true;
        }

        /// <summary>按保存的模组 ID 顺序恢复；快照中已不存在的模组忽略，新模组追加在末尾。</summary>
        public static List<Mod> OrderByOriginalOrder(List<Mod> mods, IList<string> originalOrder)
        {
            if (mods == null || originalOrder == null)
                return null;

            var indexesById = new Dictionary<string, Queue<int>>(StringComparer.Ordinal);
            for (int i = 0; i < mods.Count; i++)
            {
                Mod mod = mods[i];
                if (mod == null || string.IsNullOrEmpty(mod.staticID))
                    continue;

                Queue<int> indexes;
                if (!indexesById.TryGetValue(mod.staticID, out indexes))
                {
                    indexes = new Queue<int>();
                    indexesById.Add(mod.staticID, indexes);
                }
                indexes.Enqueue(i);
            }

            var used = new bool[mods.Count];
            var ordered = new List<Mod>(mods.Count);
            foreach (string id in originalOrder)
            {
                Queue<int> indexes;
                if (!string.IsNullOrEmpty(id) && indexesById.TryGetValue(id, out indexes) && indexes.Count > 0)
                {
                    int index = indexes.Dequeue();
                    used[index] = true;
                    ordered.Add(mods[index]);
                }
            }

            for (int i = 0; i < mods.Count; i++)
            {
                if (!used[i])
                    ordered.Add(mods[i]);
            }
            return ordered;
        }

        /// <summary>把当前顺序写入 mods.json（游戏原生保存，下次启动按此顺序加载）。</summary>
        public static bool Save()
        {
            Manager m = GetManager();
            if (m == null)
                return false;
            try { return m.Save(); }
            catch { return false; }
        }

        /// <summary>
        /// 把指定模组（本模组自身）移到列表第一位，其余模组相对顺序不变，并写入 mods.json。
        /// </summary>
        public static bool MoveSelfToFirst(Mod self)
        {
            Manager m = GetManager();
            if (m == null || m.mods == null || self == null)
                return false;

            int idx = m.mods.IndexOf(self);
            if (idx < 0)
                return false;   // 不在列表中
            if (idx == 0)
                return false;   // 已经在第一位，无需移动

            m.mods.RemoveAt(idx);
            m.mods.Insert(0, self);
            Save();
            return true;        // 发生了移动
        }

        /// <summary>尽力刷新模组界面的显示。</summary>
        public static void RefreshScreen()
        {
            if (currentScreen == null)
                return;

            foreach (string name in new[] { "BuildDisplay", "RebuildDisplay", "Refresh", "Rebuild", "RebuildMods" })
            {
                MethodInfo mi = currentScreen.GetType().GetMethod(name,
                    BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                if (mi == null)
                    continue;
                try
                {
                    if (mi.GetParameters().Length == 0)
                        mi.Invoke(currentScreen, null);
                    else
                        mi.Invoke(currentScreen, new object[] { null });
                    return;
                }
                catch { }
            }
        }

        /// <summary>模组在当前 DLC 下是否启用。</summary>
        public static bool IsEnabled(Mod mod)
        {
            try { return mod.IsEnabledForActiveDlc(); }
            catch { }
            return mod.enabled;
        }

        /// <summary>模组显示名称。Label 为结构体，直接取字段。</summary>
        public static string DisplayName(Mod mod)
        {
            if (!string.IsNullOrEmpty(mod.label.title))
                return mod.label.title;
            if (!string.IsNullOrEmpty(mod.title))
                return mod.title;
            return mod.label.id;
        }
    }
}
