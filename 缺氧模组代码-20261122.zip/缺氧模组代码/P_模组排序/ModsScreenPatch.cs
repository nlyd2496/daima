using System;
using System.Reflection;
using HarmonyLib;
using UnityEngine;

namespace P_模组排序
{
    /// <summary>记录模组界面实例，供排序后刷新显示使用。</summary>
    public static class ModsScreenPatch // 模组屏幕补丁
    {
        public static void Apply(Harmony harmony)
        {
            Type screen = AccessTools.TypeByName("ModsScreen");
            if (screen == null)
                return;

            MethodBase onActivate = screen.GetMethod("OnActivate",
                BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
            if (onActivate != null)
                harmony.Patch(onActivate, postfix: new HarmonyMethod(typeof(ModsScreenPatch), nameof(Postfix)));
        }

        private static void Postfix(MonoBehaviour __instance)
        {
            ModScreen.SetScreen(__instance);

            // 打开模组界面时，若自身不在第一位，就自动移到第一位（此时加载早已完成，安全）
            if (ModScreen.MoveSelfToFirst(ModSorterPlugin.SelfMod))
                ModScreen.RefreshScreen();
        }
    }
}
