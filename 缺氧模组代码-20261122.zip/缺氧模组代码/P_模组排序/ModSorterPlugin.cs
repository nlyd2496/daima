using HarmonyLib;
using KMod;
using PeterHan.PLib.Core;
using PeterHan.PLib.Options;

namespace P_模组排序
{
    public class ModSorterPlugin : UserMod2
    {
        /// <summary>模组自身的 Mod 对象（引用）。</summary>
        public static Mod SelfMod;

        /// <summary>模组自身的 staticID（引用失效时用它匹配）。</summary>
        public static string SelfStaticId;

        public override void OnLoad(Harmony harmony)
        {
            base.OnLoad(harmony);

            // UserMod2.mod 是游戏在加载本模组时注入的自身 Mod 对象
            SelfMod = this.mod;
            SelfStaticId = this.mod != null ? this.mod.staticID : null;

            PUtil.InitLibrary(true);
            new POptions().RegisterOptions(this, typeof(ModSorterSettings));
            ModsScreenPatch.Apply(harmony);
        }
    }
}
