using System;
using System.Collections.Generic;
using KMod;

namespace P_模组排序
{
    /// <summary>排序核心逻辑。</summary>
    public static class ModSorterLogic // 模组分拣逻辑
    {
        public static List<Mod> Sort(List<Mod> mods, SortMethod method, IList<string> originalOrder)
        {
            Dictionary<string, int> loadOrder = BuildLoadOrder(mods, originalOrder);

            // 「模组排序」自身固定排在第一位，不参与排序（排序方式不影响它）
            var result = new List<Mod>();
            var others = new List<Mod>();
            foreach (Mod m in mods)
            {
                if (IsSelf(m))
                    result.Add(m);
                else
                    others.Add(m);
            }

            others.Sort(GetComparer(method, loadOrder));

            // 自身第一，其余按所选方式排序
            result.AddRange(others);
            return result;
        }

        /// <summary>判断某个 Mod 是否为「模组排序」自身（引用相等 + staticID 双重匹配）。</summary>
        private static bool IsSelf(Mod m)
        {
            if (m == null)
                return false;
            if (object.ReferenceEquals(m, ModSorterPlugin.SelfMod))
                return true;
            if (!string.IsNullOrEmpty(ModSorterPlugin.SelfStaticId) &&
                string.Equals(m.staticID, ModSorterPlugin.SelfStaticId, StringComparison.Ordinal))
                return true;
            return false;
        }

        private static Dictionary<string, int> BuildLoadOrder(List<Mod> mods, IList<string> originalOrder)
        {
            var order = new Dictionary<string, int>(StringComparer.Ordinal);
            if (originalOrder != null)
            {
                for (int i = 0; i < originalOrder.Count; i++)
                {
                    string id = originalOrder[i];
                    if (!string.IsNullOrEmpty(id) && !order.ContainsKey(id))
                        order.Add(id, order.Count);
                }
            }

            foreach (Mod mod in mods)
            {
                if (mod != null && !string.IsNullOrEmpty(mod.staticID) && !order.ContainsKey(mod.staticID))
                    order.Add(mod.staticID, order.Count);
            }
            return order;
        }

        private static Comparison<Mod> GetComparer(SortMethod method, Dictionary<string, int> loadOrder)
        {
            switch (method)
            {
                case SortMethod.按游戏加载顺序:
                    return (a, b) =>
                    {
                        int orderA;
                        int orderB;
                        if (a == null || string.IsNullOrEmpty(a.staticID) || !loadOrder.TryGetValue(a.staticID, out orderA))
                            orderA = int.MaxValue;
                        if (b == null || string.IsNullOrEmpty(b.staticID) || !loadOrder.TryGetValue(b.staticID, out orderB))
                            orderB = int.MaxValue;
                        int c = orderA.CompareTo(orderB);
                        return c != 0 ? c : CompareName(a, b);
                    };

                case SortMethod.启用优先:
                    return (a, b) =>
                    {
                        int c = ModScreen.IsEnabled(b).CompareTo(ModScreen.IsEnabled(a)); // 启用在前
                        return c != 0 ? c : CompareName(a, b);
                    };

                case SortMethod.禁用优先:
                    return (a, b) =>
                    {
                        int c = ModScreen.IsEnabled(a).CompareTo(ModScreen.IsEnabled(b)); // 禁用在前
                        return c != 0 ? c : CompareName(a, b);
                    };

                case SortMethod.按来源:
                    // distribution_platform: Local=0, Steam=1, Epic=2, Rail=3, Dev=4
                    return (a, b) =>
                    {
                        int c = ((int)a.label.distribution_platform).CompareTo((int)b.label.distribution_platform);
                        return c != 0 ? c : CompareName(a, b);
                    };

                case SortMethod.按订阅时间:
                    // label.version = 工坊模组的 lastUpdateTime 时间戳（正数）；开发模组是负数/随机值，自然排到后面
                    return (a, b) =>
                    {
                        int c = b.label.version.CompareTo(a.label.version); // 降序：最新在前
                        return c != 0 ? c : CompareName(a, b);
                    };

                default: // 按字母顺序
                    return (a, b) => CompareName(a, b);
            }
        }

        private static int CompareName(Mod a, Mod b)
        {
            return string.Compare(ModScreen.DisplayName(a), ModScreen.DisplayName(b), StringComparison.OrdinalIgnoreCase);
        }
    }
}
