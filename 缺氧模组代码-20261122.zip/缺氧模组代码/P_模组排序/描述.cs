﻿using STRINGS;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P_模组排序
{
    public class STRINGS
    {
        public static void DoReplacement()
        {
            LocString.CreateLocStringKeys(typeof(STRINGS), "");
        }
        // 控制器

        // 建筑描述
        public class BUILDINGS
        {
            public class PREFABS
            {
                public class P_模组系统
                {
                    // "按字母顺序", "按模组显示名称 A→Z 排序（默认）"
                    public static LocString AZMSX_A = "按字母顺序";
                    public static LocString AZMSX_B = "按模组显示名称 A→Z 排序（默认）";
                    // "启用优先", "已启用的模组排在前面"
                    public static LocString AQYYX_A = "启用优先";
                    public static LocString AQYYX_B = "已启用的模组排在前面";
                    // "禁用优先", "已禁用的模组排在前面"
                    public static LocString AJYYX_A = "禁用优先";
                    public static LocString AJYYX_B = "已禁用的模组排在前面";
                    // "按来源", "按来源分组：本地 → 工坊 → 开发"
                    public static LocString ALY_A = "按来源";
                    public static LocString ALY_B = "按来源分组：本地 → 工坊 → 开发";
                    // "按订阅时间", "工坊模组按更新时间从新到旧（本地/开发模组排在后面）"
                    public static LocString ADYSJ_A = "按订阅时间";
                    public static LocString ADYSJ_B = "工坊模组按更新时间从新到旧（本地/开发模组排在后面）";
                    // "按游戏加载顺序", "恢复游戏模组管理器中的加载顺序"
                    public static LocString AYXJZ_A = "按游戏加载顺序";
                    public static LocString AYXJZ_B = "按首次排序前游戏模组管理器中的顺序排列";
                    // "恢复排序前顺序", "恢复首次排序前保存的模组顺序"
                    public static LocString HFSZ_A = "恢复排序前顺序";
                    public static LocString HFSZ_B = "恢复首次排序前保存的模组顺序";
                }

            }
        }
    }
}
