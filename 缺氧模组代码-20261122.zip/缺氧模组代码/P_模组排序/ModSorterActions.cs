using System.Collections.Generic;
using KMod;
using PeterHan.PLib.Core;
using PeterHan.PLib.Options;

namespace P_模组排序
{
    /// <summary>排序动作：按给定选项重排模组并保存到配置文件。</summary>
    public static class ModSorterActions // 模组分拣逻辑
    {
        public static void SortNow(ModSorterSettings settings)
        {
            List<Mod> mods = ModScreen.GetMods();
            if (mods == null || mods.Count == 0)
            {
                PUtil.LogWarning("[ModSorter] 无法读取模组列表。");
                return;
            }

            if (!settings.HasOriginalOrder)
            {
                var originalOrder = new List<string>();
                foreach (Mod mod in mods)
                {
                    if (mod != null && !string.IsNullOrEmpty(mod.staticID))
                        originalOrder.Add(mod.staticID);
                }
                settings.SetOriginalOrder(originalOrder);
                if (settings.HasOriginalOrder)
                    POptions.WriteSettings(settings);
            }

            SortMethod method = settings.GetSortMethod();
            List<Mod> sorted = ModSorterLogic.Sort(mods, method, settings.GetOriginalOrder());

            // 应用到内存（即时预览）并刷新模组界面
            ModScreen.ApplyOrder(sorted);
            ModScreen.RefreshScreen();

            // 写入 mods.json，重启后按新顺序加载
            bool ok = ModScreen.Save();

            PUtil.LogDebug(ok
                ? "[ModSorter] 已按「" + method + "」排序并写入配置文件，重启后生效。"
                : "[ModSorter] 保存失败。");
        }

        public static void RestoreOriginalOrder(ModSorterSettings settings)
        {
            if (settings == null || !settings.HasOriginalOrder)
            {
                PUtil.LogWarning("[ModSorter] 没有可恢复的排序前顺序，请先执行一次排序。");
                return;
            }

            List<Mod> mods = ModScreen.GetMods();
            List<Mod> restored = ModScreen.OrderByOriginalOrder(mods, settings.GetOriginalOrder());
            if (restored == null || !ModScreen.ApplyOrder(restored))
            {
                PUtil.LogWarning("[ModSorter] 无法恢复模组顺序。");
                return;
            }

            ModScreen.RefreshScreen();
            bool ok = ModScreen.Save();
            PUtil.LogDebug(ok
                ? "[ModSorter] 已恢复到首次排序前的模组顺序。"
                : "[ModSorter] 已恢复内存顺序，但写入配置文件失败。");
        }
    }
}
