﻿using HarmonyLib;
using UnityEngine;

namespace P_基础系统_1._0
{
    /*
    [HarmonyPatch(typeof(ElementSplitterComponents))]
    [HarmonyPatch("CanFirstAbsorbSecond")]
    public class 物体堆叠上限
    {
        // 注意：原方法是 static bool CanFirstAbsorbSecond(Handle first, Handle second)
        // 所以 Prefix 必须匹配参数，并通过 __result 控制返回值
        private static bool Prefix(
            HandleVector<int>.Handle first,
            HandleVector<int>.Handle second,
            out bool __result)  // 使用 out __result 来覆盖原方法返回值
        {
            // 如果任一 Handle 无效，直接返回 false（与原逻辑一致）
            if (first == HandleVector<int>.InvalidHandle || second == HandleVector<int>.InvalidHandle)
            {
                __result = false;
                return false; // 不执行原方法
            }

            // 获取两个 ElementSplitter 数据
            var data = GameComps.ElementSplitters.GetData(first);
            var data2 = GameComps.ElementSplitters.GetData(second);

            // 自定义判断逻辑：将上限从 25000 改为 50000
            __result = data.primaryElement.ElementID == data2.primaryElement.ElementID &&
                       data.primaryElement.Units + data2.primaryElement.Units < 50000f &&
                       !data.kPrefabID.HasTag(GameTags.MarkedForMove) &&
                       !data2.kPrefabID.HasTag(GameTags.MarkedForMove);

            return false; // 跳过原始方法，使用我们设置的 __result
        }
    }
    */
}