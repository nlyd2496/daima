using System;
using System.Collections;
using System.Collections.Generic;
using HarmonyLib;
using PeterHan.PLib.Options;
using UnityEngine;

namespace P_基础系统_1._0
{
    /// <summary>
    /// P019GG1 蓝图一键领取
    /// 原版领取蓝图要一件一件点（每点一次只提交一条 SetItemOpened，还要等服务器回包）。
    /// 这里在掉落界面加一个「全部领取」按钮，把所有未领取的物品一次塞进 KleiItems 的请求队列。
    /// 队列本身是串行的，但不用人再点了。
    /// </summary>
    [HarmonyPatch(typeof(KleiItemDropScreen), "PresentItem")]
    public class 蓝图一键领取
    {
        public static void Postfix(KleiItemDropScreen __instance)
        {
            if (!SingletonOptions<控制台>.Instance.P019GG1)
            {
                return;
            }

            try
            {
                蓝图领取按钮.确保(__instance);
            }
            catch (Exception e)
            {
                Debug.LogWarning("[蓝图一键领取] 添加按钮失败: " + e.Message);
            }
        }
    }

    /// <summary>
    /// 领取逻辑：蓝图的归属在 Klei 服务器，本地只是缓存，未领取的物品标记为未开封。
    /// </summary>
    internal static class 蓝图领取工具
    {
        public static List<KleiItems.ItemData> 收集未领取()
        {
            List<KleiItems.ItemData> list = new List<KleiItems.ItemData>();
            try
            {
                foreach (KleiItems.ItemData item in PermitItems.IterateInventory())
                {
                    if (!item.IsOpened)
                    {
                        list.Add(item);
                    }
                }
            }
            catch (Exception e)
            {
                Debug.LogWarning("[蓝图一键领取] 读取库存失败: " + e.Message);
            }

            return list;
        }

        public static int 统计未领取()
        {
            return 收集未领取().Count;
        }

        /// <summary>
        /// 把所有未领取的物品一次性提交到网络队列，返回提交数量。
        /// </summary>
        public static int 全部入队()
        {
            List<KleiItems.ItemData> items = 收集未领取();
            int queued = 0;
            foreach (KleiItems.ItemData item in items)
            {
                try
                {
                    PermitItems.QueueRequestOpenOrUnboxItem(item, null);
                    queued++;
                }
                catch (Exception e)
                {
                    Debug.LogWarning("[蓝图一键领取] 提交失败 " + item.Id + ": " + e.Message);
                }
            }

            return queued;
        }
    }

    /// <summary>
    /// 读写游戏私有字段的小工具（AccessTools 会向上查找基类）。
    /// </summary>
    internal static class 蓝图反射
    {
        public static T 取<T>(object obj, string fieldName)
        {
            System.Reflection.FieldInfo field = AccessTools.Field(obj.GetType(), fieldName);
            if (field == null)
            {
                Debug.LogWarning("[蓝图一键领取] 找不到字段: " + fieldName);
                return default(T);
            }

            return (T)field.GetValue(obj);
        }

        public static void 设(object obj, string fieldName, object value)
        {
            System.Reflection.FieldInfo field = AccessTools.Field(obj.GetType(), fieldName);
            if (field == null)
            {
                Debug.LogWarning("[蓝图一键领取] 找不到字段: " + fieldName);
                return;
            }

            field.SetValue(obj, value);
        }
    }

    /// <summary>
    /// 后台协程：神秘箱子（Shipment X/Y/Z）开出来会变成新的未领取物品，所以要反复扫库存直到清空。
    /// </summary>
    public class 蓝图领取协程 : MonoBehaviour
    {
        private static 蓝图领取协程 实例;
        private bool 运行中;

        public static void 开始()
        {
            if (实例 == null)
            {
                GameObject 宿主 = new GameObject("蓝图一键领取_Runner");
                UnityEngine.Object.DontDestroyOnLoad(宿主);
                实例 = 宿主.AddComponent<蓝图领取协程>();
            }

            if (!实例.运行中)
            {
                实例.StartCoroutine(实例.流程());
            }
        }

        private IEnumerator 流程()
        {
            运行中 = true;
            int 轮次 = 0;
            while (轮次++ < 20)
            {
                int queued = 蓝图领取工具.全部入队();
                if (queued == 0)
                {
                    break;
                }

                Debug.Log("[蓝图一键领取] 第 " + 轮次 + " 轮：提交 " + queued + " 个领取请求，等待服务器处理...");

                // 每领取成功一件都会触发一次库存刷新，未领取数量会下降
                float 已等待 = 0f;
                float 无进展 = 0f;
                int 上次数量 = int.MaxValue;
                while (true)
                {
                    int 现在 = 蓝图领取工具.统计未领取();
                    if (现在 == 0)
                    {
                        break;
                    }

                    if (现在 != 上次数量)
                    {
                        上次数量 = 现在;
                        无进展 = 0f;
                    }
                    else
                    {
                        无进展 += 0.5f;
                    }

                    已等待 += 0.5f;
                    if (无进展 > 20f)
                    {
                        Debug.LogWarning("[蓝图一键领取] 20 秒没有进展，可能有个别物品被服务器拒绝，结束本轮等待");
                        break;
                    }

                    if (已等待 > 300f)
                    {
                        Debug.LogWarning("[蓝图一键领取] 等待超时（300 秒），结束本轮等待");
                        break;
                    }

                    yield return new WaitForSecondsRealtime(0.5f);
                }

                if (蓝图领取工具.统计未领取() == 0)
                {
                    break;
                }

                yield return new WaitForSecondsRealtime(0.25f);
            }

            运行中 = false;
            try
            {
                KleiItemsStatusRefresher.Refresh();
            }
            catch (Exception e)
            {
                Debug.LogWarning("[蓝图一键领取] 刷新界面失败: " + e.Message);
            }

            Debug.Log("[蓝图一键领取] 结束，剩余未领取: " + 蓝图领取工具.统计未领取());
        }
    }

    /// <summary>
    /// 在蓝图掉落界面（KleiItemDropScreen）的领取按钮左边，克隆一个「全部领取」按钮。
    /// </summary>
    internal static class 蓝图领取按钮
    {
        private const string 按钮名 = "P019GG1_ClaimAllButton";

        public static void 确保(KleiItemDropScreen screen)
        {
            if (screen == null)
            {
                return;
            }

            KButton accept = 蓝图反射.取<KButton>(screen, "acceptButton");
            if (accept == null)
            {
                return;
            }

            Transform parent = accept.transform.parent;
            if (parent == null || parent.Find(按钮名) != null)
            {
                return;
            }

            GameObject clone = UnityEngine.Object.Instantiate(accept.gameObject, parent);
            clone.name = 按钮名;

            KButton button = clone.GetComponentInChildren<KButton>(true);
            if (button == null)
            {
                UnityEngine.Object.Destroy(clone);
                return;
            }

            LocText label = clone.GetComponentInChildren<LocText>(true);
            if (label != null)
            {
                label.SetText(STRINGS.BUILDINGS.PREFABS.P_UI.P019GG1B);
            }

            RectTransform srcRect = accept.GetComponent<RectTransform>();
            RectTransform rect = clone.GetComponent<RectTransform>();
            if (srcRect != null && rect != null)
            {
                // 放在原按钮左侧并排；UI 缩放特殊的话改这里的间距
                float offsetX = (srcRect.rect.width > 1f ? srcRect.rect.width : 160f) + 24f;
                rect.anchoredPosition = new Vector2(srcRect.anchoredPosition.x - offsetX, 0f);
            }

            button.ClearOnClick();
            button.onClick += () => 点击(screen);
            clone.SetActive(true);
        }

        private static void 点击(KleiItemDropScreen screen)
        {
            int queued = 蓝图领取工具.全部入队();
            Debug.Log("[蓝图一键领取] 一键领取：提交 " + queued + " 个请求");

            try
            {
                // 打断逐个展示的协程，直接关掉这个界面
                Coroutine routine = 蓝图反射.取<Coroutine>(screen, "activePresentationRoutine");
                if (routine != null)
                {
                    screen.StopCoroutine(routine);
                }

                蓝图反射.设(screen, "shouldDoCloseRoutine", false);
                screen.Show(false);
            }
            catch (Exception e)
            {
                Debug.LogWarning("[蓝图一键领取] 关闭界面失败: " + e.Message);
            }

            蓝图领取协程.开始();
        }
    }
}
