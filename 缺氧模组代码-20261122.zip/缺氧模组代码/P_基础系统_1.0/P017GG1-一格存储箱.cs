﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using STRINGS;
using TUNING;
using UnityEngine;

namespace P_基础系统_1._0
{ 
    /*
     * 
    public class P017GG1 : IBuildingConfig
    {
        public override BuildingDef CreateBuildingDef()
        {
            string id = "P017GG1";
            int width = 1;
            int height = 1;
            string anim = "P017GG1_kanim";
            int hitpoints = 30;
            float construction_time = 30f;
            float[] construction_mass = new float[]
            {
            100f,
            100f
            };
            string[] construction_materials = new string[]
            {
            "RefinedMetal",
            "Glass"
            };
            float melting_point = 800f;
            BuildLocationRule build_location_rule = BuildLocationRule.Anywhere;
            EffectorValues none = NOISE_POLLUTION.NONE;
            BuildingDef buildingDef = BuildingTemplates.CreateBuildingDef(id, width, height, anim, hitpoints, construction_time, construction_mass, construction_materials, melting_point, build_location_rule, TUNING.BUILDINGS.DECOR.PENALTY.TIER1, none, 0.2f);
            BuildingTemplates.CreateFoundationTileDef(buildingDef);
            buildingDef.Floodable = false;
            buildingDef.Entombable = false;
            buildingDef.Overheatable = false;
            buildingDef.UseStructureTemperature = false;
            buildingDef.AudioCategory = "Glass";
            buildingDef.AudioSize = "small";
            buildingDef.BaseTimeUntilRepair = -1f;
            buildingDef.SceneLayer = Grid.SceneLayer.TileMain;
            buildingDef.AddSearchTerms(SEARCH_TERMS.TILE);
            buildingDef.AddSearchTerms(SEARCH_TERMS.STORAGE);
            buildingDef.ConstructionOffsetFilter = BuildingDef.ConstructionOffsetFilter_OneDown;
            //--------------------------
            if (控制台.Instance.P017GG1) { buildingDef.Deprecated = false; } else { buildingDef.Deprecated = true; }
            //--------------------------
            return buildingDef;
        }
        public override void ConfigureBuildingTemplate(GameObject go, Tag prefab_tag)
        {
            GeneratedBuildings.MakeBuildingAlwaysOperational(go);
            BuildingConfigManager.Instance.IgnoreDefaultKComponent(typeof(RequiresFoundation), prefab_tag);
            SimCellOccupier simCellOccupier = go.AddOrGet<SimCellOccupier>();
            simCellOccupier.movementSpeedMultiplier = DUPLICANTSTATS.MOVEMENT_MODIFIERS.PENALTY_2;
            simCellOccupier.notifyOnMelt = true;
            Storage storage = go.AddOrGet<Storage>();
            storage.SetDefaultStoredItemModifiers(new List<Storage.StoredItemModifier>
            {
                Storage.StoredItemModifier.Hide,
                Storage.StoredItemModifier.Seal,
                Storage.StoredItemModifier.Insulate
            });
            storage.capacityKg = 1000f;
            storage.showInUI = true;
            storage.allowItemRemoval = true;
            storage.showDescriptor = true;
            storage.storageFilters = STORAGEFILTERS.STORAGE_LOCKERS_STANDARD;
            storage.fetchCategory = Storage.FetchCategory.GeneralStorage;
            storage.showCapacityStatusItem = true;
            storage.showCapacityAsMainStatus = true;

            storage.SetDefaultStoredItemModifiers(new List<Storage.StoredItemModifier>
                {
                    Storage.StoredItemModifier.Hide,
                    Storage.StoredItemModifier.Seal,
                    Storage.StoredItemModifier.Insulate
                });

            go.AddOrGet<StorageTileSwitchItemWorkable>();
            TreeFilterable treeFilterable = go.AddOrGet<TreeFilterable>();
            treeFilterable.copySettingsEnabled = false;
            treeFilterable.dropIncorrectOnFilterChange = false;
            treeFilterable.preventAutoAddOnDiscovery = true;
            StorageTile.Def def = go.AddOrGetDef<StorageTile.Def>();
            def.MaxCapacity = 1000f;
            def.specialItemCases = new StorageTile.SpecificItemTagSizeInstruction[]
            {
            new StorageTile.SpecificItemTagSizeInstruction(GameTags.AirtightSuit, 0.5f),
            new StorageTile.SpecificItemTagSizeInstruction(GameTags.Dehydrated, 0.6f),
            new StorageTile.SpecificItemTagSizeInstruction(GameTags.MoltShell, 0.5f)
            };
            go.AddOrGet<TileTemperature>();
            go.AddOrGet<BuildingHP>().destroyOnDamaged = true;
            Prioritizable.AddRef(go);
            go.AddOrGetDef<RocketUsageRestriction.Def>().restrictOperational = false;
        }
        public override void DoPostConfigureComplete(GameObject go)
        {
            GeneratedBuildings.RemoveLoopingSounds(go);
            go.GetComponent<KPrefabID>().AddTag(GameTags.FloorTiles, false);
        }
        public const string ID = "P017GG1";
    }
    */
}