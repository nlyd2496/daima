﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HarmonyLib;
using STRINGS;
using KMod;
using PeterHan.PLib.Core;
using PeterHan.PLib.Database;
using Klei.AI;
using PeterHan.PLib.Options;

namespace P_基础系统_1._0
{
    public class STRINGS
    {
        public static void DoReplacement()
        {
            LocString.CreateLocStringKeys(typeof(STRINGS), "");
        }
        public class BUILDINGS
        {
            public class PREFABS
            {
                public class P_UI
                {
                    public static LocString P001GG1 = "启用超级装饰";
                    public static LocString P001GG1X1 = "装饰度";
                    public static LocString P001GG1X2 = "装饰半径";
                    public static LocString P002GG1 = "启用沉默喷泉";
                    public static LocString P003GG1 = "启用高速经验";
                    public static LocString P003GG1X1 = "经验加成倍数";
                    public static LocString P004GG1 = "启用更大操作距离";
                    public static LocString P005GG1 = "启用喷泉无压力反应";
                    public static LocString P006GG1X1 = "万物可水平旋转（废弃）";
                    public static LocString P006GG1X2 = "万物可垂直旋转（废弃）";
                    public static LocString P006GG1X3 = "万物可圆周旋转（废弃）";
                    public static LocString P007GG1 = "启用无限缩放";
                    public static LocString P008GG1 = "启用无需研究";
                    public static LocString P009GG1 = "启用箱子隔热密封";
                    public static LocString P010GG1 = "启用永不过热";
                    public static LocString P011GG1 = "启用永不淹没";
                    public static LocString P012GG1 = "启用永喷泉（和沉默喷泉互斥）";
                    public static LocString P012GG1X1 = "喷发质量倍数";
                    public static LocString P013GG1 = "启用游戏加速";
                    public static LocString P014GG1 = "启用砖块移动速度增益";
                    public static LocString P014GG1X1 = "砖上移动速度";
                    public static LocString P017GG1 = "启用一格存储箱";
                    public static LocString P019GG1 = "启用蓝图一键领取";
                    public static LocString P019GG1T = "在蓝图领取界面增加「全部领取」按钮：把所有未领取的蓝图（含神秘箱子）一次性提交给 Klei 服务器，不用再一件一件点。需要联网并已登录 Klei 账号。";
                    public static LocString P019GG1B = "全部领取";
                }
                // 建筑---------------------------------------------------------------------------------------------------------------------------
                // 一格存储箱
                public class P017GG1
                {
                    public static LocString NAME = UI.FormatAsLink("一格存储箱", "P017GG1");
                    public static LocString EFFECT = "可以在任意位置建造的存储箱，尽管小巧可爱，但它有容乃大。";
                    public static LocString DESC = "不要看我小，缺充满了大大的能量。";
                }


            }
        }
    }
}
