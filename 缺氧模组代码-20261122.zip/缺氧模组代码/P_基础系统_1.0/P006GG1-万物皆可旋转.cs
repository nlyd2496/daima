﻿using HarmonyLib;
using PeterHan.PLib.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P_基础系统_1._0
{
    /*
    // 使用 Harmony 库进行方法修补（Method Patching），常用于游戏模组开发中修改原游戏逻辑
    using HarmonyLib;

    // 补丁目标：修补 BuildingTemplates 类中的静态方法 CreateBuildingDef
    // 该方法用于创建建筑的定义（BuildingDef），包含建筑的基本属性（如大小、电力、温度等）
    [HarmonyPatch(typeof(BuildingTemplates), "CreateBuildingDef")]
    public static class buildingdef
    {
        // Postfix 补丁：在原方法执行完成后执行
        // 用于修改或扩展原方法的返回结果
        public static void Postfix(BuildingDef __result)
        {
            // 判断当前建筑的放置规则是否不是“铺地”类型（即不是 Tile 类型）
            // BuildLocationRule.Tile 通常指像地板、电线、管道这类需要铺设的建筑
            bool flag = __result.BuildLocationRule != BuildLocationRule.Tile;

            // 如果建筑不是铺地类型，则允许水平翻转（镜像）
            if (flag)
            {
                // 将该建筑的允许旋转方式设置为仅允许水平翻转（FlipH）
                // PermittedRotations.FlipH 表示建筑可以左右镜像，但不能旋转90度
                // 这通常用于对称但非完全可旋转的建筑（如门、某些机器）
                __result.PermittedRotations = PermittedRotations.FlipH;
            }
        }
    }

    // 补丁目标：修补 DirectionControl 类中的 SetAllowedDirection 方法
    // 该方法用于设置工作台（如洗手台、工作台等）允许交互的方向（左或右）
    [HarmonyPatch(typeof(DirectionControl), "SetAllowedDirection")]
    public static class washstation
    {
        // Postfix 补丁：在原方法执行后执行
        // 用于根据建筑的朝向动态调整动画中的箭头显示
        public static void Postfix(DirectionControl __instance, ref WorkableReactable.AllowedDirection new_direction)
        {
            // 获取当前 DirectionControl 组件所属 GameObject 的动画控制器
            KBatchedAnimController component = __instance.GetComponent<KBatchedAnimController>();

            // 检查该建筑是否具有 Rotatable 组件，并获取其当前朝向
            // 如果朝向为水平翻转（FlipH），表示建筑已被镜像（左右翻转）
            bool flag = __instance.GetComponent<Rotatable>().GetOrientation() == Orientation.FlipH;

            // 如果建筑当前处于水平翻转状态，则需要调整箭头动画的显示
            if (flag)
            {
                // 如果新的允许交互方向是“向左”
                bool flag2 = new_direction == WorkableReactable.AllowedDirection.Left;
                if (flag2)
                {
                    // 隐藏“arrow2”和“arrow_left”这两个符号（动画部件）
                    component.SetSymbolVisiblity("arrow2", false);
                    component.SetSymbolVisiblity("arrow_left", false);

                    // 显示“arrow_right”符号
                    // 因为建筑已被翻转，原本的“向左”方向在视觉上应显示为“向右”
                    component.SetSymbolVisiblity("arrow_right", true);
                }
                else
                {
                    // 否则，如果新的允许方向是“向右”
                    bool flag3 = new_direction == WorkableReactable.AllowedDirection.Right;
                    if (flag3)
                    {
                        // 隐藏“arrow2”和“arrow_right”
                        component.SetSymbolVisiblity("arrow2", false);
                        component.SetSymbolVisiblity("arrow_right", false);

                        // 显示“arrow_left”，因为翻转后“向右”在视觉上应显示为“向左”
                        component.SetSymbolVisiblity("arrow_left", true);
                    }
                }
            }
        }
    }
    */

}
