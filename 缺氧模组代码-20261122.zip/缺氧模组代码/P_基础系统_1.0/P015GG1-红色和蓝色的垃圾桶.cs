﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P_基础系统_1._0
{
    class P015GG1_红色和蓝色的垃圾桶
    {
    }
}
