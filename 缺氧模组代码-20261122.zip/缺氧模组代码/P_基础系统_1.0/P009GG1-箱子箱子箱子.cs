﻿using HarmonyLib;
using PeterHan.PLib.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace P_基础系统_1._0
{
    [HarmonyPatch(typeof(StorageLockerConfig))]
    [HarmonyPatch("DoPostConfigureComplete")]
    public class 存储箱隔热密封
    {
        private static void Postfix(GameObject go)
        {
            bool P009GG1 = SingletonOptions<控制台>.Instance.P009GG1;
            if (P009GG1)
            {
                Storage storage = go.AddOrGet<Storage>();
                storage.SetDefaultStoredItemModifiers(new List<Storage.StoredItemModifier>
                { 
                    Storage.StoredItemModifier.Hide,
                    Storage.StoredItemModifier.Seal,
                    Storage.StoredItemModifier.Insulate
                });
            }

        }
    }
    [HarmonyPatch(typeof(StorageLockerSmartConfig))]
    [HarmonyPatch("DoPostConfigureComplete")]
    public class 智能存储箱隔热密封
    {
        private static void Postfix(GameObject go)
        {
            bool P009GG1 = SingletonOptions<控制台>.Instance.P009GG1;
            if (P009GG1)
            {
                Storage storage = go.AddOrGet<Storage>();
                storage.SetDefaultStoredItemModifiers(new List<Storage.StoredItemModifier>
                {
                    Storage.StoredItemModifier.Hide,
                    Storage.StoredItemModifier.Seal,
                    Storage.StoredItemModifier.Insulate
                });
            }
        }
    }
    [HarmonyPatch(typeof(StorageTileConfig))]
    [HarmonyPatch("DoPostConfigureComplete")]
    public class 储存砖隔热密封
    {
        private static void Postfix(GameObject go)
        {
            bool P009GG1 = SingletonOptions<控制台>.Instance.P009GG1;
            if (P009GG1)
            {
                Storage storage = go.AddOrGet<Storage>();
                storage.SetDefaultStoredItemModifiers(new List<Storage.StoredItemModifier>
                {
                    Storage.StoredItemModifier.Hide,
                    Storage.StoredItemModifier.Seal,
                    Storage.StoredItemModifier.Insulate
                });
            }
        }
    }
}
