﻿using ElementData;
using HarmonyLib;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace E_铅隔绝辐射
{
    [HarmonyPatch(typeof(ElementLoader), "CopyEntryToElement")]
    public class 铅完全阻隔辐射
    {
        // 修改 Postfix 方法，直接操作 elem 对象
        private static void Postfix(ElementEntry entry, Element elem)
        {
            // 检查当前正在处理的元素ID是否为 "Lead"
            if (entry.elementId == "Lead")
            {
                // 直接修改 elem 对象的属性，这才是游戏最终使用的对象
                elem.radiationAbsorptionFactor = 10f;
            }
        }
    }
}
