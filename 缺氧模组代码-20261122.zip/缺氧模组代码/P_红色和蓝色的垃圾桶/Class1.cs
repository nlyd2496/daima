﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P_红色和蓝色的垃圾桶
{
    public class Class1
    {
    }
}
