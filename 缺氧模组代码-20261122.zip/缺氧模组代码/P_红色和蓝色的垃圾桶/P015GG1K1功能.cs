﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace P_红色和蓝色的垃圾桶
{
    public class P015GG1K1 : KMonoBehaviour, ISim1000ms
    {
        
        public void Sim1000ms(float dt)
        {
            

            foreach (GameObject go in this.storage.items)
            {
                go.DeleteObject();
            }
        }
        
        protected override void OnSpawn()
        {
            base.OnSpawn();
        }
        
        [MyCmpGet]
        internal Storage storage;
        
    }
}
