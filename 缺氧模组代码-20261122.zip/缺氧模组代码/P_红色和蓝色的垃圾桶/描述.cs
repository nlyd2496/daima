﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HarmonyLib;
using STRINGS;
using KMod;
using PeterHan.PLib.Core;
using PeterHan.PLib.Database;
using Klei.AI;
using PeterHan.PLib.Options;

namespace P_红色和蓝色的垃圾桶
{

    public class STRINGS
    {
        public static void DoReplacement()
        {
            LocString.CreateLocStringKeys(typeof(STRINGS), "");
        }
        // 控制器
        
        // 建筑描述
        public class BUILDINGS
        {
            public class PREFABS
            {
                public class P015GG1
                {
                    public static LocString NAME = UI.FormatAsLink("蓝色垃圾桶", "P015GG1");
                    public static LocString EFFECT = "不要小瞧我，我能吃下一切。";
                    public static LocString DESC = "喜欢一个人，就要接受她的一切。";
                }
                public class P015GG1L2
                {
                    public static LocString NAME = UI.FormatAsLink("蓝蓝色垃圾桶", "P015GG1");
                    public static LocString EFFECT = "我是蓝色垃圾箱的双胞胎弟弟蓝色二号。";
                }
                public class P015GG1L3
                {
                    public static LocString NAME = UI.FormatAsLink("粉色垃圾桶", "P015GG1");
                    public static LocString EFFECT = "我是蓝色二号的姐姐，粉色一号。";
                }
                public class P015GG1L4
                {
                    public static LocString NAME = UI.FormatAsLink("粉粉色垃圾桶", "P015GG1");
                    public static LocString EFFECT = "我是粉色一号的双胞胎妹妹，粉色二号。";
                }
            }
        }
    }
}
