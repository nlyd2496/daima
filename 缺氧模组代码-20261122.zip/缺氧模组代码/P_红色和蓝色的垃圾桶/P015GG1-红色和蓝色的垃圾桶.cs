﻿using Database;
using HarmonyLib;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TUNING;
using UnityEngine;

namespace P_红色和蓝色的垃圾桶
{
    public class P015GG1 : IBuildingConfig
    {
        
        public override BuildingDef CreateBuildingDef()
        {
            string id = "P015GG1";
            int width = 1;
            int height = 1;
            string anim = "P015GG1L1_kanim";
            int hitpoints = 30;
            float construction_time = 3f;
            float[] tier = BUILDINGS.CONSTRUCTION_MASS_KG.TIER2;
            string[] raw_MINERALS = MATERIALS.RAW_MINERALS;
            float melting_point = 1600f;
            BuildLocationRule build_location_rule = BuildLocationRule.OnFloor;
            EffectorValues none = NOISE_POLLUTION.NONE;
            BuildingDef buildingDef = BuildingTemplates.CreateBuildingDef(id, width, height, anim, hitpoints, construction_time, tier, raw_MINERALS, melting_point, build_location_rule, new EffectorValues
            {
                amount = 3,
                radius = 2
            }, none, 0.2f);
            buildingDef.Floodable = false;
            buildingDef.AudioCategory = "Metal";
            buildingDef.Overheatable = false;
            buildingDef.PermittedRotations = PermittedRotations.FlipH;
            // buildingDef.LogicInputPorts = LogicOperationalController.CreateSingleInputPortList(new CellOffset(0, 0));
            return buildingDef;
        }
        
        public override void ConfigureBuildingTemplate(GameObject go, Tag prefab_tag)
        {
            SoundEventVolumeCache.instance.AddVolume("storagelocker_kanim", "StorageLocker_Hit_metallic_low", NOISE_POLLUTION.NOISY.TIER1);
            Prioritizable.AddRef(go);
            Storage storage = go.AddOrGet<Storage>();
            storage.showInUI = true;
            storage.allowItemRemoval = true;
            storage.showDescriptor = true;
            storage.storageFilters = STORAGEFILTERS.NOT_EDIBLE_SOLIDS;
            storage.storageFullMargin = STORAGE.STORAGE_LOCKER_FILLED_MARGIN;
            storage.fetchCategory = Storage.FetchCategory.GeneralStorage;
            go.AddOrGet<CopyBuildingSettings>().copyGroupTag = GameTags.StorageLocker;
            go.AddOrGet<P015GG1K1>(); // 垃圾桶功能控制
            go.AddOrGet<StorageLocker>();


        }

        public override void DoPostConfigureComplete(GameObject go)
        {
            go.AddOrGetDef<StorageController.Def>();
            // go.AddOrGet<LogicOperationalController>();
            go.AddOrGet<Automatable>();
        }
        
        public const string ID = "P015GG1";
        
    }
    [HarmonyPatch(typeof(BuildingFacades), MethodType.Constructor, new Type[] { typeof(ResourceSet) })]
    public static class 蓝图系统A011GG1
    {
        public static void Postfix(BuildingFacades __instance)
        {
            __instance.Add("P015GG1L2",
                STRINGS.BUILDINGS.PREFABS.P015GG1L2.NAME, STRINGS.BUILDINGS.PREFABS.P015GG1L2.EFFECT, PermitRarity.Universal,
                "P015GG1", "P015GG1L2_kanim", null, null, null ,null );
            __instance.Add("P015GG1L3",
                STRINGS.BUILDINGS.PREFABS.P015GG1L3.NAME, STRINGS.BUILDINGS.PREFABS.P015GG1L3.EFFECT, PermitRarity.Universal,
                "P015GG1", "P015GG1L3_kanim", null, null, null, null);
            __instance.Add("P015GG1L4",
                STRINGS.BUILDINGS.PREFABS.P015GG1L4.NAME, STRINGS.BUILDINGS.PREFABS.P015GG1L4.EFFECT, PermitRarity.Universal,
                "P015GG1", "P015GG1L4_kanim", null, null, null, null);
        }
    }
}
