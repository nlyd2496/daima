﻿using System;
using HarmonyLib;
using KMod;
using PeterHan.PLib.Core;
using PeterHan.PLib.Options;
using UnityEngine.Diagnostics;

namespace P_红色和蓝色的垃圾桶
{
    public class ModLoad : UserMod2
	{
        public static string Namespace { get; private set; }
        public override void OnLoad(Harmony harmony)
		{           
            base.OnLoad(harmony);
            ModLoad.Namespace = base.GetType().Namespace;
            PUtil.InitLibrary(true);
            Namespace = base.GetType().Namespace;           
        }
    }
}