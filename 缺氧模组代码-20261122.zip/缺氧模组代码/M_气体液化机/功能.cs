﻿using System;
using System.Collections.Generic;
using KSerialization;
using STRINGS;
using UnityEngine;

namespace M_气体液化机
{
    [SerializationConfig(MemberSerialization.OptIn)]
    [AddComponentMenu("KMonoBehaviour/scripts/M006GG1K1")]
    // public class M006GG1K1 : KMonoBehaviour, ISaveLoadable, IGameObjectEffectDescriptor, ISim200ms
    public class M006GG1K1 : KMonoBehaviour, ISaveLoadable, ISim200ms
    {
        public float lastGasTemp { get; private set; }

        // 定义气体 → (液态元素, 目标温度 K)
        private static readonly Dictionary<SimHashes, (SimHashes liquidElement, float targetTempK)> GasToLiquidMap = new Dictionary<SimHashes, (SimHashes, float)>
    {
        { SimHashes.Oxygen,                (SimHashes.LiquidOxygen,                72f)  }, // (-218.8 + -183)/2 ≈ -201°C → 72K
        { SimHashes.Hydrogen,              (SimHashes.LiquidHydrogen,              17f)  }, // (-259.2 + -252.2)/2 ≈ -256°C → 17K
        { SimHashes.ChlorineGas,           (SimHashes.Chlorine,                   205f)  }, // (-101 + -34.6)/2 ≈ -68°C → 205K
        { SimHashes.Steam,                 (SimHashes.Water,                      322f)  }, // (-0.6 + 99.4)/2 = 49.4 → 49°C → 322K
        { SimHashes.EthanolGas,            (SimHashes.Ethanol,                    255f)  }, // (-114.1 + 78.4)/2 ≈ -17.85 → -18°C → 255K
        { SimHashes.Methane,               (SimHashes.LiquidMethane,              101f)  }, // (-182.6 + -161.5)/2 ≈ -172°C → 101K
        { SimHashes.CarbonDioxide,         (SimHashes.LiquidCarbonDioxide,        221f)  }, // (-56.5 + -48.1)/2 ≈ -52.3 → -52°C → 221K
    };

        protected override void OnPrefabInit()
        {
            base.OnPrefabInit();
            base.Subscribe(-592767678, OnOperationalChanged); // OperationalChanged
            base.Subscribe(824508782, OnActiveChanged);       // ActiveChanged
        }

        protected override void OnSpawn()
        {
            base.OnSpawn();
            this.cooledAirOutputCell = this.building.GetUtilityOutputCell();
        }

        public void Sim200ms(float dt)
        {
            if (this.operational != null && !this.operational.IsOperational)
            {
                this.operational.SetActive(false, false);
                return;
            }
            UpdateState(dt);
        }

        private void UpdateState(float dt)
        {
            bool hasValidInput = false;
            List<GameObject> items = this.storage.items;

            for (int i = 0; i < items.Count; i++)
            {
                PrimaryElement pe = items[i].GetComponent<PrimaryElement>();
                if (pe == null || pe.Mass <= 0f)
                    continue;

                SimHashes inputElement = pe.ElementID;

                // 检查是否支持该气体
                if (!GasToLiquidMap.TryGetValue(inputElement, out var mapping))
                    continue;

                hasValidInput = true;
                this.lastGasTemp = pe.Temperature;

                // 使用预设的目标温度（K）
                float outputTemp = mapping.targetTempK;

                // 输出对应的液态元素
                Game.Instance.liquidConduitFlow.AddElement(
                    this.cooledAirOutputCell,
                    mapping.liquidElement,
                    pe.Mass,
                    outputTemp,
                    pe.DiseaseIdx,
                    pe.DiseaseCount
                );

                // 清空输入
                pe.KeepZeroMassObject = true;
                pe.Mass = 0f;
                pe.ModifyDiseaseCount(-pe.DiseaseCount, "M006GG1K1.Consumed");

                break; // 一次处理一个
            }

            this.operational.SetActive(hasValidInput, false);
            UpdateStatus();
        }

        private void OnOperationalChanged(object data)
        {
            if (this.operational.IsOperational)
            {
                UpdateState(0f);
            }
        }

        private void OnActiveChanged(object data)
        {
            UpdateStatus();
        }

        private void UpdateStatus()
        {
            if (this.operational.IsActive)
            {
                if (this.statusHandle == Guid.Empty)
                {
                    this.statusHandle = this.selectable.SetStatusItem(
                        Db.Get().StatusItemCategories.Main,
                        Db.Get().BuildingStatusItems.Cooling,
                        null
                    );
                }
            }
            else
            {
                this.statusHandle = this.selectable.SetStatusItem(
                    Db.Get().StatusItemCategories.Main,
                    null,
                    null
                );
            }
        }
        /*
        public List<Descriptor> GetDescriptors(GameObject go)
        {
            List<Descriptor> list = new List<Descriptor>();
            Descriptor desc = new Descriptor();
            desc.SetupDescriptor(
                "Liquefies supported gases at optimal liquid temperature",
                "Converts specific gases (Oxygen, Hydrogen, Chlorine, Steam, Ethanol, Methane, CO₂) into their liquid forms at stable mid-range temperatures. No heat is produced.",
                Descriptor.DescriptorType.Effect
            );
            list.Add(desc);
            return list;
        }
        */
        // ===== 组件引用 =====
        [MyCmpReq] private KSelectable selectable;
        [MyCmpReq] protected Storage storage;
        [MyCmpReq] protected Operational operational;
        [MyCmpReq] private ConduitConsumer consumer;
        [MyCmpReq] private BuildingComplete building;

        private int cooledAirOutputCell = -1;
        private Guid statusHandle = Guid.Empty;
    }
}