﻿using System;
using HarmonyLib;
using UnityEngine;

namespace M_气体液化机
{
    [HarmonyPatch(typeof(Db), "Initialize")]
    public class 研究栏
    {
        public static void Postfix()
        {
            Db.Get().Techs.Get("PressureManagement").unlockedItemIDs.Add("M006GG1");
        }
    }
}
