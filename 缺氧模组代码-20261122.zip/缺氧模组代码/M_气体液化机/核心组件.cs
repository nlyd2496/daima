﻿using System;
using HarmonyLib;
using KMod;
using PeterHan.PLib.Core;
using PeterHan.PLib.Options;
using UnityEngine.Diagnostics;

namespace M_气体液化机
{
    public class ModLoad : UserMod2
	{
        public static string Namespace { get; private set; }
        public override void OnLoad(Harmony harmony)
		{
            base.OnLoad(harmony);
            PUtil.InitLibrary(true);
            Namespace = base.GetType().Namespace;
            ModLoad.Namespace = base.GetType().Namespace;
            // new POptions().RegisterOptions(this, typeof(控制台));
        }
    }
}