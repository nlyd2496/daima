﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HarmonyLib;
using STRINGS;
using KMod;
using PeterHan.PLib.Core;
using PeterHan.PLib.Database;
using Klei.AI;
using PeterHan.PLib.Options;

namespace M_气体液化机
{

    public class STRINGS
    {
        public static void DoReplacement()
        {
            LocString.CreateLocStringKeys(typeof(STRINGS), "");
        }
        // 控制器
        
        // 建筑描述
        public class BUILDINGS
        {
            public class PREFABS
            {
                public class M006GG1
                {
                    public static LocString NAME = UI.FormatAsLink("气体液化机", "M006GG1");
                    public static LocString EFFECT = new LocString(
                        "将部分" + UI.FormatAsLink("气体", "ELEMENTS_GAS") + "气体液化成对应的"+UI.FormatAsLink("液体", "ELEMENTS_LIQUID") +
                        "\n\n气态氧转化为液态氧" +
                        "\n\n气态氢转换为液态氢" +
                        "\n\n气态二氧化碳转换为液态二氧化碳" +
                        "\n\n气态甲烷转换为液态甲烷" +
                        "\n\n气态氯转换为液态氯" +
                        "\n\n气态水转换为液态水"
                        );
                    public static LocString DESC = "夏国重工";
                }
            }
        }
    }
}
