﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HarmonyLib;
using STRINGS;
using KMod;
using PeterHan.PLib.Core;
using PeterHan.PLib.Database;
using Klei.AI;
using PeterHan.PLib.Options;

namespace P_安全门
{

    public class STRINGS
    {
        public static void DoReplacement()
        {
            LocString.CreateLocStringKeys(typeof(STRINGS), "");
        }
        // 控制器
        
        // 建筑描述
        public class BUILDINGS
        {
            public class PREFABS
            {
                public class EMERGENYDOOR20230213
                {
                    public static LocString NAME = UI.FormatAsLink("安全门", "EMERGENYDOOR20230213");
                    public static LocString EFFECT = "高2格，宽2格，我们的目标是更大更快更强。黑海重工集团倾力大造，质量有保证。";
                    public static LocString DESC = "您的安全，由我守护。";

                }
            }
        }
    }
}
