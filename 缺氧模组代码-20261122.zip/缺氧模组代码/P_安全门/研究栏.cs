﻿using System;
using HarmonyLib;
using UnityEngine;

namespace P_安全门
{
    [HarmonyPatch(typeof(Db), "Initialize")]
    public class 研究栏
    {
        public static void Postfix()
        {
            Db.Get().Techs.Get("Combustion").unlockedItemIDs.Add("EMERGENYDOOR20230213");
        }
    }
}
