﻿using Newtonsoft.Json;
using PeterHan.PLib.Options;

namespace C_气体液化机
{
    [RestartRequired]
    [JsonObject(MemberSerialization.OptIn)]
    [ConfigFile("C030GG1.json", true, false)]
    // [ModInfo("https://space.bilibili.com/30725645", "mmm.png", true)]

    public class 控制台 : SingletonOptions<控制台>
    {   
        
    }
}
