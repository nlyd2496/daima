﻿using System;
using System.Collections.Generic;
using TUNING;
using UnityEngine;

public class C030GG1 : IBuildingConfig
{
    public override BuildingDef CreateBuildingDef()
    {
        string id = "C030GG1";
        int width = 3;
        int height = 3;
        string anim = "C030GG1_kanim";
        int hitpoints = 100;
        float construction_time = 120f;
        float[] tier = BUILDINGS.CONSTRUCTION_MASS_KG.TIER3;
        string[] raw_METALS = MATERIALS.REFINED_METALS;
        float melting_point = 1600f;
        BuildLocationRule build_location_rule = BuildLocationRule.OnFloor;
        EffectorValues tier2 = NOISE_POLLUTION.NOISY.TIER2;
        BuildingDef buildingDef = BuildingTemplates.CreateBuildingDef(id, width, height, anim, hitpoints, construction_time, tier, raw_METALS, melting_point, build_location_rule, BUILDINGS.DECOR.NONE, tier2, 0.2f);
        BuildingTemplates.CreateElectricalBuildingDef(buildingDef);
        buildingDef.EnergyConsumptionWhenActive = 480f;
        buildingDef.SelfHeatKilowattsWhenActive = 30f;
        buildingDef.ExhaustKilowattsWhenActive = 10f;
        buildingDef.ThermalConductivity = 5f;
        buildingDef.InputConduitType = ConduitType.Gas;
        buildingDef.OutputConduitType = ConduitType.Liquid;
        buildingDef.UtilityInputOffset = new CellOffset(0, 1);
        buildingDef.UtilityOutputOffset = new CellOffset(0, 0);
        buildingDef.PermittedRotations = PermittedRotations.FlipH;
        buildingDef.ViewMode = OverlayModes.LiquidConduits.ID;

        buildingDef.LogicInputPorts = LogicOperationalController.CreateSingleInputPortList(new CellOffset(0, 1));

        return buildingDef;
    }
    public override void ConfigureBuildingTemplate(GameObject go, Tag prefab_tag)
    {
        go.AddOrGet<LoopingSounds>();
        go.AddOrGet<C030GG1K1>();

        go.AddOrGet<KBatchedAnimHeatPostProcessingEffect>();
        Storage storage = BuildingTemplates.CreateDefaultStorage(go, false);
        storage.showInUI = true;
        storage.SetDefaultStoredItemModifiers(new List<Storage.StoredItemModifier>
        {
            Storage.StoredItemModifier.Hide,
            Storage.StoredItemModifier.Seal,
            Storage.StoredItemModifier.Insulate
        });

        ConduitConsumer conduitConsumer = go.AddOrGet<ConduitConsumer>();
        conduitConsumer.conduitType = ConduitType.Gas;
        conduitConsumer.consumptionRate = 2f;
        conduitConsumer.capacityKG = 10f;
        conduitConsumer.forceAlwaysSatisfied = true;
        conduitConsumer.wrongElementResult = ConduitConsumer.WrongElementResult.Store;



        ConduitDispenser conduitDispenser = go.AddOrGet<ConduitDispenser>();
        conduitDispenser.conduitType = ConduitType.Liquid;
        conduitDispenser.invertElementFilter = true;
        



    }
    public override void DoPostConfigureComplete(GameObject go)
    {
        go.AddOrGet<LogicOperationalController>();
        go.AddOrGetDef<PoweredActiveController.Def>();
    }
}
