﻿using System;
using HarmonyLib;
using UnityEngine;

namespace C_气体液化机
{
    [HarmonyPatch(typeof(Db), "Initialize")]
    public class 研究栏
    {
        public static void Postfix()
        {
            Db.Get().Techs.Get("PressureManagement").unlockedItemIDs.Add("C030GG1");
        }
    }
}
