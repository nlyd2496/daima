﻿using Database;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TUNING;
using UnityEngine;
using static ResearchTypes;

namespace R_圣诞礼物
{
    public class R024GG1 : IBuildingConfig
    {
        public override BuildingDef CreateBuildingDef()
        {
            string id = "R024GG1";
            int width = 1;
            int height = 1;
            string anim = "R024GG1_tag_kanim";
            int hitpoints = 1000;
            float construction_time = 60f;
            float[] construction_mass = new float[]
            {
                23f
            };
            string[] any_BUILDABLE = MATERIALS.ANY_BUILDABLE;
            float melting_point = 9999f;
            BuildLocationRule build_location_rule = BuildLocationRule.Anywhere;
            EffectorValues none = NOISE_POLLUTION.NONE;
            BuildingDef buildingDef = BuildingTemplates.CreateBuildingDef(id, width, height, anim, hitpoints, construction_time, construction_mass, any_BUILDABLE, melting_point, build_location_rule, new EffectorValues
            {
                amount = 3,
                radius = 3
            }, none, 0.2f);
            buildingDef.Floodable = false;
            buildingDef.Overheatable = false;
            buildingDef.OverheatTemperature = 2273.15f;
            buildingDef.ObjectLayer = ObjectLayer.Plants;
            buildingDef.SceneLayer = Grid.SceneLayer.Creatures;
            buildingDef.PermittedRotations = PermittedRotations.FlipH;
            return buildingDef;
        }
        public override void ConfigureBuildingTemplate(GameObject go, Tag prefab_tag)
        {
            go.GetComponent<KPrefabID>().AddTag(GameTags.Decoration, false);
        }
        public override void DoPostConfigureComplete(GameObject go)
        {
            SelectableSign selectable = go.AddOrGet<SelectableSign>();
            selectable.AnimationNames = new List<string>()
            {
                "art_a",
                "art_b",
                "art_c",
                "art_d",
                "art_e",
                "art_f",
                "art_g",
                "art_h",
                "art_i",
                "art_j",
                "art_k",
                "art_l",
                "art_m",
                "art_n",
                "art_o",
                "art_p",
                "art_q",
                "art_r",
                "art_s",
                "art_t",
                "art_u",
            }
            ;
        }
        public const string ID = "R024GG1";
    }
}
