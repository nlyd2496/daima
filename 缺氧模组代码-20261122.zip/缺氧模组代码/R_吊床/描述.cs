﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HarmonyLib;
using STRINGS;
using KMod;
using PeterHan.PLib.Core;
using PeterHan.PLib.Database;
using Klei.AI;
using PeterHan.PLib.Options;

namespace R_吊床
{
    public class STRINGS
    {
        public static void DoReplacement()
        {
            LocString.CreateLocStringKeys(typeof(STRINGS), "");
        }
        public class BUILDINGS
        {
            public class PREFABS
            {
                public class R006GG1
                {
                    public static LocString NAME = UI.FormatAsLink("海湾吊床", "R006GG1");
                    public static LocString EFFECT = "天蓝的色彩，轻巧的造型，圆润的曲线，五一不透露出它的美。小人睡在上面有点晃，是真的吗，并不是，那是调皮的小人在做着美梦。";
                    public static LocString DESC = "哪怕只是离地一尺，那也是天空的味道。";
                }
                public class R006GG1L2
                {
                    public static LocString NAME = NAME = UI.FormatAsLink("北欧吊床", "R006GG1");
                    public static LocString DESC = "怀念逝去的过往，巨大与精制的美。";
                }
            }
        }
    }
}
