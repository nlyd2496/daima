﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace C_废液桶
{
    public class K1C026GG1 : KMonoBehaviour, ISim1000ms
    {
        public void Sim1000ms(float dt)
        {

            foreach (GameObject go in this.storage.items)
            {
                go.DeleteObject();
            }
        }
        protected override void OnSpawn()
        {
            base.OnSpawn();
        }
        [MyCmpGet]
        internal Storage storage;
    }
}
