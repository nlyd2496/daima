﻿using System;
using System.Collections.Generic;
using Database;
using HarmonyLib;

namespace M_精炼系统
{
    [HarmonyPatch(typeof(Db), "Initialize")]
    public static class Db_Initialize_Patch
    {
        public static void Postfix()
        {
            ModUtil.AddBuildingToPlanScreen("Oxygen", "AdvacnedElectrolyzer");
            Db_Initialize_Patch.AddBuildingToTechnology("ImprovedOxygen", "AdvacnedElectrolyzer");
        }
        public static void AddBuildingToTechnology(string tech, string buildingId)
        {
            Traverse traverse = Traverse.Create(typeof(Techs));
            Dictionary<string, string[]> dictionary;
            if (traverse == null)
            {
                dictionary = null;
            }
            else
            {
                Traverse traverse2 = traverse.Field("TECH_GROUPING");
                dictionary = ((traverse2 != null) ? traverse2.GetValue<Dictionary<string, string[]>>() : null);
            }
            Dictionary<string, string[]> dictionary2 = dictionary;
            if (dictionary2 != null)
            {
                if (dictionary2.ContainsKey(tech))
                {
                    List<string> list = new List<string>(dictionary2[tech])
                    {
                        buildingId
                    };
                    dictionary2[tech] = list.ToArray();
                    return;
                }
                Debug.LogWarning("Could not find '" + tech + "' tech in TECH_GROUPING.");
                return;
            }
            else
            {
                Tech tech2 = Db.Get().Techs.TryGet(tech);
                if (tech2 == null)
                {
                    Debug.LogWarning("Could not find '" + tech + "' tech.");
                    return;
                }
                Traverse traverse3 = Traverse.Create(tech2);
                if (traverse3 == null)
                {
                    return;
                }
                Traverse traverse4 = traverse3.Field("unlockedItemIDs");
                if (traverse4 == null)
                {
                    return;
                }
                List<string> value = traverse4.GetValue<List<string>>();
                if (value == null)
                {
                    return;
                }
                value.Add(buildingId);
                return;
            }
        }
    }
}
