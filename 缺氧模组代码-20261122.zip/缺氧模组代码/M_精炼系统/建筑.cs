﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using HarmonyLib;
using Newtonsoft.Json;
using PeterHan.PLib.Options;
using TUNING;
using UnityEngine;

namespace M_精炼系统
{
    public class IndustrialElectrolyzerConfig : IBuildingConfig
    {


        public override BuildingDef CreateBuildingDef()
        {
            float[] array = new float[]
            {
            BUILDINGS.CONSTRUCTION_MASS_KG.TIER3[0],
            50f
            };
            string[] array2 = new string[]
            {
            "Metal",
            "Salt"
            };
            BuildingDef buildingDef = BuildingTemplates.CreateBuildingDef("AdvacnedElectrolyzer", 2, 2, "electrolyzer_kanim", 250, 60f, false ? array : BUILDINGS.CONSTRUCTION_MASS_KG.TIER3, false ? array2 : MATERIALS.ALL_METALS, 3200f, BuildLocationRule.Anywhere, BUILDINGS.DECOR.PENALTY.TIER2, NOISE_POLLUTION.NOISY.TIER2, 0.2f);
            buildingDef.RequiresPowerInput = true;
            buildingDef.PowerInputOffset = new CellOffset(1, 0);
            buildingDef.EnergyConsumptionWhenActive = 50f;
            buildingDef.ExhaustKilowattsWhenActive = 5f;
            buildingDef.SelfHeatKilowattsWhenActive = 5f;
            buildingDef.ViewMode = OverlayModes.GasConduits.ID;
            buildingDef.MaterialCategory = MATERIALS.REFINED_METALS;
            buildingDef.AudioCategory = "HollowMetal";
            buildingDef.InputConduitType = ConduitType.Liquid;
            buildingDef.UtilityInputOffset = new CellOffset(0, 0);
            buildingDef.OutputConduitType = ConduitType.Gas;
            buildingDef.UtilityOutputOffset = new CellOffset(1, 1);
            buildingDef.PermittedRotations = PermittedRotations.FlipH;
            buildingDef.LogicInputPorts = LogicOperationalController.CreateSingleInputPortList(new CellOffset(1, 0));
            GeneratedBuildings.RegisterWithOverlay(OverlayScreen.GasVentIDs, "AdvacnedElectrolyzer");
            return buildingDef;
        }

        public override void ConfigureBuildingTemplate(GameObject go, Tag prefab_tag)
        {
            go.GetComponent<KPrefabID>().AddTag(RoomConstraints.ConstraintTags.IndustrialMachinery, false);
            go.AddOrGet<Structure>();
            go.AddOrGet<LoopingSounds>();
            Storage storage = go.AddOrGet<Storage>();
            storage.capacityKg = 6f;
            storage.showInUI = true;
            ConduitConsumer conduitConsumer = go.AddOrGet<ConduitConsumer>();
            conduitConsumer.conduitType = ConduitType.Liquid;
            conduitConsumer.capacityTag = GameTags.AnyWater;
            conduitConsumer.capacityKG = storage.capacityKg;
            conduitConsumer.forceAlwaysSatisfied = true;
            conduitConsumer.wrongElementResult = ConduitConsumer.WrongElementResult.Dump;
            go.AddOrGet<IndustrialElectrolyzer>().portInfo = this.secondaryPort;
            Prioritizable.AddRef(go);
        }

        public override void DoPostConfigurePreview(BuildingDef def, GameObject go)
        {
            base.DoPostConfigurePreview(def, go);
            this.AttachPort(go);
        }

        public override void DoPostConfigureUnderConstruction(GameObject go)
        {
            base.DoPostConfigureUnderConstruction(go);
            this.AttachPort(go);
        }

        public override void DoPostConfigureComplete(GameObject go)
        {
            go.AddOrGet<LogicOperationalController>();
            go.AddOrGetDef<PoweredActiveController.Def>();
        }

        private void AttachPort(GameObject go)
        {
            go.AddComponent<ConduitSecondaryOutput>().portInfo = this.secondaryPort;
        }

        public const string ID = "AdvacnedElectrolyzer";

        // 定义输出管道信息
        private readonly ConduitPortInfo secondaryPort = new ConduitPortInfo(ConduitType.Gas, new CellOffset(0, 1));

    }
    
}
