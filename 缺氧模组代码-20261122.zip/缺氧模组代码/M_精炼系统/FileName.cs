﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HarmonyLib;
using KMod;
using Newtonsoft.Json;
using PeterHan.PLib.Core;
using PeterHan.PLib.Options;
using UnityEngine;

namespace M_精炼系统
{
    public sealed class AdvancedElectrolyzersMod : UserMod2
    {
        public override void OnLoad(Harmony harmony)
        {
            base.OnLoad(harmony);
            
            PUtil.InitLibrary(false);
            
            AdvancedElectrolyzersMod.mod_loc = base.mod.relative_root;
        }

        [Conditional("DEBUG")]
        public static void Log(object obj, LogType logLevel = LogType.Log)
        {
            string obj2 = "[AdvancedElectrolyzer]: " + ((obj != null) ? obj.ToString() : null);
            switch (logLevel)
            {
                case LogType.Error:
                case LogType.Exception:
                    global::Debug.LogError(obj2);
                    return;
                case LogType.Assert:
                case LogType.Warning:
                    global::Debug.LogWarning(obj2);
                    return;
            }
            global::Debug.Log(obj2);
        }

        public static string mod_loc;

        

        
    }

}
