﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using STRINGS;

namespace M_精炼系统
{

        public class STRINGS
        {
            public class BUILDINGS
            {
                public class PREFABS
                {
                    public class ADVACNEDELECTROLYZER
                    {
                        public static LocString NAME = UI.FormatAsLink("Industrial Electrolyzer", "AdvacnedElectrolyzer");
                        public static LocString DESC = "Water goes in one end. life sustaining oxygen comes out the other.";
                        public static LocString EFFECT = string.Concat(new string[]
                        {
                        "Converts ",
                        UI.FormatAsLink("Water", "WATER"),
                        " to ",
                        UI.FormatAsLink("Oxygen", "OXYGEN"),
                        " and ",
                        UI.FormatAsLink("Hydrogen", "HYDROGEN"),
                        ". Also converts ",
                        UI.FormatAsLink("Polluted Water", "DIRTYWATER"),
                        " to ",
                        UI.FormatAsLink("Polluted Oxygen", "CONTAMINATEDOXYGEN"),
                        " and ",
                        UI.FormatAsLink("Hydrogen", "HYDROGEN"),
                        ".Through ElectroQuarters off dangerous areas and prevents gases from seeping into the colony while closed, while allowing ",
                        UI.FormatAsLink("Light", "LIGHT"),
                        " and ",
                        UI.FormatAsLink("Decor", "DECOR"),
                        " to pass through.\n\nDuplicants passing through will open the door for a short while, letting gases and liquids to pass through."
                        });
                    }
                }
            }

            public class BUILDING
            {
                public class STATUSITEMS
                {
                    public class INDUSTRIALELECTROLYZERINPUT
                    {
                        public static LocString NAME = "Using {ElementType}: {FlowRate}";
                        public static LocString TOOLTIP = "This building is using {ElementType} from storage at a rate of " + UI.FormatAsNegativeRate("{FlowRate}");
                    }

                    public class INDUSTRIALELECTROLYZEROUTPUT
                    {
                        public static LocString NAME = "Emitting {ElementType}: {FlowRate}";
                        public static LocString TOOLTIP = "This building is releasing {ElementType} at a rate of " + UI.FormatAsPositiveRate("{FlowRate}");
                    }
                }
            }
        }
    
}
