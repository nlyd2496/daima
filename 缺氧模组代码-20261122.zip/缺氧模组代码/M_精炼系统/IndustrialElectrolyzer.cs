﻿using System;
using System.Collections.Generic;
using Klei;
using Klei.AI;
using UnityEngine;

namespace M_精炼系统
{
    public class IndustrialElectrolyzer : StateMachineComponent<IndustrialElectrolyzer.StatesInstance>, ISecondaryOutput
    {
        protected override void OnPrefabInit()
        {
            base.OnPrefabInit();
            Attributes attributes = base.gameObject.GetAttributes();
            this.machinerySpeedAttribute = attributes.Add(Db.Get().Attributes.MachinerySpeed);
            if (IndustrialElectrolyzer.IndustrialElectrolyzerOutputStatusItem == null)
            {
                IndustrialElectrolyzer.IndustrialElectrolyzerOutputStatusItem = new StatusItem("INDUSTRIALELECTROLYZEROUTPUT", "BUILDING", string.Empty, StatusItem.IconType.Info, NotificationType.Neutral, true, OverlayModes.None.ID, true, 129022, null).SetResolveStringCallback(delegate (string str, object data)
                {
                    Tag a = (Tag)data;
                    str = str.Replace("{ElementType}", (a == GameTags.Oxygen) ? "Oxygen" : "Hydrogen");
                    str = str.Replace("{FlowRate}", GameUtil.GetFormattedByTag(GameTags.Oxygen, (a == GameTags.Oxygen) ? 1f : 1f, GameUtil.TimeSlice.PerSecond));
                    return str;
                });
            }
        }

        protected override void OnSpawn()
        {
            base.OnSpawn();
            this.oxygenOutputCell = this.building.GetUtilityOutputCell();
            int cell = Grid.PosToCell(base.transform.GetPosition());
            CellOffset rotatedOffset = this.building.GetRotatedOffset(this.portInfo.offset);

            // 注册氢气输出管道
            this.hydrogenOutputCell = Grid.OffsetCell(cell, rotatedOffset);
            IUtilityNetworkMgr networkManager = Conduit.GetNetworkManager(this.portInfo.conduitType);
            this.hydrogenOutputItem = new FlowUtilityNetwork.NetworkItem(this.portInfo.conduitType, Endpoint.Source, this.hydrogenOutputCell, base.gameObject);
            networkManager.AddToNetworks(this.hydrogenOutputCell, this.hydrogenOutputItem, true);
            this.WaterAccumulator = Game.Instance.accumulators.Add("ElementsConsumed", this);
            this.OxygenAccumulator = Game.Instance.accumulators.Add("OutputElements", this);
            this.HydrogenAccumulator = Game.Instance.accumulators.Add("OutputElements", this);
            KBatchedAnimController component = base.GetComponent<KBatchedAnimController>();
            if (this.hasMeter)
            {
                this.meter = new MeterController(component, "U2H_meter_target", "meter", Meter.Offset.Behind, Grid.SceneLayer.NoLayer, new Vector3(-0.4f, 0.5f, -0.1f), new string[]
                {
                "U2H_meter_target",
                "U2H_meter_tank",
                "U2H_meter_waterbody",
                "U2H_meter_level"
                });
            }
            base.smi.StartSM();
            this.UpdateMeter();
            Tutorial.Instance.oxygenGenerators.Add(base.gameObject);
        }

        protected override void OnCleanUp()
        {
            Tutorial.Instance.oxygenGenerators.Remove(base.gameObject);
            Conduit.GetNetworkManager(this.portInfo.conduitType).RemoveFromNetworks(this.hydrogenOutputCell, this.hydrogenOutputItem, true);
            Game.Instance.accumulators.Remove(this.WaterAccumulator);
            Game.Instance.accumulators.Remove(this.OxygenAccumulator);
            Game.Instance.accumulators.Remove(this.HydrogenAccumulator);
            base.OnCleanUp();
        }

        public bool HasSecondaryConduitType(ConduitType type)
        {
            return this.portInfo.conduitType == type;
        }

        public CellOffset GetSecondaryConduitOffset(ConduitType type)
        {
            return this.portInfo.offset;
        }

        private float GetSpeedMultiplier()
        {
            return this.machinerySpeedAttribute.GetTotalValue() * 1f;
        }

        public void UpdateMeter()
        {
            if (this.hasMeter)
            {
                float positionPercent = Mathf.Clamp01(this.storage.GetMassAvailable(GameTags.AnyWater) / this.storage.capacityKg);
                this.meter.SetPositionPercent(positionPercent);
            }
        }

        public bool CanConvertAtAll()
        {
            bool result = false;
            List<GameObject> items = this.storage.items;
            for (int i = 0; i < items.Count; i++)
            {
                GameObject gameObject = items[i];
                if (gameObject.HasTag(GameTags.AnyWater) && gameObject.GetComponent<PrimaryElement>().Mass > 0.0001f)
                {
                    result = true;
                }
            }
            return result;
        }

        public bool HasEnoughMass()
        {
            float num = 1f * this.GetSpeedMultiplier();
            bool result = true;
            List<GameObject> items = this.storage.items;
            float num2 = 0f;
            for (int i = 0; i < items.Count; i++)
            {
                GameObject gameObject = items[i];
                if (gameObject != null && gameObject.HasTag(GameTags.AnyWater))
                {
                    num2 += gameObject.GetComponent<PrimaryElement>().Mass;
                }
            }
            if (num2 < 1f * num)
            {
                result = false;
            }
            return result;
        }

        private void CheckStorage()
        {
            for (int i = 0; i < this.storage.items.Count; i++)
            {
                GameObject gameObject = this.storage.items[i];
                if (gameObject != null && !gameObject.HasTag(GameTags.AnyWater))
                {
                    i--;
                    this.storage.Remove(gameObject, true);
                    PrimaryElement component = gameObject.GetComponent<PrimaryElement>();
                    int disease_count = (int)((float)component.DiseaseCount * component.Mass);
                    SimMessages.AddRemoveSubstance(Grid.PosToCell(base.transform.GetPosition()), component.Element.id, CellEventLogger.Instance.ConduitConsumerWrongElement, component.Mass, component.Temperature, component.DiseaseIdx, disease_count, true, -1);
                }
            }
        }

        private void ConvertMass()
        {
            SimUtil.DiseaseInfo diseaseInfo = SimUtil.DiseaseInfo.Invalid;
            diseaseInfo.idx = byte.MaxValue;
            diseaseInfo.count = 0;
            float speedMultiplier = this.GetSpeedMultiplier();
            float num = 0f;
            float num2 = 0f;
            float num3 = 0f;
            float num4 = 0f;
            float num5 = 1f * speedMultiplier;
            Tag tag = SimHashes.DirtyWater.CreateTag();
            Tag tag2 = SimHashes.SaltWater.CreateTag();
            Tag tag3 = SimHashes.Brine.CreateTag();
            bool flag = false;
            for (int i = 0; i < this.storage.items.Count; i++)
            {
                GameObject gameObject = this.storage.items[i];
                if (gameObject != null && gameObject.HasTag(GameTags.AnyWater))
                {
                    PrimaryElement component = gameObject.GetComponent<PrimaryElement>();
                    float num6 = Mathf.Min(num5, component.Mass);
                    int num7 = (int)(num6 / component.Mass * (float)component.DiseaseCount);
                    component.Mass -= num6;
                    component.ModifyDiseaseCount(-num7, "IndustrialElectrolyzer.ConvertMass");
                    if (gameObject.HasTag(tag2))
                    {
                        num += num6 * 1f;
                        num2 += num6 * 1f;
                        num3 += num6 * 1f;
                    }
                    else if (gameObject.HasTag(tag3))
                    {
                        num += num6 * 1f;
                        num2 += num6 * 1f;
                        num3 += num6 * 1f;
                    }
                    else
                    {
                        num += num6 * 1f;
                        num2 += num6 * 1f;
                    }
                    num4 += num6;
                    if (gameObject.HasTag(tag) && num6 > 0.0001f)
                    {
                        flag = true;
                    }
                    diseaseInfo = SimUtil.CalculateFinalDiseaseInfo(diseaseInfo.idx, diseaseInfo.count, component.DiseaseIdx, component.DiseaseCount);
                    num5 -= num6;
                    if (num5 <= 0f)
                    {
                        global::Debug.Assert(num5 <= 0f);
                        break;
                    }
                }
            }
            float temperature = base.GetComponent<PrimaryElement>().Temperature;
            if (this.onConvertMass != null && num4 > 0.0001f)
            {
                this.onConvertMass(num4);
            }
            ConduitFlow flowManager = Conduit.GetFlowManager(this.portInfo.conduitType);
            SimHashes element = flag ? SimHashes.ContaminatedOxygen : SimHashes.Oxygen;
            float num8 = flowManager.AddElement(this.oxygenOutputCell, element, num * speedMultiplier, Mathf.Max(1f, temperature), diseaseInfo.idx, diseaseInfo.count / 2);
            ReportManager.Instance.ReportValue(ReportManager.ReportType.OxygenCreated, num8, base.gameObject.GetProperName(), null);
            Game.Instance.accumulators.Accumulate(this.OxygenAccumulator, num8);
            float amount = flowManager.AddElement(this.hydrogenOutputCell, SimHashes.Hydrogen, num2 * speedMultiplier, Mathf.Max(1f, temperature), diseaseInfo.idx, diseaseInfo.count / 2);
            Game.Instance.accumulators.Accumulate(this.HydrogenAccumulator, amount);
            if (num3 > 0.0001f)
            {
                Element element2 = ElementLoader.FindElementByHash(SimHashes.BleachStone);
                Vector3 vector = this.building.GetRotatedOffset(new CellOffset(1, 0)).ToVector3() + new Vector3(0.5f, 0.5f, 0f) + base.transform.position;
                UnityEngine.Debug.Log("[AE] transform is at " + base.transform.position.ToString());
                string str = "[AE] exit is at ";
                Vector3 vector2 = vector;
                UnityEngine.Debug.Log(str + vector2.ToString());
                element2.substance.SpawnResource(vector, num3, temperature, diseaseInfo.idx, diseaseInfo.count, false, false, false);
            }
            this.storage.Trigger(-1697596308, base.gameObject);
        }

        private bool RoomForPressure
        {
            get
            {
                ConduitFlow flowManager = Conduit.GetFlowManager(this.portInfo.conduitType);
                return flowManager.IsConduitEmpty(this.hydrogenOutputCell) && flowManager.IsConduitEmpty(this.oxygenOutputCell);
            }
        }

        

        public HandleVector<int>.Handle WaterAccumulator { get; private set; }

        public HandleVector<int>.Handle OxygenAccumulator { get; private set; }

        public HandleVector<int>.Handle HydrogenAccumulator { get; private set; }

        [SerializeField]
        public bool hasMeter = true;

        [MyCmpAdd]
        private Storage storage;

        [MyCmpReq]
        private Operational operational;

        // 定义输出管道信息
        [SerializeField]
        public ConduitPortInfo portInfo;

        [MyCmpReq]
        private Building building;

        private const float EPSILON = 0.0001f;

        public Action<float> onConvertMass;

        private static StatusItem IndustrialElectrolyzerOutputStatusItem;

        private MeterController meter;

        private AttributeInstance machinerySpeedAttribute;

        private int hydrogenOutputCell;

        private FlowUtilityNetwork.NetworkItem hydrogenOutputItem;

        private int oxygenOutputCell;

        public class StatesInstance : GameStateMachine<IndustrialElectrolyzer.States, IndustrialElectrolyzer.StatesInstance, IndustrialElectrolyzer, object>.GameInstance
        {
            public StatesInstance(IndustrialElectrolyzer smi) : base(smi)
            {
            }

            public void AddStatusItems()
            {
                this.statusItemEntries.Add(base.master.GetComponent<KSelectable>().AddStatusItem(IndustrialElectrolyzer.IndustrialElectrolyzerOutputStatusItem, GameTags.Oxygen));
                this.statusItemEntries.Add(base.master.GetComponent<KSelectable>().AddStatusItem(IndustrialElectrolyzer.IndustrialElectrolyzerOutputStatusItem, GameTags.Hydrogen));
            }

            public void RemoveStatusItems()
            {
                foreach (Guid guid in this.statusItemEntries)
                {
                    base.master.GetComponent<KSelectable>().RemoveStatusItem(guid, false);
                }
                this.statusItemEntries.Clear();
            }

            private List<Guid> statusItemEntries = new List<Guid>();
        }

        public class States : GameStateMachine<IndustrialElectrolyzer.States, IndustrialElectrolyzer.StatesInstance, IndustrialElectrolyzer>
        {
            public override void InitializeStates(out StateMachine.BaseState default_state)
            {
                default_state = this.disabled;
                this.root.EventTransition(GameHashes.OperationalChanged, this.disabled, (IndustrialElectrolyzer.StatesInstance smi) => !smi.master.operational.IsOperational).EventHandler(GameHashes.OnStorageChange, delegate (IndustrialElectrolyzer.StatesInstance smi)
                {
                    smi.master.UpdateMeter();
                });
                this.disabled.Enter("Disabled", delegate (IndustrialElectrolyzer.StatesInstance smi)
                {
                }).EventTransition(GameHashes.OperationalChanged, this.waiting, (IndustrialElectrolyzer.StatesInstance smi) => smi.master.operational.IsOperational);
                this.waiting.Enter("Waiting", delegate (IndustrialElectrolyzer.StatesInstance smi)
                {
                    smi.master.operational.SetActive(false, false);
                }).EventTransition(GameHashes.OnStorageChange, this.converting, (IndustrialElectrolyzer.StatesInstance smi) => smi.master.HasEnoughMass());
                this.converting.Enter("Ready", delegate (IndustrialElectrolyzer.StatesInstance smi)
                {
                    smi.AddStatusItems();
                    smi.master.operational.SetActive(true, false);
                }).Exit("RemoveStatusItems", delegate (IndustrialElectrolyzer.StatesInstance smi)
                {
                    smi.RemoveStatusItems();
                }).Transition(this.waiting, (IndustrialElectrolyzer.StatesInstance smi) => !smi.master.CanConvertAtAll(), UpdateRate.SIM_200ms).Transition(this.blocked, (IndustrialElectrolyzer.StatesInstance smi) => !smi.master.RoomForPressure, UpdateRate.SIM_200ms).Update("ConvertMass", delegate (IndustrialElectrolyzer.StatesInstance smi, float dt)
                {
                    smi.master.CheckStorage();
                    smi.master.ConvertMass();
                }, UpdateRate.SIM_1000ms, true);
                this.blocked.Enter("Blocked", delegate (IndustrialElectrolyzer.StatesInstance smi)
                {
                    smi.master.operational.SetActive(false, false);
                }).Transition(this.converting, (IndustrialElectrolyzer.StatesInstance smi) => smi.master.RoomForPressure, UpdateRate.SIM_200ms);
            }

            public GameStateMachine<IndustrialElectrolyzer.States, IndustrialElectrolyzer.StatesInstance, IndustrialElectrolyzer, object>.State disabled;

            public GameStateMachine<IndustrialElectrolyzer.States, IndustrialElectrolyzer.StatesInstance, IndustrialElectrolyzer, object>.State waiting;

            public GameStateMachine<IndustrialElectrolyzer.States, IndustrialElectrolyzer.StatesInstance, IndustrialElectrolyzer, object>.State converting;

            public GameStateMachine<IndustrialElectrolyzer.States, IndustrialElectrolyzer.StatesInstance, IndustrialElectrolyzer, object>.State blocked;
        }
    }

}
