﻿using PeterHan.PLib.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TUNING;
using UnityEngine;

namespace N_南孚电池
{
    public class N012GGG1 : BaseBatteryConfig
    {
        public override BuildingDef CreateBuildingDef()
        {
            string id = "N012GGG1";
            int width = 3;
            int height = 3;
            string anim = "N012GGG1_kanim";
            int hitpoints = 100;
            float construction_time = 120f;
            float[] tier = BUILDINGS.CONSTRUCTION_MASS_KG.TIER5;
            string[] all_METALS = MATERIALS.ALL_METALS;
            float melting_point = 2400f;
            BuildLocationRule build_location_rule = BuildLocationRule.OnFloor;
            EffectorValues tier2 = NOISE_POLLUTION.NOISY.TIER5;
            BuildingDef buildingDef = BuildingTemplates.CreateBuildingDef(id, width, height, anim, hitpoints, construction_time, tier, all_METALS, melting_point, build_location_rule, BUILDINGS.DECOR.PENALTY.TIER2, tier2, 0.2f);
            buildingDef.GeneratorWattageRating = 100000f;
            buildingDef.GeneratorBaseCapacity = buildingDef.GeneratorWattageRating;
            buildingDef.ExhaustKilowattsWhenActive = 16f;
            buildingDef.SelfHeatKilowattsWhenActive = 4f;
            buildingDef.RequiresPowerOutput = true;
            buildingDef.PowerOutputOffset = new CellOffset(1, 0);
            buildingDef.ViewMode = OverlayModes.Power.ID;
            buildingDef.AudioCategory = "HollowMetal";
            buildingDef.AudioSize = "large";
            buildingDef.LogicInputPorts = LogicOperationalController.CreateSingleInputPortList(new CellOffset(1, 0));
            return buildingDef;
        }
        public override void ConfigureBuildingTemplate(GameObject go, Tag prefab_tag)
        {
            go.GetComponent<KPrefabID>().AddTag(RoomConstraints.ConstraintTags.IndustrialMachinery, false);
            go.GetComponent<KPrefabID>().AddTag(RoomConstraints.ConstraintTags.PowerBuilding, false);
            go.GetComponent<KPrefabID>().AddTag(RoomConstraints.ConstraintTags.GeneratorType, false);
            go.GetComponent<KPrefabID>().AddTag(RoomConstraints.ConstraintTags.HeavyDutyGeneratorType, false);
            EnergyGenerator energyGenerator = go.AddOrGet<EnergyGenerator>();
            energyGenerator.formula = EnergyGenerator.CreateSimpleFormula(SimHashes.EnrichedUranium.CreateTag(), 1f, 100f, SimHashes.Steel, 0.02f, false, new CellOffset(0, 2), 373.15f);
            energyGenerator.meterOffset = Meter.Offset.Behind;
            energyGenerator.SetSliderValue(50f, 0);
            energyGenerator.powerDistributionOrder = 9;
            Storage storage = go.AddOrGet<Storage>();
            storage.capacityKg = 600f;
            go.AddOrGet<LoopingSounds>();
            Prioritizable.AddRef(go);
            ManualDeliveryKG manualDeliveryKG = go.AddOrGet<ManualDeliveryKG>();
            manualDeliveryKG.SetStorage(storage);
            manualDeliveryKG.RequestedItemTag = SimHashes.EnrichedUranium.CreateTag();
            manualDeliveryKG.capacity = storage.capacityKg;
            manualDeliveryKG.refillMass = 100f;
            manualDeliveryKG.choreTypeIDHash = Db.Get().ChoreTypes.PowerFetch.IdHash;
            Tinkerable.MakePowerTinkerable(go);
        }
        public override void DoPostConfigureComplete(GameObject go)
        {
            go.AddOrGet<LogicOperationalController>();
            go.AddOrGetDef<PoweredActiveController.Def>();
        }
        public const string ID = "N012GGG1";
    }
}