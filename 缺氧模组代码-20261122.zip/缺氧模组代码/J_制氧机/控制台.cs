﻿using Newtonsoft.Json;
using PeterHan.PLib.Options;


namespace J_制氧机
{
    [RestartRequired]
    [JsonObject(MemberSerialization.OptIn)]
    [ConfigFile("J001GG1.json", true, false)]
    // [ModInfo("https://space.bilibili.com/30725645", "mmm.png", true)]

    public class 控制台 : SingletonOptions<控制台>
    {
        // 氧气输出量
        [Option("STRINGS.BUILDINGS.PREFABS.J_UI.J001GGG1X1_UI", null, null)][Limit(0, 10)][JsonProperty] public float J001GGG1X1 { get; set; } = 0.88f;
        // 氢气输出量
        [Option("STRINGS.BUILDINGS.PREFABS.J_UI.J001GGG1X2_UI", null, null)][Limit(0, 10)][JsonProperty] public float J001GGG1X2 { get; set; } = 0.11f;

    }
}
