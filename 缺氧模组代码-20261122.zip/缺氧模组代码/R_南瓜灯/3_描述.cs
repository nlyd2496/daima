﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using STRINGS;

namespace R_南瓜灯
{
    public class STRINGS
    {
        public static void DoReplacement()
        {
            LocString.CreateLocStringKeys(typeof(STRINGS), "");
        }
        public class BUILDINGS
        {
            public class PREFABS
            {
                public class R020GG1
                {
                    public static LocString NAME = UI.FormatAsLink("南瓜灯", "R020GG1");
                    public static LocString DESC = "拥有一个可以发出七彩光芒的南瓜灯，你就是万圣节最靓的仔。";
                    public static LocString EFFECT = string.Concat(new string[]
                    { 
                        UI.FormatAsLink("通电", "POWER"),"以提供",UI.FormatAsLink("光照", "LIGHT"), "，负智人在光照下的工作效率会得到提升。"
                    });

                    public static LocString NAME_RED = "红色";
                    public static LocString NAME_GREEN = "绿色";
                    public static LocString NAME_BLUE = "蓝色";
                    public static LocString NAME_SZ = "数值";
                }
            }
        }
    }
}
