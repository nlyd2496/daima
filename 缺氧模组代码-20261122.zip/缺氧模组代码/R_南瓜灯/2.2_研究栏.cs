﻿using System;
using HarmonyLib;
using UnityEngine;

namespace R_南瓜灯
{
    [HarmonyPatch(typeof(Db))]
    [HarmonyPatch("Initialize")]
    public class 研究栏
    {
        public static void Postfix()
        {
            // Db.Get().Techs.Get("Luxury").unlockedItemIDs.Add("R020GG1");
        }
    }
}
