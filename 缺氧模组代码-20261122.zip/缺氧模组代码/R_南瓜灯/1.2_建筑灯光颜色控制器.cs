﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using KSerialization;
using STRINGS;
using UnityEngine;

namespace R_南瓜灯
{
    [SerializationConfig(MemberSerialization.OptIn)]
    public class R020GG1K1 : KMonoBehaviour, IMultiSliderControl
    {

        // 构造函数，初始化滑块控件数组
        public R020GG1K1()
        {
            this.sliderControls = new ISliderControl[]
            {
                new R020GG1K1K1(this), // 初始化1号滑块控件 - 红色通道
                new R020GG1K1K2(this), // 初始化2号滑块控件 - 绿色通道
                new R020GG1K1K3(this)  // 初始化3号滑块控件 - 蓝色通道
            };
        }

        string IMultiSliderControl.SidescreenTitleKey => "STRINGS.BUILDINGS.PREFABS.R020GG1.NAME"; // 控制器名称

        // 复制设置方法
        internal void OnCopySettings(object data)
        {
            var component = ((GameObject)data).GetComponent<R020GG1K1>();
            if (component == null) return;
            RedValue = component.RedValue;
            GreenValue = component.GreenValue;
            BlueValue = component.BlueValue;
            UpdateLightColor();
        }

        // 滑条
        [MyCmpReq]
        public Light2D light2D; // 组件引用

        [Serialize]
        public float RedValue = 10f; // 红色通道值 (0-255)

        [Serialize]
        public float GreenValue = 0f; // 绿色通道值 (0-255)

        [Serialize]
        public float BlueValue = 10f; // 蓝色通道值 (0-255)

        // 更新灯光颜色的方法
        internal void UpdateLightColor()
        {
            // 将0-255范围的RGB值转换为0-1范围的Unity Color
            float normalizedRed = Mathf.Clamp01(RedValue / 255.0f) * 10f;
            float normalizedGreen = Mathf.Clamp01(GreenValue / 255.0f) * 10f;
            float normalizedBlue = Mathf.Clamp01(BlueValue / 255.0f) * 10f;

            // 创建新的颜色并应用到灯光
            Color newColor = new Color(normalizedRed, normalizedGreen, normalizedBlue, 1f);
            this.light2D.Color = newColor;
        }

        protected ISliderControl[] sliderControls; // 受保护的滑块控件数组

        bool IMultiSliderControl.SidescreenEnabled() => true; // 控制器启用

        [MyCmpAdd]
        public CopyBuildingSettings copyBuildingSettings; // 复制建筑设置组件                                                      

        protected override void OnSpawn()
        {
            base.OnSpawn();
            this.UpdateLightColor();
        } // OnSpawn方法，在生成时调用

        ISliderControl[] IMultiSliderControl.sliderControls => this.sliderControls; // 滑块控件数组      

        protected override void OnPrefabInit()
        {
            base.OnPrefabInit();
            base.Subscribe(-905833192, new Action<object>(this.OnCopySettings));
        } // OnPrefabInit方法，在预制初始化时调用

        // 内部类，1号滑块控件 - 红色通道
        public class R020GG1K1K1 : KMonoBehaviour, ISingleSliderControl, ISliderControl
        {
            public string SliderUnits => " "; // 无单位
            public string SliderTitleKey => "STRINGS.BUILDINGS.PREFABS.R020GG1.NAME_RED"; // 滑条名称_红色        
            public float GetSliderMin(int index) => 0; // 最小值           
            public float GetSliderMax(int index) => 255; // 最大值
            public int SliderDecimalPlaces(int index) => 0; // 整数值          

            public R020GG1K1 target; // 目标对象           
            public string GetSliderTooltip(int index) => STRINGS.BUILDINGS.PREFABS.R020GG1.NAME_SZ; // 滑块提示
            public string GetSliderTooltipKey(int index) => ""; // 滑块提示键（空）
            public float GetSliderValue(int index) => this.target.RedValue; // 获取滑块值
            public R020GG1K1K1(R020GG1K1 target) { this.target = target; } // 构造函数，初始化目标对象
            public void SetSliderValue(float value, int index)
            {
                this.target.RedValue = value;
                this.target.UpdateLightColor();
            } // 设置滑块值
        }

        // 滑条2 - 绿色通道
        public class R020GG1K1K2 : KMonoBehaviour, ISingleSliderControl, ISliderControl
        {
            public string SliderUnits => " "; // 无单位
            public string SliderTitleKey => "STRINGS.BUILDINGS.PREFABS.R020GG1.NAME_GREEN"; // 滑条名称_绿色      
            public float GetSliderMin(int index) => 0; // 最小值
            public float GetSliderMax(int index) => 255; // 最大值
            public int SliderDecimalPlaces(int index) => 0; // 整数值          

            public R020GG1K1 target; // 目标对象           
            public string GetSliderTooltip(int index) => STRINGS.BUILDINGS.PREFABS.R020GG1.NAME_SZ; // 滑块提示
            public string GetSliderTooltipKey(int index) => ""; // 滑块提示键（空）
            public float GetSliderValue(int index) => this.target.GreenValue; // 获取滑块值
            public R020GG1K1K2(R020GG1K1 target) { this.target = target; } // 构造函数，初始化目标对象
            public void SetSliderValue(float value, int index)
            {
                this.target.GreenValue = value;
                this.target.UpdateLightColor();
            } // 设置滑块值
        }

        // 滑条3 - 蓝色通道
        public class R020GG1K1K3 : KMonoBehaviour, ISingleSliderControl, ISliderControl
        {
            public string SliderUnits => " "; // 无单位
            public string SliderTitleKey => "STRINGS.BUILDINGS.PREFABS.R020GG1.NAME_BLUE"; // 滑条名称_蓝色      
            public float GetSliderMin(int index) => 0; // 最小值
            public float GetSliderMax(int index) => 255; // 最大值
            public int SliderDecimalPlaces(int index) => 0; // 整数值          

            public R020GG1K1 target; // 目标对象           
            public string GetSliderTooltip(int index) => STRINGS.BUILDINGS.PREFABS.R020GG1.NAME_SZ; // 滑块提示
            public string GetSliderTooltipKey(int index) => ""; // 滑块提示键（空）
            public float GetSliderValue(int index) => this.target.BlueValue; // 获取滑块值
            public R020GG1K1K3(R020GG1K1 target) { this.target = target; } // 构造函数，初始化目标对象
            public void SetSliderValue(float value, int index)
            {
                this.target.BlueValue = value;
                this.target.UpdateLightColor();
            } // 设置滑块值
        }
    }
}