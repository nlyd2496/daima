﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HarmonyLib;
using KMod;
using PeterHan.PLib.Core;
using PeterHan.PLib.Options;

namespace R_南瓜灯
{
    public class ModLoad : UserMod2
    {
        public static string Namespace { get; private set; }
        public override void OnLoad(Harmony harmony)
        {
            base.OnLoad(harmony);
            ModLoad.Namespace = base.GetType().Namespace;
            PUtil.InitLibrary(true);
            // new POptions().RegisterOptions(this, typeof(控制台));            
            Namespace = base.GetType().Namespace;        
        }
    }
}
