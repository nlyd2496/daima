﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Reflection.Emit;
using HarmonyLib;
using KMod;
using PeterHan.PLib.Core;
using PeterHan.PLib.Options;

namespace P_小人氧气消耗增加
{
    [HarmonyPatch(typeof(OxygenBreather), "Sim200ms")]
    public class 小人氧气消耗
    {
        public static bool Prefix(ref float dt)
        {
            dt *= SingletonOptions<控制台>.Instance.P016GG1X1;

            return true;

        }
        /*
        public static void Postfix(float dt, OxygenBreather __instance)
        {
            __instance.O2toCO2conversion = SingletonOptions<控制台>.Instance.P016GG1X1 * 0.02f;
            __instance.minCO2ToEmit = SingletonOptions<控制台>.Instance.P016GG1X1 * 0.01f;
        }
        */
    }
}