﻿using Newtonsoft.Json;
using PeterHan.PLib.Options;


namespace P_小人氧气消耗增加
{
    [RestartRequired]
    [JsonObject(MemberSerialization.OptIn)]
    [ConfigFile("P015GG1X1.json", true, false)]
    [ModInfo("https://space.bilibili.com/30725645", "mmm.png", true)]

    public class 控制台 : SingletonOptions<控制台>
    {   
        [Option("STRINGS.BUILDINGS.PREFABS.P_UI.P016GG1X1_UI", null, null, Format = "F0")][Limit(1, 10)][JsonProperty] public float P016GG1X1 { get; set; } = 2f;
    }
}
