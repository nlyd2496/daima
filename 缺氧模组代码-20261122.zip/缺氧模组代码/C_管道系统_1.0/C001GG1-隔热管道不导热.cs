﻿using HarmonyLib;
using PeterHan.PLib.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C_管道系统_1._0
{
    [HarmonyPatch(typeof(InsulatedGasConduitConfig))]
    [HarmonyPatch("CreateBuildingDef")]
    public class 隔热气体管道导热系数为零
    {
        public static void Postfix(ref BuildingDef __result)
        {
            bool C001GG1 = SingletonOptions<控制台>.Instance.C001GG1;
            if (C001GG1)
            {
                __result.ThermalConductivity = 0f;
            }
        }
    }
    [HarmonyPatch(typeof(InsulatedLiquidConduitConfig))]
    [HarmonyPatch("CreateBuildingDef")]
    public class 隔热液体管道导热系数为零
    {
        public static void Postfix(ref BuildingDef __result)
        {
            bool C001GG1 = SingletonOptions<控制台>.Instance.C001GG1;
            if (C001GG1)
            {
                __result.ThermalConductivity = 0f;
            }
        }
    }

    [HarmonyPatch(typeof(ElementLoader), "CopyEntryToElement")]
    public class 辐射阻隔率
    {
        private static void Postfix(ElementData.ElementEntry entry, Element elem)
        {
            if (entry.elementId == "SuperInsulator")
            {
                elem.highTemp = 6000f;
            }
        }
    }
}

