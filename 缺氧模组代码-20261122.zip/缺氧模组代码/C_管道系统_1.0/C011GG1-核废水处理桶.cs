﻿using Database;
using HarmonyLib;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TUNING;
using UnityEngine;
using static STRINGS.UI;

namespace C_管道系统_1._0
{
    public class C011GG1 : IBuildingConfig
    {
        public override string[] GetRequiredDlcIds()
        {
            return DlcManager.EXPANSION1; 
        }
        public override BuildingDef CreateBuildingDef()
        {
            string id = "C011GG1";
            int width = 1;
            int height = 1;
            string anim = "C011GG1L1_kanim";
            int hitpoints = 30;
            float construction_time = 3f;
            float[] tier = BUILDINGS.CONSTRUCTION_MASS_KG.TIER2;
            string[] raw_MINERALS = MATERIALS.RAW_MINERALS;
            float melting_point = 1600f;
            BuildLocationRule build_location_rule = BuildLocationRule.OnFloor;
            EffectorValues none = NOISE_POLLUTION.NONE;
            BuildingDef buildingDef = BuildingTemplates.CreateBuildingDef(id, width, height, anim, hitpoints, construction_time, tier, raw_MINERALS, melting_point, build_location_rule, new EffectorValues
            {
                amount = -6,
                radius = 2
            }, none, 0.2f);
            buildingDef.Floodable = false;
            buildingDef.Overheatable = false;
            buildingDef.InputConduitType = ConduitType.Liquid;
            buildingDef.UtilityInputOffset = new CellOffset(0, 0);
            buildingDef.ViewMode = OverlayModes.LiquidConduits.ID;
            buildingDef.PermittedRotations = PermittedRotations.FlipH;
            //--------------------------
            if (控制台.Instance.C011GG1) { buildingDef.Deprecated = false; } else { buildingDef.Deprecated = true; }
            //--------------------------
            return buildingDef;
        }
        
        public override void ConfigureBuildingTemplate(GameObject go, Tag prefab_tag)
        {
            Storage storage = go.AddOrGet<Storage>();
            storage.showInUI = true;
            storage.capacityKg = 100f;
            storage.allowItemRemoval = true;
            storage.showDescriptor = true;
            storage.storageFullMargin = STORAGE.STORAGE_LOCKER_FILLED_MARGIN;
            storage.fetchCategory = Storage.FetchCategory.GeneralStorage;
            storage.storageFilters = STORAGEFILTERS.LIQUIDS;
            ConduitConsumer conduitConsumer = go.AddOrGet<ConduitConsumer>();
            conduitConsumer.conduitType = ConduitType.Liquid;
            conduitConsumer.capacityTag = GameTagExtensions.Create(SimHashes.NuclearWaste);
            conduitConsumer.ignoreMinMassCheck = true;
            conduitConsumer.forceAlwaysSatisfied = true;
            conduitConsumer.alwaysConsume = true;
            conduitConsumer.capacityKG = 100f;
            go.AddOrGet<C011GG1K1>();
            go.AddOrGet<StorageLocker>();
        }
        
        public override void DoPostConfigureComplete(GameObject go)
        {
            go.AddOrGetDef<StorageController.Def>();
        }

    }
    [HarmonyPatch(typeof(BuildingFacades), MethodType.Constructor, new Type[] { typeof(ResourceSet) })]
    public static class 蓝图系统C011GG1
    {
        public static void Postfix(BuildingFacades __instance)
        {
            __instance.Add("C011GG1L2",
                STRINGS.BUILDINGS.PREFABS.C011GG1L2.NAME, STRINGS.BUILDINGS.PREFABS.C011GG1L2.EFFECT, PermitRarity.Universal,
                "C011GG1", "C011GG1L2_kanim",
                null,
                null,
                null,
                null);
        }
    }

}
