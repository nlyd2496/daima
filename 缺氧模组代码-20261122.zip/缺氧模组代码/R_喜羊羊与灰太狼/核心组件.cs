﻿using System;
using HarmonyLib;
using KMod;
using PeterHan.PLib.Core;
using PeterHan.PLib.Options;
using UnityEngine.Diagnostics;

namespace R_喜羊羊与灰太狼
{
    public class 核心组件
    {
        public class ModLoad : UserMod2
        {
            public static string Namespace { get; private set; }
            public override void OnLoad(Harmony harmony)
            {
                base.OnLoad(harmony);
                ModLoad.Namespace = base.GetType().Namespace;
                // PUtil.InitLibrary(true);
                Namespace = base.GetType().Namespace;


                Namespace = GetType().Namespace;
                Debug.Log($"{Namespace}: Loaded from: {this.mod.ContentPath}");
                Debug.Log($"{Namespace}: DLL version: {GetType().Assembly.GetName().Version} " +
                $"supporting game build {this.mod.packagedModInfo.minimumSupportedBuild} ({this.mod.packagedModInfo.supportedContent})");
            }
        }
    }
}