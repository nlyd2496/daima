﻿using HarmonyLib;
using PeterHan.PLib.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace N_超级蒸汽机
{ 
    [HarmonyPatch(typeof(SteamTurbineConfig2))]
    [HarmonyPatch("DoPostConfigureComplete")]
    public class 输出温度
    {
        public static void Postfix(GameObject go)
        {

                SteamTurbine steamTurbine = go.AddOrGet<SteamTurbine>();
                steamTurbine.wasteHeatToTurbinePercent = SingletonOptions<控制台>.Instance.N003GG1X1;//热量转移效率
                steamTurbine.minActiveTemperature = SingletonOptions<控制台>.Instance.N003GG1X2 + 273.15f;//吸收蒸汽最低温度
                steamTurbine.outputElementTemperature = SingletonOptions<控制台>.Instance.N003GG1X3 + 273.15f;//输出液体温度

                steamTurbine.maxBuildingTemperature = 423.15f;//蒸汽机过热温度

                go.AddOrGet<N003GG1K1>();
            
        }
    }
    [HarmonyPatch(typeof(SteamTurbineConfig2))]
    [HarmonyPatch("CreateBuildingDef")]
    public class 蒸汽机功率上限
    {
        public static void Postfix(ref BuildingDef __result)
        {

                __result.GeneratorWattageRating = SingletonOptions<控制台>.Instance.N003GG1X4;//蒸汽机功率上限
                __result.GeneratorBaseCapacity = SingletonOptions<控制台>.Instance.N003GG1X4;//蒸汽机功率上限
            
        }
    }
}
