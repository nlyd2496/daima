﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HarmonyLib;
using STRINGS;
using KMod;
using PeterHan.PLib.Core;
using PeterHan.PLib.Database;
using Klei.AI;
using PeterHan.PLib.Options;

namespace N_超级蒸汽机
{
    public class STRINGS
    {
        public static void DoReplacement()
        {
            LocString.CreateLocStringKeys(typeof(STRINGS), "");
        }
        

        public class BUILDINGS
        {
            public class PREFABS
            {
                public static LocString N003GG1X1_UI = "蒸汽机热量转移效率";
                public static LocString N003GG1X2_UI = "蒸汽机吸收蒸汽最低温度";
                public static LocString N003GG1X3_UI = "蒸汽机输出液体温度";
                public static LocString N003GG1X4_UI = "蒸汽机功率上限";


            }
            

        }
    }
}
