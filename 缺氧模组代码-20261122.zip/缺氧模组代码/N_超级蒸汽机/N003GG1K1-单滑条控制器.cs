﻿using KSerialization;
using STRINGS;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace N_超级蒸汽机
{
    public class N003GG1K1 : KMonoBehaviour, ISingleSliderControl, ISliderControl
    {
        public float GetSliderMin(int index) => 1;//最小值
        public float GetSliderMax(int index) => 100;//最大值
        public int SliderDecimalPlaces(int index) => 0;//小数点
        public string SliderUnits => UI.UNITSUFFIXES.MASS.KILOGRAM; 
        public string SliderTitleKey => "STRINGS.BUILDINGS.PREFABS.STEAMTURBINE2.NAME";//窗口名称
        public string GetSliderTooltip(int index) => "";//空
        //--------------------------
        [Serialize] public float AA = 26f;//AA参数默认值
        //--------------------------
        [MyCmpReq] public SteamTurbine steamTurbine;
        internal void Update() { this.steamTurbine.pumpKGRate = this.AA ; }//将AA的值赋予源功能组件
        //--------------------------
        //以下内容无需更改
        public float GetSliderValue(int index) => this.AA;
        public string GetSliderTooltipKey(int index) => "";//空
        [MyCmpAdd] public CopyBuildingSettings copyBuildingSettings;
        protected override void OnSpawn() { base.OnSpawn(); this.Update(); }
        public void SetSliderValue(float value, int index) { this.AA = value; this.Update(); }
        protected override void OnPrefabInit() { base.OnPrefabInit(); base.Subscribe(-905833192, new Action<object>(this.OnCopySettings)); }
        internal void OnCopySettings(object data) { var component = ((GameObject)data).GetComponent<N003GG1K1>(); if (component == null) return; AA = component.AA; Update(); }
        //--------------------------
    }
}
