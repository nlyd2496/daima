﻿using Klei.AI;
using Newtonsoft.Json;
using PeterHan.PLib.Options;
using static STRINGS.UI.BUILDCATEGORIES;
using static STRINGS.UI.METERS;


namespace N_超级蒸汽机
{
    [RestartRequired]
    [JsonObject(MemberSerialization.OptIn)]
    [ConfigFile("Controler.json", true, false)]
    // [ModInfo("https://space.bilibili.com/30725645", "mmm.png", true)]

    public class 控制台 : SingletonOptions<控制台>
    {
        // 蒸汽机热量转移效率
        [Option("STRINGS.BUILDINGS.PREFABS.N003GG1X1_UI", null, null)]
        [Limit(0, 0.1)]
        [JsonProperty]
        public float N003GG1X1 { get; set; } = 0.1f;

        // 蒸汽机吸收蒸汽最低温度
        [Option("STRINGS.BUILDINGS.PREFABS.N003GG1X2_UI", null, null)]
        [Limit(90, 150)]
        [JsonProperty]
        public float N003GG1X2 { get; set; } = 90f;

        // 蒸汽机输出液体温度
        [Option("STRINGS.BUILDINGS.PREFABS.N003GG1X3_UI", null, null)]
        [Limit(10, 80)]
        [JsonProperty]
        public float N003GG1X3 { get; set; } = 20f;

        // 蒸汽机功率上限
        [Option("STRINGS.BUILDINGS.PREFABS.N003GG1X4_UI", null, null, Format = "F0")]
        [Limit(1, 10000)]
        [JsonProperty]
        public float N003GG1X4 { get; set; } = 1000f;
    }
}
