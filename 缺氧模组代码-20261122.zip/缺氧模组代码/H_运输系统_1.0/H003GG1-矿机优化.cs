﻿using HarmonyLib;
using KSerialization;
using PeterHan.PLib.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace H_运输系统_1._0
{
    //--------------------------
    [HarmonyPatch(typeof(AutoMinerConfig))]
    [HarmonyPatch("DoPostConfigureComplete")]
    public static class 挖机挖掘范围
    {
        public static void Postfix(GameObject go)
        {
            bool H003GG1 = SingletonOptions<控制台>.Instance.H003GG1;
            if (H003GG1)
            {


                go.AddOrGet<H003GG1K1>();
            }
        }
    }

    [HarmonyPatch(typeof(AutoMinerConfig))]
    [HarmonyPatch("CreateBuildingDef")]
    public class 挖机基础属性
    {
        public static void Postfix(ref BuildingDef __result)
        {
            bool H003GG1 = SingletonOptions<控制台>.Instance.H003GG1;
            if (H003GG1)
            {
                __result.Overheatable = false;
                __result.Floodable = false;
            }
        }
    }
    [HarmonyPatch(typeof(AutoMiner))]
    [HarmonyPatch("RefreshDiggableCell")]
    public static class 挖机挖掘硬度设置一
    {
        private static bool IsPatched = false;

        static void Prefix()
        {
            if (AutoMiner.DigBlockingCB == null || IsPatched)
                return;

            // 保存原始委托（可选，用于恢复）
            var original = AutoMiner.DigBlockingCB;

            // 替换为智能委托：内部动态判断开关
            AutoMiner.DigBlockingCB = (int cell) =>
            {
                // 如果开关关闭，使用原始逻辑
                if (!SingletonOptions<控制台>.Instance.H003GG1)
                    return original(cell);

                // 开关开启：使用自定义逻辑（硬度 >= 255 才阻挡）
                bool flag = Grid.HasDoor[cell] && Grid.Foundation[cell] && Grid.ObjectLayers[9].ContainsKey(cell);
                if (flag)
                {
                    Door component = Grid.ObjectLayers[9][cell].GetComponent<Door>();
                    flag = (component != null && component.IsOpen() && !component.IsPendingClose());
                }
                return (Grid.Foundation[cell] && Grid.Solid[cell] && !flag) || Grid.Element[cell].hardness >= 255;
            };

            IsPatched = true;
            Debug.Log("✅ AutoMiner.DigBlockingCB patched with dynamic H003GG1 support");
        }
    }
    [HarmonyPatch(typeof(AutoMiner))]
    [HarmonyPatch("ValidDigCell")]
    public static class 挖机挖掘硬度设置二
    {
        private static void Postfix(int cell, ref bool __result)
        {
            bool H003GG1 = SingletonOptions<控制台>.Instance.H003GG1;
            if (H003GG1)
            {
                __result = (Grid.Solid[cell] && !Grid.Foundation[cell] && Grid.Element[cell].hardness < 255);

            }
        }
    }
    [HarmonyPatch(typeof(WorldDamage))]
    [HarmonyPatch("OnDigComplete")]
    public static class 挖掘掉落率
    {
        private static bool H003GG1 = SingletonOptions<控制台>.Instance.H003GG1;
        private static IEnumerable<CodeInstruction> Transpiler(IEnumerable<CodeInstruction> instructions)
        {
            var codes = new List<CodeInstruction>(instructions);

            for (int i = 0; i < codes.Count; i++)
            {
                if (codes[i].opcode == OpCodes.Ldc_R4 && (float)codes[i].operand == 0.5f)
                {
                    if (H003GG1)
                    {
                        codes[i].operand = SingletonOptions<控制台>.Instance.H003GG1X1;
                    }
                }
            }
            return codes;
        }
    }
    [HarmonyPatch(typeof(AutoMinerConfig))]
    [HarmonyPatch("CreateBuildingDef")]
    internal class 挖掘机能量守恒之发热
    {
        public static void Postfix(BuildingDef __result)
        {
            bool H003GG1 = SingletonOptions<控制台>.Instance.H003GG1;
            if (H003GG1)
            {

                bool H000GG1 = SingletonOptions<控制台>.Instance.H000GG1;
                if (H000GG1)
                {
                    // __result.ExhaustKilowattsWhenActive = SingletonOptions<控制台>.Instance.H003GG1X1;
                    __result.SelfHeatKilowattsWhenActive = SingletonOptions<控制台>.Instance.H003GG1X1;
                }
            }
        }
    }
}
