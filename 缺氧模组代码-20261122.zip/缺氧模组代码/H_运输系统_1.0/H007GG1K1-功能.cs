﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using KSerialization;
using TUNING;
using UnityEngine;

namespace H_运输系统_1._0
{
    [SerializationConfig(MemberSerialization.OptIn)]
    public class H007GG1K0 : StateMachineComponent<H007GG1K0.SMInstance>
    {
        protected override void OnPrefabInit()
        {
            base.OnPrefabInit();
        }

        protected override void OnSpawn()
        {
            base.OnSpawn();
            this.meter = new MeterController(this, Meter.Offset.Infront, Grid.SceneLayer.NoLayer, Array.Empty<string>());
            base.Subscribe<H007GG1K0>(-1697596308, H007GG1K0.OnStorageChangedDelegate);
            this.UpdateMeter();
            base.smi.StartSM();
        }

        protected override void OnCleanUp()
        {
            base.OnCleanUp();
        }

        private void OnStorageChanged(object data)
        {
            this.UpdateMeter();
        }

        private void UpdateMeter()
        {
            float positionPercent = Mathf.Clamp01(this.storage.MassStored() / this.storage.capacityKg);
            this.meter.SetPositionPercent(positionPercent);
        }

        private void UpdateConsuming()
        {
            base.smi.sm.consuming.Set(this.consumer.IsConsuming, base.smi, false);
        }

        private void Sim1000ms(float dt)
        {
            foreach (GameObject gameObject in this.storage.items)
            {
                if (gameObject != null)
                {
                    gameObject.DeleteObject();
                }
            }
            this.UpdateMeter();
        }

        [MyCmpReq]
        private Operational operational;

        [MyCmpReq]
        private SolidConduitConsumer consumer;

        [MyCmpAdd]
        private Storage storage;

        private MeterController meter;

        private static readonly EventSystem.IntraObjectHandler<H007GG1K0> OnStorageChangedDelegate = new EventSystem.IntraObjectHandler<H007GG1K0>(delegate (H007GG1K0 component, object data)
        {
            component.OnStorageChanged(data);
        });

        public class SMInstance : GameStateMachine<H007GG1K0.States, H007GG1K0.SMInstance, H007GG1K0, object>.GameInstance
        {
            public SMInstance(H007GG1K0 master) : base(master)
            {
            }
        }

        public class States : GameStateMachine<H007GG1K0.States, H007GG1K0.SMInstance, H007GG1K0>
        {
            public override void InitializeStates(out StateMachine.BaseState default_state)
            {
                default_state = this.idle;
                this.root.Update("RefreshConsuming", delegate (H007GG1K0.SMInstance smi, float dt)
                {
                    smi.master.UpdateConsuming();
                    smi.master.Sim1000ms(dt);
                }, UpdateRate.SIM_1000ms, false);
                this.idle.PlayAnim("on").ParamTransition<bool>(this.consuming, this.working, GameStateMachine<H007GG1K0.States, H007GG1K0.SMInstance, H007GG1K0, object>.IsTrue);
                this.working.PlayAnim("working_pre").QueueAnim("working_loop", true, null).ParamTransition<bool>(this.consuming, this.post, GameStateMachine<H007GG1K0.States, H007GG1K0.SMInstance, H007GG1K0, object>.IsFalse);
                this.post.PlayAnim("working_pst").OnAnimQueueComplete(this.idle);
            }

            public StateMachine<H007GG1K0.States, H007GG1K0.SMInstance, H007GG1K0, object>.BoolParameter consuming;
            public GameStateMachine<H007GG1K0.States, H007GG1K0.SMInstance, H007GG1K0, object>.State idle;
            public GameStateMachine<H007GG1K0.States, H007GG1K0.SMInstance, H007GG1K0, object>.State working;
            public GameStateMachine<H007GG1K0.States, H007GG1K0.SMInstance, H007GG1K0, object>.State post;
        }
    }
}
