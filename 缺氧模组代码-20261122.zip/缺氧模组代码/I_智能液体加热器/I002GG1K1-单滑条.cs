﻿using KSerialization;
using STRINGS;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using static STRINGS.BUILDINGS.PREFABS;

namespace I_智能液体加热器
{
    [SerializationConfig(MemberSerialization.OptIn)]
    public class I002GGG1K2 : KMonoBehaviour, IMultiSliderControl
    {
        // 构造函数，初始化滑块控件数组
        public I002GGG1K2()
        {
            this.sliderControls = new ISliderControl[]
            {
                new I002GGG1K2K2(this), // 初始化1号滑块控件
            };
        }
        string IMultiSliderControl.SidescreenTitleKey => "STRINGS.BUILDINGS.PREFABS.LIQUIDHEATER.NAME"; // 控制器名称
        // 复制设置方法
        internal void OnCopySettings(object data)
        {
            var component = ((GameObject)data).GetComponent<I002GGG1K2>();
            if (component == null) return;
            AA = component.AA;
            Update();
        }
        // 滑条
        [MyCmpReq] public SpaceHeater spaceHeater;
        [Serialize] public float AA = 26f; // 滑条1_初始值

        // 更新方法，将AA的值赋予源功能组件
        internal void Update()
        {
            this.spaceHeater.targetTemperature = this.AA + 273.15f;
        }
        // ----------------
        // ----------------       
        protected ISliderControl[] sliderControls; // 受保护的滑块控件数组
        bool IMultiSliderControl.SidescreenEnabled() => true; // 控制器启用
        [MyCmpAdd] public CopyBuildingSettings copyBuildingSettings; // 复制建筑设置组件                                                      
        protected override void OnSpawn() { base.OnSpawn(); this.Update(); } // OnSpawn方法，在生成时调用
        ISliderControl[] IMultiSliderControl.sliderControls => this.sliderControls; // 滑块控件数组      
        protected override void OnPrefabInit() { base.OnPrefabInit(); base.Subscribe(-905833192, new Action<object>(this.OnCopySettings)); }// OnPrefabInit方法，在预制初始化时调用
        // ----------------
        // ----------------
        // 内部类，1号滑块控件
        public class I002GGG1K2K2 : KMonoBehaviour, ISingleSliderControl, ISliderControl
        {
            public string SliderUnits => UI.UNITSUFFIXES.TEMPERATURE.CELSIUS; // ℃
            public string SliderTitleKey => null; // 滑条名称_温度        
            public float GetSliderMin(int index) => -200; // 最小值           
            public float GetSliderMax(int index) => 300; // 最大值
            public int SliderDecimalPlaces(int index) => 0; // 小数点          
            // ----------------
            public I002GGG1K2 target; // 目标对象           
            public string GetSliderTooltip(int index) => null; // 滑块提示
            public string GetSliderTooltipKey(int index) => null; // 滑块提示键（空）
            public float GetSliderValue(int index) => this.target.AA; // 获取滑块值
            public I002GGG1K2K2(I002GGG1K2 target) { this.target = target; } // 构造函数，初始化目标对象
            public void SetSliderValue(float value, int index) { this.target.AA = value; this.target.Update(); } // 设置滑块值
        }
        /*
        public class I002GGG1K2 : KMonoBehaviour, ISingleSliderControl, ISliderControl
        {
            public int SliderDecimalPlaces(int index) => 0;//小数点
            public float GetSliderMin(int index) => 10;//最小值
            public float GetSliderMax(int index) => 800;//最大值
            public string SliderTitleKey => "";
            public string GetSliderTooltip(int index) => "";//滑块名称
            public string SliderUnits => UI.UNITSUFFIXES.TEMPERATURE.CELSIUS; // 单位
            //--------------------------                                                        
            [Serialize] public float AA = 60f;
            [MyCmpReq] public SpaceHeater spaceHeater;
            internal void Update() { this.spaceHeater.targetTemperature = this.AA + 273.15f; }//将AA的值赋予源功能组件
            //--------------------------
            public float GetSliderValue(int index) => this.AA;
            public string GetSliderTooltipKey(int index) => "";//空
            [MyCmpAdd] public CopyBuildingSettings copyBuildingSettings;
            protected override void OnSpawn() { base.OnSpawn(); this.Update(); }
            public void SetSliderValue(float value, int index) { this.AA = value; this.Update(); }
            protected override void OnPrefabInit() { base.OnPrefabInit(); base.Subscribe(-905833192, new Action<object>(this.OnCopySettings)); }
            internal void OnCopySettings(object data) { var component = ((GameObject)data).GetComponent<I002GGG1K2>(); if (component == null) return; AA = component.AA; Update(); }
            //--------------------------
        }
        */
    }
}
