﻿using HarmonyLib;
using PeterHan.PLib.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace N_电力系统_1._0
{
    [HarmonyPatch(typeof(DevGeneratorConfig))]
    [HarmonyPatch("CreateBuildingDef")]
    internal class 启用开发者电池
    {
        public static void Postfix(BuildingDef __result)
        {
            bool N001GG1 = SingletonOptions<控制台>.Instance.N001GG1;
            if (N001GG1)
            {
                __result.DebugOnly = false;//正常模式可使用
                __result.Floodable = false;//可被淹没
                __result.Overheatable = false;//不会过热
                __result.ThermalConductivity = 0f;//导热系数为0
                __result.UseStructureTemperature = false;//不使用结构温度
                //--------------------------
                bool N001GG1X1 = SingletonOptions<控制台>.Instance.N001GG1X1;
                if (N001GG1X1)
                {
                    __result.GeneratorWattageRating = float.PositiveInfinity;//功率
                    __result.GeneratorBaseCapacity = float.PositiveInfinity;//容量
                }
                //--------------------------
            }
        }
    }
    [HarmonyPatch(typeof(DevGeneratorConfig))]
    [HarmonyPatch("DoPostConfigureComplete")]
    public class 开发者发电机额定功率
    {
        private static void Postfix(GameObject go)
        {
            bool N001GG1X1 = SingletonOptions<控制台>.Instance.N001GG1X1;
            if (N001GG1X1)
            {
                DevGenerator devGenerator = go.AddOrGet<DevGenerator>();
                devGenerator.wattageRating = float.PositiveInfinity;//额定功率
            }
        }
    }
}

