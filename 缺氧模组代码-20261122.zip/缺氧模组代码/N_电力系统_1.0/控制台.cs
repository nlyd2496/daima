﻿using Klei.AI;
using Newtonsoft.Json;
using PeterHan.PLib.Options;
using static STRINGS.UI.BUILDCATEGORIES;
using static STRINGS.UI.METERS;


namespace N_电力系统_1._0
{
    [RestartRequired]
    [JsonObject(MemberSerialization.OptIn)]
    [ConfigFile("Controler.json", true, false)]
    // [ModInfo("https://space.bilibili.com/30725645", "mmm.png", true)]

    public class 控制台 : SingletonOptions<控制台>
    {

        // 启用开发者电池
        [Option("STRINGS.BUILDINGS.PREFABS.N_UI.N001GG1_UI", null, null)]
        [JsonProperty]
        public bool N001GG1 { get; set; } = true;

        // 开发者电池输出无穷大
        [Option("STRINGS.BUILDINGS.PREFABS.N_UI.N001GG1X1_UI", null, null)]
        [JsonProperty]
        public bool N001GG1X1 { get; set; } = true;
        // 启用超级氢气发电机
        [Option("STRINGS.BUILDINGS.PREFABS.N_UI.N002GG1_UI", null, null)]
        [JsonProperty]
        public bool N002GG1 { get; set; } = true;

        // 超级氢气发电机功率
        [Option("STRINGS.BUILDINGS.PREFABS.N_UI.N002GG1X1_UI", null, null, Format = "F0")]
        [Limit(1.0, 100000.0)]
        [JsonProperty]
        public float N002GG1X1 { get; set; } = 10000f;

        // 超级氢气发电机氢气消耗
        [Option("STRINGS.BUILDINGS.PREFABS.N_UI.N002GG1X2_UI", null, null)]
        [Limit(0.1, 1.0)]
        [JsonProperty]
        public float N002GG1X2 { get; set; } = 0.1f;
        
        // 启用超级蒸汽机
        [Option("STRINGS.BUILDINGS.PREFABS.N_UI.N003GG1_UI", null, null)]
        [JsonProperty]
        public bool N003GG1 { get; set; } = true;

        // 蒸汽机热量转移效率
        [Option("STRINGS.BUILDINGS.PREFABS.N_UI.N003GG1X1_UI", null, null)]
        [Limit(0, 0.1)]
        [JsonProperty]
        public float N003GG1X1 { get; set; } = 0.1f;

        // 蒸汽机吸收蒸汽最低温度
        [Option("STRINGS.BUILDINGS.PREFABS.N_UI.N003GG1X2_UI", null, null)]
        [Limit(90, 150)]
        [JsonProperty]
        public float N003GG1X2 { get; set; } = 90f;

        // 蒸汽机输出液体温度
        [Option("STRINGS.BUILDINGS.PREFABS.N_UI.N003GG1X3_UI", null, null)]
        [Limit(10, 80)]
        [JsonProperty]
        public float N003GG1X3 { get; set; } = 20f;

        // 蒸汽机功率上限
        [Option("STRINGS.BUILDINGS.PREFABS.N_UI.N003GG1X4_UI", null, null, Format = "F0")]
        [Limit(1, 10000)]
        [JsonProperty]
        public float N003GG1X4 { get; set; } = 1000f;

        // 启用高负荷线可穿墙
        [Option("STRINGS.BUILDINGS.PREFABS.N_UI.N004GG1_UI", null, null)]
        [JsonProperty]
        public bool N004GG1 { get; set; } = true;

        // 启用基础电池容量无穷大
        [Option("STRINGS.BUILDINGS.PREFABS.N_UI.N005GG1_UI", null, null)]
        [JsonProperty]
        public bool N005GG1 { get; set; } = true;

        // 启用跨两格导线桥
        [Option("STRINGS.BUILDINGS.PREFABS.N_UI.N006GG1_UI", null, null)]
        [JsonProperty]
        public bool N006GG1 { get; set; } = true;

        // 启用跨三格导线桥
        [Option("STRINGS.BUILDINGS.PREFABS.N_UI.N007GG1_UI", null, null)]
        [JsonProperty]
        public bool N007GG1 { get; set; } = true;

        // 启用跨两格电线桥
        [Option("STRINGS.BUILDINGS.PREFABS.N_UI.N008GG1_UI", null, null)]
        [JsonProperty]
        public bool N008GG1 { get; set; } = true;

        // 启用跨三格电线桥
        [Option("STRINGS.BUILDINGS.PREFABS.N_UI.N009GG1_UI", null, null)]
        [JsonProperty]
        public bool N009GG1 { get; set; } = true;

        // 梦世界的电线
        [Option("STRINGS.BUILDINGS.PREFABS.N_UI.N010GG1_UI", null, null)]
        [JsonProperty]
        public bool N010GG1 { get; set; } = true;

        // 启用民用电池组（DLC限定）
        [Option("STRINGS.BUILDINGS.PREFABS.N_UI.N011GG1_UI", null, null)]
        [JsonProperty]
        public bool N011GG1 { get; set; } = true;

        // 民用电池组容量
        [Option("STRINGS.BUILDINGS.PREFABS.N_UI.N011GG1X1_UI", null, null, Format = "F0")]
        [Limit(1, 200000)]
        [JsonProperty]
        public float N011GG1X1 { get; set; } = 20000f;

        // 启用南孚电池
        [Option("STRINGS.BUILDINGS.PREFABS.N_UI.N012GG1_UI", null, null)]
        [JsonProperty]
        public bool N012GG1 { get; set; } = true;

        // 南孚电池容量
        [Option("STRINGS.BUILDINGS.PREFABS.N_UI.N012GG1X1_UI", null, null, Format = "F0")]
        [Limit(1, 100000)]
        [JsonProperty]
        public float N012GG1X1 { get; set; } = 10000f;

        // 电线及电线桥
        [Option("STRINGS.BUILDINGS.PREFABS.N_UI.N013GG1X1_UI", null, null, Format = "F0")]
        [Limit(1000, 31415926)]
        [JsonProperty]
        public float N013GG1X1 { get; set; } = 5000f;

        // 导线及导线桥及绝缘电线
        [Option("STRINGS.BUILDINGS.PREFABS.N_UI.N013GG1X2_UI", null, null, Format = "F0")]
        [Limit(2000, 20000)]
        [JsonProperty]
        public float N013GG1X2 { get; set; } = 10000f;

        // 高负荷电线及接线板
        [Option("STRINGS.BUILDINGS.PREFABS.N_UI.N013GG1X3_UI", null, null, Format = "F0")]
        [Limit(20000, 200000)]
        [JsonProperty]
        public float N013GG1X3 { get; set; } = 100000f;

        // 高负荷导线及接线板
        [Option("STRINGS.BUILDINGS.PREFABS.N_UI.N013GG1X4_UI", null, null, Format = "F0")]
        [Limit(50000, 500000)]
        [JsonProperty]
        public float N013GG1X4 { get; set; } = 200000f;

        // 细电线
        [Option("STRINGS.BUILDINGS.PREFABS.N_UI.N014GG1_UI", null, null)]
        [JsonProperty]
        public bool N014GG1 { get; set; } = true;

        // 启用一格电池
        [Option("STRINGS.BUILDINGS.PREFABS.N_UI.N015GG1_UI", null, null)]
        [JsonProperty]
        public bool N015GG1 { get; set; } = true;

        // 一格电池容量
        [Option("STRINGS.BUILDINGS.PREFABS.N_UI.N015GG1X1_UI", null, null, Format = "F0")]
        [Limit(1, 50000.0)]
        [JsonProperty]
        public float N015GG1X1 { get; set; } = 5000f;

        // 启用变压器输出可调
        [Option("STRINGS.BUILDINGS.PREFABS.N_UI.N016GG1_UI", null, null)]
        [JsonProperty]
        public bool N016GG1 { get; set; } = true;
        // 启用核聚变发电机
        [Option("STRINGS.BUILDINGS.PREFABS.N_UI.N017GG1_UI", null, null)]
        [JsonProperty]
        public bool N017GG1 { get; set; } = true;
        // 启用移动电源充电机增强
        [Option("STRINGS.BUILDINGS.PREFABS.N_UI.N018GG1_UI", null, null)]
        [JsonProperty]
        public bool N018GG1 { get; set; } = true;
        // 移动电源充电机充电倍率
        [Option("STRINGS.BUILDINGS.PREFABS.N_UI.N018GG1X1_UI", null, null, Format = "F0")]
        [Limit(1, 100.0)]
        [JsonProperty]
        public float N018GG1X1 { get; set; } = 10f;
        // 启用增强移动电源
        [Option("STRINGS.BUILDINGS.PREFABS.N_UI.N019GG1_UI", null, null)]
        [JsonProperty]
        public bool N019GG1 { get; set; } = true;
        // 移动电源容量
        [Option("STRINGS.BUILDINGS.PREFABS.N_UI.N019GG1X1_UI", null, null, Format = "F0")]
        [Limit(200000, 20000000.0)]
        [JsonProperty]
        public float N019GG1X1 { get; set; } = 200000f;
        // 启用增强放电器
        [Option("STRINGS.BUILDINGS.PREFABS.N_UI.N020GG1_UI", null, null)]
        [JsonProperty]
        public bool N020GG1 { get; set; } = true;
        // 放电器输出功率
        [Option("STRINGS.BUILDINGS.PREFABS.N_UI.N020GG1X1_UI", null, null, Format = "F0")]
        [Limit(1000, 10000.0)]
        [JsonProperty]
        public float N020GG1X1 { get; set; } = 1000f;
        // 启用电力幽灵
        [Option("STRINGS.BUILDINGS.PREFABS.N_UI.N021GG1_UI", null, null)]
        [JsonProperty]
        public bool N021GG1 { get; set; } = true;


        /*
        [Option("启用开发者电池", null, null)][JsonProperty] public bool N001GG1 { get; set; }
        [Option("开发者电池输出无穷大", null, null)][JsonProperty] public bool N001GG1X1 { get; set; }
        [Option("启用民用电池组（DLC限定）", null, null)][JsonProperty] public bool N011GG1 { get; set; }
        [Option("民用电池组容量", null, null, Format = "F0")][Limit(1, 200000)][JsonProperty] public float N011GG1X1 { get; set; } = 20000f;
        [Option("启用南孚电池", null, null)][JsonProperty] public bool N012GG1 { get; set; }
        [Option("南孚电池容量", null, null, Format = "F0")][Limit(1, 100000)][JsonProperty] public float N012GG1X1 { get; set; } = 10000f;
        [Option("启用一格电池", null, null)][JsonProperty] public bool N015GG1 { get; set; }
        [Option("一格电池容量", null, null, Format = "F0")][Limit(1, 50000.0)][JsonProperty] public float N015GG1X1 { get; set; } = 5000f;
        [Option("启用基础电池容量无穷大", null, null)][JsonProperty] public bool N005GG1 { get; set; }
        [Option("启用超级氢气发电机", null, null)][JsonProperty] public bool N002GG1 { get; set; }
        [Option("超级氢气发电机功率", null, null, Format = "F0")][Limit(1.0, 100000.0)][JsonProperty] public float N002GG1X1 { get; set; } = 10000f;
        [Option("超级氢气发电机氢气消耗", null, null)][Limit(0.1, 1.0)][JsonProperty] public float N002GG1X2 { get; set; } = 0.1f;
        [Option("启用超级蒸汽机", null, null)][JsonProperty] public bool N003GG1 { get; set; }
        [Option("蒸汽机热量转移效率", null, null)][Limit(0, 0.1)][JsonProperty] public float N003GG1X1 { get; set; } = 0.1f;
        [Option("蒸汽机吸收蒸汽最低温度", null, null)][Limit(90, 150)][JsonProperty] public float N003GG1X2 { get; set; } = 90f;
        [Option("蒸汽机输出液体温度", null, null)][Limit(10, 80)][JsonProperty] public float N003GG1X3 { get; set; } = 20f;
        [Option("蒸汽机功率上限", null, null, Format = "F0")][Limit(1, 10000)][JsonProperty] public float N003GG1X4 { get; set; } = 1000f;
        [Option("梦世界的电线", null, null)][JsonProperty] public bool N010GG1 { get; set; }
        [Option("细电线", null, null)][JsonProperty] public bool N014GG1 { get; set; }
        [Option("启用跨两格导线桥", null, null)][JsonProperty] public bool N006GG1 { get; set; }
        [Option("启用跨三格导线桥", null, null)][JsonProperty] public bool N007GG1 { get; set; }
        [Option("启用跨两格电线桥", null, null)][JsonProperty] public bool N008GG1 { get; set; }
        [Option("启用跨三格电线桥", null, null)][JsonProperty] public bool N009GG1 { get; set; }
        [Option("电线及电线桥", null, null, Format = "F0")][Limit(1000, 31415926)][JsonProperty] public float N013GG1X1 { get; set; } = 5000f;
        [Option("导线及导线桥", null, null, Format = "F0")][Limit(2000, 20000)][JsonProperty] public float N013GG1X2 { get; set; } = 10000f;
        [Option("高负荷电线及接线板", null, null, Format = "F0")][Limit(20000, 200000)][JsonProperty] public float N013GG1X3 { get; set; } = 100000f;
        [Option("高负荷导线及接线板", null, null, Format = "F0")][Limit(50000, 500000)][JsonProperty] public float N013GG1X4 { get; set; } = 200000f;
        [Option("启用高负荷线可穿墙", null, null)][JsonProperty] public bool N004GG1 { get; set; }
        [Option("启用变压器输出可调", null, null)][JsonProperty] public bool N016GG1 { get; set; }
    */
    }
}
