﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace I_实用系统_1._0
{
    using UnityEngine;
    using KSerialization;

    [SerializationConfig(MemberSerialization.OptIn)]
    public class I004GG1K0 : KMonoBehaviour, ISim200ms
    {
        // ------------------- 原有温度调节逻辑 -------------------
        public float targetTemperature;
        public int effectWidth;
        public int effectHeight;
        private const float temperatureControlK = 0.2f;

        // ------------------- 新增：动画控制相关 -------------------
        [SerializeField] private KBatchedAnimController animController;

        private const float COLD_TEMP = 0f;      // ≤ 0°C 播放 cold
        private const float HOT_TEMP = 30f;     // ≥ 30°C 播放 hot
        private float lastUpdateTime;
        private const float UPDATE_INTERVAL = 1f;
        private string currentAnim = "";

        // ------------------- 核心方法 -------------------

        protected override void OnSpawn()
        {
            base.OnSpawn();

            // 获取动画控制器
            animController = GetComponent<KBatchedAnimController>();
            if (animController == null)
            {
                Debug.LogError($"{name}: 缺少 KBatchedAnimController 组件！");
                return;
            }

            // 确保初始动画正确
            UpdateAnimation();
        }

        public void Sim200ms(float dt)
        {
            // ------------------- 原有：温度调节逻辑 -------------------
            Vector2I vector2I = new Vector2I(-this.effectWidth / 2, -this.effectHeight / 2);
            Vector2I vector2I2 = new Vector2I(this.effectWidth / 2, this.effectHeight / 2);
            int num, num2;
            Grid.PosToXY(base.transform.GetPosition(), out num, out num2);
            int num3 = Grid.XYToCell(num, num2);

            if (Grid.IsValidCell(num3))
            {
                int world = (int)Grid.WorldIdx[num3];
                for (int i = vector2I.y; i <= vector2I2.y; i++)
                {
                    for (int j = vector2I.x; j <= vector2I2.x; j++)
                    {
                        int num4 = Grid.XYToCell(num + j, num2 + i);
                        if (Grid.IsValidCellInWorld(num4, world))
                        {
                            float num5 = (this.targetTemperature - Grid.Temperature[num4]) *
                                         Grid.Element[num4].specificHeatCapacity *
                                         Grid.Mass[num4] * temperatureControlK;

                            if (!Mathf.Approximately(0f, num5))
                            {
                                SimMessages.ModifyEnergy(num4, num5, 5000f,
                                    (num5 > 0f) ? SimMessages.EnergySourceID.DebugHeat : SimMessages.EnergySourceID.DebugCool);
                            }
                        }
                    }
                }
            }

            // ------------------- 新增：每秒检查一次温度并更新动画 -------------------
            lastUpdateTime += dt;
            if (lastUpdateTime >= UPDATE_INTERVAL)
            {
                lastUpdateTime = 0f;
                UpdateAnimation();
            }
        }

        private void UpdateAnimation()
        {
            if (animController == null) return;

            int cell = Grid.PosToCell(transform.GetPosition());
            if (!Grid.IsValidCell(cell)) return;

            float tempCelsius = Grid.Temperature[cell] - 273.15f;

            string targetAnim;
            if (tempCelsius <= COLD_TEMP)
                targetAnim = "cold";
            else if (tempCelsius >= HOT_TEMP)
                targetAnim = "hot";
            else
                targetAnim = "normal";

            // 仅当动画变化时才播放
            if (targetAnim != currentAnim)
            {
                animController.Play(targetAnim, KAnim.PlayMode.Loop);
                currentAnim = targetAnim;
            }
        }

        [ContextMenu("Refresh")]
        public void FullRefresh()
        {
            if (!base.isSpawned || !base.isActiveAndEnabled)
            {
                return;
            }
            UpdateAnimation(); // 手动刷新动画
        }
    }
}
