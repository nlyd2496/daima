﻿using System;
using UnityEngine;
using Klei;

namespace I_实用系统_1._0
{
    /// <summary>
    /// 温度可视化组件：根据所在位置的温度，动态改变物体颜色
    /// </支持自定义多段颜色映射，区间内平滑渐变：
    ///   [-263.15°C ~ -0.1°C]  青色
    ///   [ -0.1°C ~   9.9°C]  蓝色
    ///   [   9.9°C ~  19.9°C] 绿色
    ///   [  19.9°C ~  29.9°C] 黄色
    ///   [  29.9°C ~  36.9°C] 品红
    ///   [  36.9°C ~ 3000°C ] 红色（渐变至深红可选）
    /// 特点：只读取温度，不修改热力学数据，安全无冲突
    /// </summary>
    public class I004GG1K2_废弃 : KMonoBehaviour, ISim200ms
    {
        // 动画控制器引用（自动获取）
        [MyCmpGet]
        private KBatchedAnimController animController;

        // 更新频率控制
        private float _lastUpdateTime = 0f;
        [SerializeField] private float updateInterval = 0.5f; // 每0.5秒更新一次

        public void Sim200ms(float dt)
        {
            _lastUpdateTime += dt;
            if (_lastUpdateTime < updateInterval)
                return;

            _lastUpdateTime = 0f;

            // 获取当前位置的单元格
            int cellX, cellY;
            Vector3 pos = base.transform.GetPosition();
            Grid.PosToXY(pos, out cellX, out cellY);
            int cell = Grid.XYToCell(cellX, cellY);

            if (!Grid.IsValidCell(cell))
                return;

            float currentTemp = Grid.Temperature[cell]; // 单位：K
            currentTemp -= 273.15f; // 转换为摄氏度

            // 计算目标颜色
            Color targetColor = TemperatureToCustomColor(currentTemp);

            // 应用颜色遮罩
            if (animController != null)
            {
                animController.TintColour = targetColor;
            }
        }

        /// <summary>
        /// 根据温度返回对应颜色，区间内平滑渐变
        /// </summary>
        private Color TemperatureToCustomColor(float temp)
        {
            // 定义关键温度点（单位：°C）
            const float T_CyanEnd = -0.1f;
            const float T_BlueEnd = 9.9f;
            const float T_GreenEnd = 19.9f;
            const float T_YellowEnd = 29.9f;
            const float T_MagentaEnd = 36.9f;
            const float T_RedMax = 3000f;

            // 区间 1: <= -0.1°C → 青色
            if (temp <= T_CyanEnd) return Color.cyan;
            // 区间 2: -0.1°C ~ 9.9°C → 青色到蓝色
            else if (temp <= T_BlueEnd) return Color.Lerp(Color.cyan, Color.blue, Mathf.InverseLerp(T_CyanEnd, T_BlueEnd, temp));
            // 区间 3: 9.9°C ~ 19.9°C → 蓝色到绿色
            else if (temp <= T_GreenEnd) return Color.Lerp(Color.blue, Color.green, Mathf.InverseLerp(T_BlueEnd, T_GreenEnd, temp));
            // 区间 4: 19.9°C ~ 29.9°C → 绿色到黄色
            else if (temp <= T_YellowEnd) return Color.Lerp(Color.green, Color.yellow, Mathf.InverseLerp(T_GreenEnd, T_YellowEnd, temp));
            // 区间 5: 29.9°C ~ 36.9°C → 黄色到品红
            else if (temp <= T_MagentaEnd) return Color.Lerp(Color.yellow, Color.magenta, Mathf.InverseLerp(T_YellowEnd, T_MagentaEnd, temp));
            // 区间 6: >= 36.9°C → 品红到红色
            else return Color.Lerp(Color.magenta, Color.red, Mathf.InverseLerp(T_MagentaEnd, T_RedMax, temp));
        }
    }
}
// -273.15青色    -0.1 蓝色 9.9绿色  19.9 黄色 29.9 品红 36.9    1799.9红色