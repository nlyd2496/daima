﻿using HarmonyLib;
using System;
using System.Collections.Generic;
using System.Reflection;

namespace I_实用系统_1._0
{
    /*
    [HarmonyPatch(typeof(SpaceHeater), "MonitorHeating")]
    public class SpaceHeater_Temperature_Patch
    {
        // 使用 Prefix 拦截 MonitorHeating 方法
        // 注意：这里不再使用 SpaceHeater.MonitorState 作为参数类型，而是使用 object
        static bool Prefix(SpaceHeater __instance, ref object __result)
        {
            // 尝试获取我们自定义的模组组件
            var myComponent = __instance.GetComponent<I002GG1K2>();

            // 如果组件不存在（比如这是原版的其他加热器），则不拦截，让原版逻辑继续执行
            if (myComponent == null)
            {
                return true;
            }

            // ========== 以下是完全接管后的自定义温度判定逻辑 ==========

            // 1. 动态获取 MonitorState 枚举类型
            Type monitorStateType = AccessTools.Inner(typeof(SpaceHeater), "MonitorState");

            // 2. 获取预设的枚举值
            // 注意：如果枚举值名称发生变化，这里需要对应修改
            object notEnoughLiquid = Enum.Parse(monitorStateType, "NotEnoughLiquid");
            object tooHot = Enum.Parse(monitorStateType, "TooHot");
            object readyToHeat = Enum.Parse(monitorStateType, "ReadyToHeat");

            // 3. 获取加热器周围的监控单元格列表
            var monitorCells = (List<int>)AccessTools.Field(typeof(SpaceHeater), "monitorCells").GetValue(__instance);
            monitorCells.Clear();

            int radius = __instance.radius;
            GameUtil.GetNonSolidCells(Grid.PosToCell(__instance.transform.GetPosition()), radius, monitorCells);

            int validCellCount = 0;
            float totalTemp = 0f;

            // 遍历周围的格子，统计符合条件的液体平均温度
            foreach (int cell in monitorCells)
            {
                if (Grid.Mass[cell] > __instance.minimumCellMass && Grid.Element[cell].IsLiquid)
                {
                    validCellCount++;
                    totalTemp += Grid.Temperature[cell];
                }
            }

            // 如果没有足够的液体，返回 NotEnoughLiquid
            if (validCellCount == 0)
            {
                __result = notEnoughLiquid;
                return false; // 阻止原版逻辑
            }

            float averageTemp = totalTemp / validCellCount;
            // 获取我们滑块设定的目标温度（摄氏度转开尔文）
            float customTargetTemp = myComponent.AA + 273.15f;

            // 核心突破：使用我们自定义的目标温度进行判定，彻底抛弃 85°C 限制
            if (averageTemp >= customTargetTemp)
            {
                __result = tooHot;
                return false; // 阻止原版逻辑
            }

            // 温度未达标，继续加热
            __result = readyToHeat;
            return false; // 阻止原版逻辑
        }
    }
    */
}