﻿using HarmonyLib;
using PeterHan.PLib.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace I_实用系统_1._0
{
    [HarmonyPatch(typeof(SpaceHeaterConfig))]
    [HarmonyPatch("ConfigureBuildingTemplate")]
    public static class 智能空间加热器
    {
        public static void Postfix(GameObject go)
        {

                go.AddOrGet<I001GG1K1>();
                go.AddOrGet<MinimumOperatingTemperature>().minimumTemperature = 13.15f;//最低工作温度30K
            
        }
    }
    [HarmonyPatch(typeof(SpaceHeaterConfig))]
    [HarmonyPatch("CreateBuildingDef")]
    public class 智能空间加热器常规属性更改
    {
        public static void Postfix(ref BuildingDef __result)
        {

                __result.OverheatTemperature = 873.15f;
                __result.EnergyConsumptionWhenActive = 130f;
                __result.ExhaustKilowattsWhenActive = 3f;
            
        }
    }
}
