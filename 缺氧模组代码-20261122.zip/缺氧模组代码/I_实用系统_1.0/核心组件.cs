﻿using System;
using HarmonyLib;
using KMod;
using PeterHan.PLib.Core;
using PeterHan.PLib.Options;
using UnityEngine.Diagnostics;

namespace I_实用系统_1._0
{
	public class ModLoad : UserMod2
	{
        public static string Namespace { get; private set; }
        public override void OnLoad(Harmony harmony)
		{
            //--------------------------
            base.OnLoad(harmony);
            ModLoad.Namespace = base.GetType().Namespace;
            //配置项组件
            //new POptions().RegisterOptions(this, typeof(TestModSettings));
            PUtil.InitLibrary(true);
            new POptions().RegisterOptions(this, typeof(控制台));
            //--------------------------
            Namespace = base.GetType().Namespace;
            //--------------------------
        }
    }
}