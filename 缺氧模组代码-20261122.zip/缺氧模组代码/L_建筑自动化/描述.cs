﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HarmonyLib;
using STRINGS;
using KMod;
using PeterHan.PLib.Core;
using PeterHan.PLib.Database;
using Klei.AI;
using PeterHan.PLib.Options;

namespace L_建筑自动化
{

    public class STRINGS
    {
        public static void DoReplacement()
        {
            LocString.CreateLocStringKeys(typeof(STRINGS), "");
        }
        // 控制器
        
        // 建筑描述
        public class BUILDINGS
        {
            public class PREFABS
            {
                public class OOOOOOOOOOO
                {
                    public static LocString NAME = UI.FormatAsLink("安全门", "OOOOOOOOOOO");
                    public static LocString EFFECT = "OOOOOOOOOOO";
                    public static LocString DESC = "OOOOOOOOOOO";

                }
            }
        }
    }
}
