﻿using System;
using HarmonyLib;
using UnityEngine;

namespace L_建筑自动化
{
    [HarmonyPatch(typeof(Db), "Initialize")]
    public class 研究栏
    {
        public static void Postfix()
        {
            // Db.Get().Techs.Get("Combustion").unlockedItemIDs.Add("EMERGENYDOOR20230213");
        }
    }
}
