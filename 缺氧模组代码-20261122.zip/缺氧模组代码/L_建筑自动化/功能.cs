﻿using System;
using System.Collections.Generic;
using System.Reflection;
using HarmonyLib;
using UnityEngine;

namespace L_建筑自动化
{
    [HarmonyPatch(typeof(MetalRefineryConfig), "DoPostConfigureComplete")]
    public class 金属精炼器
    {
        public static void Postfix(GameObject go)
        {
            go.AddOrGet<BuildingComplete>().isManuallyOperated = false;
            LiquidCooledRefinery refinery = go.AddOrGet<LiquidCooledRefinery>();
            refinery.duplicantOperated = false;
        }
    }

    [HarmonyPatch(typeof(MicrobeMusherConfig), "DoPostConfigureComplete")]
    public class 食物压制器
    {
        public static void Postfix(GameObject go)
        {
            go.AddOrGet<BuildingComplete>().isManuallyOperated = false;
            go.AddOrGet<ComplexFabricator>().duplicantOperated = false;
        }
    }

    [HarmonyPatch(typeof(CookingStationConfig), "DoPostConfigureComplete")]
    public class 电动烤炉
    {
        public static void Postfix(GameObject go)
        {
            go.AddOrGet<BuildingComplete>().isManuallyOperated = false;
            go.AddOrGet<ComplexFabricator>().duplicantOperated = false;
        }
    }

    [HarmonyPatch(typeof(GourmetCookingStationConfig), "DoPostConfigureComplete")]
    public class 燃气灶X
    {
        public static void Postfix(GameObject go)
        {
            go.AddOrGet<BuildingComplete>().isManuallyOperated = false;
            go.AddOrGet<GourmetCookingStation>().duplicantOperated = false;
        }
    }

    [HarmonyPatch(typeof(EggCrackerConfig), "DoPostConfigureComplete")]
    public class 敲蛋桌X
    {
        public static void Postfix(GameObject go)
        {
            go.AddOrGet<BuildingComplete>().isManuallyOperated = false;
            go.AddOrGet<ComplexFabricator>().duplicantOperated = false;
        }
    }

    [HarmonyPatch(typeof(RockCrusherConfig), "DoPostConfigureComplete")]
    public class 碎石机X
    {
        public static void Postfix(GameObject go)
        {
            go.AddOrGet<BuildingComplete>().isManuallyOperated = false;
            ComplexFabricator refinery = go.AddOrGet<ComplexFabricator>();
            refinery.duplicantOperated = false;
        }
    }

    [HarmonyPatch(typeof(GlassForgeConfig), "DoPostConfigureComplete")]
    public class 玻璃熔炉X
    {
        public static void Postfix(GameObject go)
        {
            go.AddOrGet<BuildingComplete>().isManuallyOperated = false;
            GlassForge refinery = go.AddOrGet<GlassForge>();
            refinery.sideScreenStyle = ComplexFabricatorSideScreen.StyleSetting.ListQueueHybrid;
            ComplexFabricatorWorkable workable = go.AddOrGet<ComplexFabricatorWorkable>();
            refinery.duplicantOperated = false;
        }
    }

    [HarmonyPatch(typeof(SupermaterialRefineryConfig), "DoPostConfigureComplete")]
    public class 分子熔炉
    {
        public static void Postfix(GameObject go)
        {
            go.AddOrGet<BuildingComplete>().isManuallyOperated = false;
            go.AddOrGet<ComplexFabricator>().duplicantOperated = false;
        }
    }

    [HarmonyPatch(typeof(ClothingFabricatorConfig), "DoPostConfigureComplete")]
    public class 纺织机X
    {
        public static void Postfix(GameObject go)
        {
            go.AddOrGet<BuildingComplete>().isManuallyOperated = false;
            go.AddOrGet<ComplexFabricator>().duplicantOperated = false;
        }
    }

    [HarmonyPatch(typeof(SuitFabricatorConfig), "DoPostConfigureComplete")]
    public class 太空服锻造台
    {
        public static void Postfix(GameObject go)
        {
            go.AddOrGet<BuildingComplete>().isManuallyOperated = false;
            go.AddOrGet<ComplexFabricator>().duplicantOperated = false;
        }
    }

    [HarmonyPatch(typeof(ApothecaryConfig), "DoPostConfigureComplete")]
    public class 配药桌X
    {
        public static void Postfix(GameObject go)
        {
            go.AddOrGet<BuildingComplete>().isManuallyOperated = false;
            go.AddOrGet<ComplexFabricator>().duplicantOperated = false;
        }
    }
}