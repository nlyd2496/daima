﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HarmonyLib;
using STRINGS;
using KMod;
// using PeterHan.PLib.Core;
// using PeterHan.PLib.Database;
using Klei.AI;
// using PeterHan.PLib.Options;

namespace G_高效钻头前锥
{
    public class STRINGS
    {
        public class BUILDINGS
        {
            public class PREFABS
            {
                public class G_UI
                {
                    public static LocString G001GG1_UI = "启用高效钻头前锥";
                    public static LocString G001GG1X1_UI = "启用钻头前锥容量";
                    public static LocString G001GG1X2_UI = "启用钻头前锥挖掘速度";
                }
            }
        }
    }
}