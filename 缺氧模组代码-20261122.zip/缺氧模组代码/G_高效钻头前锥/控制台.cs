﻿using Newtonsoft.Json;
using PeterHan.PLib.Options;


namespace G_高效钻头前锥
{
    [RestartRequired]
    [JsonObject(MemberSerialization.OptIn)]
    [ConfigFile("G000GG0.json", true, true)]
    // [ModInfo("https://space.bilibili.com/30725645", "mmm.png", true)]

    public class 控制台 : SingletonOptions<控制台>
    {

        // 高效钻头前锥
        [Option("STRINGS.BUILDINGS.PREFABS.G_UI.G001GG1_UI", null, null)][JsonProperty] public bool G001GG1 { get; set; } = true;
        // 钻石容量
        [Option("STRINGS.BUILDINGS.PREFABS.G_UI.G001GG1X1_UI", null, null, Format = "F0")][Limit(1000, 1000000)][JsonProperty] public float G001GG1X1 { get; set; } = 100000f;
        // 钻头挖掘速度
        [Option("STRINGS.BUILDINGS.PREFABS.G_UI.G001GG1X2_UI", null, null, Format = "F0")][Limit(10, 100)][JsonProperty] public float G001GG1X2 { get; set; } = 50f;
        
    }

}
