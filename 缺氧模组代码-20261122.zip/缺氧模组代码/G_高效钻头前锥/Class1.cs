﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace G_高效钻头前锥
{
    public class Class1
    {
    }
}
