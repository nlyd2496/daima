﻿using UnityEngine;
using HarmonyLib;
using System.Collections.Generic;

namespace M_金属精炼器自动化
{
    [HarmonyPatch(typeof(MetalRefineryConfig))]
    [HarmonyPatch("ConfigureBuildingTemplate")]
    public class M_金属精炼器自动化
    {
        private static void Postfix(GameObject go)
        {
            go.AddOrGet<BuildingComplete>().isManuallyOperated = false;
            go.AddOrGet<LiquidCooledRefinery>().duplicantOperated = false;
        }
    }
}
