﻿using HarmonyLib;
using PeterHan.PLib.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TUNING;
using UnityEngine;

namespace G_火箭系统_1._0
{
    [HarmonyPatch(typeof(LiquidCargoBayClusterConfig))]
    [HarmonyPatch("DoPostConfigureComplete")]
    public class 火箭大型液缸容量
    {
        public static void Postfix(GameObject go)
        {
            bool G004GG1 = SingletonOptions<控制台>.Instance.G004GG1;
            if (G004GG1)
            {
                go = BuildingTemplates.ExtendBuildingToClusterCargoBay(go, SingletonOptions<控制台>.Instance.G004GG1X1, STORAGEFILTERS.LIQUIDS, CargoBay.CargoType.Liquids);
            }
        }
    }
    [HarmonyPatch(typeof(LiquidCargoBaySmallConfig))]
    [HarmonyPatch("DoPostConfigureComplete")]
    public class 火箭小型液缸容量
    {
        public static void Postfix(GameObject go)
        {
            bool G004GG1 = SingletonOptions<控制台>.Instance.G004GG1;
            if (G004GG1)
            {
                go = BuildingTemplates.ExtendBuildingToClusterCargoBay(go, SingletonOptions<控制台>.Instance.G004GG1X1, STORAGEFILTERS.LIQUIDS, CargoBay.CargoType.Liquids);
            }
        }
    }
        [HarmonyPatch(typeof(GasCargoBayClusterConfig))]
        [HarmonyPatch("DoPostConfigureComplete")]
        public class 火箭大型气缸容量
    {
            public static void Postfix(GameObject go)
            {
                bool G004GG1 = SingletonOptions<控制台>.Instance.G004GG1;
                if (G004GG1)
                {
                    go = BuildingTemplates.ExtendBuildingToClusterCargoBay(go, SingletonOptions<控制台>.Instance.G004GG1X1, STORAGEFILTERS.GASES, CargoBay.CargoType.Gasses);
                }
            }
        }
    [HarmonyPatch(typeof(GasCargoBaySmallConfig))]
    [HarmonyPatch("DoPostConfigureComplete")]
    public class 火箭小型气缸容量
    {
        public static void Postfix(GameObject go)
        {
            bool G004GG1 = SingletonOptions<控制台>.Instance.G004GG1;
            if (G004GG1)
            {
                go = BuildingTemplates.ExtendBuildingToClusterCargoBay(go, SingletonOptions<控制台>.Instance.G004GG1X1, STORAGEFILTERS.GASES, CargoBay.CargoType.Gasses);
            }
        }
    }
    [HarmonyPatch(typeof(SolidCargoBayClusterConfig))]
    [HarmonyPatch("DoPostConfigureComplete")]
    public class 火箭大型固缸容量
    {
        public static void Postfix(GameObject go)
        {
            bool G004GG1 = SingletonOptions<控制台>.Instance.G004GG1;
            if (G004GG1)
            {
                go = BuildingTemplates.ExtendBuildingToClusterCargoBay(go, SingletonOptions<控制台>.Instance.G004GG1X1, STORAGEFILTERS.STORAGE_SOLID_CARGO_BAY, new List<Tag>(2)
                {
                    GameTags.Liquid,
                    GameTags.Gas
                }, CargoBay.CargoType.Solids);
            }
        }
    }
    [HarmonyPatch(typeof(SolidCargoBaySmallConfig))]
    [HarmonyPatch("DoPostConfigureComplete")]
    public class 火箭小型固缸容量
    {
        public static void Postfix(GameObject go)
        {
            bool G004GG1 = SingletonOptions<控制台>.Instance.G004GG1;
            if (G004GG1)
            {
                go = BuildingTemplates.ExtendBuildingToClusterCargoBay(go, SingletonOptions<控制台>.Instance.G004GG1X1, STORAGEFILTERS.STORAGE_SOLID_CARGO_BAY, new List<Tag>(2)
                {
                    GameTags.Liquid,
                    GameTags.Gas
                }, CargoBay.CargoType.Solids);            }
        }
    }
}
