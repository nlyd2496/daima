﻿using Newtonsoft.Json;
using PeterHan.PLib.Options;


namespace G_火箭系统_1._0
{
    [RestartRequired]
    [JsonObject(MemberSerialization.OptIn)]
    [ConfigFile("G000GG0.json", true, true)]
    // [ModInfo("https://space.bilibili.com/30725645", "mmm.png", true)]

    public class 控制台 : SingletonOptions<控制台>
    {

        // 高效钻头前锥
        [Option("STRINGS.BUILDINGS.PREFABS.G_UI.G001GG1_UI", null, "STRINGS.BUILDINGS.PREFABS.G_UI.G001GG0_UI")][JsonProperty] public bool G001GG1 { get; set; } = true;
        // 钻石容量
        [Option("STRINGS.BUILDINGS.PREFABS.G_UI.G001GG1X1_UI", null, "STRINGS.BUILDINGS.PREFABS.G_UI.G001GG0_UI", Format = "F0")][Limit(1000, 1000000)][JsonProperty] public float G001GG1X1 { get; set; } = 100000f;
        // 钻头挖掘速度
        [Option("STRINGS.BUILDINGS.PREFABS.G_UI.G001GG1X2_UI", null, "STRINGS.BUILDINGS.PREFABS.G_UI.G001GG0_UI", Format = "F0")][Limit(10, 100)][JsonProperty] public float G001GG1X2 { get; set; } = 50f;
        
        // 火箭燃料仓输入更改
        [Option("STRINGS.BUILDINGS.PREFABS.G_UI.G002GG1_UI", null, "STRINGS.BUILDINGS.PREFABS.G_UI.G001GG0_UI")][JsonProperty] public bool G002GG1 { get; set; } = true;

        // 侦察者电量修改
        [Option("STRINGS.BUILDINGS.PREFABS.G_UI.G003GG1_UI", null, "STRINGS.BUILDINGS.PREFABS.G_UI.G002GG0_UI")][JsonProperty] public bool G003GG1 { get; set; } = true;       
        // 电量
        [Option("STRINGS.BUILDINGS.PREFABS.G_UI.G003GG1X1_UI", null, "STRINGS.BUILDINGS.PREFABS.G_UI.G002GG0_UI", Format = "F0")][Limit(1, 1000000000)][JsonProperty] public float G003GG1X1 { get; set; } = 1000000f;
       
        // 火箭更大货仓
        [Option("STRINGS.BUILDINGS.PREFABS.G_UI.G004GG1_UI", null, "STRINGS.BUILDINGS.PREFABS.G_UI.G001GG0_UI")][JsonProperty] public bool G004GG1 { get; set; } = true;
        // 货仓容量
        [Option("STRINGS.BUILDINGS.PREFABS.G_UI.G004GG1X1_UI", null, "STRINGS.BUILDINGS.PREFABS.G_UI.G001GG0_UI", Format = "F0")][Limit(1, 100000)][JsonProperty] public float G004GG1X1 { get; set; } = 10000f;
        
        // 液氢引擎
        [Option("STRINGS.BUILDINGS.PREFABS.G_UI.G005GG1_UI", null, "STRINGS.BUILDINGS.PREFABS.G_UI.G003GG0_UI")][JsonProperty] public bool G005GG1 { get; set; } = true;
        // 火箭高度
        [Option("STRINGS.BUILDINGS.PREFABS.G_UI.G005GG1X1_UI", null, "STRINGS.BUILDINGS.PREFABS.G_UI.G003GG0_UI", Format = "F0")][Limit(10, 100)][JsonProperty] public float G005GG1X1 { get; set; } = 50f;
        // 负担
        [Option("STRINGS.BUILDINGS.PREFABS.G_UI.G005GG1X2_UI", null, "STRINGS.BUILDINGS.PREFABS.G_UI.G003GG0_UI", Format = "F0")][Limit(1, 10)][JsonProperty] public float G005GG1X2 { get; set; } = 1f;
        // 引擎功率
        [Option("STRINGS.BUILDINGS.PREFABS.G_UI.G005GG1X3_UI", null, "STRINGS.BUILDINGS.PREFABS.G_UI.G003GG0_UI", Format = "F0")][Limit(1, 100)][JsonProperty] public float G005GG1X3 { get; set; } = 50f;
        // 每单位燃料
        [Option("STRINGS.BUILDINGS.PREFABS.G_UI.G005GG1X4_UI", null, "STRINGS.BUILDINGS.PREFABS.G_UI.G003GG0_UI", Format = "F0")][Limit(1, 10)][JsonProperty] public float G005GG1X4 { get; set; } = 1f;
        
        // 石油引擎
        [Option("STRINGS.BUILDINGS.PREFABS.G_UI.G005GG2_UI", null, "STRINGS.BUILDINGS.PREFABS.G_UI.G004GG0_UI")][JsonProperty] public bool G005GG2 { get; set; } = true;
        // 火箭高度
        [Option("STRINGS.BUILDINGS.PREFABS.G_UI.G005GG2X1_UI", null, "STRINGS.BUILDINGS.PREFABS.G_UI.G004GG0_UI", Format = "F0")][Limit(10, 100)][JsonProperty] public float G005GG2X1 { get; set; } = 50f;
        // 负担
        [Option("STRINGS.BUILDINGS.PREFABS.G_UI.G005GG2X2_UI", null, "STRINGS.BUILDINGS.PREFABS.G_UI.G004GG0_UI", Format = "F0")][Limit(1, 10)][JsonProperty] public float G005GG2X2 { get; set; } = 1f;
        // 引擎功率
        [Option("STRINGS.BUILDINGS.PREFABS.G_UI.G005GG2X3_UI", null, "STRINGS.BUILDINGS.PREFABS.G_UI.G004GG0_UI", Format = "F0")][Limit(1, 100)][JsonProperty] public float G005GG2X3 { get; set; } = 50f;
        // 每单位燃料
        [Option("STRINGS.BUILDINGS.PREFABS.G_UI.G005GG2X4_UI", null, "STRINGS.BUILDINGS.PREFABS.G_UI.G004GG0_UI", Format = "F0")][Limit(1, 10)][JsonProperty] public float G005GG2X4 { get; set; } = 1f;

        // 小型石油引擎
        [Option("STRINGS.BUILDINGS.PREFABS.G_UI.G005GG3_UI", null, "STRINGS.BUILDINGS.PREFABS.G_UI.G005GG0_UI")][JsonProperty] public bool G005GG3 { get; set; } = true;
        // 火箭高度
        [Option("STRINGS.BUILDINGS.PREFABS.G_UI.G005GG3X1_UI", null, "STRINGS.BUILDINGS.PREFABS.G_UI.G005GG0_UI", Format = "F0")][Limit(10, 100)][JsonProperty] public float G005GG3X1 { get; set; } = 50f;
        // 负担
        [Option("STRINGS.BUILDINGS.PREFABS.G_UI.G005GG3X2_UI", null, "STRINGS.BUILDINGS.PREFABS.G_UI.G005GG0_UI", Format = "F0")][Limit(1, 10)][JsonProperty] public float G005GG3X2 { get; set; } = 1f;
        // 引擎功率
        [Option("STRINGS.BUILDINGS.PREFABS.G_UI.G005GG3X3_UI", null, "STRINGS.BUILDINGS.PREFABS.G_UI.G005GG0_UI", Format = "F0")][Limit(1, 100)][JsonProperty] public float G005GG3X3 { get; set; } = 50f;
        // 每单位燃料
        [Option("STRINGS.BUILDINGS.PREFABS.G_UI.G005GG3X4_UI", null, "STRINGS.BUILDINGS.PREFABS.G_UI.G005GG0_UI", Format = "F0")][Limit(1, 10)][JsonProperty] public float G005GG3X4 { get; set; } = 1f;

        // 蒸汽引擎
        [Option("STRINGS.BUILDINGS.PREFABS.G_UI.G005GG4_UI", null, "STRINGS.BUILDINGS.PREFABS.G_UI.G006GG0_UI")][JsonProperty] public bool G005GG4 { get; set; } = true;
        // 火箭高度
        [Option("STRINGS.BUILDINGS.PREFABS.G_UI.G005GG4X1_UI", null, "STRINGS.BUILDINGS.PREFABS.G_UI.G006GG0_UI", Format = "F0")][Limit(10, 100)][JsonProperty] public float G005GG4X1 { get; set; } = 50f;
        // 负担     
        [Option("STRINGS.BUILDINGS.PREFABS.G_UI.G005GG4X2_UI", null, "STRINGS.BUILDINGS.PREFABS.G_UI.G006GG0_UI", Format = "F0")][Limit(1, 10)][JsonProperty] public float G005GG4X2 { get; set; } = 1f;
        // 引擎功率
        [Option("STRINGS.BUILDINGS.PREFABS.G_UI.G005GG4X3_UI", null, "STRINGS.BUILDINGS.PREFABS.G_UI.G006GG0_UI", Format = "F0")][Limit(1, 100)][JsonProperty] public float G005GG4X3 { get; set; } = 50f;
        // 每单位燃料
        [Option("STRINGS.BUILDINGS.PREFABS.G_UI.G005GG4X4_UI", null, "STRINGS.BUILDINGS.PREFABS.G_UI.G006GG0_UI", Format = "F0")][Limit(1, 10)][JsonProperty] public float G005GG4X4 { get; set; }

        // 糖素引擎
        [Option("STRINGS.BUILDINGS.PREFABS.G_UI.G005GG5_UI", null, "STRINGS.BUILDINGS.PREFABS.G_UI.G007GG0_UI")][JsonProperty] public bool G005GG5 { get; set; } = true;
        // 火箭高度
        [Option("STRINGS.BUILDINGS.PREFABS.G_UI.G005GG5X1_UI", null, "STRINGS.BUILDINGS.PREFABS.G_UI.G007GG0_UI", Format = "F0")][Limit(10, 100)][JsonProperty] public float G005GG5X1 { get; set; } = 50f;
        // 负担 
        [Option("STRINGS.BUILDINGS.PREFABS.G_UI.G005GG5X2_UI", null, "STRINGS.BUILDINGS.PREFABS.G_UI.G007GG0_UI", Format = "F0")][Limit(1, 10)][JsonProperty] public float G005GG5X2 { get; set; } = 1f;
        // 引擎功率
        [Option("STRINGS.BUILDINGS.PREFABS.G_UI.G005GG5X3_UI", null, "STRINGS.BUILDINGS.PREFABS.G_UI.G007GG0_UI", Format = "F0")][Limit(1, 100)][JsonProperty] public float G005GG5X3 { get; set; } = 50f;
        // 每单位燃料
        [Option("STRINGS.BUILDINGS.PREFABS.G_UI.G005GG5X4_UI", null, "STRINGS.BUILDINGS.PREFABS.G_UI.G007GG0_UI", Format = "F0")][Limit(1, 10)][JsonProperty] public float G005GG5X4 { get; set; } = 1f;

        // 二氧化碳引擎
        [Option("STRINGS.BUILDINGS.PREFABS.G_UI.G005GG6_UI", null, "STRINGS.BUILDINGS.PREFABS.G_UI.G008GG0_UI")][JsonProperty] public bool G005GG6 { get; set; } = true;
        // 火箭高度
        [Option("STRINGS.BUILDINGS.PREFABS.G_UI.G005GG6X1_UI", null, "STRINGS.BUILDINGS.PREFABS.G_UI.G008GG0_UI", Format = "F0")][Limit(10, 100)][JsonProperty] public float G005GG6X1 { get; set; } = 50f;
        // 负担 
        [Option("STRINGS.BUILDINGS.PREFABS.G_UI.G005GG6X2_UI", null, "STRINGS.BUILDINGS.PREFABS.G_UI.G008GG0_UI", Format = "F0")][Limit(1, 10)][JsonProperty] public float G005GG6X2 { get; set; } = 1f;
        // 引擎功率
        [Option("STRINGS.BUILDINGS.PREFABS.G_UI.G005GG6X3_UI", null, "STRINGS.BUILDINGS.PREFABS.G_UI.G008GG0_UI", Format = "F0")][Limit(1, 100)][JsonProperty] public float G005GG6X3 { get; set; } = 50f;
        // 每单位燃料
        [Option("STRINGS.BUILDINGS.PREFABS.G_UI.G005GG6X4_UI", null, "STRINGS.BUILDINGS.PREFABS.G_UI.G008GG0_UI", Format = "F0")][Limit(1, 10)][JsonProperty] public float G005GG6X4 { get; set; } = 1f;

        // 辐射粒子引擎
        [Option("STRINGS.BUILDINGS.PREFABS.G_UI.G005GG7_UI", null, "STRINGS.BUILDINGS.PREFABS.G_UI.G009GG0_UI")][JsonProperty] public bool G005GG7 { get; set; } = true;
        // 火箭高度
        [Option("STRINGS.BUILDINGS.PREFABS.G_UI.G005GG7X1_UI", null, "STRINGS.BUILDINGS.PREFABS.G_UI.G009GG0_UI", Format = "F0")][Limit(10, 100)][JsonProperty] public float G005GG7X1 { get; set; } = 50f;
        // 负担
        [Option("STRINGS.BUILDINGS.PREFABS.G_UI.G005GG7X2_UI", null, "STRINGS.BUILDINGS.PREFABS.G_UI.G009GG0_UI", Format = "F0")][Limit(1, 10)][JsonProperty] public float G005GG7X2 { get; set; } = 1f;
        // 引擎功率
        [Option("STRINGS.BUILDINGS.PREFABS.G_UI.G005GG7X3_UI", null, "STRINGS.BUILDINGS.PREFABS.G_UI.G009GG0_UI", Format = "F0")][Limit(1, 100)][JsonProperty] public float G005GG7X3 { get; set; } = 50f;
        // 每单位燃料
        [Option("STRINGS.BUILDINGS.PREFABS.G_UI.G005GG7X4_UI", null, "STRINGS.BUILDINGS.PREFABS.G_UI.G009GG0_UI", Format = "F0")][Limit(1, 10)][JsonProperty] public float G005GG7X4 { get; set; } = 1f;
        
        // 星球资源恢复
        [Option("STRINGS.BUILDINGS.PREFABS.G_UI.G006GG1_UI", null, "STRINGS.BUILDINGS.PREFABS.G_UI.G0010GG0_UI")][JsonProperty] public bool G006GG1 { get; set; } = true;
        
        // 超级望远镜
        [Option("STRINGS.BUILDINGS.PREFABS.G_UI.G007GG1X1_UI", null, "STRINGS.BUILDINGS.PREFABS.G_UI.G0011GG0_UI")][JsonProperty] public bool G007GG1X1 { get; set; } = true;
        // 望远镜监测范围增加
        [Option("STRINGS.BUILDINGS.PREFABS.G_UI.G007GG1X2_UI", null, "STRINGS.BUILDINGS.PREFABS.G_UI.G0011GG0_UI")][JsonProperty] public bool G007GG1X2 { get; set; } = true;
        // 隔绝式望远镜不耗电
        [Option("STRINGS.BUILDINGS.PREFABS.G_UI.G007GG1X3_UI", null, "STRINGS.BUILDINGS.PREFABS.G_UI.G0011GG0_UI")][JsonProperty] public bool G007GG1X3 { get; set; } = true;







    }

}
