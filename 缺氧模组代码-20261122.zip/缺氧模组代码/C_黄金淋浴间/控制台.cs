﻿using Newtonsoft.Json;
using PeterHan.PLib.Options;


namespace C_黄金淋浴间
{
    [RestartRequired]
    [JsonObject(MemberSerialization.OptIn)]
    [ConfigFile("J001GG1.json", true, false)]
    [ModInfo("https://space.bilibili.com/30725645", "mmm.png", true)]

    public class 控制台 : SingletonOptions<控制台>
    {
        
    }
}
