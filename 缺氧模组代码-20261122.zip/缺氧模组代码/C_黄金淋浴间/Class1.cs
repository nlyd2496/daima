﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C_黄金淋浴间
{
    public class Class1
    {
    }
}
