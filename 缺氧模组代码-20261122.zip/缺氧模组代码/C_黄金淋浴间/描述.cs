﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HarmonyLib;
using STRINGS;
using KMod;
using PeterHan.PLib.Core;
using PeterHan.PLib.Database;
using Klei.AI;
using PeterHan.PLib.Options;

namespace C_黄金淋浴间
{
    public class STRINGS
    {
        public static void DoReplacement()
        {
            LocString.CreateLocStringKeys(typeof(STRINGS), "");
        }
        public class BUILDINGS
        {
            public class PREFABS
            {
                public class C013GG1
                {
                    public static LocString NAME = UI.FormatAsLink("黄金淋浴间", "C013GG1");
                    public static LocString DESC = "定期在金闪闪的淋浴间洗澡，愚蠢的负智人都变得更漂亮了。";
                    public static LocString EFFECT = string.Concat(new string[]
                    {
                        "为复制人提供",UI.FormatAsLink("士气", "MORALE"),"，并移除大量",UI.FormatAsLink("细菌", "DISEASE"),"。"
                    });
                    
                }
            }
        }
    }
}
