﻿using HarmonyLib;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace I_强化制冰机
{
    //----------------------------------------------------------------------------------------------------
    [HarmonyPatch(typeof(IceMachineConfig))]
    [HarmonyPatch("CreateBuildingDef")]
    public class 发热量及功率提升
    {
        public static void Postfix(ref BuildingDef __result)
        {
            __result.EnergyConsumptionWhenActive = 80f;//-------------------------------   60
            __result.ExhaustKilowattsWhenActive = 8f;//----------------------------------   4
            __result.SelfHeatKilowattsWhenActive = 20f;//--------------------------------   12
        }
    }
    //----------------------------------------------------------------------------------------------------
    [HarmonyPatch(typeof(IceMachineConfig))]
    [HarmonyPatch("ConfigureBuildingTemplate")]
    internal class 容量及效率强化
    {
        private static void Postfix(GameObject go, Tag prefab_tag)
        {
            Storage storage = go.AddOrGet<Storage>();
            storage.capacityKg = 200f;//-------------------------------------------------    30
            Storage storage2 = go.AddComponent<Storage>();
            storage2.capacityKg = 2000f;//-----------------------------------------------    150
            IceMachine iceMachine = go.AddOrGet<IceMachine>();
            iceMachine.SetStorages(storage, storage2);
            iceMachine.heatRemovalRate = 500f;//-----------------------------------------    20
            ManualDeliveryKG manualDeliveryKG = go.AddOrGet<ManualDeliveryKG>();
            manualDeliveryKG.capacity = 200f;//------------------------------------------    30

        }
    }
    //----------------------------------------------------------------------------------------------------
}
