﻿using System;
using HarmonyLib;
using KMod;
using UnityEngine.Diagnostics;

namespace I_强化制冰机
{
    public class ModLoad : UserMod2
	{
        public static string Namespace { get; private set; }
        public override void OnLoad(Harmony harmony)
		{
            base.OnLoad(harmony);
            ModLoad.Namespace = base.GetType().Namespace;
            Namespace = base.GetType().Namespace;
        }        
    }
}