﻿using HarmonyLib;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T_安的魔法厨房_2._0
{
    [HarmonyPatch(typeof(GeneratedBuildings))]
    [HarmonyPatch("LoadGeneratedBuildings")]
    public class 建筑栏
    {
        public static void Prefix()
        {
            ModUtil.AddBuildingToPlanScreen("Food", "TA001GG1"); // 种子生成站
            ModUtil.AddBuildingToPlanScreen("Food", "UA001GG1"); // 冰淇淋机
            ModUtil.AddBuildingToPlanScreen("Food", "UA002GG1"); // 磨面机
            ModUtil.AddBuildingToPlanScreen("Food", "UA003GG1"); // 榨汁机

        }
    }
}
//  基地 氧气   电力  食物 液管     气管 精炼     医疗    家具      站台      实用      自动化     运输       火箭     辐射
//  Base Oxygen Power Food Plumbing HVAC Refining Medical Furniture Equipment Utilities Automation Conveyance Rocketry HEP
