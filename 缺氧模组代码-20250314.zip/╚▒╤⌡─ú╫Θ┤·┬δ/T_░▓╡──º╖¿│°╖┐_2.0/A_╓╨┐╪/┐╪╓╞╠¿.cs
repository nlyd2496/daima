﻿using Newtonsoft.Json;
using PeterHan.PLib.Options;


namespace T_安的魔法厨房_2._0
{
    [RestartRequired]
    [JsonObject(MemberSerialization.OptIn)]
    [ConfigFile("T000GG0.json", true, false)]
    // [ModInfo("https://space.bilibili.com/30725645", "mmm.png", true)]

    public class 控制台 : SingletonOptions<控制台>
    {       
        // 冰淇淋机
        [Option("STRINGS.BUILDINGS.PREFABS.T_UI.UA001GG1_UI", null, "STRINGS.BUILDINGS.PREFABS.T_UI.UA000GG0_UI")][JsonProperty] public bool UA001GG1 { get; set; } = true;
        // 磨面机
        [Option("STRINGS.BUILDINGS.PREFABS.T_UI.UA002GG1_UI", null, "STRINGS.BUILDINGS.PREFABS.T_UI.UA000GG0_UI")][JsonProperty] public bool UA002GG1 { get; set; } = true;
        // 榨汁机
        [Option("STRINGS.BUILDINGS.PREFABS.T_UI.UA003GG1_UI", null, "STRINGS.BUILDINGS.PREFABS.T_UI.UA000GG0_UI")][JsonProperty] public bool UA003GG1 { get; set; } = true;
        // 冰淇淋---1
        [Option("STRINGS.BUILDINGS.PREFABS.T_UI.U001GG1X1_UI", null, "STRINGS.BUILDINGS.PREFABS.T_UI.U000GG0_UI")][JsonProperty] public bool U001GG1X1 { get; set; } = true;
        // 月饼---2
        [Option("STRINGS.BUILDINGS.PREFABS.T_UI.U002GG1X1_UI", null, "STRINGS.BUILDINGS.PREFABS.T_UI.U000GG0_UI")][JsonProperty] public bool U002GG1X1 { get; set; } = true;
        // 饺子---3
        [Option("STRINGS.BUILDINGS.PREFABS.T_UI.U003GG1X1_UI", null, "STRINGS.BUILDINGS.PREFABS.T_UI.U000GG0_UI")][JsonProperty] public bool U003GG1X1 { get; set; } = true;
        // 川菜---4
        [Option("STRINGS.BUILDINGS.PREFABS.T_UI.U004GG1X1_UI", null, "STRINGS.BUILDINGS.PREFABS.T_UI.U000GG0_UI")][JsonProperty] public bool U004GG1X1 { get; set; } = true;
        // 奶油---5
        [Option("STRINGS.BUILDINGS.PREFABS.T_UI.U005GG1X1_UI", null, "STRINGS.BUILDINGS.PREFABS.T_UI.U000GG0_UI")][JsonProperty] public bool U005GG1X1 { get; set; } = true;
        // 细份---6
        [Option("STRINGS.BUILDINGS.PREFABS.T_UI.U006GG1X1_UI", null, "STRINGS.BUILDINGS.PREFABS.T_UI.U000GG0_UI")][JsonProperty] public bool U006GG1X1 { get; set; } = true;
        // 面食---7
        [Option("STRINGS.BUILDINGS.PREFABS.T_UI.U007GG1X1_UI", null, "STRINGS.BUILDINGS.PREFABS.T_UI.U000GG0_UI")][JsonProperty] public bool U007GG1X1 { get; set; } = true;
        // 果汁---8
        [Option("STRINGS.BUILDINGS.PREFABS.T_UI.U008GG1X1_UI", null, "STRINGS.BUILDINGS.PREFABS.T_UI.U000GG0_UI")][JsonProperty] public bool U008GG1X1 { get; set; } = true;

    }
}
