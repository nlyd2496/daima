﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HarmonyLib;
using STRINGS;
using CaiLib.Utils;
using KMod;
using PeterHan.PLib.Core;
using PeterHan.PLib.Database;
using Klei.AI;
using PeterHan.PLib.Options;

namespace T_安的魔法厨房_2._0
{
    public class STRINGS
    {
        public static void DoReplacement()
        {
            LocString.CreateLocStringKeys(typeof(STRINGS), "");
        }
        
        [HarmonyPatch(typeof(EntityConfigManager))]
        [HarmonyPatch("LoadGeneratedEntities")]
        
        
        


        public class 添加到数据库
        {
            public static void Prefix()
            {
                //------------------------------------------------------------新植物------------------------------------------------------------
                // 辣椒
                StringUtils.AddPlantSeedStrings("T001GG1Z1", STRINGS.CREATURES.SPECIES.T001GG1Z1.T1, STRINGS.CREATURES.SPECIES.T001GG1Z1.T2);//添加种子
                StringUtils.AddPlantStrings("T001GG1Z2", STRINGS.CREATURES.SPECIES.T001GG1Z1.T3, STRINGS.CREATURES.SPECIES.T001GG1Z1.T4, STRINGS.CREATURES.SPECIES.T001GG1Z1.T5);//添加植物
                PlantUtils.AddCropType("T001GG1Z3", 1f, 1);//果实属性 生长周期 掉落种子数
                StringUtils.AddFoodStrings("T001GG1Z3", STRINGS.CREATURES.SPECIES.T001GG1Z1.T6, STRINGS.CREATURES.SPECIES.T001GG1Z1.T7);//添加果实

                // 花椒
                StringUtils.AddPlantSeedStrings("T002GG1Z1", STRINGS.CREATURES.SPECIES.T002GG1Z1.T1, STRINGS.CREATURES.SPECIES.T002GG1Z1.T2);//添加种子
                StringUtils.AddPlantStrings("T002GG1Z2", STRINGS.CREATURES.SPECIES.T002GG1Z1.T3, STRINGS.CREATURES.SPECIES.T002GG1Z1.T4, STRINGS.CREATURES.SPECIES.T002GG1Z1.T5);//添加植物
                PlantUtils.AddCropType("T002GG1Z3", 1f, 1);//果实属性 生长周期 掉落种子数
                StringUtils.AddFoodStrings("T002GG1Z3", STRINGS.CREATURES.SPECIES.T002GG1Z1.T6, STRINGS.CREATURES.SPECIES.T002GG1Z1.T7);//添加果实

                // 香蕉
                StringUtils.AddPlantSeedStrings("T003GG1Z1", STRINGS.CREATURES.SPECIES.T003GG1Z1.T1, STRINGS.CREATURES.SPECIES.T003GG1Z1.T2);//添加种子
                StringUtils.AddPlantStrings("T003GG1Z2", STRINGS.CREATURES.SPECIES.T003GG1Z1.T3, STRINGS.CREATURES.SPECIES.T003GG1Z1.T4, STRINGS.CREATURES.SPECIES.T003GG1Z1.T5);//添加植物
                PlantUtils.AddCropType("T003GG1Z3", 4f, 1);//果实属性 生长周期 掉落种子数
                StringUtils.AddFoodStrings("T003GG1Z3", STRINGS.CREATURES.SPECIES.T003GG1Z1.T6, STRINGS.CREATURES.SPECIES.T003GG1Z1.T7);//添加果实

                // 西红柿
                StringUtils.AddPlantSeedStrings("T004GG1Z1", STRINGS.CREATURES.SPECIES.T004GG1Z1.T1, STRINGS.CREATURES.SPECIES.T004GG1Z1.T2);//添加种子
                StringUtils.AddPlantStrings("T004GG1Z2", STRINGS.CREATURES.SPECIES.T004GG1Z1.T3, STRINGS.CREATURES.SPECIES.T004GG1Z1.T4, STRINGS.CREATURES.SPECIES.T004GG1Z1.T5);//添加植物
                PlantUtils.AddCropType("T004GG1Z3", 4f, 1);//果实属性 生长周期 掉落种子数
                StringUtils.AddFoodStrings("T004GG1Z3", STRINGS.CREATURES.SPECIES.T004GG1Z1.T6, STRINGS.CREATURES.SPECIES.T004GG1Z1.T7);//添加果实

                // 白菜
                StringUtils.AddPlantSeedStrings("T005GG1Z1", STRINGS.CREATURES.SPECIES.T005GG1Z1.T1, STRINGS.CREATURES.SPECIES.T005GG1Z1.T2);//添加种子
                StringUtils.AddPlantStrings("T005GG1Z2", STRINGS.CREATURES.SPECIES.T005GG1Z1.T3, STRINGS.CREATURES.SPECIES.T005GG1Z1.T4, STRINGS.CREATURES.SPECIES.T005GG1Z1.T5);//添加植物
                PlantUtils.AddCropType("T005GG1Z3", 2f, 1);//果实属性 生长周期 掉落种子数
                StringUtils.AddFoodStrings("T005GG1Z3", STRINGS.CREATURES.SPECIES.T005GG1Z1.T6, STRINGS.CREATURES.SPECIES.T005GG1Z1.T7);//添加果实

                // 西瓜
                StringUtils.AddPlantSeedStrings("T006GG1Z1", STRINGS.CREATURES.SPECIES.T006GG1Z1.T1, STRINGS.CREATURES.SPECIES.T006GG1Z1.T2);//添加种子
                StringUtils.AddPlantStrings("T006GG1Z2", STRINGS.CREATURES.SPECIES.T006GG1Z1.T3, STRINGS.CREATURES.SPECIES.T006GG1Z1.T4, STRINGS.CREATURES.SPECIES.T006GG1Z1.T5);//添加植物
                PlantUtils.AddCropType("T006GG1Z3", 4f, 1);//果实属性 生长周期 掉落种子数
                StringUtils.AddFoodStrings("T006GG1Z3", STRINGS.CREATURES.SPECIES.T006GG1Z1.T6, STRINGS.CREATURES.SPECIES.T006GG1Z1.T7);//添加果实
                
                // 玫瑰
                StringUtils.AddPlantSeedStrings("T007GG1Z1", STRINGS.CREATURES.SPECIES.T007GG1Z1.T1, STRINGS.CREATURES.SPECIES.T007GG1Z1.T2);//添加种子
                StringUtils.AddPlantStrings("T007GG1Z2", STRINGS.CREATURES.SPECIES.T007GG1Z1.T3, STRINGS.CREATURES.SPECIES.T007GG1Z1.T4, STRINGS.CREATURES.SPECIES.T007GG1Z1.T5);//添加植物

                // 百合
                StringUtils.AddPlantSeedStrings("T007GG2Z1", STRINGS.CREATURES.SPECIES.T007GG2Z1.T1, STRINGS.CREATURES.SPECIES.T007GG2Z1.T2);//添加种子
                StringUtils.AddPlantStrings("T007GG2Z2", STRINGS.CREATURES.SPECIES.T007GG2Z1.T3, STRINGS.CREATURES.SPECIES.T007GG2Z1.T4, STRINGS.CREATURES.SPECIES.T007GG2Z1.T5);//添加植物
                
                // 玫瑰
                StringUtils.AddPlantSeedStrings("T007GG3Z1", STRINGS.CREATURES.SPECIES.T007GG3Z1.T1, STRINGS.CREATURES.SPECIES.T007GG3Z1.T2);//添加种子
                StringUtils.AddPlantStrings("T007GG3Z2", STRINGS.CREATURES.SPECIES.T007GG3Z1.T3, STRINGS.CREATURES.SPECIES.T007GG3Z1.T4, STRINGS.CREATURES.SPECIES.T007GG3Z1.T5);//添加植物

                // 仙人掌
                StringUtils.AddPlantSeedStrings("T007GG4Z1", STRINGS.CREATURES.SPECIES.T007GG4Z1.T1, STRINGS.CREATURES.SPECIES.T007GG4Z1.T2);//添加种子
                StringUtils.AddPlantStrings("T007GG4Z2", STRINGS.CREATURES.SPECIES.T007GG4Z1.T3, STRINGS.CREATURES.SPECIES.T007GG4Z1.T4, STRINGS.CREATURES.SPECIES.T007GG4Z1.T5);//添加植物

                // 水仙
                StringUtils.AddPlantSeedStrings("T007GG5Z1", STRINGS.CREATURES.SPECIES.T007GG5Z1.T1, STRINGS.CREATURES.SPECIES.T007GG5Z1.T2);//添加种子
                StringUtils.AddPlantStrings("T007GG5Z2", STRINGS.CREATURES.SPECIES.T007GG5Z1.T3, STRINGS.CREATURES.SPECIES.T007GG5Z1.T4, STRINGS.CREATURES.SPECIES.T007GG5Z1.T5);//添加植物

                // 波斯菊
                StringUtils.AddPlantSeedStrings("T007GG6Z1", STRINGS.CREATURES.SPECIES.T007GG6Z1.T1, STRINGS.CREATURES.SPECIES.T007GG6Z1.T2);//添加种子
                StringUtils.AddPlantStrings("T007GG6Z2", STRINGS.CREATURES.SPECIES.T007GG6Z1.T3, STRINGS.CREATURES.SPECIES.T007GG6Z1.T4, STRINGS.CREATURES.SPECIES.T007GG6Z1.T5);//添加植物

                // 三色堇
                StringUtils.AddPlantSeedStrings("T007GG7Z1", STRINGS.CREATURES.SPECIES.T007GG7Z1.T1, STRINGS.CREATURES.SPECIES.T007GG7Z1.T2);//添加种子
                StringUtils.AddPlantStrings("T007GG7Z2", STRINGS.CREATURES.SPECIES.T007GG7Z1.T3, STRINGS.CREATURES.SPECIES.T007GG7Z1.T4, STRINGS.CREATURES.SPECIES.T007GG7Z1.T5);//添加植物




                //------------------------------------------------------------新食物-----------------------------------------------------------
                // 冰淇淋
                StringUtils.AddFoodStrings("U001GG1", STRINGS.CREATURES.SPECIES.U001GG1.U1, STRINGS.CREATURES.SPECIES.U001GG1.U2); // 冰淇淋
                StringUtils.AddFoodStrings("U001GG2", STRINGS.CREATURES.SPECIES.U001GG2.U1, STRINGS.CREATURES.SPECIES.U001GG2.U2); // 西瓜冰淇淋
                // 月饼
                StringUtils.AddFoodStrings("U002GG1", STRINGS.CREATURES.SPECIES.U002GG1.U1, STRINGS.CREATURES.SPECIES.U002GG1.U2); // 冰皮月饼
                StringUtils.AddFoodStrings("U002GG2", STRINGS.CREATURES.SPECIES.U002GG2.U1, STRINGS.CREATURES.SPECIES.U002GG2.U2); // 鲜花月饼
                StringUtils.AddFoodStrings("U002GG3", STRINGS.CREATURES.SPECIES.U002GG3.U1, STRINGS.CREATURES.SPECIES.U002GG3.U2); // 鲜肉月饼
                StringUtils.AddFoodStrings("U002GG4", STRINGS.CREATURES.SPECIES.U002GG4.U1, STRINGS.CREATURES.SPECIES.U002GG4.U2); // 芝麻月饼
                // 饺子
                StringUtils.AddFoodStrings("U003GG1", STRINGS.CREATURES.SPECIES.U003GG1.U1, STRINGS.CREATURES.SPECIES.U003GG1.U2); // 菜饺子
                StringUtils.AddFoodStrings("U003GG2", STRINGS.CREATURES.SPECIES.U003GG2.U1, STRINGS.CREATURES.SPECIES.U003GG2.U2); // 肉饺子
                // 川菜
                StringUtils.AddFoodStrings("U004GG1", STRINGS.CREATURES.SPECIES.U004GG1.U1, STRINGS.CREATURES.SPECIES.U004GG1.U2); // 豆花饭
                StringUtils.AddFoodStrings("U004GG2", STRINGS.CREATURES.SPECIES.U004GG2.U1, STRINGS.CREATURES.SPECIES.U004GG2.U2); // 辣椒炒辣椒
                StringUtils.AddFoodStrings("U004GG3", STRINGS.CREATURES.SPECIES.U004GG3.U1, STRINGS.CREATURES.SPECIES.U004GG3.U2); // 辣椒炒肉
                StringUtils.AddFoodStrings("U004GG4", STRINGS.CREATURES.SPECIES.U004GG4.U1, STRINGS.CREATURES.SPECIES.U004GG4.U2); // 麻辣烫
                StringUtils.AddFoodStrings("U004GG5", STRINGS.CREATURES.SPECIES.U004GG5.U1, STRINGS.CREATURES.SPECIES.U004GG5.U2); // 水煮鱼
                // 奶油
                StringUtils.AddFoodStrings("U005GG1", STRINGS.CREATURES.SPECIES.U005GG1.U1, STRINGS.CREATURES.SPECIES.U005GG1.U2); // 鸡蛋奶油
                // 细粉
                StringUtils.AddFoodStrings("U006GG1", STRINGS.CREATURES.SPECIES.U006GG1.U1, STRINGS.CREATURES.SPECIES.U006GG1.U2); // 面粉
                StringUtils.AddFoodStrings("U006GG2", STRINGS.CREATURES.SPECIES.U006GG2.U1, STRINGS.CREATURES.SPECIES.U006GG2.U2); // 大米
                // 面食
                StringUtils.AddFoodStrings("U007GG1", STRINGS.CREATURES.SPECIES.U007GG1.U1, STRINGS.CREATURES.SPECIES.U007GG1.U2); // 油团
                // StringUtils.AddFoodStrings("U007GG2", STRINGS.CREATURES.SPECIES.U007GG2.U1, STRINGS.CREATURES.SPECIES.U007GG2.U2); // 油条
                StringUtils.AddFoodStrings("U007GG3", STRINGS.CREATURES.SPECIES.U007GG3.U1, STRINGS.CREATURES.SPECIES.U007GG3.U2); // 饼干
                StringUtils.AddFoodStrings("U007GG4", STRINGS.CREATURES.SPECIES.U007GG4.U1, STRINGS.CREATURES.SPECIES.U007GG4.U2); // 面包
                StringUtils.AddFoodStrings("U007GG5", STRINGS.CREATURES.SPECIES.U007GG5.U1, STRINGS.CREATURES.SPECIES.U007GG5.U2); // 葱油饼

                // 果汁
                StringUtils.AddFoodStrings("U008GG1", STRINGS.CREATURES.SPECIES.U008GG1.U1, STRINGS.CREATURES.SPECIES.U008GG1.U2); // 西瓜汁
                StringUtils.AddFoodStrings("U008GG2", STRINGS.CREATURES.SPECIES.U008GG2.U1, STRINGS.CREATURES.SPECIES.U008GG2.U2); // 西红柿汁              
                StringUtils.AddFoodStrings("U008GG3", STRINGS.CREATURES.SPECIES.U008GG3.U1, STRINGS.CREATURES.SPECIES.U008GG3.U2); // 羽叶果薯汁
                StringUtils.AddFoodStrings("U008GG4", STRINGS.CREATURES.SPECIES.U008GG4.U1, STRINGS.CREATURES.SPECIES.U008GG4.U2); // 雪莓汁
                StringUtils.AddFoodStrings("U008GG5", STRINGS.CREATURES.SPECIES.U008GG5.U1, STRINGS.CREATURES.SPECIES.U008GG5.U2); // 刺果汁


            }
        }
        public class CREATURES
        {
            public class SPECIES
            {
                /*
                 * 种子名称
                 * 种子描述
                 * 植物名称
                 * 植物描述
                 * 未知不填
                 * 果实名称
                 * 果实描述
                 * 种子配方描述
                 */

                // 辣椒
                public class T001GG1Z1
                {
                    public static LocString T1 = "辣椒籽";
                    public static LocString T2 = "播下一粒辣椒籽，长成一株辣椒树。";
                    public static LocString T3 = "辣椒树";
                    public static LocString T4 = "辣椒，是茄科辣椒属的一年生草本植物，其根系不发达，茎直立；单叶互生，卵圆形，叶面光滑；花单生或簇生，多为白色；果面平滑或皱褶，具光泽；果实呈扁圆、圆球、圆锥或线形，种子为淡黄色的扁肾形；花果期5-11月。";
                    public static LocString T5 = "5"; 
                    public static LocString T6 = "辣椒";
                    public static LocString T7 = "辣椒树的果实来辣椒，辣，添加到其它食物里面能够获得别一番的风味。注意，别多放，不然，你会怀疑人生。";
                    public static LocString T8 = "等交易获得辣椒籽";
                }

                // 花椒
                public class T002GG1Z1
                {
                    public static LocString T1 = "花椒仔";
                    public static LocString T2 = "播下一粒花椒籽，长成一株花椒树。";
                    public static LocString T3 = "花椒树";
                    public static LocString T4 = "花椒树，原名:花椒，别名:檓、大椒、秦椒、蜀椒，拉丁文名:Zanthoxylum bungeanum Maxim.为芸香科、花椒属落叶小乔木;茎干上的刺常早落，枝有短刺，小枝上的刺基部宽而扁且劲直的长三角形，当年生枝被短柔毛。产地北起东北南部，南至五岭北坡，东南至江苏、浙江沿海地带，西南至西藏东南部;台湾、海南及广东不产。见于平原至海拔较高的山地，在青海，见于海拔2500米的坡地，也有栽种。耐旱，喜阳光，各地多栽种。花椒用作中药，有温中行气、逐寒、止痛、杀虫等功效。治胃腹冷痛、呕吐、泄泻、血吸虫、蛔虫等症。";
                    public static LocString T5 = "5"; 
                    public static LocString T6 = "花椒";
                    public static LocString T7 = "花椒树的果实来花椒，麻，花椒的一大特点就是麻。";
                    public static LocString T8 = "等交易获得花椒籽";
                }

                // 香蕉
                public class T003GG1Z1
                {
                    public static LocString T1 = "蕉籽";
                    public static LocString T2 = "播下一粒香蕉籽，长成一株香蕉树。";
                    public static LocString T3 = "香蕉树";
                    public static LocString T4 = "香蕉是中国南方四大水果之一，为芭蕉科芭蕉属植物，因果实如弓，故又叫弓蕉。香蕉品种很多，主要分香蕉、芭蕉和粉蕉三类，其中以香蕉质量最好。香蕉体弯曲，果实丰满、肥壮，色泽新鲜、光亮，果面光滑，无病斑、无虫疤、无霉菌、无创伤，果实易剥离，果肉稍硬，甜如蜜，气味清香芬芳，味甘爽口，肉软滑腻，而滋味常在牙齿之间，所以又叫香牙蕉、甘蕉。";
                    public static LocString T5 = "5"; 
                    public static LocString T6 = "香蕉";
                    public static LocString T7 = "黄灿灿的一串挂在高高的枝头，望蕉解渴。";
                    public static LocString T8 = "等交易获得香蕉籽";
                }

                // 西红柿
                public class T004GG1Z1
                {
                    public static LocString T1 = "西红柿籽";
                    public static LocString T2 = "播下一粒西红柿籽，长成一株西红柿树。";
                    public static LocString T3 = "西红柿树";
                    public static LocString T4 = "西红柿最早生长在南美洲，因为色彩娇艳，人们对它十分警惕，视为“狐狸的果实”，又称狼桃，只供观赏，不敢品尝，后来一个画家，在画西红柿的时候，饥渴难耐，实在忍不住才吃了一个，从此以后西红柿才进入到餐桌之上，西方人叫做番茄，传入中国之后，因为跟我国的柿子外形相似，所以我们称之为“西红柿“，而今它却是人们日常生活中不可缺少的美味佳品。";
                    public static LocString T5 = "5"; 
                    public static LocString T6 = "西红柿";
                    public static LocString T7 = "你以为是西红柿，错，其实它是番茄。";
                    public static LocString T8 = "等交易获得西红柿籽";
                }
                // 白菜
                public class T005GG1Z1
                {
                    public static LocString T1 = "小白菜籽";
                    public static LocString T2 = "播下一粒小白菜籽，长成一株小白菜树。";
                    public static LocString T3 = "小白菜树";
                    public static LocString T4 = "小白菜古代称为“黄芽菜”，其栽培历史晚于芜菁，《诗经》中记载的“葑”是指与白菜近亲的蔬菜芜菁，直到唐代《新修本草》中提到的“牛肚菘”，才是不结球的散叶小白菜首次亮相。";
                    public static LocString T5 = "5"; 
                    public static LocString T6 = "小白菜";
                    public static LocString T7 = "你以为是小白菜，对，它就是小小白菜。";
                    public static LocString T8 = "等交易获得白菜籽";
                }
                // 西瓜
                public class T006GG1Z1
                {
                    public static LocString T1 = "西瓜籽";
                    public static LocString T2 = "播下一粒西瓜籽，长成一株西瓜藤。";
                    public static LocString T3 = "西瓜藤";
                    public static LocString T4 = "《日用本草》记载西瓜富含多种维生素，具有平衡血压、调节心脏功能的作用。";
                    public static LocString T5 = "5"; 
                    public static LocString T6 = "西瓜";
                    public static LocString T7 = "你以为是西瓜，对，它就是西瓜。";
                    public static LocString T8 = "等交易获得西瓜籽。";
                }
                // 玫瑰
                public class T007GG1Z1
                {
                    public static LocString T1 = "玫瑰籽";
                    public static LocString T2 = "播下一粒玫瑰籽，长成一株玫瑰花。";
                    public static LocString T3 = "玫瑰花";
                    public static LocString T4 = "玫瑰花是“爱情之花”。特别是2月14日，西方情人节，在爱情之河畅游的年轻人，都用此花献给自己的心上人来表达自己的感情。";
                    public static LocString T5 = "5";
                    public static LocString T6 = "玫瑰";
                    public static LocString T7 = "你以为是玫瑰，对，它就是玫瑰。";
                    public static LocString T8 = "等交易获得玫瑰籽。";
                }
                // 百合
                public class T007GG2Z1
                {
                    public static LocString T1 = "百合籽";
                    public static LocString T2 = "播下一粒百合籽，长成一株百合花。";
                    public static LocString T3 = "百合花";
                    public static LocString T4 = "白色的百合花是我们最经常见到的，它代表着纯洁、庄严和百年好合。";
                    public static LocString T5 = "5";
                    public static LocString T6 = "百合";
                    public static LocString T7 = "你以为是百合，对，它就是百合。";
                    public static LocString T8 = "等交易获得百合籽。";
                }
                // 牡丹
                public class T007GG3Z1
                {
                    public static LocString T1 = "牡丹籽";
                    public static LocString T2 = "播下一粒牡丹籽，长成一株牡丹花。";
                    public static LocString T3 = "牡丹花";
                    public static LocString T4 = "牡丹的花语：圆满、浓情、富贵、吉祥、幸福、雍容华贵、国色天香。";
                    public static LocString T5 = "5";
                    public static LocString T6 = "牡丹";
                    public static LocString T7 = "你以为是牡丹，对，它就是牡丹。";
                    public static LocString T8 = "等交易获得牡丹籽。";
                }
                // 仙人掌
                public class T007GG4Z1
                {
                    public static LocString T1 = "仙人掌籽";
                    public static LocString T2 = "播下一粒仙人掌籽，长成一株仙人掌。";
                    public static LocString T3 = "仙人掌";
                    public static LocString T4 = "仙人掌的花语：坚强、温暖、刚毅的爱情、外表坚硬而内心柔软。";
                    public static LocString T5 = "5";
                    public static LocString T6 = "仙人掌";
                    public static LocString T7 = "你以为是仙人掌，对，它就是仙人掌。";
                    public static LocString T8 = "等交易获得仙人掌籽。";
                }
                // 水仙
                public class T007GG5Z1
                {
                    public static LocString T1 = "水仙籽";
                    public static LocString T2 = "播下一粒水仙籽，长成一株水仙。";
                    public static LocString T3 = "水仙花";
                    public static LocString T4 = "白色水仙花的花语：纯洁和吉祥，代表着坚贞的爱情。";
                    public static LocString T5 = "5";
                    public static LocString T6 = "水仙";
                    public static LocString T7 = "你以为是水仙，对，它就是水仙。";
                    public static LocString T8 = "等交易获得水仙籽。";
                }
                // 波斯菊
                public class T007GG6Z1
                {
                    public static LocString T1 = "波斯菊籽";
                    public static LocString T2 = "播下一粒波斯菊籽，长成一株波斯菊。";
                    public static LocString T3 = "波斯菊";
                    public static LocString T4 = "波斯菊的花语是纯洁、多情、自由、爽朗和永远快乐。";
                    public static LocString T5 = "5";
                    public static LocString T6 = "波斯菊";
                    public static LocString T7 = "你以为是波斯菊，对，它就是波斯菊。";
                    public static LocString T8 = "等交易获得波斯菊籽。";
                }
                // 三色堇
                public class T007GG7Z1
                {
                    public static LocString T1 = "三色堇籽";
                    public static LocString T2 = "播下一粒三色堇籽，长成一株三色堇。";
                    public static LocString T3 = "三色堇";
                    public static LocString T4 = "三色堇的花语代表着深思、快乐和思念你。";
                    public static LocString T5 = "5";
                    public static LocString T6 = "三色堇";
                    public static LocString T7 = "你以为是三色堇，对，它就是三色堇。";
                    public static LocString T8 = "等交易获得三色堇籽。";
                }

                // 冰淇淋
                public class U001GG1
                {
                    public static LocString U1 = UI.FormatAsLink("小爱", "U001GG1");
                    public static LocString U2 = "由冰加鸡蛋奶油制作而成，保留了奶油的软糯，继承了冰的嫩白。香软可口，让异国他乡的小人们，也能吃上一口熟悉的冰淇淋！";
                    public static LocString U3 = "好吃吗，冰冰的。";
                }
                public class U001GG2
                {
                    public static LocString U1 = "西瓜冰淇淋";
                    public static LocString U2 = "冰+奶油+西瓜汁+西瓜，在冰冻后，别有一番风味。";
                    public static LocString U3 = "西瓜口味的冰淇淋，不止只有冰淇淋，还有一只小西瓜。";
                }


                // 月饼
                public class U002GG1
                {
                    public static LocString U1 = "冰皮月饼";
                    public static LocString U2 = "冰皮月饼不用烘烤，用糯米粉和冰糖制成皮，馅料有各种水果、奶油、冰淇淋等，口感清爽甜美，适合夏秋之交食用。";
                    public static LocString U3 = "中秋节快乐！";
                }
                public class U002GG2
                {
                    public static LocString U1 = "鲜花月饼";
                    public static LocString U2 = "鲜花月饼特点是馅料主要是果蔬，配料是鲜花，馅心滑软，风味各异，馅料有菊花、玫瑰花、荔枝、草莓、白合、芋头、乌梅、橙等，又配以果汁或果浆，因此更具清新爽甜的风味。";
                    public static LocString U3 = "中秋节快乐！";
                }
                public class U002GG3
                {
                    public static LocString U1 = "鲜肉月饼";
                    public static LocString U2 = "鲜肉月饼是江浙一带的特色，用面粉和猪肉馅制成，外皮金黄酥脆，内馅肉汁丰富，咸香可口，是一种咸味月饼。";
                    public static LocString U3 = "中秋节快乐！";
                }

                public class U002GG4
                {
                    public static LocString U1 = "芝麻月饼";
                    public static LocString U2 = "芝麻月饼是北方地区的传统食品，用面粉和芝麻馅制成，外皮白色或黑色，内馅香甜软糯，富含维生素E和钙质。";
                    public static LocString U3 = "中秋节快乐！";
                }

                // 饺子
                public class U003GG1
                {
                    public static LocString U1 = "菜饺子";
                    public static LocString U2 = "高明的厨师，化平凡为传奇。任谁能想到，将菜包裹在面皮里，可以蒸煎炒炸煮，万般手法，万般滋味。";
                    public static LocString U3 = "菜馅的饺子";
                }

                public class U003GG2
                {
                    public static LocString U1 = "肉饺子";
                    public static LocString U2 = "高明的厨师，化平凡为传奇。任谁能想到，将肉包裹在面皮里，可以蒸煎炒炸煮，万般手法，万般滋味。";
                    public static LocString U3 = "肉馅的饺子。";
                }


                //川菜
                public class U004GG1
                {
                    public static LocString U1 = "豆花饭";
                    public static LocString U2 = "简简单单的一碗豆花饭。";
                    public static LocString U3 = "辣.豆花饭";
                }

                public class U004GG2
                {
                    public static LocString U1 = "辣椒炒辣椒";
                    public static LocString U2 = "辣椒炒辣椒也是一道一场美味的食物，但请注意，对于大多数而言，这并不是一道“美味”的食物。";
                    public static LocString U3 = "食材只有辣椒";
                }

                public class U004GG3
                {
                    public static LocString U1 = "辣椒炒肉";
                    public static LocString U2 = "辣椒炒肉的第一个秘诀，辣！辣椒炒肉的第二个秘诀，辣，辣！辣椒炒肉的第三个秘诀，辣，辣，辣！";
                    public static LocString U3 = "辣.辣椒炒肉";
                }

                public class U004GG4
                {
                    public static LocString U1 = "麻辣烫";
                    public static LocString U2 = "麻辣烫主要是将各种食材放入沸腾的麻辣汤中煮熟，然后捞出沾上调味料食用，具有麻、辣、香、鲜的特点！";
                    public static LocString U3 = "辣.麻辣烫";
                }

                public class U004GG5
                {
                    public static LocString U1 = "水煮鱼";
                    public static LocString U2 = "水煮鱼的奥秘是什么？一把辣椒！什么，做出来的水煮鱼依然不好吃？那就再来一把辣椒！什么，还是不好吃？把鱼肉挑出来，把辣椒倒进去！！！";
                    public static LocString U3 = "辣.水煮鱼";
                }

                // 鸡蛋奶油
                public class U005GG1
                {
                    public static LocString U1 = "鸡蛋奶油";
                    public static LocString U2 = "从未想过普普通通的鸡蛋也能做成此等美食，软糯、细腻、白嫩，带着淡淡的说不出的香味，好想舔一口。";
                    public static LocString U3 = "鸡蛋+水，获得鸡蛋奶油。";
                }

                // 面粉
                public class U006GG1
                {
                    public static LocString U1 = "面粉";
                    public static LocString U2 = "将粗糙的难以下咽的冰霜麦粒去皮，大力碾压，小火烘焙，制得细腻如玉，白如清雪的面粉。作为初级食材，你可以直接食用，但如果经过简单的烹饪，味道将更加美好。";
                    public static LocString U3 = "磨制冰霜麦粒得到面粉。";
                }
                // 大米
                public class U006GG2
                {
                    public static LocString U1 = "大米";
                    public static LocString U2 = "将粗糙的难以下咽的米虱去皮，调节磨面机的间隙及功率，在保证去皮的基础上，并不会将米虱给完全磨碎，最后得到一粒粒饱满青春的米粒。作为初级食材，你可以直接食用，但如果经过简单的烹饪，味道将更加美好。";
                    public static LocString U3 = "磨制米虱得到大米。";
                }

                // 油团
                public class U007GG1
                {
                    public static LocString U1 = "油团";
                    public static LocString U2 = "小小的一团面团，在大铁锅里慢慢油炸，体积能膨胀几十倍，圆圆的，好大。";
                    public static LocString U3 = "面粉+水，油炸，油团。";
                }
                /*
                // 油条
                public class U007GG2
                {
                    public static LocString U1 = "油条";
                    public static LocString U2 = "做为一种即食油炸食品，极其适合战斗时的早餐使用。";
                    public static LocString U3 = "面粉+水，油炸，油条。";
                }
                */
                // 饼干
                public class U007GG3
                {
                    public static LocString U1 = "饼干";
                    public static LocString U2 = "没有小熊饼干，洞洞饼干也不错，香脆可口。";
                    public static LocString U3 = "面粉+水，烤制，饼干。";
                }
                // 面包
                public class U007GG4
                {
                    public static LocString U1 = "面包";
                    public static LocString U2 = "疏松多孔的烤面包，入口即化。";
                    public static LocString U3 = "面粉+水，烤制，面包。";
                }
                // 葱油饼
                public class U007GG5
                {
                    public static LocString U1 = "葱油饼";
                    public static LocString U2 = "简单的烹饪手法，真香。";
                    public static LocString U3 = "面粉+水，油炸，葱油饼。";
                }
                // 西瓜汁
                public class U008GG1
                {
                    public static LocString U1 = "西瓜汁";
                    public static LocString U2 = "皇上，你还记得大明湖畔的西瓜汁吗。";
                    public static LocString U3 = "加入一个大西瓜，得到西瓜汁。";
                }

                // 西红柿汁
                public class U008GG2
                {
                    public static LocString U1 = "西红柿汁";
                    public static LocString U2 = "红红的，酸酸的，真好喝。";
                    public static LocString U3 = "加入一个大西红柿，得到西红柿汁。";
                }
                // 羽叶果薯汁
                public class U008GG3
                {
                    public static LocString U1 = "羽叶果薯汁";
                    public static LocString U2 = "带有淡淡的泥土和优雅的清香，红里透白，真好喝。";
                    public static LocString U3 = "加入一个大羽叶果薯，得到羽叶果薯汁。";
                }
                // 雪莓汁
                public class U008GG4
                {
                    public static LocString U1 = "雪莓汁";
                    public static LocString U2 = "和别的果汁不一样，它特别酸，却有说不出的甜味，流连忘返，真好喝。";
                    public static LocString U3 = "加入一个大雪莓，得到雪莓汁。";
                }
                // 刺果汁
                public class U008GG5
                {
                    public static LocString U1 = "刺果汁";
                    public static LocString U2 = "不用担心，里面没有刺。不去考虑口味，补充能量是极好的，真好喝。";
                    public static LocString U3 = "加入一个大刺果，得到刺果汁。";
                }
            }
        }
        public class BUILDINGS
        {
            public class PREFABS
            {
                public class TA001GG1 // 种子研究站
                {
                    public static LocString NAME = "种子研究站";
                    public static LocString EFFECT = "等价交易，在这里，你能获得一些想不到的种子。";
                    public static LocString DESC = "有钱，你就拥有了一切。";
                }
                public class UA001GG1 // 冰淇淋机
                {
                    public static LocString NAME = "冰淇淋机";
                    public static LocString EFFECT = "高端科技，即便是平平无奇咸乳，也能化腐朽为神奇。一点点冰，一点点咸乳，一点点爱，冰淇淋，闪亮登场。";
                    public static LocString DESC = "轻一点，别把小章鱼吓跑了。";
                }
                public class UA002GG1 // 磨面机
                {
                    public static LocString NAME = "磨面机";
                    public static LocString EFFECT = "将各种食材磨成精细的粉末，然后将其用于制作其它更加精美的食物。";
                    public static LocString DESC = "这是小人的一小步，却是世界的一大步。";
                }
                public class UA003GG1 // 榨汁机
                {
                    public static LocString NAME = "榨汁机";
                    public static LocString EFFECT = "将新鲜的水果榨成可口的水果汁，小人们爱极了。";
                    public static LocString DESC = "小心，水有剧毒。";
                }
                
                public class T_UI
                {
                    // 分类名称
                    public static LocString UA000GG0_UI = "食物获取";
                    public static LocString U000GG0_UI = "食物";                   
                    // 食物获取
                    public static LocString UA001GG1_UI = "启用冰淇淋机";
                    public static LocString UA002GG1_UI = "启用磨面机";
                    public static LocString UA003GG1_UI = "启用榨汁机";
                    // 食物
                    // 冰淇淋
                    public static LocString U001GG1X1_UI = "启用冰淇淋";
                    // 月饼
                    public static LocString U002GG1X1_UI = "启用月饼";
                    // 饺子
                    public static LocString U003GG1X1_UI = "启用饺子";
                    // 川菜
                    public static LocString U004GG1X1_UI = "启用川菜";
                    // 奶油
                    public static LocString U005GG1X1_UI = "启用奶油";
                    // 启用细粉
                    public static LocString U006GG1X1_UI = "启用细粉";
                    // 启用油团
                    public static LocString U007GG1X1_UI = "启用面食";
                    //启用果汁
                    public static LocString U008GG1X1_UI = "启用果汁";
                }
                
            }
        }
    }
}
