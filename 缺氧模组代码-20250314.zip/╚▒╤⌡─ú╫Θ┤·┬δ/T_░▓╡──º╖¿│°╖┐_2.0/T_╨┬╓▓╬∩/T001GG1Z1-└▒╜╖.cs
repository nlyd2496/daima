﻿using System.Collections.Generic;
using STRINGS;
using TUNING;
using UnityEngine;


namespace T_安的魔法厨房_2._0
{
    public class T001GG1Z1 : IEntityConfig
    {
        // 种子_ID_名称_描述_动画
        public const string SeedId = "T001GG1Z1";
        public static string SeedName = STRINGS.CREATURES.SPECIES.T001GG1Z1.T1;
        public static string SeedDescription = STRINGS.CREATURES.SPECIES.T001GG1Z1.T2;
        private const string AnimNameSeed = "T001GG1Z1_kanim";
        // 植物_ID_预览ID_名称_描述1_描述2_动画
        public const string Id = "T001GG1Z2";
        public const string Preview = "T001GG1Z2_preview";
        public static string Name = STRINGS.CREATURES.SPECIES.T001GG1Z1.T3;
        public static string Description = STRINGS.CREATURES.SPECIES.T001GG1Z1.T4;
        public static string DomesticatedDescription = STRINGS.CREATURES.SPECIES.T001GG1Z1.T5;
        private const string AnimName = "T001GG1Z2_kanim";

        // 果实_ID
        private const string CropID = "T001GG1Z3";
        // 创建植物
        public GameObject CreatePrefab()
        {

            var placedEntity = EntityTemplates.CreatePlacedEntity(
                id: Id,
                name: Name,
                desc: Description,
                mass: 1f,
                anim: Assets.GetAnim(AnimName),
                initialAnim: "idle_loop",
                sceneLayer: Grid.SceneLayer.BuildingFront,
                width: 1, // 宽
                height: 2, // 高
                decor: DECOR.BONUS.TIER1, // 装饰度
                defaultTemperature: 298.15f); // 默认温度
            EntityTemplates.ExtendEntityToBasicPlant
                (
                template: placedEntity,
                temperature_lethal_low: 263.15f, // 致死低温  ---   -10°
                temperature_warning_low: 283.15f, // 生长低温 ---   10°
                temperature_warning_high: 348.15f, // 生长高温---   75°
                temperature_lethal_high: 373.15f, // 致死高温 ---   100°
                safe_elements: new[]
                {
                    SimHashes.Oxygen, // 氧气
                    SimHashes.ContaminatedOxygen, // 污染氧
                    SimHashes.CarbonDioxide // 二氧化碳
                },
                pressure_sensitive: true, // 是否压力敏感
                pressure_lethal_low: 0f, //致命低压（kg）
                pressure_warning_low: 0.001f, // 低压警告（kg）
                should_grow_old: false,// 是否会变老
                max_age: 2400f,// 最大寿命（秒）
                min_radiation: 0f, //最低辐射
                max_radiation: 10000f, //最大辐射
                crop_id: CropID,
                baseTraitId: $"{Id}Original",
                baseTraitName: Name
                );

            // 添加到标准作物
            placedEntity.AddOrGet<StandardCropPlant>();

            // 消耗元素
            var consumer = placedEntity.AddOrGet<ElementConsumer>();
            consumer.elementToConsume = SimHashes.Oxygen; // 元素
            consumer.consumptionRate = 0.001f; // 速率
            // 释放元素
            var emitter = placedEntity.AddOrGet<ElementEmitter>();
            emitter.outputElement = new ElementConverter.OutputElement(0.001f, SimHashes.CarbonDioxide, 0f, true, false, 0f, 2f);
            emitter.maxPressure = 10f; // 最大压力

            // 植物消耗实体元素
            EntityTemplates.ExtendPlantToFertilizable(placedEntity, new PlantElementAbsorber.ConsumeInfo[]
            {
                new PlantElementAbsorber.ConsumeInfo
                {
                    tag = GameTags.Dirt,
                    massConsumptionRate = 0.001f
                }
            });

            // 添加植物种子
            var seed = EntityTemplates.CreateAndRegisterSeedForPlant(
                plant: placedEntity,
                id: SeedId,
                name: SeedName,
                desc: SeedDescription,
                productionType: SeedProducer.ProductionType.Sterile,
                anim: Assets.GetAnim(AnimNameSeed),
                numberOfSeeds: 0, // 种子数量
                additionalTags: new List<Tag> { GameTags.CropSeed }, // 种子额外标签
                sortOrder: 7,
                domesticatedDescription: DomesticatedDescription,
                width: 0.5f,
                height: 0.5f);
            // 植物预览
            EntityTemplates.CreateAndRegisterPreviewForPlant
                (
                seed: seed,
                id: Preview,
                anim: Assets.GetAnim(AnimName),
                initialAnim: "place",
                width: 1, // 预览植物宽
                height: 2 // 预览植物高
                ); 

            SoundEventVolumeCache.instance.AddVolume("bristleblossom_kanim", "PrickleFlower_harvest", NOISE_POLLUTION.CREATURES.TIER1);

            return placedEntity;
        }
        public string[] GetDlcIds()
        {
            return DlcManager.AVAILABLE_ALL_VERSIONS;
            // AVAILABLE_ALL_VERSIONS-------------------------------本体+DLC可用
            //AVAILABLE_VANILLA_ONLY--------------------------------仅本体可用
            //AVAILABLE_EXPANSION1_ONLY-----------------------------仅DLC可用
        }
        public void OnPrefabInit(GameObject inst)
        {
        }
        public void OnSpawn(GameObject inst)
        {
        }
    }
    /*
    grow = "grow"，表示植物正在生长的状态
    grow_pst = "grow_pst"，表示植物生长完成的状态
    idle_full = "idle_full"，表示植物处于满产的状态
    wilt_base = "wilt"，表示植物开始枯萎的状态
    harvest = "harvest"，表示植物被收获的状态
    waning = "waning"，表示植物逐渐消失的状态
    */
}
