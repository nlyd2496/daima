﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace T_安的魔法厨房_2._0
{
    public class T002GG1Z3 : IEntityConfig
    {
        //--------------------------
        public static string Id = "T002GG1Z3";// 果实ID
        public static string Name = STRINGS.CREATURES.SPECIES.T002GG1Z1.T6;// 果实名称
        public static string Description = STRINGS.CREATURES.SPECIES.T002GG1Z1.T7;// 果实名称
        private const string AnimName = "T002GG1Z3_kanim";// 果实动画
        //--------------------------
        // 创建果实
        public GameObject CreatePrefab()
        {
            var entity = EntityTemplates.CreateLooseEntity(
                id: Id, // 果实ID
                name: Name, // 果实名称
                desc: Description, // 果实STRINGS.BUILDINGS.PREFABS
                mass: 1f, // 果实质量
                unitMass: false, // 果实单位质量
                anim: Assets.GetAnim(AnimName), // 果实动画
                initialAnim: "object", // 果实初始动画
                sceneLayer: Grid.SceneLayer.Front, // 果实场景层
                collisionShape: EntityTemplates.CollisionShape.RECTANGLE, // 果实碰撞形状
                width: 1f, // 果实宽度
                height: 1f, // 果实高度
                isPickupable: true); // 果实是否可拾取

            // 创建食物信息
            var foodInfo = new EdiblesManager.FoodInfo(
                id: Id, // 果实ID
                dlcId: DlcManager.VANILLA_ID, // 果实DLC ID
                caloriesPerUnit: 100000f, // 果实每单位卡路里   ---   100 000
                quality: 1, // 果实质量
                preserveTemperatue: 263.15f, // 果实保存温度  ---   -10°
                rotTemperature: 303.15f, // 果实腐烂温度  ---   30°
                spoilTime: TUNING.FOOD.SPOIL_TIME.SLOW, // 果实腐烂时间
                can_rot: true); // 果实是否可腐烂
            var foodEntity = EntityTemplates.ExtendEntityToFood(entity, foodInfo);

            /*
            // 给食物添加Sublimates组件，使其能够升华为气体
            var sublimates = foodEntity.AddOrGet<Sublimates>();
            sublimates.spawnFXHash = SpawnFXHashes.OxygenEmissionBubbles; // 升华的特效
            sublimates.info = new Sublimates.Info(
                rate: 0.001f, // 升华的速率
                min_amount: 0f, // 升华的最小量
                max_destination_mass: 1.8f, // 升华的最大目标质量
                mass_power: 0.0f, // 升华的质量指数
                element: SimHashes.Oxygen); // 升华的元素
            */


            // 返回食物的预制体
            return foodEntity;
        }
        public string[] GetDlcIds()
        {
            return DlcManager.AVAILABLE_ALL_VERSIONS;
            // AVAILABLE_ALL_VERSIONS-------------------------------本体+DLC可用
            //AVAILABLE_VANILLA_ONLY--------------------------------仅本体可用
            //AVAILABLE_EXPANSION1_ONLY-----------------------------仅DLC可用
        }
        public void OnPrefabInit(GameObject inst)
        {
        }
        public void OnSpawn(GameObject inst)
        {
        }
    }
}
