﻿using System;
using System.Collections.Generic;
using STRINGS;
using TUNING;
using UnityEngine;

namespace T_安的魔法厨房_2._0
{
    public class T007GG5Z1 : IEntityConfig
    {
        //--------------------------
        public const string SeedId = "T007GG5Z1"; // 种子ID
        public static string SeedName = STRINGS.CREATURES.SPECIES.T007GG5Z1.T1; // 种子名称
        public static string SeedDescription = STRINGS.CREATURES.SPECIES.T007GG5Z1.T2; // 种子描述
        private const string AnimNameSeed = "T007GG5Z1_kanim"; // 种子动画
        //--------------------------
        public const string Id = "T007GG5Z2"; // 植物ID
        public static string Name = STRINGS.CREATURES.SPECIES.T007GG5Z1.T3; // 植物名字
        public static string Description = STRINGS.CREATURES.SPECIES.T007GG5Z1.T4; // 植物描述1
        public static string DomesticatedDescription = STRINGS.CREATURES.SPECIES.T007GG5Z1.T5; // 植物描述2
        private const string AnimName = "T007GG5Z2_kanim"; // 植物动画
        public string[] GetDlcIds()
        {
            return DlcManager.AVAILABLE_ALL_VERSIONS;
        }
        public GameObject CreatePrefab()
        {
            string id = Id;
            string name = Name;
            string desc = Description;
            float mass = 1f;
            EffectorValues positive_DECOR_EFFECT = this.POSITIVE_DECOR_EFFECT;
            GameObject gameObject = EntityTemplates.CreatePlacedEntity(id, name, desc, mass, 
                Assets.GetAnim(AnimName), "grow_seed", Grid.SceneLayer.BuildingFront, 1, 2,  // 宽，高
                positive_DECOR_EFFECT, default(EffectorValues), SimHashes.Creature, null, 283.15f); // 适宜温度12℃
            EntityTemplates.ExtendEntityToBasicPlant(gameObject, 273.15f, 283.15f, 303.15f, 323.15f, new SimHashes[]
            {
            SimHashes.Oxygen,
            SimHashes.ContaminatedOxygen,
            SimHashes.CarbonDioxide,
            SimHashes.ChlorineGas,
            SimHashes.Hydrogen
            }, true, 0f, 0.15f, null, true, false, true, true, 2400f, 0f, 2200f, $"{Id}Original",
            Name);
            PrickleGrass prickleGrass = gameObject.AddOrGet<PrickleGrass>();
            prickleGrass.positive_decor_effect = this.POSITIVE_DECOR_EFFECT;
            prickleGrass.negative_decor_effect = this.NEGATIVE_DECOR_EFFECT;
            EntityTemplates.CreateAndRegisterPreviewForPlant(EntityTemplates.CreateAndRegisterSeedForPlant
                (gameObject, SeedProducer.ProductionType.Hidden, SeedId,
                SeedName,
                SeedDescription, 
                Assets.GetAnim(AnimNameSeed), "object", 1, new List<Tag>
                {
            GameTags.DecorSeed
        }, SingleEntityReceptacle.ReceptacleDirection.Top, default(Tag), 12,
                DomesticatedDescription, 
                EntityTemplates.CollisionShape.RECTANGLE, 0.5f, 0.5f, null, "", false, null),
                $"{Id}_preview", Assets.GetAnim(AnimName), "place", 1, 2);
            return gameObject;
        }
        public void OnPrefabInit(GameObject inst)
        {
        }
        public void OnSpawn(GameObject inst)
        {
        }
        public readonly EffectorValues POSITIVE_DECOR_EFFECT = DECOR.BONUS.TIER3;
        public readonly EffectorValues NEGATIVE_DECOR_EFFECT = DECOR.PENALTY.TIER3;
    }

}
