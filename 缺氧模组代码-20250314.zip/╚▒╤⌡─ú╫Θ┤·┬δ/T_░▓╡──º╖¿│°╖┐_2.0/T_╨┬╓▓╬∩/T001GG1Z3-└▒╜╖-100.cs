﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace T_安的魔法厨房_2._0
{
    public class T001GG1Z3 : IEntityConfig
    {
        // 果实_ID_名称_描述_动画
        public static string Id = "T001GG1Z3";
        public static string Name = STRINGS.CREATURES.SPECIES.T001GG1Z1.T6;
        public static string Description = STRINGS.CREATURES.SPECIES.T001GG1Z1.T7;
        private const string AnimName = "T001GG1Z3_kanim";
        // 创建果实
        public GameObject CreatePrefab()
        {
            var entity = EntityTemplates.CreateLooseEntity(
                id: Id,
                name: Name,
                desc: Description,
                mass: 1f, 
                unitMass: false, 
                anim: Assets.GetAnim(AnimName), 
                initialAnim: "object",
                sceneLayer: Grid.SceneLayer.Front,
                collisionShape: EntityTemplates.CollisionShape.RECTANGLE, // 碰撞形状
                width: 1f, // 宽
                height: 1f, // 高
                isPickupable: true); // 果实是否可拾取

            // 创建食物
            var foodInfo = new EdiblesManager.FoodInfo(
                id: Id,
                dlcId: DlcManager.VANILLA_ID,
                caloriesPerUnit: 100000f, // 卡路里
                quality: 1,
                preserveTemperatue: 263.15f, // 果实保存温度  ---   -10°
                rotTemperature: 303.15f, // 果实腐烂温度  ---   30°
                spoilTime: TUNING.FOOD.SPOIL_TIME.SLOW, // 果实腐烂时间
                can_rot: true); // 果实是否可腐烂
            var foodEntity = EntityTemplates.ExtendEntityToFood(entity, foodInfo);

            /*
            // 给食物添加Sublimates组件，使其能够升华为气体
            var sublimates = foodEntity.AddOrGet<Sublimates>();
            sublimates.spawnFXHash = SpawnFXHashes.OxygenEmissionBubbles; // 升华的特效
            sublimates.info = new Sublimates.Info(
                rate: 0.001f, // 升华的速率
                min_amount: 0f, // 升华的最小量
                max_destination_mass: 1.8f, // 升华的最大目标质量
                mass_power: 0.0f, // 升华的质量指数
                element: SimHashes.Oxygen); // 升华的元素
            */
            return foodEntity;
        }
        public string[] GetDlcIds()
        {
            return DlcManager.AVAILABLE_ALL_VERSIONS;
            // AVAILABLE_ALL_VERSIONS-------------------------------本体+DLC可用
            //AVAILABLE_VANILLA_ONLY--------------------------------仅本体可用
            //AVAILABLE_EXPANSION1_ONLY-----------------------------仅DLC可用
        }
        public void OnPrefabInit(GameObject inst)
        {
        }
        public void OnSpawn(GameObject inst)
        {
        }
    }
}
