﻿using STRINGS;
using System.Collections.Generic;
using UnityEngine;
using static CaiLib.Utils.RecipeUtils;
using CaiLib.Utils;
using PeterHan.PLib.Options;

namespace T_安的魔法厨房_2._0
{
    public class U002GG2 : IEntityConfig
    {
        //--------------------------
        public const string Id = "U002GG2";// 食物ID
        public static string Name = STRINGS.CREATURES.SPECIES.U002GG2.U1;// 食物名称
        public static string EFFECT = STRINGS.CREATURES.SPECIES.U002GG2.U2;// 食物描述
        private const string AnimName = "U002GG2_kanim";// 食物动画
        //--------------------------
        public ComplexRecipe Recipe;
        public GameObject CreatePrefab()
        {
            var entity = EntityTemplates.CreateLooseEntity(
                id: Id,
                name: Name,
                desc: EFFECT,
                mass: 1f,
                unitMass: false,
                anim: Assets.GetAnim(AnimName),
                initialAnim: "object",
                sceneLayer: Grid.SceneLayer.Front,
                collisionShape: EntityTemplates.CollisionShape.RECTANGLE,
                width: 0.8f,
                height: 0.7f,
                isPickupable: true);
            var foodInfo = new EdiblesManager.FoodInfo(
                    id: Id,
                    dlcId: DlcManager.VANILLA_ID,
                    caloriesPerUnit: 4400000f, // 卡路里
                    quality: 4, // 食物质量
                    preserveTemperatue: 23.15f, // 保存温度 -10
                    rotTemperature: 293.15f, // 腐烂温度 20
                    spoilTime: 1800f, // 腐烂时间
                    can_rot: true
                    );
            var food = EntityTemplates.ExtendEntityToFood(entity, foodInfo);
            return food;
        }
        public string[] GetDlcIds()
        {
            return DlcManager.EXPANSION1;
        }
        public void OnPrefabInit(GameObject inst) { }
        public void OnSpawn(GameObject inst) { }
        public static ComplexRecipe recipe;
    }
}
