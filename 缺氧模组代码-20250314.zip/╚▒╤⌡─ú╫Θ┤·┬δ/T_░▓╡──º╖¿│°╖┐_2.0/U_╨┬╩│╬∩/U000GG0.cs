﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T_安的魔法厨房_2._0
{
    public class FOOD
    {
        public class FOOD_TYPES
        {
            public static readonly EdiblesManager.FoodInfo U001GG11 = new EdiblesManager.FoodInfo(
                "U001GG1", 800000f, -1, 255.15f, 277.15f, 19200f, false, null, null);
        }
    }
}