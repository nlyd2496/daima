﻿using System;
using System.Collections.Generic;
using STRINGS;
using TUNING;
using UnityEngine;

namespace T_安的魔法厨房_2._0
{
    public class U001GG1 : IEntityConfig
    {
        //--------------------------
        public const string Id = "U001GG1";// ID
        public static string Name = STRINGS.CREATURES.SPECIES.U001GG1.U1;// 名称
        public static string EFFECT = STRINGS.CREATURES.SPECIES.U001GG1.U2;// 食物描述
        private const string AnimName = "U001GG1_kanim";// 动画
        //--------------------------
        public ComplexRecipe Recipe;
        public GameObject CreatePrefab()
        {
            var entity = EntityTemplates.CreateLooseEntity(
                id: Id,
                name: Name,
                desc: EFFECT,
                mass: 1f,
                unitMass: false,
                anim: Assets.GetAnim(AnimName),
                initialAnim: "object",
                sceneLayer: Grid.SceneLayer.Front,
                collisionShape: EntityTemplates.CollisionShape.RECTANGLE,
                width: 0.8f,
                height: 0.7f,
                isPickupable: true);
            // 创建食物信息
            var foodInfo = new EdiblesManager.FoodInfo(
                    id: Id, // 食物ID
                    caloriesPerUnit: 18000000f, // 食物每单位卡路里   ---   300 000
                    quality: 4, // 食物质量
                    preserveTemperatue: 263.15f, // 食物保存温度 -10
                    rotTemperature: 283.15f, // 食物腐烂温度 10
                    spoilTime: 1200f, // 食物腐烂时间
                    can_rot: true
                    ) ;
            var food = EntityTemplates.ExtendEntityToFood(entity, foodInfo);
            return food;

        }
        public string[] GetDlcIds()
        {
            return new string[2] { "", "EXPANSION1_ID" };
        }
        public void OnPrefabInit(GameObject inst) { }
        public void OnSpawn(GameObject inst) { }
        public static ComplexRecipe recipe;
    }
}
