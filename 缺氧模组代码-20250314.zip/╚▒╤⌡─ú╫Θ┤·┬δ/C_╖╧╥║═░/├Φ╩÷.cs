﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HarmonyLib;
using STRINGS;
using PeterHan.PLib.Core;
using PeterHan.PLib.Database;
using Klei.AI;
using PeterHan.PLib.Options;

namespace C_废液桶
{
    public class STRINGS
    {
        public static void DoReplacement()
        {
            LocString.CreateLocStringKeys(typeof(STRINGS), "");
        }
        [HarmonyPatch(typeof(EntityConfigManager))]
        [HarmonyPatch("LoadGeneratedEntities")]        
        public class BUILDINGS
        {
            public class PREFABS
            {                
                public class C026GG1 // 废液桶
                {
                    public static LocString NAME = "Waste liquid tank"; // 废液桶
                    public static LocString EFFECT = "Automatically clear the liquid stored in it, be careful not to pour any strange liquid into it."; // 自动清除存入其中的液体，小心，不要往里面倒一些奇奇怪怪的液体。
                    public static LocString DESC = "Customized solid wood for luxurious enjoyment."; // 实木定制，奢华享受。
                }
                public class C026GG1L2 // 废液桶
                {
                    public static LocString NAME = "Waste liquid tank"; // 废液桶
                    public static LocString DESC = "Customized virtual wood for luxurious enjoyment."; // 虚木定制，奢华享受。
                }
            }
        }      
    }
}
