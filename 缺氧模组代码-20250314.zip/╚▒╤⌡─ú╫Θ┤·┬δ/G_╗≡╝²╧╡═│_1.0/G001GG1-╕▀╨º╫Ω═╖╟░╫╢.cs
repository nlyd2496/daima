﻿using HarmonyLib;
using PeterHan.PLib.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace G_火箭系统_1._0
{
    [HarmonyPatch(typeof(NoseconeHarvestConfig))]
    [HarmonyPatch("ConfigureBuildingTemplate")]
    public class 高效钻头前锥
    {
        public static void Postfix(GameObject go, Tag prefab_tag)
        {
            bool G001GG1 = SingletonOptions<控制台>.Instance.G001GG1; //控制功能启停
            if (G001GG1)
            {
                ManualDeliveryKG manualDeliveryKG = go.AddOrGet<ManualDeliveryKG>();
                manualDeliveryKG.MinimumMass = 10f;
                manualDeliveryKG.capacity = SingletonOptions<控制台>.Instance.G001GG1X1; // 钻头前锥的容量
                manualDeliveryKG.refillMass = 10f;
                go.AddOrGetDef<ResourceHarvestModule.Def>().harvestSpeed = SingletonOptions<控制台>.Instance.G001GG1X2; // 挖掘速度
                Storage storage = go.AddOrGet<Storage>();
                storage.capacityKg = 1000000f;
            }
        }
    }
    /*
    [HarmonyPatch(typeof(ResourceHarvestModule.StatesInstance))]
    [HarmonyPatch("HarvestFromPOI")]
    public class 钻石消耗速度
    {
        [HarmonyTranspiler]
        public static IEnumerable<CodeInstruction> Transpiler(IEnumerable<CodeInstruction> instructions)
        {
            foreach (var instruction in instructions)
            {
                if (instruction.opcode == OpCodes.Call && ((MethodInfo)instruction.operand).Name == "ConsumeDiamond")
                {
                    // 判断G001GG1的值，如果为false，就跳过替换
                    yield return new CodeInstruction(OpCodes.Ldsfld, typeof(控制台).GetField("G001GG1"));
                    Label label = new Label();
                    yield return new CodeInstruction(OpCodes.Brfalse, label);
                    // 如果为true，就替换ConsumeDiamond方法
                    yield return new CodeInstruction(OpCodes.Pop);
                    yield return new CodeInstruction(OpCodes.Ldc_R4, 1f);
                    yield return new CodeInstruction(OpCodes.Nop).WithLabels(label);
                }
                yield return instruction;
            }
        }
    }
    */
}
