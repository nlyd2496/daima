﻿using HarmonyLib;
using PeterHan.PLib.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace G_火箭系统_1._0
{
    [HarmonyPatch(typeof(LiquidFuelTankClusterConfig), "CreateBuildingDef")]
    public class 火箭燃料仓输入更改_谨以此纪念我第一个模组
    {
        public static void Postfix(ref BuildingDef __result)
        {
            bool G002GG1 = SingletonOptions<控制台>.Instance.G002GG1;
            if (G002GG1)
            {
                __result.UtilityInputOffset = new CellOffset(0, 2);
            }
        }
    }
}
