﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HarmonyLib;
using STRINGS;
using KMod;
// using PeterHan.PLib.Core;
// using PeterHan.PLib.Database;
using Klei.AI;
// using PeterHan.PLib.Options;

namespace G_火箭系统_1._0
{
    public class STRINGS
    {
        public class BUILDINGS
        {
            public class PREFABS
            {
                public class G_UI
                {
                    public static LocString G001GG0_UI = "火箭";
                    public static LocString G002GG0_UI = "侦察者";
                    public static LocString G003GG0_UI = "液氢引擎";
                    public static LocString G004GG0_UI = "石油引擎";
                    public static LocString G005GG0_UI = "小型石油引擎";
                    public static LocString G006GG0_UI = "蒸汽引擎";
                    public static LocString G007GG0_UI = "糖素引擎";
                    public static LocString G008GG0_UI = "二氧化碳引擎";
                    public static LocString G009GG0_UI = "辐射引擎";
                    public static LocString G0010GG0_UI = "星球";
                    public static LocString G0011GG0_UI = "望远镜";



                    public static LocString G001GG1_UI = "启用高效钻头前锥";
                    public static LocString G001GG1X1_UI = "启用钻头前锥容量";
                    public static LocString G001GG1X2_UI = "启用钻头前锥挖掘速度";
                    public static LocString G002GG1_UI = "启用火箭燃料仓输入更改";
                    public static LocString G003GG1_UI = "启用侦察者电量增加";
                    public static LocString G003GG1X1_UI = "启用侦查者电量修改";
                    public static LocString G004GG1_UI = "启用火箭货仓容量增加";
                    public static LocString G004GG1X1_UI = "启用火箭货仓容量修改";
                    public static LocString G005GG1_UI = "启用超级液氢引擎";
                    public static LocString G005GG1X1_UI = "启用液氢引擎火箭高度";
                    public static LocString G005GG1X2_UI = "启用液氢引擎负担";
                    public static LocString G005GG1X3_UI = "启用液氢引擎功率";
                    public static LocString G005GG1X4_UI = "启用液氢火箭每格燃料消耗";
                    public static LocString G005GG2_UI = "启用超级石油引擎";
                    public static LocString G005GG2X1_UI = "启用石油引擎火箭高度";
                    public static LocString G005GG2X2_UI = "启用石油引擎负担";
                    public static LocString G005GG2X3_UI = "启用石油引擎功率";
                    public static LocString G005GG2X4_UI = "启用石油火箭每格燃料消耗";
                    public static LocString G005GG3_UI = "启用超级小型石油引擎";
                    public static LocString G005GG3X1_UI = "启用小型石油引擎火箭高度";
                    public static LocString G005GG3X2_UI = "启用小型石油引擎负担";
                    public static LocString G005GG3X3_UI = "启用小型石油引擎功率";
                    public static LocString G005GG3X4_UI = "启用小型石油火箭每格燃料消耗";
                    public static LocString G005GG4_UI = "启用超级蒸汽引擎";
                    public static LocString G005GG4X1_UI = "启用蒸汽引擎火箭高度";
                    public static LocString G005GG4X2_UI = "启用蒸汽引擎负担";
                    public static LocString G005GG4X3_UI = "启用蒸汽引擎功率";
                    public static LocString G005GG4X4_UI = "启用蒸汽火箭每格燃料消耗";
                    public static LocString G005GG5_UI = "启用超级糖素引擎";
                    public static LocString G005GG5X1_UI = "启用糖素引擎火箭高度";
                    public static LocString G005GG5X2_UI = "启用糖素引擎负担";
                    public static LocString G005GG5X3_UI = "启用糖素引擎功率";
                    public static LocString G005GG5X4_UI = "启用糖素火箭每格燃料消耗";
                    public static LocString G005GG6_UI = "启用超级二氧化碳引擎";
                    public static LocString G005GG6X1_UI = "启用二氧化碳引擎火箭高度";
                    public static LocString G005GG6X2_UI = "启用二氧化碳引擎负担";
                    public static LocString G005GG6X3_UI = "启用二氧化碳引擎功率";
                    public static LocString G005GG6X4_UI = "启用二氧化碳火箭每格燃料消耗";
                    public static LocString G005GG7_UI = "启用超级辐射粒子引擎";
                    public static LocString G005GG7X1_UI = "启用辐射粒子引擎火箭高度";
                    public static LocString G005GG7X2_UI = "启用辐射粒子引擎负担";
                    public static LocString G005GG7X3_UI = "启用辐射粒子引擎功率";
                    public static LocString G005GG7X4_UI = "启用辐射粒子火箭每格燃料消耗";
                    public static LocString G006GG1_UI = "启用星际资源恢复";
                    public static LocString G007GG1X1_UI = "启用强化望远镜";
                    public static LocString G007GG1X2_UI = "启用强化隔绝式望远镜";
                    public static LocString G007GG1X3_UI = "启用隔绝式望远镜不耗电";




                }
            }
        }
    }
}