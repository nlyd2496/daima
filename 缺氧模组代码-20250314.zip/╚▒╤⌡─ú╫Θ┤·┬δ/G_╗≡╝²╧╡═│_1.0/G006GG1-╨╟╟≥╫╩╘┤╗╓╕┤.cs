﻿using Database;
using HarmonyLib;
using PeterHan.PLib;
using PeterHan.PLib.Core;
using PeterHan.PLib.Options;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace G_火箭系统_1._0
{

    [HarmonyPatch(typeof(HarvestablePOIStates.Instance))]
    [HarmonyPatch("RechargePOI")]
    public class 星球资源恢复速度增加
    {
        public static void Postfix(HarvestablePOIStates.Instance __instance, float dt)
        {
            bool G006GG1 = SingletonOptions<控制台>.Instance.G006GG1;
            if (G006GG1)
            {
                float num = __instance.configuration.GetMaxCapacity() * (dt / __instance.configuration.GetRechargeTime()) * 1000f;
                __instance.DeltaPOICapacity(num);
            }
        }
    }
    
}