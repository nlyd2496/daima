﻿using HarmonyLib;
using PeterHan.PLib.Detours;
using PeterHan.PLib.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace G_火箭系统_1._0
{
    [HarmonyPatch(typeof(ClusterTelescopeConfig))]
    [HarmonyPatch("ConfigureBuildingTemplate")]
    public class 望远镜监测范围增加
    {
        private static void Postfix(GameObject go)
        {
            
            bool G007GG1X1 = SingletonOptions<控制台>.Instance.G007GG1X1;
            if (G007GG1X1)
            {
                ClusterTelescope.Def def = go.AddOrGetDef<ClusterTelescope.Def>();
                def.clearScanCellRadius = 60;
                def.analyzeClusterRadius = 60;
            }
        }
    }
    [HarmonyPatch(typeof(ClusterTelescopeEnclosedConfig))]
    [HarmonyPatch("ConfigureBuildingTemplate")]
    public class 隔绝式望远镜监测范围增加
    {
        private static void Postfix(GameObject go)
        {
            bool G007GG1X2 = SingletonOptions<控制台>.Instance.G007GG1X2;
            if (G007GG1X2)
            {
                ClusterTelescope.Def def = go.AddOrGetDef<ClusterTelescope.Def>();
                def.clearScanCellRadius = 60;
                def.analyzeClusterRadius = 60;
            }
        }
    }
    [HarmonyPatch(typeof(ClusterTelescopeEnclosedConfig))]
    [HarmonyPatch("CreateBuildingDef")]
    public class 隔绝式望远镜不耗电
    {
        public static void Postfix(ref BuildingDef __result)
        {
            bool G007GG1X3 = SingletonOptions<控制台>.Instance.G007GG1X3;
            if (G007GG1X3)
            {
                __result.RequiresPowerInput = false;
            }
        }
    }
    
    
}
