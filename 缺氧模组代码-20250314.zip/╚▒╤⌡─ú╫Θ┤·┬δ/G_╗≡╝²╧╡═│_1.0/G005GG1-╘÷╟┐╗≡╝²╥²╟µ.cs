﻿using HarmonyLib;
using PeterHan.PLib.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using TUNING;

namespace G_火箭系统_1._0
{
    [HarmonyPatch(typeof(HEPEngineConfig))]
    [HarmonyPatch("DoPostConfigureComplete")]
    public class 辐射粒子引擎
    {
        public static void Postfix(GameObject go)
        {
            bool G005GG7 = SingletonOptions<控制台>.Instance.G005GG7;
            if (G005GG7)
            {
                go.AddOrGet<RocketEngineCluster>().maxHeight = (int)SingletonOptions<控制台>.Instance.G005GG7X1;
                go.AddOrGet<RocketEngineCluster>().efficiency = 100;
                BuildingTemplates.ExtendBuildingToRocketModuleCluster(go, null, (int)SingletonOptions<控制台>.Instance.G005GG7X2, SingletonOptions<控制台>.Instance.G005GG7X3, SingletonOptions<控制台>.Instance.G005GG7X4 / 600f);
            }
        }
    }
    [HarmonyPatch(typeof(CO2EngineConfig))]
    [HarmonyPatch("DoPostConfigureComplete")]
    public class 二氧化碳引擎
    {
        public static void Postfix(GameObject go)
        {
            bool G005GG6 = SingletonOptions<控制台>.Instance.G005GG6;
            if (G005GG6)
            {
                go.AddOrGet<RocketEngineCluster>().maxHeight = (int)SingletonOptions<控制台>.Instance.G005GG6X1;
                go.AddOrGet<RocketEngineCluster>().efficiency = 100;
                BuildingTemplates.ExtendBuildingToRocketModuleCluster(go, null, (int)SingletonOptions<控制台>.Instance.G005GG6X2, SingletonOptions<控制台>.Instance.G005GG6X3, SingletonOptions<控制台>.Instance.G005GG6X4 / 600f);
            }
        }
    }
    [HarmonyPatch(typeof(SugarEngineConfig))]
    [HarmonyPatch("DoPostConfigureComplete")]
    public class 糖素引擎
    {
        public static void Postfix(GameObject go)
        {
            bool G005GG5 = SingletonOptions<控制台>.Instance.G005GG5;
            if (G005GG5)
            {
                go.AddOrGet<RocketEngineCluster>().maxHeight = (int)SingletonOptions<控制台>.Instance.G005GG5X1;
                go.AddOrGet<RocketEngineCluster>().efficiency = 100;
                BuildingTemplates.ExtendBuildingToRocketModuleCluster(go, null, (int)SingletonOptions<控制台>.Instance.G005GG5X2, SingletonOptions<控制台>.Instance.G005GG5X3, SingletonOptions<控制台>.Instance.G005GG5X4 / 600f);
            }
        }
    }
    [HarmonyPatch(typeof(SteamEngineClusterConfig))]
    [HarmonyPatch("DoPostConfigureComplete")]
    public class 蒸汽引擎
    {
        public static void Postfix(GameObject go)
        {
            bool G005GG4 = SingletonOptions<控制台>.Instance.G005GG4;
            if (G005GG4)
            {
                go.AddOrGet<RocketEngineCluster>().maxHeight = (int)SingletonOptions<控制台>.Instance.G005GG4X1;
                go.AddOrGet<RocketEngineCluster>().efficiency = 100;
                BuildingTemplates.ExtendBuildingToRocketModuleCluster(go, null, (int)SingletonOptions<控制台>.Instance.G005GG4X2, SingletonOptions<控制台>.Instance.G005GG4X3, SingletonOptions<控制台>.Instance.G005GG4X4 / 600f);
            }
        }
    }
    [HarmonyPatch(typeof(KeroseneEngineClusterSmallConfig))]
    [HarmonyPatch("DoPostConfigureComplete")]
    public class 小型石油引擎
    {
        public static void Postfix(GameObject go)
        {
            bool G005GG3 = SingletonOptions<控制台>.Instance.G005GG3;
            if (G005GG3)
            {
                go.AddOrGet<RocketEngineCluster>().maxHeight = (int)SingletonOptions<控制台>.Instance.G005GG3X1;
                go.AddOrGet<RocketEngineCluster>().efficiency = 100;
                BuildingTemplates.ExtendBuildingToRocketModuleCluster(go, null, (int)SingletonOptions<控制台>.Instance.G005GG3X2, SingletonOptions<控制台>.Instance.G005GG3X3, SingletonOptions<控制台>.Instance.G005GG3X4 / 600f);
            }
        }
    }
    [HarmonyPatch(typeof(KeroseneEngineClusterConfig))]
    [HarmonyPatch("DoPostConfigureComplete")]
    public class 石油引擎
    {
        public static void Postfix(GameObject go)
        {
            bool G005GG2 = SingletonOptions<控制台>.Instance.G005GG2;
            if (G005GG2)
            {
                go.AddOrGet<RocketEngineCluster>().maxHeight = (int)SingletonOptions<控制台>.Instance.G005GG2X1;
                go.AddOrGet<RocketEngineCluster>().efficiency = 100;
                BuildingTemplates.ExtendBuildingToRocketModuleCluster(go, null, (int)SingletonOptions<控制台>.Instance.G005GG2X2, SingletonOptions<控制台>.Instance.G005GG2X3, SingletonOptions<控制台>.Instance.G005GG2X4 / 600f);
            }
        }
    }
    [HarmonyPatch(typeof(HydrogenEngineClusterConfig))]
    [HarmonyPatch("DoPostConfigureComplete")]
    public class 液氢引擎
    {
        public static void Postfix(GameObject go)
        {
            bool G005GG1 = SingletonOptions<控制台>.Instance.G005GG1;
            if (G005GG1)
            {
                go.AddOrGet<RocketEngineCluster>().maxHeight = (int)SingletonOptions<控制台>.Instance.G005GG1X1;
                go.AddOrGet<RocketEngineCluster>().efficiency = 100;
                BuildingTemplates.ExtendBuildingToRocketModuleCluster(go, null, (int)SingletonOptions<控制台>.Instance.G005GG1X2, SingletonOptions<控制台>.Instance.G005GG1X3, SingletonOptions<控制台>.Instance.G005GG1X4 / 600f);
            }
        }
    }
}
//go.AddOrGet<RocketEngineCluster>().maxHeight = 50; 支持火箭高度
//go.AddOrGet<RocketEngineCluster>().efficiency = 100; 发动机效率
//BuildingTemplates.ExtendBuildingToRocketModuleCluster(go, null, ROCKETRY.BURDEN.INSIGNIFICANT, (float)ROCKETRY.ENGINE_POWER.LATE_VERY_STRONG, ROCKETRY.FUEL_COST_PER_DISTANCE.GAS_VERY_LOW);
//负担、引擎功率、每单位燃料（一格=600单位）
//火箭速度=引擎功率/负担