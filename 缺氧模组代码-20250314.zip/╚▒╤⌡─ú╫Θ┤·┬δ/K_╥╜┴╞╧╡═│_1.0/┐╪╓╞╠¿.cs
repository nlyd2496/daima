﻿using Newtonsoft.Json;
using PeterHan.PLib.Options;


namespace K_医疗系统_1._0
{
    [RestartRequired]
    [JsonObject(MemberSerialization.OptIn)]
    [ConfigFile("K000GG0.json", true, false)]
    // [ModInfo("https://space.bilibili.com/30725645", "mmm.png", true)]

    public class 控制台 : SingletonOptions<控制台>
    {
        // 启用辐射药丸使用阈值
        [Option("STRINGS.BUILDINGS.PREFABS.K_UI.K001GG1_UI", null, null)][JsonProperty] public bool K001GG1 { get; set; } = true;
        // 辐射药丸阈值
        [Option("STRINGS.BUILDINGS.PREFABS.K_UI.K001GG1X1_UI", null, null)][Limit(10, 1000)][JsonProperty] public float K001GG1X1 { get; set; } = 200f;
        // 启用高效按摩床
        [Option("STRINGS.BUILDINGS.PREFABS.K_UI.K002GG1_UI", null, null)][JsonProperty] public bool K002GG1 { get; set; } = true;
        // 按摩床压力消除率倍数
        [Option("STRINGS.BUILDINGS.PREFABS.K_UI.K002GG1X1_UI", null, null, Format = "F0")][Limit(1, 10)][JsonProperty] public float K002GG1X1 { get; set; } = 2f;
        // 启用开发者维生器
        [Option("STRINGS.BUILDINGS.PREFABS.K_UI.K003GG1_UI", null, null)][JsonProperty] public bool K003GG1 { get; set; } = true;
        // 启用饥荒入侵计划
        [Option("STRINGS.BUILDINGS.PREFABS.K_UI.K004GG1_UI", null, null)][JsonProperty] public bool K004GG1 { get; set; } = true;
        // 启用医废桶
        [Option("STRINGS.BUILDINGS.PREFABS.K_UI.K005GG1_UI", null, null)][JsonProperty] public bool K005GG1 { get; set; } = true;
        // 启用医废桶
        [Option("STRINGS.BUILDINGS.PREFABS.K_UI.K006GG1_UI", null, null)][JsonProperty] public bool K006GG1 { get; set; } = true;


    }
}
