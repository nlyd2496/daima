﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HarmonyLib;
using STRINGS;
using KMod;
using PeterHan.PLib.Core;
using PeterHan.PLib.Database;
using Klei.AI;
using PeterHan.PLib.Options;

namespace K_医疗系统_1._0
{
    public class STRINGS
    {
        public static void DoReplacement()
        {
            LocString.CreateLocStringKeys(typeof(STRINGS), "");
        }
        public class BUILDINGS
        {
            public class PREFABS
            {
                public class K004GG1//饥荒入侵计划
                {
                    public static LocString NAME = "跳舞牛";//建筑名
                    public static LocString EFFECT = "献上礼金，伟大的牛牛会为你施加一个祝福，前提是你得欣赏它的舞蹈。";//建筑效果
                    public static LocString DESC = "来呀，一起舞蹈。";
                }
                public class K004GG1L2//饥荒入侵计划
                {
                    public static LocString NAME = "拒绝牛";//建筑名
                    public static LocString EFFECT = "叔叔，不约。";//建筑效果
                }
                public class K004GG1L3//饥荒入侵计划
                {
                    public static LocString NAME = "哈气牛";//建筑名
                    public static LocString EFFECT = "呼呼呼，喘气。";//建筑效果
                }
                public class K004GG1L4//饥荒入侵计划
                {
                    public static LocString NAME = "摔倒牛";//建筑名
                    public static LocString EFFECT = "啊，牛牛我摔倒了。";//建筑效果
                }
                public class K004GG1L5//饥荒入侵计划
                {
                    public static LocString NAME = "暴力牛";//建筑名
                    public static LocString EFFECT = "不打你，我打底板。";//建筑效果
                }
                public class K004GG1L6//饥荒入侵计划
                {
                    public static LocString NAME = "疑问牛";//建筑名
                    public static LocString EFFECT = "马什么梅，马冬梅。";//建筑效果
                }
                public class K005GG1//医废桶
                {
                    public static LocString NAME = "医废桶";//建筑名
                    public static LocString EFFECT = "请将医疗废弃用品置于此箱中，它会自动将其送入虚空！";//建筑效果
                    public static LocString DESC = "生命与安全。";
                }
                public class K006GG1 // 医疗箱
                {
                    public static LocString NAME = "医疗箱";
                    public static LocString EFFECT = "医疗药物专用存储箱";
                    public static LocString DESC = "不要想着它能干嘛，它只是一个医疗箱，不能用来砸人";
                }
                public class K006GG1L2
                {
                    public static LocString NAME = "医疗箱";
                    public static LocString EFFECT = "如果你不用它来砸人，它或许可以用来装医疗用品，例如：十全大补丸";
                }
                public class K006GG1L3
                {
                    public static LocString NAME = "医疗箱";
                    public static LocString EFFECT = "作为可爱的女孩子，怎么可能用来装十全大补丸，雅诗兰黛沐浴露，应当是极好的";
                }
                public class K_UI
                {
                    public static LocString K001GG1_UI = "启用辐射药丸使用阈值";
                    public static LocString K001GG1X1_UI = "辐射药丸使用阈值";
                    public static LocString K002GG1_UI = "启用高效按摩床";
                    public static LocString K002GG1X1_UI = "按摩压力消除率倍数";
                    public static LocString K003GG1_UI = "启用开发者维生器";
                    public static LocString K004GG1_UI = "启用饥荒入侵计划";
                    public static LocString K005GG1_UI = "启用医废桶";
                    public static LocString K006GG1_UI = "启用医疗箱";
                }
            }

        }
    }
}
