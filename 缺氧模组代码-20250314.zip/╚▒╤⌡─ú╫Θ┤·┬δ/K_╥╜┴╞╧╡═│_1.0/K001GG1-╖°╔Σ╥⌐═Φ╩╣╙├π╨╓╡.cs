﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HarmonyLib;
using UnityEngine;
using Klei.AI;
using PeterHan.PLib.Core;
using PeterHan.PLib.Options;
using Newtonsoft.Json;

namespace K_医疗系统_1._0
{
    [HarmonyPatch(typeof(MedicinalPillWorkable), "CanBeTakenBy")]
    public static class 辐射药丸使用阈值
    {
        public static void Postfix(ref bool __result, ref MedicinalPill ___pill, GameObject consumer)
        {
            bool K001GG1 = SingletonOptions<控制台>.Instance.K001GG1;
            if (K001GG1)
            {
                if (___pill.info.id == "BasicRadPill")
                {
                    if (consumer.GetAmounts().Get(Db.Get().Amounts.RadiationBalance.Id).value < SingletonOptions<控制台>.Instance.K001GG1X1)
                    {
                        __result = false;
                    }
                }
            }
        }
    }
}
