﻿using Database;
using HarmonyLib;
using PeterHan.PLib.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TUNING;
using UnityEngine;

namespace K_医疗系统_1._0
{
    public class K004GG1 : IBuildingConfig
    {
        public override BuildingDef CreateBuildingDef()
        {
            string id = "K004GG1";
            int width = 2;
            int height = 2;
            string anim = "K004GG1L1_kanim";
            int hitpoints = 30;
            float construction_time = 30f;
            float[] tier = BUILDINGS.CONSTRUCTION_MASS_KG.TIER4;
            string[] any_BUILDABLE = MATERIALS.ANY_BUILDABLE;
            float melting_point = 1800f;
            BuildLocationRule build_location_rule = BuildLocationRule.OnFloor;
            EffectorValues none = NOISE_POLLUTION.NONE;
            BuildingDef buildingDef = BuildingTemplates.CreateBuildingDef(id, width, height, anim, hitpoints, construction_time, tier, any_BUILDABLE, melting_point, build_location_rule, BUILDINGS.DECOR.BONUS.TIER2, none, 0.2f);
            buildingDef.Overheatable = false;
            buildingDef.Floodable = false;
            SoundEventVolumeCache.instance.AddVolume("handsanitizer_kanim", "HandSanitizer_tongue_out", NOISE_POLLUTION.NOISY.TIER0);
            SoundEventVolumeCache.instance.AddVolume("handsanitizer_kanim", "HandSanitizer_tongue_in", NOISE_POLLUTION.NOISY.TIER0);
            SoundEventVolumeCache.instance.AddVolume("handsanitizer_kanim", "HandSanitizer_tongue_slurp", NOISE_POLLUTION.NOISY.TIER0);
            //--------------------------
            if (控制台.Instance.K004GG1) { buildingDef.Deprecated = false; } else { buildingDef.Deprecated = true; }
            //--------------------------
            return buildingDef;
        }
        public override void ConfigureBuildingTemplate(GameObject go, Tag prefab_tag)
        {
            HandSanitizer handSanitizer = go.AddOrGet<HandSanitizer>();
            handSanitizer.massConsumedPerUse = 0f;
            handSanitizer.consumedElement = SimHashes.Gold;
            handSanitizer.diseaseRemovalCount = 1000000;
            HandSanitizer.Work work = go.AddOrGet<HandSanitizer.Work>();
            work.workTime = 10f;
            work.trackUses = true;
            Storage storage = go.AddOrGet<Storage>();
            storage.SetDefaultStoredItemModifiers(Storage.StandardSealedStorage);
            go.AddOrGet<DirectionControl>();
            ManualDeliveryKG manualDeliveryKG = go.AddOrGet<ManualDeliveryKG>();
            manualDeliveryKG.SetStorage(storage);
            manualDeliveryKG.RequestedItemTag = GameTagExtensions.Create(SimHashes.Gold);
            manualDeliveryKG.capacity = 100f;
            manualDeliveryKG.refillMass = 3f;
            manualDeliveryKG.choreTypeIDHash = Db.Get().ChoreTypes.FetchCritical.IdHash;
            manualDeliveryKG.operationalRequirement = Operational.State.Functional;
            go.AddOrGetDef<RocketUsageRestriction.Def>();
        }
        public override void DoPostConfigureComplete(GameObject go)
        {
        }
        public const string ID = "K004GG1";
    }
    [HarmonyPatch(typeof(BuildingFacades), MethodType.Constructor, new Type[] { typeof(ResourceSet) })]
    public static class 蓝图系统K004GG1
    {
        public static void Postfix(BuildingFacades __instance)
        {
            __instance.Add("K004GG1L2", STRINGS.BUILDINGS.PREFABS.K004GG1L2.NAME, STRINGS.BUILDINGS.PREFABS.K004GG1L2.EFFECT, PermitRarity.Universal, "K004GG1", "K004GG1L2_kanim");
            __instance.Add("K004GG1L3", STRINGS.BUILDINGS.PREFABS.K004GG1L3.NAME, STRINGS.BUILDINGS.PREFABS.K004GG1L3.EFFECT, PermitRarity.Universal, "K004GG1", "K004GG1L3_kanim");
            __instance.Add("K004GG1L4", STRINGS.BUILDINGS.PREFABS.K004GG1L4.NAME, STRINGS.BUILDINGS.PREFABS.K004GG1L4.EFFECT, PermitRarity.Universal, "K004GG1", "K004GG1L4_kanim");
            __instance.Add("K004GG1L5", STRINGS.BUILDINGS.PREFABS.K004GG1L5.NAME, STRINGS.BUILDINGS.PREFABS.K004GG1L5.EFFECT, PermitRarity.Universal, "K004GG1", "K004GG1L5_kanim");
            __instance.Add("K004GG1L6", STRINGS.BUILDINGS.PREFABS.K004GG1L6.NAME, STRINGS.BUILDINGS.PREFABS.K004GG1L6.EFFECT, PermitRarity.Universal, "K004GG1", "K004GG1L6_kanim");
        }
    }
}
