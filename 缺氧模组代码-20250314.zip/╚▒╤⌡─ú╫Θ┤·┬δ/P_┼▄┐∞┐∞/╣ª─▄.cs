﻿using HarmonyLib;
using PeterHan.PLib.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TUNING;
using UnityEngine;

namespace P_跑快快
{
    [HarmonyPatch(typeof(TileConfig))]
    [HarmonyPatch("ConfigureBuildingTemplate")]
    public class 普通砖行进速度
    {
        private static void Prefix(GameObject go)
        {
            bool P014GGG1 = SingletonOptions<控制台>.Instance.P014GGG1;
            if (P014GGG1)
            {
                SimCellOccupier simCellOccupier = go.AddOrGet<SimCellOccupier>();
                simCellOccupier.strengthMultiplier = 1f;//强度系数
                simCellOccupier.movementSpeedMultiplier = SingletonOptions<控制台>.Instance.P014GGG1X1;
            }
        }
    }
    [HarmonyPatch(typeof(GasPermeableMembraneConfig))]
    [HarmonyPatch("ConfigureBuildingTemplate")]
    public class 透气砖行进速度
    {
        private static void Prefix(GameObject go)
        {
            bool P014GGG1 = SingletonOptions<控制台>.Instance.P014GGG1;
            if (P014GGG1)
            {
                SimCellOccupier simCellOccupier = go.AddOrGet<SimCellOccupier>();
                simCellOccupier.strengthMultiplier = 1f;//强度系数     
                simCellOccupier.movementSpeedMultiplier = SingletonOptions<控制台>.Instance.P014GGG1X1;
            }
        }
    }
    [HarmonyPatch(typeof(MeshTileConfig))]
    [HarmonyPatch("ConfigureBuildingTemplate")]
    public class 网格砖行进速度
    {
        private static void Prefix(GameObject go)
        {
            bool P014GGG1 = SingletonOptions<控制台>.Instance.P014GGG1;
            if (P014GGG1)
            {
                SimCellOccupier simCellOccupier = go.AddOrGet<SimCellOccupier>();
                simCellOccupier.strengthMultiplier = 1f;//强度系数
                simCellOccupier.movementSpeedMultiplier = SingletonOptions<控制台>.Instance.P014GGG1X1;
            }
        }
    }
    [HarmonyPatch(typeof(InsulationTileConfig))]
    [HarmonyPatch("ConfigureBuildingTemplate")]
    public class 隔热砖行进速度
    {
        private static void Prefix(GameObject go)
        {
            bool P014GGG1 = SingletonOptions<控制台>.Instance.P014GGG1;
            if (P014GGG1)
            {
                SimCellOccupier simCellOccupier = go.AddOrGet<SimCellOccupier>();
                simCellOccupier.strengthMultiplier = 1f;//强度系数
                simCellOccupier.movementSpeedMultiplier = SingletonOptions<控制台>.Instance.P014GGG1X1;
            }
        }
    }
    [HarmonyPatch(typeof(PlasticTileConfig))]
    [HarmonyPatch("ConfigureBuildingTemplate")]
    public class 塑料砖行进速度
    {
        private static void Prefix(GameObject go)
        {
            bool P014GGG1 = SingletonOptions<控制台>.Instance.P014GGG1;
            if (P014GGG1)
            {
                SimCellOccupier simCellOccupier = go.AddOrGet<SimCellOccupier>();
                simCellOccupier.strengthMultiplier = 1f;//强度系数
                simCellOccupier.movementSpeedMultiplier = SingletonOptions<控制台>.Instance.P014GGG1X1;
            }
        }
    }
    [HarmonyPatch(typeof(MetalTileConfig))]
    [HarmonyPatch("ConfigureBuildingTemplate")]
    public class 金属砖行进速度
    {
        private static void Prefix(GameObject go)
        {
            bool P014GGG1 = SingletonOptions<控制台>.Instance.P014GGG1;
            if (P014GGG1)
            {
                SimCellOccupier simCellOccupier = go.AddOrGet<SimCellOccupier>();
                simCellOccupier.strengthMultiplier = 1f;//强度系数
                simCellOccupier.movementSpeedMultiplier = SingletonOptions<控制台>.Instance.P014GGG1X1;
            }
        }
    }
    [HarmonyPatch(typeof(GlassTileConfig))]
    [HarmonyPatch("ConfigureBuildingTemplate")]
    public class 窗户砖行进速度
    {
        private static void Prefix(GameObject go)
        {
            bool P014GGG1 = SingletonOptions<控制台>.Instance.P014GGG1;
            if (P014GGG1)
            {
                SimCellOccupier simCellOccupier = go.AddOrGet<SimCellOccupier>();
                simCellOccupier.strengthMultiplier = 1f;//强度系数
                simCellOccupier.movementSpeedMultiplier = SingletonOptions<控制台>.Instance.P014GGG1X1;
            }
        }
    }
    [HarmonyPatch(typeof(BunkerTileConfig))]
    [HarmonyPatch("ConfigureBuildingTemplate")]
    public class 地堡砖行进速度
    {
        private static void Prefix(GameObject go)
        {
            bool P014GGG1 = SingletonOptions<控制台>.Instance.P014GGG1;
            if (P014GGG1)
            {
                SimCellOccupier simCellOccupier = go.AddOrGet<SimCellOccupier>();
                simCellOccupier.strengthMultiplier = 1f;//强度系数
                simCellOccupier.movementSpeedMultiplier = SingletonOptions<控制台>.Instance.P014GGG1X1;
            }
        }
    }
    [HarmonyPatch(typeof(CarpetTileConfig))]
    [HarmonyPatch("ConfigureBuildingTemplate")]
    public class 地毯砖行进速度
    {
        private static void Prefix(GameObject go)
        {
            bool P014GGG1 = SingletonOptions<控制台>.Instance.P014GGG1;
            if (P014GGG1)
            {
                SimCellOccupier simCellOccupier = go.AddOrGet<SimCellOccupier>();
                simCellOccupier.strengthMultiplier = 1f;//强度系数
                simCellOccupier.movementSpeedMultiplier = SingletonOptions<控制台>.Instance.P014GGG1X1;
            }
        }
    }
    [HarmonyPatch(typeof(StorageTileConfig))]
    [HarmonyPatch("DoPostConfigureComplete")]
    public class 储存砖行进速度
    {
        private static void Postfix(GameObject go)
        {
            bool P014GGG1 = SingletonOptions<控制台>.Instance.P014GGG1;
            if (P014GGG1)
            {
                SimCellOccupier simCellOccupier = go.AddOrGet<SimCellOccupier>();
                simCellOccupier.strengthMultiplier = 1f;//强度系数
                simCellOccupier.movementSpeedMultiplier = SingletonOptions<控制台>.Instance.P014GGG1X1;
            }
        }
    }
    [HarmonyPatch(typeof(FarmTileConfig))]
    [HarmonyPatch("DoPostConfigureComplete")]
    public class 土培砖行进速度
    {
        private static void Postfix(GameObject go)
        {
            bool P014GGG1 = SingletonOptions<控制台>.Instance.P014GGG1;
            if (P014GGG1)
            {
                SimCellOccupier simCellOccupier = go.AddOrGet<SimCellOccupier>();
                simCellOccupier.strengthMultiplier = 1f;//强度系数
                simCellOccupier.movementSpeedMultiplier = SingletonOptions<控制台>.Instance.P014GGG1X1;
            }
        }
    }
    [HarmonyPatch(typeof(HydroponicFarmConfig))]
    [HarmonyPatch("DoPostConfigureComplete")]
    public class 液培砖行进速度
    {
        private static void Postfix(GameObject go)
        {
            bool P014GGG1 = SingletonOptions<控制台>.Instance.P014GGG1;
            if (P014GGG1)
            {
                SimCellOccupier simCellOccupier = go.AddOrGet<SimCellOccupier>();
                simCellOccupier.strengthMultiplier = 1f;//强度系数
                simCellOccupier.movementSpeedMultiplier = SingletonOptions<控制台>.Instance.P014GGG1X1;
            }
        }
    }

    [HarmonyPatch(typeof(Db))]
    [HarmonyPatch("Initialize")]
    public class P014GGG1X1
    {
        private static void Prefix()
        {
                DUPLICANTSTATS.MOVEMENT_MODIFIERS.NEUTRAL = SingletonOptions<控制台>.Instance.P014GGG1X1;
                DUPLICANTSTATS.MOVEMENT_MODIFIERS.BONUS_1 = SingletonOptions<控制台>.Instance.P014GGG1X1;
                DUPLICANTSTATS.MOVEMENT_MODIFIERS.BONUS_2 = SingletonOptions<控制台>.Instance.P014GGG1X1;
                DUPLICANTSTATS.MOVEMENT_MODIFIERS.BONUS_3 = SingletonOptions<控制台>.Instance.P014GGG1X1;
                DUPLICANTSTATS.MOVEMENT_MODIFIERS.BONUS_4 = SingletonOptions<控制台>.Instance.P014GGG1X1;
                DUPLICANTSTATS.MOVEMENT_MODIFIERS.PENALTY_1 = SingletonOptions<控制台>.Instance.P014GGG1X1;
                DUPLICANTSTATS.MOVEMENT_MODIFIERS.PENALTY_2 = SingletonOptions<控制台>.Instance.P014GGG1X1;
                DUPLICANTSTATS.MOVEMENT_MODIFIERS.PENALTY_3 = SingletonOptions<控制台>.Instance.P014GGG1X1;
                DUPLICANTSTATS.MOVEMENT_MODIFIERS.PENALTY_4 = SingletonOptions<控制台>.Instance.P014GGG1X1;           
        }
    }
}
