﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HarmonyLib;
using STRINGS;
using KMod;
using PeterHan.PLib.Core;
using PeterHan.PLib.Database;
using Klei.AI;
using PeterHan.PLib.Options;

namespace P_跑快快
{
    public class STRINGS
    {
        public static void DoReplacement()
        {
            LocString.CreateLocStringKeys(typeof(STRINGS), "");
        }
        public class BUILDINGS
        {
            public class PREFABS
            {
                public class P_UI
                {
                    public static LocString P014GGG1 = "启用砖块移动速度增益";
                    public static LocString P014GGG1X1 = "砖上移动速度";

                }
            }
        }
    }
}
