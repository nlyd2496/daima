﻿using Newtonsoft.Json;
using PeterHan.PLib.Options;


namespace P_跑快快
{
    [RestartRequired]
    [JsonObject(MemberSerialization.OptIn)]
    [ConfigFile("P014GGG1.json", true, false)]
    // [ModInfo("https://space.bilibili.com/30725645", "mmm.png", true)]

    public class 控制台 : SingletonOptions<控制台>
    {
        [Option("STRINGS.BUILDINGS.PREFABS.P_UI.P014GGG1", null, "基础属性")][JsonProperty] public bool P014GGG1 { get; set; } = false;
        [Option("STRINGS.BUILDINGS.PREFABS.P_UI.P014GGG1X1", null, "基础属性", Format = "F0")][Limit(1.0, 10.0)][JsonProperty] public float P014GGG1X1 { get; set; } = 5f;

    }
}
