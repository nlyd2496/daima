﻿using HarmonyLib;
using KSerialization;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using static DetailsScreen;

namespace R_枪之突突突
{
    // 感谢AKI大佬的代码支持
    class SignSideScreen : SideScreenContent
    {

        // 修改这里
        // 修改这里
        // 修改这里

        public const string SCREEN_TITLE_KEY = "STRINGS.UI.UISIDESCREENS.SIGN_SIDE_SCREEN.R008GG1L2A1";

        // 修改这里
        // 修改这里
        // 修改这里

        [SerializeField]
        private RectTransform buttonContainer;

        private GameObject stateButtonPrefab;
        private GameObject debugVictoryButton;
        private GameObject flipButton;
        private readonly List<GameObject> buttons = new List<GameObject>();
        private SelectableSign target;



        public override bool IsValidForTarget(GameObject target)
        {
            return target.GetComponent<SelectableSign>() != null;
        }

        protected override void OnSpawn()
        {
            base.OnSpawn();

            // the monument screen used here has 2 extra buttons that are not needed, disabling them
            flipButton.SetActive(false);
            debugVictoryButton.SetActive(false);
        }

        protected override void OnPrefabInit()
        {
            base.OnPrefabInit();
            titleKey = SCREEN_TITLE_KEY;
            stateButtonPrefab = transform.Find("ButtonPrefab").gameObject;
            buttonContainer = transform.Find("Content/Scroll/Grid").GetComponent<RectTransform>();
            debugVictoryButton = transform.Find("Butttons/Button").gameObject;
            flipButton = transform.Find("Butttons/FlipButton").gameObject;
        }

        public override void SetTarget(GameObject target)
        {
            base.SetTarget(target);
            this.target = target.GetComponent<SelectableSign>();
            gameObject.SetActive(true);
            GenerateStateButtons();
        }

        private void GenerateStateButtons()
        {
            ClearButtons();
            var animFile = target.GetComponent<KBatchedAnimController>().AnimFiles[0];

            foreach (string anim in target.AnimationNames)
            {
                AddButton(animFile, anim, anim, () => target.SetVariant(anim));
            }
        }

        private void AddButton(KAnimFile animFile, string animName, LocString tooltip, System.Action onClick)
        {
            var gameObject = Util.KInstantiateUI(stateButtonPrefab, buttonContainer.gameObject, true);

            if (gameObject.TryGetComponent(out KButton button))
            {
                button.onClick += onClick;
                button.fgImage.sprite = Def.GetUISpriteFromMultiObjectAnim(animFile, animName);
            }

            //FUI_SideScreen.AddSimpleToolTip(gameObject, tooltip, true);
            buttons.Add(gameObject);
        }

        private void ClearButtons()
        {
            foreach (var button in buttons)
            {
                Util.KDestroyGameObject(button);
            }

            buttons.Clear();

            flipButton.SetActive(false);
            debugVictoryButton.SetActive(false);
        }
    }
    class FUI_SideScreen
    {
        public static void AddClonedSideScreen<T>(string name, string originalName, Type originalType)
        {
            bool elementsReady = GetElements(out List<SideScreenRef> screens, out GameObject contentBody);
            if (elementsReady)
            {
                var oldPrefab = FindOriginal(originalName, screens);
                var newPrefab = Copy<T>(oldPrefab, contentBody, name, originalType);

                screens.Add(NewSideScreen(name, newPrefab));
            }
        }

        private static bool GetElements(out List<SideScreenRef> screens, out GameObject contentBody)
        {
            var detailsScreen = Traverse.Create(DetailsScreen.Instance);
            screens = detailsScreen.Field("sideScreens").GetValue<List<DetailsScreen.SideScreenRef>>();
            contentBody = detailsScreen.Field("sideScreenConfigContentBody").GetValue<GameObject>();

            return screens != null && contentBody != null;
        }

        private static SideScreenContent Copy<T>(SideScreenContent original, GameObject contentBody, string name, Type originalType)
        {
            var screen = Util.KInstantiateUI<SideScreenContent>(original.gameObject, contentBody).gameObject;
            UnityEngine.Object.Destroy(screen.GetComponent(originalType));

            var prefab = screen.AddComponent(typeof(T)) as SideScreenContent;
            prefab.name = name.Trim();

            screen.SetActive(false);
            return prefab;
        }

        private static SideScreenContent FindOriginal(string name, List<SideScreenRef> screens)
        {
            //foreach (var screen in screens)
            //    Debug.Log(screen.name + screen.GetType());

            var result = screens.Find(s => s.name == name).screenPrefab;

            if (result == null)
                Debug.LogWarning("Could not find a sidescreen with the name " + name);

            return result;
        }

        private static DetailsScreen.SideScreenRef NewSideScreen(string name, SideScreenContent prefab)
        {
            return new DetailsScreen.SideScreenRef
            {
                name = name,
                offset = Vector2.zero,
                screenPrefab = prefab
            };
        }
        public static ToolTip AddSimpleToolTip(GameObject gameObject, string message, bool alignCenter = false, float wrapWidth = 0)
        {
            if (gameObject.GetComponent<ToolTip>() != null)
            {
                Debug.Log("GO already had a tooltip! skipping");
                return null;
            }

            ToolTip toolTip = gameObject.AddComponent<ToolTip>();
            toolTip.tooltipPivot = alignCenter ? new Vector2(0.5f, 0f) : new Vector2(1f, 0f);
            toolTip.tooltipPositionOffset = new Vector2(0f, 20f);
            toolTip.parentPositionAnchor = new Vector2(0.5f, 0.5f);

            if (wrapWidth > 0)
            {
                toolTip.WrapWidth = wrapWidth;
                toolTip.SizingSetting = ToolTip.ToolTipSizeSetting.MaxWidthWrapContent;
            }
            ToolTipScreen.Instance.SetToolTip(toolTip);
            toolTip.SetSimpleTooltip(message);
            return toolTip;
        }
    }
    [HarmonyPatch(typeof(DetailsScreen), "OnPrefabInit")]
    public static class 组件1
    {
        public static void Postfix()
        {
            // 在 DetailsScreen 的 OnPrefabInit 方法之后执行
            FUI_SideScreen.AddClonedSideScreen<SignSideScreen>(
            "Sign Side Screen", // 侧边屏幕的名称
            "MonumentSideScreen", // 基于的原始侧边屏幕的名称
            typeof(MonumentSideScreen)); // 原始侧边屏幕的类型
        }
    }
    class BasicModUtils
    {
        public static void MakeSideScreenStrings(string key, string name)
        {
            Strings.Add(key, name);
        }
    }
    [SerializationConfig(MemberSerialization.OptIn)]
    class SelectableSign : KMonoBehaviour
    {
        [MyCmpGet]
        KBatchedAnimController kbac;

        [Serialize]
        public List<string> AnimationNames = new List<string>();

        [Serialize]
        public int selectedIndex = 0;

        const string VARIANT_KEY = "Selected_Variant";


        protected override void OnSpawn()
        {
            if (AnimationNames == null || AnimationNames.Count == 0)
                return;

            if (selectedIndex >= AnimationNames.Count)
                selectedIndex = 0;

            kbac.Play(AnimationNames[selectedIndex]);
        }

        public void SetVariant(string variant)
        {
            if (!AnimationNames.Contains(variant))
                return;

            selectedIndex = AnimationNames.FindIndex(str => str == variant);
            kbac.Play(variant);
        }

        public string GetCurrentVariant()
        {
            if (AnimationNames == null || AnimationNames.Count <= selectedIndex)
                return string.Empty;
            return AnimationNames[selectedIndex];
        }

        public static void Blueprints_SetData(GameObject source, JObject data)
        {
            if (source.TryGetComponent<SelectableSign>(out var behavior))
            {
                var t1 = data.GetValue(VARIANT_KEY);
                if (t1 == null)
                    return;

                string variant = t1.Value<string>();
                behavior.SetVariant(variant);
            }
        }

        public static JObject Blueprints_GetData(GameObject source)
        {
            if (source.TryGetComponent<SelectableSign>(out var behavior))
            {
                return new JObject()
                {
                    { VARIANT_KEY, behavior.GetCurrentVariant()}
                };
            }
            return null;
        }
    }
}
