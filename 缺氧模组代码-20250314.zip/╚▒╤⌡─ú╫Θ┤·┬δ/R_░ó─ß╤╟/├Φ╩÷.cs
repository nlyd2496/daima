﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HarmonyLib;
using STRINGS;
using KMod;
using PeterHan.PLib.Core;
using PeterHan.PLib.Database;
using Klei.AI;
using PeterHan.PLib.Options;

namespace R_阿尼亚
{
    public class STRINGS
    {
        public class SIDESCREEN
        {
            public static LocString R008GG1L1A1 = "哇酷哇酷"; // 哇酷哇酷
        }
        public static void DoReplacement()
        {
            LocString.CreateLocStringKeys(typeof(STRINGS), "");
        }
        [HarmonyPatch(typeof(EntityConfigManager))]
        [HarmonyPatch("LoadGeneratedEntities")]
            
        public class BUILDINGS
        {
            public class PREFABS
            {
                public class R008GG1L1
                {
                    public static LocString NAME = "阿尼亚"; // 阿尼亚
                    public static LocString EFFECT = "アニアは母亲がいなくて寂しい"; // 阿尼亚没有妈妈好寂寞啊
                    public static LocString DESC = "わくわく"; // 哇酷哇酷
                }
            }
        }
    }
}
