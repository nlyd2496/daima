﻿using HarmonyLib;
using PeterHan.PLib.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace R_家具系统_1._0
{
    [HarmonyPatch(typeof(HotTubConfig))]
    [HarmonyPatch("ConfigureBuildingTemplate")]
    public class 猛男的浴缸
    {
        public static void Postfix(GameObject go, Tag prefab_tag)
        {
            bool R017GG1 = SingletonOptions<控制台>.Instance.R017GG1;
            if (R017GG1)
            {
                go.GetComponent<ManualDeliveryKG>().RequestedItemTag = new Tag("Steel");
            }
        }
    }
}
