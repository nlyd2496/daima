﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HarmonyLib;
using STRINGS;
using KMod;
using PeterHan.PLib.Core;
using PeterHan.PLib.Database;
using Klei.AI;
using PeterHan.PLib.Options;

namespace R_家具系统_1._0
{

    public class STRINGS
    {
        public static void DoReplacement()
        {
            LocString.CreateLocStringKeys(typeof(STRINGS), "");
        }
        // 控制器
        public class 控制器UI
        {
            public static LocString R001GG1_T_UI = "启用ACGN之二次元之魂";
            public static LocString R002GG1_T_UI = "启用卡塔尔世界杯吉祥物";
            public static LocString R003GG1_T_UI = "启用背景灯";
            public static LocString R004GG1_T_UI = "启用精致梯子";
            public static LocString R004GG2_T_UI = "启用精致梯子";
            public static LocString R004GG3_T_UI = "启用精致梯子";
            public static LocString R005GG1_T_UI = "启用超级冰雕";
            public static LocString R006GG1_T_UI = "启用吊床";
            public static LocString R007GG1_T_UI = "启用叠叠床";
            public static LocString R007GG1X1_T_UI = "上叠叠床的速度";
            public static LocString R007GG1X2_T_UI = "下叠叠床的速度";
            public static LocString R008GG1_T_UI = "启用翻飞幻梦";
            public static LocString R009GG1_T_UI = "启用粉红灯";
            public static LocString R010GG1_T_UI = "启用DRX";
            public static LocString R011GG1_T_UI = "启用恭喜faker拿下第四个S赛冠军";
            public static LocString R012GG1_T_UI = "启用简单漂亮床";
            public static LocString R013GG1_T_UI = "启用角顶饰条在建筑前方";
            public static LocString R014GG1_T_UI = "启用警示牌";
            public static LocString R015GG1_T_UI = "启用九块九包邮的花盆";
            public static LocString R016GG1_T_UI = "启用沥青滴漏实验";
            public static LocString R017GG1_T_UI = "启用猛男的浴缸";
            public static LocString R018GG1_T_UI = "启用梦可床";
            public static LocString R019GG1_T_UI = "启用喵喵床";
            public static LocString R020GG1_T_UI = "启用南瓜灯";
            public static LocString R021GG1_T_UI = "启用牛战士的面具";
            public static LocString R022GG1_T_UI = "启用启动魔法少女";
            public static LocString R023GG1_T_UI = "启用闪烁的雕塑";
            public static LocString R024GG1_T_UI = "启用圣诞礼物";
            public static LocString R025GG1_T_UI = "启用圣诞树";
            public static LocString R026GG1_T_UI = "启用点唱机";
            public static LocString R026GG1X1_T_UI = "点唱机功率修改";
            public static LocString R027GG1_T_UI = "启用天地棋局";
            public static LocString R028GG1_T_UI = "启用下雪啦";
            public static LocString R029GG1_T_UI = "启用香草餐桌";
            public static LocString R030GG1_T_UI = "启用香草花盆";
            public static LocString R031GG1_T_UI = "启用香草梯子";
            public static LocString R031GG1X1_T_UI = "爬香草梯子的速度";
            public static LocString R032GG1_T_UI = "启用香草摇摇床";
            public static LocString R033GG1_T_UI = "启用熊猫贴纸";
            public static LocString R034GG1_T_UI = "启用小电视";
            public static LocString R035GG1_T_UI = "启用萤火虫灯";
            public static LocString R036GG1_T_UI = "启用智能吸顶灯";
            public static LocString R037GG1_T_UI = "启用中国兵器";
            public static LocString R038GG1_T_UI = "启用超级开发者光源";
        }

        // 侧边栏描述
        public class SIDESCREEN
        {
            public static LocString R000GG0 = "哇酷哇酷"; // 哇酷哇酷
        }
        // 建筑描述
        public class BUILDINGS
        {
            public class PREFABS
            {
                public class R001GG1
                {
                    public static LocString NAME = "ACGN之鞋子";
                    public static LocString EFFECT = "这是鞋子，你可以更换不同的鞋子。";
                    public static LocString DESC = "鞋子。";
                }
                public class R001GG2
                {
                    public static LocString NAME = "ACGN之裤子";
                    public static LocString EFFECT = "这是裤子，你可以更换不同的裤子。";
                    public static LocString DESC = "裤子";
                }
                public class R001GG3
                {
                    public static LocString NAME = "ACGN之衣裳";
                    public static LocString EFFECT = "这是衣裳，你可以更换不同的衣裳。";
                    public static LocString DESC = "衣裳";
                }
                public class R001GG4
                {
                    public static LocString NAME = "ACGN之发型";
                    public static LocString EFFECT = "这是发型，你可以更换不同的发型。";
                    public static LocString DESC = "发型";
                }
                public class R002GG1
                {
                    public static LocString NAME = "卡塔尔世界杯吉祥物";
                    public static LocString EFFECT = "喜欢足球吗，亲切的为你提供了几个可以选择的足球小子。想要在游戏里踢足球吗，啊，或许圆滚滚的哈奇是一个不错的选择。嘘，小心别被听见了，它会咬人，大概，或许，可能吧。";
                    public static LocString DESC = "请注意，那不是饺子。";
                }
                public class R003GG1
                {
                    public static LocString NAME = "背景灯";
                    public static LocString EFFECT = "它可以建造在普通建筑后面，光亮没有那么的强，用来给雕塑增加一点点氛围感，足够了。";
                    public static LocString DESC = "一丝微光，一丝点缀。";
                }
                public class R004GG1
                {
                    public static LocString NAME = "冰梯子";
                    public static LocString EFFECT = "冰块做的梯子，龟速爬上，飞速滑落。";
                    public static LocString DESC = "西山白雪三城戍。";
                }
                public class R004GG2
                {
                    public static LocString NAME = "木头梯子";
                    public static LocString EFFECT = "木头做的梯子，快快爬上，快快爬下。";
                    public static LocString DESC = "树阴照水爱晴柔。";
                }
                public class R004GG3
                {
                    public static LocString NAME = "金梯子";
                    public static LocString EFFECT = "黄金做的梯子，飞速爬上，飞速爬下。";
                    public static LocString DESC = "黄金印绶悬腰底。";
                }
                public class R006GG1
                {
                    public static LocString NAME = "海湾吊床";
                    public static LocString EFFECT = "天蓝的色彩，轻巧的造型，圆润的曲线，五一不透露出它的美。小人睡在上面有点晃，是真的吗，并不是，那是调皮的小人在做着美梦。";
                    public static LocString DESC = "哪怕只是离地一尺，那也是天空的味道。";
                }
                public class R006GG1L2
                {
                    public static LocString NAME = "北欧吊床";
                    public static LocString EFFECT = "独具匠心，石质工艺。远古的岁月让人们遗忘了仰望星空的感觉，忘记了在大自然的微风吹拂下，安然入睡的美妙。粗糙的技巧，不及曾经的十分之一，在这个年代，却又显得弥足珍贵。";
                }
                public class R007GG1
                {
                    public static LocString NAME = "叠叠床";
                    public static LocString EFFECT = "人口数量太多，床不够，怎么办，叠叠床来凑数。能够相互重叠建造，一层一个小人，在荒郊野外，简直爽歪歪。";
                    public static LocString DESC = "有点挤，忍着点。";
                }
                public class R008GG1
                {
                    public static LocString NAME = "翻飞幻梦";
                    public static LocString EFFECT = "喜欢动漫吗，喜欢二次元吗，在这里，有很多。";
                    public static LocString DESC = "好可爱，想拥有。";
                }
                public class R010GG1
                {
                    public static LocString NAME = "恭喜DRX夺得英雄联盟S12全球总决赛冠军";
                    public static LocString EFFECT = "恭喜DRX夺得英雄联盟S12全球总决赛冠军";
                    public static LocString DESC = "恭喜DRX夺得英雄联盟S12全球总决赛冠军";
                }
                public class R011GG1
                {
                    public static LocString NAME = "Faker！NB！";
                    public static LocString EFFECT = "没有人躲得过岁月，但大部分人选择逃避守着自己的半寸土地，而小部分人选择扛起自己的江山直面新时代的挑战。倘若faker S3夺冠退役，那么留给他的是史上最强刺客的名号。倘若faker S5退役，留给他的则是无与伦比的首个S双冠王。倘若faker S6退役，不败魔王至今也是最可望不可及的高峰。但他选择一直坚持到现在！十年依旧！";
                    public static LocString DESC = "恭喜faker拿下LOL全球总决赛S13冠军。";
                }
                public class R012GG1L2
                {
                    public static LocString NAME = "简单漂亮床";
                    public static LocString EFFECT = "三只气球，一只小熊猫，这又是哪位毛孩子的港湾。后面挂着的那“I LOVE YOU”，一定代表了那海枯石烂的爱情吧，不知，那梦中的情人，在何方。";
                }
                public class R014GG1
                {
                    public static LocString NAME = "警示牌";
                    public static LocString EFFECT = "暗号。";
                    public static LocString DESC = "许可通行。";
                }
                public class R014GG2
                {
                    public static LocString NAME = "警示牌图标";
                    public static LocString EFFECT = "为警示牌添加更加明显的图标。";
                    public static LocString DESC = "图标。";
                }
                public class R015GG1
                {
                    public static LocString NAME = "一壹号花盆";
                    public static LocString EFFECT = "九块九包邮的花盆大甩卖了啊！";
                }
                public class R015GG1L2
                {
                    public static LocString NAME = "贰号花盆";
                }
                public class R015GG1L3
                {
                    public static LocString NAME = "叁号花盆";
                }
                public class R015GG1L4
                {
                    public static LocString NAME = "肆号花盆";
                }
                public class R015GG1L5
                {
                    public static LocString NAME = "伍号花盆";
                }
                public class R015GG1L6
                {
                    public static LocString NAME = "陆号花盆";
                }
                public class R015GG1L7
                {
                    public static LocString NAME = "柒号花盆";
                }
                public class R015GG1L8
                {
                    public static LocString NAME = "捌号花盆";
                }
                public class R016GG1
                {
                    public static LocString NAME = "沥青滴落实验";
                    public static LocString EFFECT = "还记得初中物理对于固体液体气体的描述吗，那么问题来了，沥青是固体还是液体。如果你看它比较硬硬的，就说它是固体，这是不对的。科学，需要事实的支撑，需要数据的支撑。一年，两年，三年，很多年。或许某一天你能观察到沥青滴落的那一瞬间。那个是时候，你或许会感叹，科学，神奇。";
                    public static LocString DESC = "沥青是一种液体哟。";
                }
                public class R019GG1
                {
                    public static LocString NAME = "黄色喵喵床";
                    public static LocString EFFECT = "软乎乎，毛绒绒，如果躺在她的怀里睡觉，一定很舒服的吧。真可爱，我最乖的小猫猫，喵喵喵。";
                    public static LocString DESC = "送给好友的礼物，愿你永远青春美丽，愿你永远开心快乐*-*";
                }
                public class R019GG1L2
                {
                    public static LocString NAME = "粉色喵喵床";
                    public static LocString EFFECT = "软乎乎，毛绒绒，如果躺在她的怀里睡觉，一定很舒服的吧。真可爱，我最乖的小猫猫，喵喵喵。";
                }
                public class R020GG1
                {
                    public static LocString NAME = "南瓜灯";
                    public static LocString EFFECT = "厌倦了白炽灯白色的光芒，增加了一点点的色彩，让世界不是那么非黑即白。如果某天，没有食物了，南瓜灯去掉灯，或许可以吃，在掉下一排牙齿的前提下。";
                    public static LocString DESC = "别吃，它不是真的南瓜！";
                }
                public class R021GG1
                {
                    public static LocString NAME = "牛战士的面具";
                    public static LocString EFFECT = "挖空的，就遮起来，看不见，就没有。你可以放大缩小它的大小，变大，变小，很方便哟。";
                    public static LocString DESC = "牛战士，从不取下他的面具。";
                }
                public class R022GG1
                {
                    public static LocString NAME = "启动魔法少女";
                    public static LocString EFFECT = "孩子，想要成为魔法少女吗？缔结契约，一起拯救世界。";
                    public static LocString DESC = "小心，学姐的头被拧下来了。";
                }
                public class R024GG1
                {
                    public static LocString NAME = "圣诞礼物";
                    public static LocString EFFECT = "没有圣诞老人，圣诞老人没有办法在没有烟囱的游戏里出现。但我们仍能收到圣诞老人送出的礼物，或许老爷爷也会编程，所以通过烟囱漏洞悄咪咪的将礼物送出，也说不定哟。";
                    public static LocString DESC = "圣诞节快乐";
                }
                public class R025GG1
                {
                    public static LocString NAME = "圣诞树";
                    public static LocString EFFECT = "圣诞节怎么能够没有圣诞树呢，还是一颗能够发光的圣诞树。在这美好的节日里，未来的每一天，都是幸运的一天。";
                    public static LocString DESC = "圣诞节快乐";
                }
                public class R027GG1
                {
                    public static LocString NAME = "天地棋局";
                    public static LocString EFFECT = "以大地为棋盘，以江河为线，以日月山川为子。这是一盘棋，可以是围棋，可以是将棋，也可以是五子棋。心够大，一切皆有可能。";
                    public static LocString DESC = "放轻松，这只是一个游戏。";
                }
                public class R028GG1
                {
                    public static LocString NAME = "下雪啦";
                    public static LocString EFFECT = "想家了，想起了家乡的雪。这个世界没有雪，自己造。最新3D成像技术，带你体验下雪的美妙快感。";
                    public static LocString DESC = "假的，全都是假的，这个世界。";
                }
                public class R029GG1
                {
                    public static LocString NAME = "香草餐桌";
                    public static LocString EFFECT = "靡室靡家，玁狁之故。";
                    public static LocString DESC = "小雅·采薇。";
                }
                public class R030GG1
                {
                    public static LocString NAME = "香草蓝花盆";
                    public static LocString EFFECT = "蓝色的花盆，带着一点点点缀，高端大气上档次。";
                    public static LocString DESC = "不要怀疑，奢华风。";
                }
                public class R030GG1L2
                {
                    public static LocString NAME = "香草金花盆";
                    public static LocString EFFECT = "金色的花盆，带着一点点点缀，高端大气上档次。";
                    public static LocString DESC = "不要怀疑，奢华风。";
                }
                public class R030GG1L3
                {
                    public static LocString NAME = "香草粉花盆";
                    public static LocString EFFECT = "粉色的花盆，带着一点点点缀，高端大气上档次。";
                    public static LocString DESC = "不要怀疑，奢华风。";
                }
                public class R030GG1L4
                {
                    public static LocString NAME = "香草红花盆";
                    public static LocString EFFECT = "红色的花盆，带着一点点点缀，高端大气上档次。";
                    public static LocString DESC = "不要怀疑，奢华风。";
                }
                public class R031GG1
                {
                    public static LocString NAME = "香草梯子";
                    public static LocString EFFECT = "藤蔓编织，香草梯子。";
                    public static LocString DESC = "爱我就请踩我。";
                }
                public class R032GG1
                {
                    public static LocString NAME = "香草摇摇床";
                    public static LocString EFFECT = "睡惯了方的床，睡惯了圆的床。这里有不方不圆的床，可以考虑一下。带着青草的香味入眠，想来，也是极好的。";
                    public static LocString DESC = "不要想多了，它不会晃。";
                }
                public class R033GG1
                {
                    public static LocString NAME = "熊猫贴纸";
                    public static LocString EFFECT = "各种熊猫可以任君选择，拟人化的化的熊猫也是熊猫，可爱，萌。";
                    public static LocString DESC = "人均一只？牢底坐穿！";
                }
                public class R034GG1
                {
                    public static LocString NAME = "英雄联盟宣传片";
                    public static LocString EFFECT = "英雄联盟宣传片。";
                    public static LocString DESC = "游戏里，总要看点不一样的东西。";
                }
                public class R034GG1L2
                {
                    public static LocString NAME = "可爱的无牙仔";
                    public static LocString EFFECT = "可爱的无牙仔。";
                }
                public class R035GG1
                {
                    public static LocString NAME = "萤火虫灯";
                    public static LocString EFFECT = "酷似萤火虫的灯，你可以控制它的灯光范围和亮度，注意，范围越大能耗越高。";
                    public static LocString DESC = "可爱的萤火虫灯。";
                }
                public class R037GG1
                {
                    public static LocString NAME = "武器";
                    public static LocString EFFECT = "刀枪剑戟......十八般兵器尽入其中。你想要什么，这里不一定有，如果你是铁匠，那到有可能有。";
                    public static LocString DESC = "看着就吓人。";
                }
                public class R037GG2
                {
                    public static LocString NAME = "武器架";
                    public static LocString EFFECT = "平平无奇的木头架子，上面或许可以放一点东西。放一些什么呢，当然是放一排的武器了，你想要放什么，最好是放冷兵器，因为热兵器太热了。";
                    public static LocString DESC = "大人，你就不想把它填满吗。";
                }

                /*
                 * 
                 public class UII
                {
                public static LocString 千克 = "kg";//千克
                public static LocString 摄氏度 = "℃";//摄氏度
                public static LocString 卡尔文 = "K";//开尔文
                public static LocString 勒克斯 = "lux";//光强
                public static LocString 瓦 = "W";//瓦
                public static LocString 焦耳 = "J";//焦耳
                public static LocString 拉德 = "Rads";//辐射kDTU/s
                public static LocString 热量 = "kDTU/s";//热量
                public static LocString 格 = "格";//热量
                public static LocString 控制器 = "控制器";//空
                public static LocString 点这里 = "点这里";//空
                public static LocString 空 = "x";//空
                public static LocString 长 = "长";//空
                public static LocString 高 = "高";//空
                public static LocString 宽 = "宽";//空
                public static LocString 能量 = "能量";//空
                public static LocString PARTRICLES = " Radbolts";
                }
                public class R001GG1
                {
                    public static LocString NAME = "ACGN之鞋子";
                    public static LocString EFFECT = "这是鞋子，你可以更换不同的鞋子。";
                    public static LocString DESC = "鞋子。";
                }
                public class R001GG2
                {
                    public static LocString NAME = "ACGN之裤子";
                    public static LocString EFFECT = "这是裤子，你可以更换不同的裤子。";
                    public static LocString DESC = "裤子";
                }
                public class R001GG3
                {
                    public static LocString NAME = "ACGN之衣裳";
                    public static LocString EFFECT = "这是衣裳，你可以更换不同的衣裳。";
                    public static LocString DESC = "衣裳";
                }
                public class R001GG4
                {
                    public static LocString NAME = "ACGN之发型";
                    public static LocString EFFECT = "这是发型，你可以更换不同的发型。";
                    public static LocString DESC = "发型";
                }
                public class R002GG1
                {
                    public static LocString NAME = "卡塔尔世界杯吉祥物";
                    public static LocString EFFECT = "喜欢足球吗，亲切的为你提供了几个可以选择的足球小子。想要在游戏里踢足球吗，啊，或许圆滚滚的哈奇是一个不错的选择。嘘，小心别被听见了，它会咬人，大概，或许，可能吧。";
                    public static LocString DESC = "请注意，那不是饺子。";
                }
                public class R003GG1
                {
                    public static LocString NAME = "背景灯";
                    public static LocString EFFECT = "它可以建造在普通建筑后面，光亮没有那么的强，用来给雕塑增加一点点氛围感，足够了。";
                    public static LocString DESC = "一丝微光，一丝点缀。";
                }
                public class R004GG1
                {
                    public static LocString NAME = "冰梯子";
                    public static LocString EFFECT = "冰块做的梯子，龟速爬上，飞速滑落。";
                    public static LocString DESC = "西山白雪三城戍。";
                }
                public class R004GG2
                {
                    public static LocString NAME = "木头梯子";
                    public static LocString EFFECT = "木头做的梯子，快快爬上，快快爬下。";
                    public static LocString DESC = "树阴照水爱晴柔。";
                }
                public class R004GG3
                {
                    public static LocString NAME = "金梯子";
                    public static LocString EFFECT = "黄金做的梯子，飞速爬上，飞速爬下。";
                    public static LocString DESC = "黄金印绶悬腰底。";
                }
                public class R006GG1
                {
                    public static LocString NAME = "海湾吊床";
                    public static LocString EFFECT = "天蓝的色彩，轻巧的造型，圆润的曲线，五一不透露出它的美。小人睡在上面有点晃，是真的吗，并不是，那是调皮的小人在做着美梦。";
                    public static LocString DESC = "哪怕只是离地一尺，那也是天空的味道。";
                }
                public class R006GG1L2
                {
                    public static LocString NAME = "北欧吊床";
                    public static LocString EFFECT = "独具匠心，石质工艺。远古的岁月让人们遗忘了仰望星空的感觉，忘记了在大自然的微风吹拂下，安然入睡的美妙。粗糙的技巧，不及曾经的十分之一，在这个年代，却又显得弥足珍贵。";
                }
                public class R007GG1
                {
                    public static LocString NAME = "叠叠床";
                    public static LocString EFFECT = "人口数量太多，床不够，怎么办，叠叠床来凑数。能够相互重叠建造，一层一个小人，在荒郊野外，简直爽歪歪。";
                    public static LocString DESC = "有点挤，忍着点。";
                }
                public class R008GG1
                {
                    public static LocString NAME = "翻飞幻梦";
                    public static LocString EFFECT = "喜欢动漫吗，喜欢二次元吗，在这里，有很多。";
                    public static LocString DESC = "好可爱，想拥有。";
                }
                public class R010GG1
                {
                    public static LocString NAME = "恭喜DRX夺得英雄联盟S12全球总决赛冠军";
                    public static LocString EFFECT = "恭喜DRX夺得英雄联盟S12全球总决赛冠军";
                    public static LocString DESC = "恭喜DRX夺得英雄联盟S12全球总决赛冠军";
                }
                public class R011GG1
                {
                    public static LocString NAME = "Faker！NB！";
                    public static LocString EFFECT = "没有人躲得过岁月，但大部分人选择逃避守着自己的半寸土地，而小部分人选择扛起自己的江山直面新时代的挑战。倘若faker S3夺冠退役，那么留给他的是史上最强刺客的名号。倘若faker S5退役，留给他的则是无与伦比的首个S双冠王。倘若faker S6退役，不败魔王至今也是最可望不可及的高峰。但他选择一直坚持到现在！十年依旧！";
                    public static LocString DESC = "恭喜faker拿下LOL全球总决赛S13冠军。";
                }
                public class R012GG1L2
                {
                    public static LocString NAME = "简单漂亮床";
                    public static LocString EFFECT = "三只气球，一只小熊猫，这又是哪位毛孩子的港湾。后面挂着的那“I LOVE YOU”，一定代表了那海枯石烂的爱情吧，不知，那梦中的情人，在何方。";
                }
                public class R014GG1
                {
                    public static LocString NAME = "警示牌";
                    public static LocString EFFECT = "暗号。";
                    public static LocString DESC = "许可通行。";
                }
                public class R014GG2
                {
                    public static LocString NAME = "警示牌图标";
                    public static LocString EFFECT = "为警示牌添加更加明显的图标。";
                    public static LocString DESC = "图标。";
                }
                public class R015GG1
                {
                    public static LocString NAME = "一壹号花盆";
                    public static LocString EFFECT = "九块九包邮的花盆大甩卖了啊！";
                }
                public class R015GG1L2
                {
                    public static LocString NAME = "贰号花盆";
                }
                public class R015GG1L3
                {
                    public static LocString NAME = "叁号花盆";
                }
                public class R015GG1L4
                {
                    public static LocString NAME = "肆号花盆";
                }
                public class R015GG1L5
                {
                    public static LocString NAME = "伍号花盆";
                }
                public class R015GG1L6
                {
                    public static LocString NAME = "陆号花盆";
                }
                public class R015GG1L7
                {
                    public static LocString NAME = "柒号花盆";
                }
                public class R015GG1L8
                {
                    public static LocString NAME = "捌号花盆";
                }
                public class R016GG1
                {
                    public static LocString NAME = "沥青滴落实验";
                    public static LocString EFFECT = "还记得初中物理对于固体液体气体的描述吗，那么问题来了，沥青是固体还是液体。如果你看它比较硬硬的，就说它是固体，这是不对的。科学，需要事实的支撑，需要数据的支撑。一年，两年，三年，很多年。或许某一天你能观察到沥青滴落的那一瞬间。那个是时候，你或许会感叹，科学，神奇。";
                    public static LocString DESC = "沥青是一种液体哟。";
                }
                public class R019GG1
                {
                    public static LocString NAME = "黄色喵喵床";
                    public static LocString EFFECT = "软乎乎，毛绒绒，如果躺在她的怀里睡觉，一定很舒服的吧。真可爱，我最乖的小猫猫，喵喵喵。";
                    public static LocString DESC = "送给好友的礼物，愿你永远青春美丽，愿你永远开心快乐*-*";
                }
                public class R019GG1L2
                {
                    public static LocString NAME = "粉色喵喵床";
                    public static LocString EFFECT = "软乎乎，毛绒绒，如果躺在她的怀里睡觉，一定很舒服的吧。真可爱，我最乖的小猫猫，喵喵喵。";
                }
                public class R020GG1
                {
                    public static LocString NAME = "南瓜灯";
                    public static LocString EFFECT = "厌倦了白炽灯白色的光芒，增加了一点点的色彩，让世界不是那么非黑即白。如果某天，没有食物了，南瓜灯去掉灯，或许可以吃，在掉下一排牙齿的前提下。";
                    public static LocString DESC = "别吃，它不是真的南瓜！";
                }
                public class R021GG1
                {
                    public static LocString NAME = "牛战士的面具";
                    public static LocString EFFECT = "挖空的，就遮起来，看不见，就没有。你可以放大缩小它的大小，变大，变小，很方便哟。";
                    public static LocString DESC = "牛战士，从不取下他的面具。";
                }
                public class R022GG1
                {
                    public static LocString NAME = "启动魔法少女";
                    public static LocString EFFECT = "孩子，想要成为魔法少女吗？缔结契约，一起拯救世界。";
                    public static LocString DESC = "小心，学姐的头被拧下来了。";
                }
                public class R024GG1
                {
                    public static LocString NAME = "圣诞礼物";
                    public static LocString EFFECT = "没有圣诞老人，圣诞老人没有办法在没有烟囱的游戏里出现。但我们仍能收到圣诞老人送出的礼物，或许老爷爷也会编程，所以通过烟囱漏洞悄咪咪的将礼物送出，也说不定哟。";
                    public static LocString DESC = "圣诞节快乐";
                }
                public class R025GG1
                {
                    public static LocString NAME = "圣诞树";
                    public static LocString EFFECT = "圣诞节怎么能够没有圣诞树呢，还是一颗能够发光的圣诞树。在这美好的节日里，未来的每一天，都是幸运的一天。";
                    public static LocString DESC = "圣诞节快乐";
                }
                public class R027GG1
                {
                    public static LocString NAME = "天地棋局";
                    public static LocString EFFECT = "以大地为棋盘，以江河为线，以日月山川为子。这是一盘棋，可以是围棋，可以是将棋，也可以是五子棋。心够大，一切皆有可能。";
                    public static LocString DESC = "放轻松，这只是一个游戏。";
                }
                public class R028GG1
                {
                    public static LocString NAME = "下雪啦";
                    public static LocString EFFECT = "想家了，想起了家乡的雪。这个世界没有雪，自己造。最新3D成像技术，带你体验下雪的美妙快感。";
                    public static LocString DESC = "假的，全都是假的，这个世界。";
                }
                public class R029GG1
                {
                    public static LocString NAME = "香草餐桌";
                    public static LocString EFFECT = "靡室靡家，玁狁之故。";
                    public static LocString DESC = "小雅·采薇。";
                }
                public class R030GG1
                {
                    public static LocString NAME = "香草蓝花盆";
                    public static LocString EFFECT = "蓝色的花盆，带着一点点点缀，高端大气上档次。";
                    public static LocString DESC = "不要怀疑，奢华风。";
                }
                public class R030GG1L2
                {
                    public static LocString NAME = "香草金花盆";
                    public static LocString EFFECT = "金色的花盆，带着一点点点缀，高端大气上档次。";
                    public static LocString DESC = "不要怀疑，奢华风。";
                }
                public class R030GG1L3
                {
                    public static LocString NAME = "香草粉花盆";
                    public static LocString EFFECT = "粉色的花盆，带着一点点点缀，高端大气上档次。";
                    public static LocString DESC = "不要怀疑，奢华风。";
                }
                public class R030GG1L4
                {
                    public static LocString NAME = "香草红花盆";
                    public static LocString EFFECT = "红色的花盆，带着一点点点缀，高端大气上档次。";
                    public static LocString DESC = "不要怀疑，奢华风。";
                }
                public class R031GG1
                {
                    public static LocString NAME = "香草梯子";
                    public static LocString EFFECT = "藤蔓编织，香草梯子。";
                    public static LocString DESC = "爱我就请踩我。";
                }
                public class R032GG1
                {
                    public static LocString NAME = "香草摇摇床";
                    public static LocString EFFECT = "睡惯了方的床，睡惯了圆的床。这里有不方不圆的床，可以考虑一下。带着青草的香味入眠，想来，也是极好的。";
                    public static LocString DESC = "不要想多了，它不会晃。";
                }
                public class R033GG1
                {
                    public static LocString NAME = "熊猫贴纸";
                    public static LocString EFFECT = "各种熊猫可以任君选择，拟人化的化的熊猫也是熊猫，可爱，萌。";
                    public static LocString DESC = "人均一只？牢底坐穿！";
                }
                public class R034GG1
                {
                    public static LocString NAME = "英雄联盟宣传片";
                    public static LocString EFFECT = "英雄联盟宣传片。";
                    public static LocString DESC = "游戏里，总要看点不一样的东西。";
                }
                public class R034GG1L2
                {
                    public static LocString NAME = "可爱的无牙仔";
                    public static LocString EFFECT = "可爱的无牙仔。";
                }
                public class R035GG1
                {
                    public static LocString NAME = "萤火虫灯";
                    public static LocString EFFECT = "酷似萤火虫的灯，你可以控制它的灯光范围和亮度，注意，范围越大能耗越高。";
                    public static LocString DESC = "可爱的萤火虫灯。";
                }
                public class R037GG1
                {
                    public static LocString NAME = "武器";
                    public static LocString EFFECT = "刀枪剑戟......十八般兵器尽入其中。你想要什么，这里不一定有，如果你是铁匠，那到有可能有。";
                    public static LocString DESC = "看着就吓人。";
                }
                public class R037GG2
                {
                    public static LocString NAME = "武器架";
                    public static LocString EFFECT = "平平无奇的木头架子，上面或许可以放一点东西。放一些什么呢，当然是放一排的武器了，你想要放什么，最好是放冷兵器，因为热兵器太热了。";
                    public static LocString DESC = "大人，你就不想把它填满吗。";
                }
                */
            }
        }
    }
}
