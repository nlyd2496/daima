﻿using STRINGS;
using System;
using System.IO;
using System.Reflection;

namespace N_南孚电池
{

    public class STRINGS
    {
        public static void DoReplacement()
        {
            LocString.CreateLocStringKeys(typeof(STRINGS), "");
        }
        public class BUILDINGS
        {
            public class PREFABS
            {
                public class N_UI
                {
                    public static LocString N001GGG1X1_UI = "电池蓄电量";
                }
                public class N012GGG1//南孚电池
                {
                    public static LocString NAME = "北孚电池";
                    public static LocString EFFECT = "连接输电线，将电网中多余的电量以化学能的方式储存起来，并在你需要的时候将其释放在电网中。 \n\n 这不是南孚电池，这是北孚电池。我们不生产电能，我们只是电能的搬运工。";
                    public static LocString DESC = "北孚电池，一节更比一节强。";
                    public static LocString LOGIC_PORT = "充电参数";
                    public static LocString LOGIC_PORT_ACTIVE = "发送" + UI.FormatAsAutomationState("绿色信号", UI.AutomationState.Active) + "当电池电量低于<b>低阈值</b>时，直到再次达到<b>高阈值</b>。";
                    public static LocString LOGIC_PORT_INACTIVE = "发送" + UI.FormatAsAutomationState("红色信号", UI.AutomationState.Standby) + "当电池充电超过<b>高阈值</b>时，直到再次达到<b>低阈值</b>。";

                }
            }
        }
    }
}
