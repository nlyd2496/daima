﻿using Microsoft.SqlServer.Server;
using Newtonsoft.Json;
using PeterHan.PLib.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace N_南孚电池
{
    [RestartRequired]
    [JsonObject(MemberSerialization.OptIn)]
    [ConfigFile("Controler.json", true, false)]
    // [ModInfo("https://space.bilibili.com/30725645", "mmm.png", true)]

    public class 控制台 : SingletonOptions<控制台>
    {
        [Option("STRINGS.BUILDINGS.PREFABS.N_UI.N001GGG1X1_UI", null, null, Format = "F0")][Limit(1, 100000)][JsonProperty] public float N012GGG1X1 { get; set; } = 10000f;
    }
}
