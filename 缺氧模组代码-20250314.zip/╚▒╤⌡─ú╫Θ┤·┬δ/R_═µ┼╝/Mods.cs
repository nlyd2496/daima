﻿using HarmonyLib;
using KMod;
using PeterHan.PLib.Core;
using PeterHan.PLib.Options;

namespace R_玩偶
{
    public class Mod : UserMod2
    {       
        public static string Namespace { get; private set; }
        public override void OnLoad(Harmony harmony)
		{
            base.OnLoad(harmony);         
            PUtil.InitLibrary(true);
            Namespace = base.GetType().Namespace;          
            new POptions().RegisterOptions(this, typeof(控制台));           
        }
    }
}
