﻿using Newtonsoft.Json;
using PeterHan.PLib.Options;

namespace R_玩偶
{
    [RestartRequired]
    [JsonObject(MemberSerialization.OptIn)]
    [ConfigFile("R008GGG0.json", true, false)]
    // [ModInfo("https://space.bilibili.com/30725645", "mmm.png", true)]
    public class 控制台 : SingletonOptions<控制台>
    {
        [Option("STRINGS.BUILDINGS.PREFABS.R_UI.R008GGG1_UI", null, null)][JsonProperty] public bool R008GGG1 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.R_UI.R008GGG2_UI", null, null)][JsonProperty] public bool R008GGG2 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.R_UI.R008GGG3_UI", null, null)][JsonProperty] public bool R008GGG3 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.R_UI.R008GGG4_UI", null, null)][JsonProperty] public bool R008GGG4 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.R_UI.R008GGG5_UI", null, null)][JsonProperty] public bool R008GGG5 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.R_UI.R008GGG6_UI", null, null)][JsonProperty] public bool R008GGG6 { get; set; } = true;

    }
}
