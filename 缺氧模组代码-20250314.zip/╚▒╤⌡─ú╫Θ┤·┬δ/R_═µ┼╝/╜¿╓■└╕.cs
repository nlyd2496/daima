﻿using HarmonyLib;

namespace R_玩偶
{
    [HarmonyPatch(typeof(GeneratedBuildings))]
    [HarmonyPatch("LoadGeneratedBuildings")]
    public class 建筑栏
    {
        public static void Prefix()
        {
            // 测试
            ModUtil.AddBuildingToPlanScreen("Furniture", "R000GGG1");
            // 测试

            

            // 侧边栏描述
            BasicModUtils.MakeSideScreenStrings(SignSideScreen.SCREEN_TITLE_KEY, STRINGS.SIDESCREEN.R008GGGG1);
            // 建筑栏描述
            ModUtil.AddBuildingToPlanScreen("Furniture", "R008GGG1");
            ModUtil.AddBuildingToPlanScreen("Furniture", "R008GGG2"); 
            ModUtil.AddBuildingToPlanScreen("Furniture", "R008GGG3");
            ModUtil.AddBuildingToPlanScreen("Furniture", "R008GGG4");
            ModUtil.AddBuildingToPlanScreen("Furniture", "R008GGG5");
            ModUtil.AddBuildingToPlanScreen("Furniture", "R008GGG6");


        }
    }
}
//  基地 氧气   电力  食物 液管     气管 精炼     医疗    家具      站台      实用      自动化     运输       火箭     辐射
//  Base Oxygen Power Food Plumbing HVAC Refining Medical Furniture Equipment Utilities Automation Conveyance Rocketry HEP

