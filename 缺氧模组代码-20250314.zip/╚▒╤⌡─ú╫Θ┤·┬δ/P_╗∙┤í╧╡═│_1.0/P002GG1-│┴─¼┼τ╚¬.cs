﻿using System;
using HarmonyLib;
using UnityEngine;
using TUNING;
using PeterHan.PLib.Options;

namespace P_基础系统_1._0
{
    [HarmonyPatch(typeof(GeyserConfigurator.GeyserInstanceConfiguration))]
    [HarmonyPatch("GetIterationPercent")]//获取迭代百分百
    public static class 喷泉喷发期为零
    {
        public static void Postfix(ref float __result)
        {
            bool 沉默喷泉 = SingletonOptions<控制台>.Instance.P002GG1;
            if (沉默喷泉)
            {
                __result = 0f;
            }
        }
    }
    //--------------------------
    [HarmonyPatch(typeof(GeyserConfigurator.GeyserInstanceConfiguration))]
    [HarmonyPatch("GetYearPercent")]//获取年度百分百
    public static class 喷泉活跃期为零
    {
        private static void Postfix(ref float __result)
        {
            bool 沉默喷泉 = SingletonOptions<控制台>.Instance.P002GG1;
            if (沉默喷泉)
            {
                __result = 0f;
            }
        }
    }
}
