﻿using HarmonyLib;
using PeterHan.PLib.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P_基础系统_1._0
{
    //喷发质量倍数
    [HarmonyPatch(typeof(GeyserConfigurator.GeyserInstanceConfiguration))]
    [HarmonyPatch("GetEmitRate")]
    public static class 喷发质量倍数
    {
        private static void Postfix(ref float __result)
        {
            bool P012GG1 = SingletonOptions<控制台>.Instance.P012GG1;
            if (P012GG1)
            {
                __result *= SingletonOptions<控制台>.Instance.P012GG1X1;
            }
        }
    }
    //喷泉喷发期
    [HarmonyPatch(typeof(GeyserConfigurator.GeyserInstanceConfiguration))]
    [HarmonyPatch("GetIterationPercent")]//获取迭代百分百
    public static class 喷泉喷发期
    {
        public static void Postfix(ref float __result)
        {
            bool P012GG1 = SingletonOptions<控制台>.Instance.P012GG1;
            if (P012GG1)
            {
                __result = 1f;
            }
        }
    }
    //喷泉活跃期
    [HarmonyPatch(typeof(GeyserConfigurator.GeyserInstanceConfiguration))]
    [HarmonyPatch("GetYearPercent")]//获取年度百分百
    public static class 喷泉活跃期
    {
        private static void Postfix(ref float __result)
        {
            bool P012GG1 = SingletonOptions<控制台>.Instance.P012GG1;
            if (P012GG1)
            {
                __result = 1f;
            }
        }
    }
}
