﻿using System;
using HarmonyLib;
using PeterHan.PLib.Options;
using UnityEngine;

namespace P_基础系统_1._0
{
    [HarmonyPatch(typeof(BuildingLoader))]
    [HarmonyPatch("CreateBuildingComplete")]
    public class 永不过热
    {
        public static void Prefix(ref BuildingDef def)
        {
            bool P010GG1 = SingletonOptions<控制台>.Instance.P010GG1;
            if (P010GG1)
            {
                def.Overheatable = false;//不会过热
            }
        }
    }
}

