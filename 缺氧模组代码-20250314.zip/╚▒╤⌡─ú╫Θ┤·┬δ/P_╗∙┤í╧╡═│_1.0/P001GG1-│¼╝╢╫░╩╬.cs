﻿using System;
using HarmonyLib;
using PeterHan.PLib.Options;
using UnityEngine;
using TUNING;

namespace P_基础系统_1._0
{
    [HarmonyPatch(typeof(BuildingTemplates))]
    [HarmonyPatch("CreateBuildingDef")]
    public class 超级装饰
    {
        private static void Postfix(BuildingDef __result)
        {
            bool P001GG1 = SingletonOptions<控制台>.Instance.P001GG1;
            if (P001GG1)
            {
                __result.BaseDecor = SingletonOptions<控制台>.Instance.P001GG1X1;//装饰度
                __result.BaseDecorRadius = SingletonOptions<控制台>.Instance.P001GG1X2;//装饰半径
            }
        }
    }
}
