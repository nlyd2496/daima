﻿using Newtonsoft.Json;
using PeterHan.PLib.Options;


namespace P_基础系统_1._0
{
    [RestartRequired]
    [JsonObject(MemberSerialization.OptIn)]
    [ConfigFile("P000GG0.json", true, true)]
    // [ModInfo("https://space.bilibili.com/30725645", "mmm.png", true)]

    public class 控制台 : SingletonOptions<控制台>
    {
        [Option("STRINGS.BUILDINGS.PREFABS.P_UI.P001GG1", null, null)][JsonProperty] public bool P001GG1 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.P_UI.P001GG1X1", null, null, Format = "F0")][Limit(1.0, 10.0)][JsonProperty] public float P001GG1X1 { get; set; } = 10f;
        [Option("STRINGS.BUILDINGS.PREFABS.P_UI.P001GG1X2", null, null, Format = "F0")][Limit(1.0, 10.0)][JsonProperty] public float P001GG1X2 { get; set; } = 10f;
        [Option("STRINGS.BUILDINGS.PREFABS.P_UI.P002GG1", null, null)][JsonProperty] public bool P002GG1 { get; set; } = false;
        [Option("STRINGS.BUILDINGS.PREFABS.P_UI.P003GG1", null, null)][JsonProperty] public bool P003GG1 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.P_UI.P003GG1X1", null, null, Format = "F0")][Limit(1.0, 10.0)][JsonProperty] public float P003GG1X1 { get; set; } = 5f;
        [Option("STRINGS.BUILDINGS.PREFABS.P_UI.P004GG1", null, null)][JsonProperty] public bool P004GG1 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.P_UI.P005GG1", null, null)][JsonProperty] public bool P005GG1 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.P_UI.P007GG1", null, null)][JsonProperty] public bool P007GG1 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.P_UI.P008GG1", null, null)][JsonProperty] public bool P008GG1 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.P_UI.P009GG1", null, null)][JsonProperty] public bool P009GG1 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.P_UI.P010GG1", null, null)][JsonProperty] public bool P010GG1 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.P_UI.P011GG1", null, null)][JsonProperty] public bool P011GG1 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.P_UI.P012GG1", null, null)][JsonProperty] public bool P012GG1 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.P_UI.P012GG1X1", null, null, Format = "F0")][Limit(1.0, 10.0)][JsonProperty] public float P012GG1X1 { get; set; } = 5f;
        [Option("STRINGS.BUILDINGS.PREFABS.P_UI.P013GG1", null, null)][JsonProperty] public bool P013GG1 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.P_UI.P014GG1", null, null)][JsonProperty] public bool P014GG1 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.P_UI.P014GG1X1", null, null, Format = "F0")][Limit(1.0, 10.0)][JsonProperty] public float P014GG1X1 { get; set; } = 5f;

    }
}
