﻿using HarmonyLib;
using PeterHan.PLib.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace P_基础系统_1._0
{
    [HarmonyPatch(typeof(SpeedControlScreen))]
    [HarmonyPatch("OnChanged")]
    internal class 游戏加速
    {
        private static bool ChangeTimeScale(SpeedControlScreen __instance, ref bool __result)
        {
            bool P013GG1 = SingletonOptions<控制台>.Instance.P013GG1;
            if (P013GG1)
            {
                if (__instance.IsPaused)
                {
                    Time.timeScale = 0f;
                    return false;
                }
                switch (__instance.GetSpeed())
                {
                    case 0:
                        Time.timeScale = 1f;
                        break;
                    case 1:
                        Time.timeScale = 3f;
                        break;
                    case 2:
                        Time.timeScale = 6f;
                        break;
                    default:
                        Time.timeScale = 1f;
                        break;
                }
            }
            return true; // 返回原方法的返回值
        }
    }

}
