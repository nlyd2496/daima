﻿using System;
using HarmonyLib;
using PeterHan.PLib.Options;
using UnityEngine;

namespace P_基础系统_1._0
{
    [HarmonyPatch(typeof(BuildingLoader))]
    [HarmonyPatch("CreateBuildingComplete")]
    public class 永不淹没
    {
        public static void Prefix(ref BuildingDef def)
        {
            bool P011GG1 = SingletonOptions<控制台>.Instance.P011GG1;
            if (P011GG1)
            {
                def.Floodable = false;//不会被淹没
            }
        }
    }
}

