﻿using HarmonyLib;
using PeterHan.PLib.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P_基础系统_1._0
{
    [HarmonyPatch(typeof(GeyserConfigurator.GeyserInstanceConfiguration))]
    [HarmonyPatch("GetMaxPressure")]
    public static class 喷泉无压力反应
    {
        private static void Postfix(ref float __result)
        {
            bool P005GG1 = SingletonOptions<控制台>.Instance.P005GG1;
            if (P005GG1)
            {
                __result = float.MaxValue;
            }
        }
    }
}
