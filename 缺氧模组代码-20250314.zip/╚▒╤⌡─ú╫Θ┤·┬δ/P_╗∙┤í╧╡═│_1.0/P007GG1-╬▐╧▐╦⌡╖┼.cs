﻿using HarmonyLib;
using PeterHan.PLib.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P_基础系统_1._0
{
    [HarmonyPatch(typeof(CameraController))]
    [HarmonyPatch("OnPrefabInit")]
    internal class 无限缩放
    {
        private static void Prefix(CameraController __instance)
        {
            bool P007GG1 = SingletonOptions<控制台>.Instance.P007GG1;
            if (P007GG1)
            {
                Traverse.Create(__instance).Field("maxOrthographicSize").SetValue(200);
            }
            Traverse.Create(__instance).Field("maxOrthographicSize").SetValue(200);
        }
    }
}
