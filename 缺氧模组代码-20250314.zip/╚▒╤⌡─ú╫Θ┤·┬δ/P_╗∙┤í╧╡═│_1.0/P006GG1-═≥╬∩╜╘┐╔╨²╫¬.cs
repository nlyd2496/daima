﻿using HarmonyLib;
using PeterHan.PLib.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P_基础系统_1._0
{
    /*
    [HarmonyPatch(typeof(BuildingLoader))]
    [HarmonyPatch("CreateBuildingComplete")]
    public class 万物皆可旋转
    {
        public static void Prefix(ref BuildingDef def)
        {
            bool P006GG1X1 = SingletonOptions<控制台>.Instance.P006GG1X1;
            if (P006GG1X1)
            {
                // 水平翻转
                def.PermittedRotations = PermittedRotations.FlipH;
            }
            bool P006GG1X2 = SingletonOptions<控制台>.Instance.P006GG1X2;
            if (P006GG1X2)
            {
                // 垂直翻转
                def.PermittedRotations = PermittedRotations.FlipV;
            }
            bool P006GG1X3 = SingletonOptions<控制台>.Instance.P006GG1X3;
            if (P006GG1X3)
            {
                // 360翻转
                def.PermittedRotations = PermittedRotations.R90;
            }
        }
    }
    */
}
