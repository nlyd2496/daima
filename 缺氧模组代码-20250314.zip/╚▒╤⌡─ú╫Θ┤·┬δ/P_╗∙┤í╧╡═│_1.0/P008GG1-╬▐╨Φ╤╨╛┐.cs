﻿using HarmonyLib;
using PeterHan.PLib.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P_基础系统_1._0
{
    [HarmonyPatch("OnResearchClicked")]
    [HarmonyPatch(typeof(ResearchEntry))]
    internal class 无需研究
    {
        public static void Postfix()
        {
            bool P008GG1 = SingletonOptions<控制台>.Instance.P008GG1;
            if (P008GG1)            {
                for (int i = 0; i < Db.Get().Techs.Count; i++)
                {
                    Tech tech = Db.Get().Techs[i];
                    if (!tech.IsComplete())
                    {
                        foreach (KeyValuePair<string, float> keyValuePair in tech.costsByResearchTypeID)
                        {
                            Research.Instance.AddResearchPoints(keyValuePair.Key, keyValuePair.Value);
                        }
                    }
                }
            }
            
        }
    }

}
