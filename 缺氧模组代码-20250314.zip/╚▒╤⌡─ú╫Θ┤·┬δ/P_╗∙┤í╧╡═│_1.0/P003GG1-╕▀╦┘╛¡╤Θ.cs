﻿using HarmonyLib;
using PeterHan.PLib.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P_基础系统_1._0
{
    [HarmonyPatch(typeof(MinionResume))]
    [HarmonyPatch("AddExperience")]
    public class 高速经验
    {
        private static bool Prefix(MinionStartingStats __instance, ref float amount)
        {
            bool 高速经验 = SingletonOptions<控制台>.Instance.P003GG1;
            if (高速经验)
            {
                amount = SingletonOptions<控制台>.Instance.P003GG1X1 * 0.1f;
            }
            return true;
        }
    }
}
