﻿using KSerialization;
using STRINGS;
using System;
using UnityEngine;
using HarmonyLib;


namespace E_辐射系统_1._0
{
    public class E005GG1K1 : RadiationEmitter, IMultiSliderControl
    {
        public E005GG1K1()
        {
            this.sliderControls = new ISliderControl[]
            {
            new SliderControl1(this),
            new SliderControl2(this),

            };
        }
        string IMultiSliderControl.SidescreenTitleKey // 控制器名称
        {
            get
            {
                return "STRINGS.BUILDINGS.PREFABS.I005GG1.NAME";
            }
        }
        ISliderControl[] IMultiSliderControl.sliderControls
        {
            get
            {
                return this.sliderControls;
            }
        }
        bool IMultiSliderControl.SidescreenEnabled()
        {
            return true;
        }
        protected ISliderControl[] sliderControls;
        public class SliderControl1 : KMonoBehaviour, ISliderControl
        {
            public SliderControl1(RadiationEmitter t)
            {
                this.target = t;
            }
            public string SliderTitleKey // 1号滑条名称
            {
                get
                {
                    return "STRINGS.BUILDINGS.PREFABS.I004GG1.NAME_1";
                }
            }
            public string SliderUnits // 1号滑条单位
            {
                get
                {
                    return UII.格;
                }
            }
            public float GetSliderMax(int index)
            {
                return 3000f;
            }
            public float GetSliderMin(int index)
            {
                return 10f;
            }
            public string GetSliderTooltip(int index)
            {
                return "";
            }
            public string GetSliderTooltipKey(int index)
            {
                return "";
            }
            public float GetSliderValue(int index)
            {
                return (float)this.target.emitRadiusX;
            }
            public void SetSliderValue(float value, int index)
            {
                this.target.emitRadiusX = (short)value;
            }
            public int SliderDecimalPlaces(int index)
            {
                return 0;
            }
            protected RadiationEmitter target;
        }
        public class SliderControl2 : KMonoBehaviour, ISliderControl
        {
            public SliderControl2(RadiationEmitter t)
            {
                this.target = t;
            }
            public string SliderTitleKey // 二号滑条名称
            {
                get
                {
                    return "STRINGS.BUILDINGS.PREFABS.I004GG1.NAME_2";
                }
            }
            public string SliderUnits // 二号滑条单位
            {
                get
                {
                    return UII.辐射;
                }
            }
            public float GetSliderMax(int index)
            {
                return 10f;
            }
            public float GetSliderMin(int index)
            {
                return 1f;
            }
            public string GetSliderTooltip(int index)
            {
                return "";
            }
            public string GetSliderTooltipKey(int index)
            {
                return "";
            }
            public float GetSliderValue(int index)
            {
                return (float)this.target.emitRads;
            }
            public void SetSliderValue(float value, int index)
            {
                this.target.emitRads = (int)value;
                // this.target.FullRefresh();
            }
            public int SliderDecimalPlaces(int index)
            {
                return 0;
            }
            protected RadiationEmitter target;
        }
    }
    /*
       public class E005GG1K1 : KMonoBehaviour, ISingleSliderControl, ISliderControl
       {
           //------------------------------------------------------------------------------------------------
           public float[] sliderMax = { 32, 32 };                                      
           public float[] sliderMin = { 1, 1 }; 
           public int SliderDecimalPlaces(int index) => 0;//小数位
           public string SliderUnits => UII.空;//单位
           public string GetSliderTooltipKey(int index)
           {
               switch (index)
               {
                   case 0:
                       return "UII.长";//第一个滑条的名称
                   case 1:
                       return "UII.能量";//第二个滑条的名称
                   default:
                       return "";
               }
           }
           public string SliderTitleKey => "UII.控制器";//窗口名称
           //--------------------------
           [Serialize] public int AA = 2;//默认值
           [Serialize] public int BB = 2;//默认值
           [MyCmpReq] public RadiationEmitter radiationEmitter;
           private void UpdateRange() 
           { 
               this.radiationEmitter.emitRadiusX = (short)AA; 
               this.radiationEmitter.emitRads = BB;
           }
           //--------------------------
           public float GetSliderMax(int index) => sliderMax[index];
           public float GetSliderMin(int index) => sliderMin[index];
           [MyCmpAdd] public CopyBuildingSettings copyBuildingSettings;
           protected override void OnSpawn() { base.OnSpawn(); UpdateRange(); }
           public string GetSliderTooltip(int index) => Strings.Get(GetSliderTooltipKey(index));
           protected override void OnPrefabInit() { base.OnPrefabInit(); Subscribe((int)GameHashes.CopySettings, OnCopySettings); }
           public float GetSliderValue(int index) { switch (index) { case 0: return AA; case 1: return BB; default: throw new ArgumentException("Invalid index"); } }
           public void SetSliderValue(float percent, int index) { switch (index) { case 0: AA = Convert.ToInt32(percent); break; case 1: BB = Convert.ToInt32(percent); break; } UpdateRange(); }
           private void OnCopySettings(object data) { var component = ((GameObject)data).GetComponent<E005GG1K1>(); if (component == null) return; AA = component.AA; BB = component.BB; UpdateRange(); }
       }

       [HarmonyPatch(typeof(DualSliderSideScreen), "SetTarget")] 
       public static class 双滑条控制器组件
       { public static void Prefix(DualSliderSideScreen __instance, GameObject new_target) { if (new_target.GetComponent<A69GG1_KZQ>() == null) return; var sliderSets = __instance.sliderSets; for (var i = 0; i < sliderSets.Count; i++) { sliderSets[i].index = i; } } }
   */
}
