﻿using Newtonsoft.Json;
using PeterHan.PLib.Options;


namespace E_辐射系统_1._0
{
    
    [RestartRequired]
    [JsonObject(MemberSerialization.OptIn)]
    [ConfigFile("Controler.json", true, false)]
    // [ModInfo("https://space.bilibili.com/30725645", "mmm.png", true)]

    public class 控制台 : SingletonOptions<控制台>
    {
        // 开发者工具
        [Option("启用超级开发者辐射器", "自定义释放辐射强度", "开发者工具")][JsonProperty] public bool E001GG1 { get; set; } = false;
        [Option("超级开发者辐射粒子生成器", "不需要辐射也能发射辐射粒子", "开发者工具")][JsonProperty] public bool E006GG1 { get; set; } = false;
        // 辐射粒子收集器
        [Option("启用强化辐射粒子收集器", "辐射粒子收集器的效率被强化", "辐射粒子收集器")][JsonProperty] public bool E004GG1 { get; set; } = false;
        [Option("辐射粒子收集器收集倍率", "辐射粒子收集倍率", "辐射粒子收集器")][Limit(1, 10)][JsonProperty] public float E004GG1X1 { get; set; } = 1.1f;
        [Option("辐射粒子收集器功率", "W", "辐射粒子收集器", Format = "F0")][Limit(10, 1000000)][JsonProperty] public float E004GG1X2 { get; set; } = 100f;
        [Option("辐射粒子收集器发热", "1000*J/S", "辐射粒子收集器", Format = "F0")][Limit(0, 10)][JsonProperty] public float E004GG1X3 { get; set; } = 0f;
        [Option("辐射粒子收集器发射间隔", "s", "辐射粒子收集器", Format = "F0")][Limit(1, 10)][JsonProperty] public float E004GG1X4 { get; set; } = 1f;
        // 其它
        [Option("辐射掌", "游戏内滑条设置相关数值后，重启游戏生效", "其它")][JsonProperty] public bool E005GG1 { get; set; } = false;
        [Option("核废料处理器", "将核废料转变为铁", "其它")][JsonProperty] public bool E002GG1 { get; set; } = false;
        [Option("核废水处理器", "将核废水转变铁和污染水", "其它")][JsonProperty] public bool E002GG2 { get; set; } = false;
        [Option("铅完全隔绝辐射", "铅的辐射阻隔率为100%", "其它")][JsonProperty] public bool E003GG1 { get; set; } = false;

    }

}
