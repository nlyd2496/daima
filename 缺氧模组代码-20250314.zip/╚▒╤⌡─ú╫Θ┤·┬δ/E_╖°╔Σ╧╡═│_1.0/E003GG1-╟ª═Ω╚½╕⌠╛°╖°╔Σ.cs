﻿using HarmonyLib;
using PeterHan.PLib.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace E_辐射系统_1._0
{
    [HarmonyPatch(typeof(ElementLoader), "CopyEntryToElement")]
    public class 铅完全阻隔辐射
    {
        private static void Prefix(ref ElementLoader.ElementEntry entry, ref Element elem)
        {
            bool E003GG1 = SingletonOptions<控制台>.Instance.E003GG1;
            if (E003GG1)
            {
                if (entry.elementId == "Lead") { entry.radiationAbsorptionFactor = 2f; }
            }
        }
    }
}
