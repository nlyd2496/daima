﻿using HarmonyLib;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace E_辐射系统_1._0
{
    [HarmonyPatch(typeof(GeneratedBuildings))]
    [HarmonyPatch("LoadGeneratedBuildings")]
    public class 建筑栏
    {
        public static void Prefix()
        {
            ModUtil.AddBuildingToPlanScreen("HEP", "E002GG1"); // 核废料处理器
            ModUtil.AddBuildingToPlanScreen("HEP", "E002GG2"); // 核废液处理器
            ModUtil.AddBuildingToPlanScreen("HEP", "E005GG1"); // 辐射掌

        }
    }
}
//  基地 氧气   电力  食物 液管     气管 精炼     医疗    家具      站台      实用      自动化     运输       火箭     辐射
//  Base Oxygen Power Food Plumbing HVAC Refining Medical Furniture Equipment Utilities Automation Conveyance Rocketry HEP
