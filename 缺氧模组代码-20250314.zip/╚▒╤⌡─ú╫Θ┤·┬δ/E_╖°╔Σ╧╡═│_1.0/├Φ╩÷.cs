﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HarmonyLib;
using STRINGS;
using KMod;
// using PeterHan.PLib.Core;
// using PeterHan.PLib.Database;
using Klei.AI;
// using PeterHan.PLib.Options;

namespace E_辐射系统_1._0
{
    public class UII
    {
        public static LocString 格 = "格";//千克
        public static LocString 摄氏度 = "℃";//千克
        public static LocString 开尔文 = "K";//千克
        public static LocString 控制器 = "控制器";//空
        public static LocString 点这里 = "点这里";//空
        public static LocString 温度 = "温度";//空
        public static LocString 辐射 = "Rads";//辐射kDTU/s
        public static LocString 空 = "";//空

    }
    public class STRINGS
    {
        public class BUILDINGS
        {
            public class PREFABS
            {
                public class E002GG1 // 核废料处理器
                {
                    public static LocString NAME = "核废料处理器";
                    public static LocString EFFECT = "裂解核废料，强制衰变，生成铁和污染水。";
                    public static LocString DESC = "废物，是放错地方的资源。";
                }
                public class E002GG2 // 核废水处理器
                {
                    public static LocString NAME = "核废水处理器";
                    public static LocString EFFECT = "裂解核废水，强制衰变，生成铁和污染水。";
                    public static LocString DESC = "废物，是放错地方的资源。";
                }
                public class E005GG1 // 辐射掌
                {
                    public static LocString NAME = UI.FormatAsLink("辐射掌", "E005GG1");//安全门

                    public static LocString EFFECT = "远古生物，开天辟地，无所不能。";
                    public static LocString DESC = "大日如来神棍，又或许，大辐射棍。";
                    public static LocString NAME1 = "长";
                    public static LocString NAME2 = "能量";

                }
            }
        }
    }
}