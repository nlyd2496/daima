﻿using PeterHan.PLib.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TUNING;
using UnityEngine;
using static KAnim;

namespace R_前进的一小步
{
    /*
    public class R_QJDYXB : BaseBatteryConfig
    {
        public override BuildingDef CreateBuildingDef()
        {
            string id = "R_QJDYXB";
            int width = 1;
            int height = 1;
            string anim = "co2filter_kanim";
            int hitpoints = 1000;
            float construction_time = 60f;
            float[] tier = BUILDINGS.CONSTRUCTION_MASS_KG.TIER4;
            string[] raw_METALS = MATERIALS.RAW_METALS;
            float melting_point = 1600f;
            BuildLocationRule build_location_rule = BuildLocationRule.Anywhere;
            EffectorValues tier1 = NOISE_POLLUTION.NOISY.TIER6;
            BuildingDef buildingDef = BuildingTemplates.CreateBuildingDef
                (id, width, height, anim, hitpoints, construction_time, tier, raw_METALS,
                melting_point, build_location_rule, new EffectorValues
                {
                    amount = 3,
                    radius = 3
                }, tier1, 0.2f);
            buildingDef.AudioCategory = "Metal";
            buildingDef.Floodable = false;
            buildingDef.Overheatable = false;
            return buildingDef;
        }
        public override void DoPostConfigureComplete(GameObject go)
        {
            // go.AddOrGet<R_QJDYXB_K1>();
            go.AddOrGet<LoopingSounds>();
        }
        public const string ID = "R_QJDYXB";

    }
    */
}
