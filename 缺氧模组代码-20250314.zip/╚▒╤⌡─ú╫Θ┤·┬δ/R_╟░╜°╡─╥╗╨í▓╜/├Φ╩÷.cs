﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HarmonyLib;
using STRINGS;
using KMod;
using PeterHan.PLib.Core;
using PeterHan.PLib.Database;
using Klei.AI;
using PeterHan.PLib.Options;

namespace R_前进的一小步
{
    public class STRINGS
    {
        public static void DoReplacement()
        {
            LocString.CreateLocStringKeys(typeof(STRINGS), "");
        }
        public class BUILDINGS
        {
            public class PREFABS
            {
                public class R_QJDYXB
                {
                    public static LocString NAME = "1";
                    public static LocString EFFECT = "2";
                    public static LocString DESC = "3";
                }
            }
        }
    }
}
