﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using PeterHan.PLib.Options;

namespace R_前进的一小步
{
    using System;
    using System.Collections.Generic;
    using Newtonsoft.Json;
    using System.IO;

    [RestartRequired] // 重启应用程序以使设置生效的属性
    [JsonObject(MemberSerialization.OptIn)] // 仅序列化标记为 [JsonProperty] 的成员
    [ConfigFile("I000GG0.json", true, false)] // 指定配置文件的路径和行为
    public class 控制台 // 定义类“控制台”
    {
        public enum OptionMode // 定义枚举类型 OptionMode
        {
            全部启用, // 全部启用选项
            全部停止, // 全部停止选项
            自由设定 // 自由设定选项
        }

        private OptionMode mode; // 私有枚举字段 mode，用于存储当前选项模式

        [Option("操作模式", null, null)] // 定义配置选项标签 操作模式
        [JsonProperty] // 指定该属性应被序列化
        public OptionMode Mode // 属性 Mode，用于获取和设置操作模式
        {
            get => mode; // 获取当前模式值
            set
            {
                mode = value; // 设置模式值
                HandleModeChange();
            }
        }

        public 控制台() // 构造函数，初始化 mode 和模组列表
        {
            mode = OptionMode.自由设定; // 将 mode 初始化为 自由设定
            LoadMods(); // 加载模组列表
        }

        private List<Mod> mods = new List<Mod>(); // 存储模组列表

        private void LoadMods() // 加载模组列表
        {
            string json = File.ReadAllText("mods/mods.json"); // 读取 mods.json 文件内容
            mods = JsonConvert.DeserializeObject<List<Mod>>(json); // 反序列化 JSON 内容到模组列表
        }

        private void EnableAllMods() // 启用所有模组
        {
            foreach (var mod in mods)
            {
                mod.EnabledForDlc = new List<string> { "EXPANSION1_ID" }; // 启用模组
                Console.WriteLine($"Enabling {mod.Name}");
            }
            SaveMods(); // 保存修改后的模组列表
        }

        private void DisableAllMods() // 停止所有模组
        {
            foreach (var mod in mods)
            {
                mod.EnabledForDlc = new List<string>(); // 停止模组
                Console.WriteLine($"Disabling {mod.Name}");
            }
            SaveMods(); // 保存修改后的模组列表
        }

        private void SaveMods() // 保存修改后的模组列表
        {
            string json = JsonConvert.SerializeObject(mods, Formatting.Indented); // 序列化模组列表
            File.WriteAllText("mods/mods.json", json); // 将序列化后的内容写回 mods.json 文件
        }

        private void HandleModeChange() // 根据模式值处理模组启停操作
        {
            switch (mode)
            {
                case OptionMode.全部启用:
                    EnableAllMods();
                    break;

                case OptionMode.全部停止:
                    DisableAllMods();
                    break;

                case OptionMode.自由设定:
                    // 保持当前状态
                    Console.WriteLine("自由设定模式下，不控制模组启停。");
                    break;
            }
        }
    }

    public class Mod // 定义模组类
    {
        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("enabledForDlc")]
        public List<string> EnabledForDlc { get; set; }
    }

    class Program
    {
        static void Main()
        {
            控制台 console = new 控制台();
            console.Mode = 控制台.OptionMode.全部启用; // 启用所有模组
            console.Mode = 控制台.OptionMode.全部停止; // 停止所有模组
            console.Mode = 控制台.OptionMode.自由设定; // 自由设定模式，不控制模组启停
        }
    }





}






/*
public class R_QJDYXB_K1 : KMonoBehaviour, ISim200ms
{
    // 动画文件数组，包含四个动画文件的名称
    private static readonly string[] AnimFiles =
    {
    "R_QJDYXB_L5_kanim",
    "R_QJDYXB_L6_kanim",
    "R_QJDYXB_L7_kanim",
    "R_QJDYXB_L8_kanim",
    "R_QJDYXB_L500_kanim",
    "R_QJDYXB_L1000_kanim",
    "R_QJDYXB_L2000_kanim",
    "R_QJDYXB_L5000_kanim",
    "R_QJDYXB_L10000_kanim",
    "R_QJDYXB_L20000_kanim"
};

    private KAnimFile currentAnimFile; // 当前动画文件
    private KBatchedAnimController animController; // 动画控制器
    private int lastCyclePlayed; // 上次播放动画的周期数

    // 在对象生成时调用，初始化动画控制器
    protected override void OnSpawn()
    {
        base.OnSpawn();
        animController = GetComponent<KBatchedAnimController>(); // 获取当前对象的动画控制器组件
        lastCyclePlayed = -1; // 初始值为-1，表示还未播放动画
    }

    // 每200毫秒调用一次，更新动画状态
    public void Sim200ms(float dt)
    {
        // 获取已运行的周期数
        int currentCycle = GameClock.Instance.GetCycle();

        // 如果当前周期数与上次播放动画的周期数不同，则播放动画
        if (currentCycle != lastCyclePlayed)
        {
            // 根据周期数播放相应的动画
            if (currentCycle == 4) // 周期5
            {
                PlayAnimation(0); // 播放第1个动画
            }
            else if (currentCycle == 5) // 周期6
            {
                PlayAnimation(1); // 播放第2个动画
            }
            else if (currentCycle == 6) // 周期7
            {
                PlayAnimation(2); // 播放第3个动画
            }
            else if (currentCycle == 7) // 周期8
            {
                PlayAnimation(3); // 播放第4个动画
            }
            else if (currentCycle == 499) // 周期500
            {
                PlayAnimation(1); // 播放第2个动画
            }
            else if (currentCycle == 999) // 周期1000
            {
                PlayAnimation(2); // 播放第3个动画
            }
            else if (currentCycle == 1999) // 周期2000
            {
                PlayAnimation(3); // 播放第4个动画
            }
            else if (currentCycle == 4999) // 周期5000
            {
                PlayAnimation(1); // 播放第2个动画
            }
            else if (currentCycle == 9999) // 周期10000
            {
                PlayAnimation(2); // 播放第3个动画
            }
            else if (currentCycle >= 19999) // 周期20000
            {
                PlayAnimation(3); // 播放第4个动画
            }

            // 记录本周期为已播放动画的周期
            lastCyclePlayed = currentCycle;
        }
    }

    // 播放指定索引的动画
    private void PlayAnimation(int animIndex)
    {
        // 检查索引是否在有效范围内
        if (animIndex >= 0 && animIndex < AnimFiles.Length)
        {
            currentAnimFile = Assets.GetAnim(AnimFiles[animIndex]); // 获取指定索引的动画文件
            animController.SwapAnims(new KAnimFile[] { currentAnimFile }); // 更换动画
        }
    }
}
*/







/*
public class R_QJDYXB_K1 : KMonoBehaviour, ISim200ms
{
    // 动画文件数组，包含四个动画文件的名称
    private static readonly string[] AnimFiles =
    {
    "R_QJDYXB_L5_kanim",
    "R_QJDYXB_L6_kanim",
    "R_QJDYXB_L7_kanim",
    "R_QJDYXB_L8_kanim",
    "R_QJDYXB_L500_kanim",
    "R_QJDYXB_L1000_kanim",
    "R_QJDYXB_L2000_kanim",
    "R_QJDYXB_L5000_kanim",
    "R_QJDYXB_L10000_kanim",
    "R_QJDYXB_L20000_kanim"
};

    private KAnimFile currentAnimFile; // 当前动画文件
    private KBatchedAnimController animController; // 动画控制器

    // 在对象生成时调用，初始化动画控制器
    protected override void OnSpawn()
    {
        base.OnSpawn();
        animController = GetComponent<KBatchedAnimController>(); // 获取当前对象的动画控制器组件
    }

    // 每200毫秒调用一次，更新动画状态
    public void Sim200ms(float dt)
    {
        // 获取已运行的周期数
        int currentCycle = GameClock.Instance.GetCycle();

        // 根据周期数播放相应的动画
        if (currentCycle == 4) // 周期5
        {
            PlayAnimation(0); // 播放第1个动画
        }
        else if (currentCycle == 5) // 周期6
        {
            PlayAnimation(1); // 播放第2个动画
        }
        else if (currentCycle == 6) // 周期7
        {
            PlayAnimation(2); // 播放第3个动画
        }
        else if (currentCycle == 7) // 周期8
        {
            PlayAnimation(3); // 播放第4个动画
        }
        else if (currentCycle == 499) // 周期500
        {
            PlayAnimation(1); // 播放第2个动画
        }
        else if (currentCycle == 999) // 周期1000
        {
            PlayAnimation(2); // 播放第3个动画
        }
        else if (currentCycle == 1999) // 周期2000
        {
            PlayAnimation(3); // 播放第4个动画
        }
        else if (currentCycle == 4999) // 周期5000
        {
            PlayAnimation(1); // 播放第2个动画
        }
        else if (currentCycle == 9999) // 周期10000
        {
            PlayAnimation(2); // 播放第3个动画
        }
        else if (currentCycle >= 19999) // 周期20000
        {
            PlayAnimation(3); // 播放第4个动画
        }
    }

    // 播放指定索引的动画
    private void PlayAnimation(int animIndex)
    {
        // 检查索引是否在有效范围内
        if (animIndex >= 0 && animIndex < AnimFiles.Length)
        {
            currentAnimFile = Assets.GetAnim(AnimFiles[animIndex]); // 获取指定索引的动画文件
            animController.SwapAnims(new KAnimFile[] { currentAnimFile }); // 更换动画
        }
    }
}







*/

