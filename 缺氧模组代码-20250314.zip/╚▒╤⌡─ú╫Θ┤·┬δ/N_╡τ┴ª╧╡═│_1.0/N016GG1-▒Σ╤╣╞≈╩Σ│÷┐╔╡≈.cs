﻿using HarmonyLib;
using PeterHan.PLib.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace N_电力系统_1._0
{
    // 变压器输出可调
    [HarmonyPatch(typeof(PowerTransformerConfig))]
    [HarmonyPatch("CreateBuildingDef")]
    internal class 变压器输入修改
    {
        public static void Postfix(BuildingDef __result)
        {
            bool N016GG1 = SingletonOptions<控制台>.Instance.N016GG1;
            if (N016GG1)
            {
                __result.GeneratorWattageRating = float.PositiveInfinity;//功率
                __result.GeneratorBaseCapacity = float.PositiveInfinity;//容量
            }
        }
    }
    [HarmonyPatch(typeof(PowerTransformerConfig))]
    [HarmonyPatch("ConfigureBuildingTemplate")]
    public class 变压器输出可调
    {
        public static void Postfix(GameObject go)
        {
            bool N016GG1 = SingletonOptions<控制台>.Instance.N016GG1;
            if (N016GG1)
            {
                go.AddOrGet<N016GG1K1>();
            }
        }
    }
    // 小型变压器输出可调
    [HarmonyPatch(typeof(PowerTransformerSmallConfig))]
    [HarmonyPatch("CreateBuildingDef")]
    internal class 小型变压器输入修改
    {
        public static void Postfix(BuildingDef __result)
        {
            bool N016GG1 = SingletonOptions<控制台>.Instance.N016GG1;
            if (N016GG1)
            {
                __result.GeneratorWattageRating = float.PositiveInfinity;//功率
                __result.GeneratorBaseCapacity = float.PositiveInfinity;//容量
            }
        }
    }
    [HarmonyPatch(typeof(PowerTransformerSmallConfig))]
    [HarmonyPatch("ConfigureBuildingTemplate")]
    public class 小型变压器输出可调
    {
        public static void Postfix(GameObject go)
        {
            bool N016GG1 = SingletonOptions<控制台>.Instance.N016GG1;
            if (N016GG1)
            {
                go.AddOrGet<N016GG1K2>();
            }
        }
    }
}
