﻿using System;
using Database;
using HarmonyLib;
using PeterHan.PLib.Options;
using UnityEngine;

namespace N_电力系统_1._0
{
    // 电线替换
    [HarmonyPatch(typeof(WireConfig))]
    [HarmonyPatch("CreateBuildingDef")]
    public static class 梦世界的电线
    {
        private static BuildingDef Postfix(BuildingDef def)
        {
            bool N010GG1 = SingletonOptions<控制台>.Instance.N010GG1;
            if (N010GG1)
            {
                def.AnimFiles = new KAnimFile[]
                {
                    Assets.GetAnim("N010GG1_kanim")
                };
            }
            return def;
        }
    }
    // 导线蓝图
    [HarmonyPatch(typeof(BuildingFacades), MethodType.Constructor, new Type[] { typeof(ResourceSet) })]
    public static class N010GG2L2
    {
        public static void Postfix(BuildingFacades __instance)
        {
            bool N010GG1 = SingletonOptions<控制台>.Instance.N010GG1;
            if (N010GG1)
            {
                __instance.Add("N010GG2L2",
                STRINGS.BUILDINGS.PREFABS.N010GG2L2.NAME, STRINGS.BUILDINGS.PREFABS.N010GG2L2.EFFECT, PermitRarity.Universal,
                "WIREREFINED", "N010GG2L2_kanim");

            }
        }
    }
}
