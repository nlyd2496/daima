﻿using HarmonyLib;
using PeterHan.PLib.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace N_电力系统_1._0
{
   
    [HarmonyPatch(typeof(Electrobank))]
    [HarmonyPatch("OnPrefabInit")]
    public static class 增强移动电源
    {
        private static void Prefix(Electrobank __instance)
        {
            bool N019GG1 = SingletonOptions<控制台>.Instance.N019GG1;
            if (N019GG1)
            {
                FieldInfo capacityField = typeof(Electrobank).GetField("capacity", BindingFlags.NonPublic | BindingFlags.Static);
                if (capacityField != null)
                {
                    capacityField.SetValue(null, SingletonOptions<控制台>.Instance.N019GG1X1);
                }
            }
        }
    }
    /*
   [HarmonyPatch(typeof(Electrobank))]
   [HarmonyPatch("CreatePrefab")]
   public static class 增强放电器
   {
       private static IEnumerable<CodeInstruction> Transpiler(IEnumerable<CodeInstruction> instructions)
       {
           List<CodeInstruction> list = new List<CodeInstruction>(instructions);
           for (int i = 0; i < list.Count; i++)
           {
               bool flag = list[i].opcode == OpCodes.Ldc_R4
                   && (float)list[i].operand == 1200000f
                   && list[i + 1].opcode == OpCodes.Ldarg_1;
               if (flag)
               {
                   list[i].operand = 666f;
               }
           }
           return list.AsEnumerable<CodeInstruction>();
       }
   }
   */
}
