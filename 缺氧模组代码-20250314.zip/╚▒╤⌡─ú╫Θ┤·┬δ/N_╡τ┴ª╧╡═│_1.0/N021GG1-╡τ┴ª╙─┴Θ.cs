﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TUNING;
using UnityEngine;

namespace N_电力系统_1._0
{
    public class N021GG1 : IBuildingConfig
    {

        public override BuildingDef CreateBuildingDef()
        {
            string id = "N021GG1";
            int width = 1;
            int height = 2;
            string anim = "N021GG1_kanim";
            int hitpoints = 30;
            float construction_time = 30f;
            float[] tier = BUILDINGS.CONSTRUCTION_MASS_KG.TIER5;
            string[] any_BUILDABLE = MATERIALS.ANY_BUILDABLE;
            float melting_point = 9999f;
            BuildLocationRule build_location_rule = BuildLocationRule.OnFloor;
            EffectorValues none = NOISE_POLLUTION.NONE;
            BuildingDef buildingDef = BuildingTemplates.CreateBuildingDef(id, width, height, anim, hitpoints, construction_time, tier, any_BUILDABLE, melting_point, build_location_rule, BUILDINGS.DECOR.BONUS.TIER2, none, 0.2f);
            buildingDef.Floodable = false;
            buildingDef.Overheatable = false;
            buildingDef.RequiresPowerInput = true;
            buildingDef.EnergyConsumptionWhenActive = 1000f;
            buildingDef.SelfHeatKilowattsWhenActive = 0.1f;
            buildingDef.LogicInputPorts = LogicOperationalController.CreateSingleInputPortList(new CellOffset(0, 0));

            //--------------------------
            if (控制台.Instance.N021GG1) { buildingDef.Deprecated = false; } else { buildingDef.Deprecated = true; }
            //--------------------------
            return buildingDef;
        }





        public override void ConfigureBuildingTemplate(GameObject go, Tag prefab_tag)
        {
            go.AddOrGet<LoopingSounds>();
            Light2D light2D = go.AddOrGet<Light2D>();
            light2D.overlayColour = LIGHT2D.CEILINGLIGHT_OVERLAYCOLOR;
            light2D.Color = LIGHT2D.CEILINGLIGHT_COLOR;
            light2D.Range = 1f;
            light2D.Angle = 1f;
            light2D.Direction = LIGHT2D.CEILINGLIGHT_DIRECTION;
            light2D.Offset = new Vector2(0f, 1.5f);
            light2D.shape = global::LightShape.Circle;
            light2D.drawOverlay = true;
            light2D.Lux = 1;
            go.AddOrGetDef<LightController.Def>();
            //----------------------------
            go.AddOrGet<N021GG1K1>();
            
            //----------------------------
        }

        public override void DoPostConfigureComplete(GameObject go)
        {
            // go.AddOrGetDef<OperationalController.Def>();
            go.AddOrGetDef<PoweredActiveController.Def>();
            go.AddOrGet<LogicOperationalController>();

        }


    }
}
