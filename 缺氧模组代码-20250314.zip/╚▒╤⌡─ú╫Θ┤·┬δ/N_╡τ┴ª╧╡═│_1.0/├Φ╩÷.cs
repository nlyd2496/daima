﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HarmonyLib;
using STRINGS;
using KMod;
using PeterHan.PLib.Core;
using PeterHan.PLib.Database;
using Klei.AI;
using PeterHan.PLib.Options;

namespace N_电力系统_1._0
{
    public class STRINGS
    {
        public static void DoReplacement()
        {
            LocString.CreateLocStringKeys(typeof(STRINGS), "");
        }
        

        public class BUILDINGS
        {
            public class PREFABS
            {
                public class N006GG1//跨两格导线桥
                {
                    public static LocString NAME = "跨两格导线桥";//建筑名
                    public static LocString EFFECT = "这个导线桥由导线制造而成，在它的下方能够穿越两条输电线而不会对它造成影响。但请注意，越复杂的电路越显现出它的作用，但也越发的增加了电路设计和维护的难度，谨记!";//建筑效果
                    public static LocString DESC = "横跨两格，就问你怕不怕！";
                }
                public class N007GG1//跨三格导线桥
                {
                    public static LocString NAME = "跨三格导线桥";//建筑名
                    public static LocString EFFECT = "这个导线桥由导线制造而成，在它的下方能够穿越三条输电线而不会对它造成影响。但请注意，越复杂的电路越显现出它的作用，但也越发的增加了电路设计和维护的难度，谨记!";//建筑效果
                    public static LocString DESC = "横跨三格，就问你怕不怕！";
                }
                public class N008GG1//跨两格电线桥
                {
                    public static LocString NAME = "跨两格电线桥";//建筑名
                    public static LocString EFFECT = "这个导线桥由电线制造而成，在它的下方能够穿越两条输电线而不会对它造成影响。但请注意，越复杂的电路越显现出它的作用，但也越发的增加了电路设计和维护的难度，谨记!";//建筑效果
                    public static LocString DESC = "横跨两格，就问你怕不怕！";
                }
                public class N009GG1//跨三格电线桥
                {
                    public static LocString NAME = "跨三格电线桥";//建筑名
                    public static LocString EFFECT = "这个导线桥由导线制造而成，在它的下方能够穿越三条输电线而不会对它造成影响。但请注意，越复杂的电路越显现出它的作用，但也越发的增加了电路设计和维护的难度，谨记!";//建筑效果
                    public static LocString DESC = "横跨三格，就问你怕不怕！";
                }
                public class N010GG2L2 // 导线蓝图
                {
                    public static LocString NAME = "香草导线"; // 建筑名
                    public static LocString EFFECT = "看起来像是藤蔓的导线，为家园添加一点绿色气息。";
                }
                public class N011GG1//民用电池组
                {
                    public static LocString NAME = "民用电池组";//建筑名
                    public static LocString EFFECT = "连接输电线，将电网中多余的电量以化学能的方式储存起来，并在你需要的时候将其释放在电网中。 \n\n 可相互堆叠的电池，不仅节省了大量的空间，也能更加便利的管理电源系统。如果喜欢，十个电池重叠建造，也是可以的。";//建筑效果
                    public static LocString DESC = "一个电池不够？那就再来一个！";
                }
                public class N012GG1//南孚电池
                {
                    public static LocString NAME = "北孚电池";//建筑名
                    public static LocString EFFECT = "连接输电线，将电网中多余的电量以化学能的方式储存起来，并在你需要的时候将其释放在电网中。 \n\n 这不是南孚电池，这是北孚电池。我们不生产电能，我们只是电能的搬运工。";//建筑效果
                    public static LocString DESC = "北孚电池，一节更比一节强。";
                }
                public class N014GG1//细电线
                {
                    public static LocString NAME = "细电线";//建筑名
                    public static LocString EFFECT = "厌倦了拳头粗的电线，厌倦了明明同样使用金属制造却极易过载的普通电线。美观、实用，是它的代名词。在你需要的地方使用它，在你不需要的地方使用它，不要后悔，你会爱上它的细。";//建筑效果
                    public static LocString DESC = "粗，有粗的好处。细，有细的精妙。";
                }
                public class N015GG1//一格电池
                {
                    public static LocString NAME = "一格电池";//建筑名
                    public static LocString EFFECT = "连接输电线，将电网中多余的电量以化学能的方式储存起来，并在你需要的时候将其释放在电网中。 \n\n 小小的身躯，大大的能量。在最新的制造工艺下，即便只有方寸大小，依然能够容纳不可估量的容量。";//建筑效果
                    public static LocString DESC = "不要觉得我小，其实我很大。";
                }
                public class N015GG1L2//一格电池
                {
                    public static LocString NAME = "真一格电池";//建筑名
                    public static LocString EFFECT = "未来的数字化狂潮从此刻，席卷而来。";//建筑效果
                }
                public class N017GG1 // 核聚变发电机
                {
                    public static LocString NAME = "核聚变发电机";
                    public static LocString EFFECT = "添加浓缩铀，释放大量能量和热量。注意，它很安全，并没有爆炸的风险。";
                    public static LocString DESC = "e = mc^2。";
                }
                public class N021GG1 // 电力幽灵
                {
                    public static LocString NAME = "电力幽灵";
                    public static LocString EFFECT = "消耗电路中大量的空余电力，注意，它并不会产生什么有用的产物，或许如此。";
                    public static LocString DESC = "能量不会凭空产生，但会凭空消失。";
                }
                public class N_UI
                {
                    public static LocString N000GG0_KZT_0_UI = "模组功能启停";
                    public static LocString N001GG1_UI = "启用开发者电池";
                    public static LocString N001GG1X1_UI = "开发者电池输出无穷大";
                    public static LocString N011GG1_UI = "启用民用电池组（DLC限定）";
                    public static LocString N011GG1X1_UI = "民用电池组容量";
                    public static LocString N012GG1_UI = "启用南孚电池";
                    public static LocString N012GG1X1_UI = "南孚电池容量";
                    public static LocString N015GG1_UI = "启用一格电池";
                    public static LocString N015GG1X1_UI = "一格电池容量";
                    public static LocString N005GG1_UI = "启用基础电池容量无穷大";
                    public static LocString N002GG1_UI = "启用超级氢气发电机";
                    public static LocString N002GG1X1_UI = "超级氢气发电机功率";
                    public static LocString N002GG1X2_UI = "超级氢气发电机氢气消耗";
                    public static LocString N003GG1_UI = "启用超级蒸汽机";
                    public static LocString N003GG1X1_UI = "蒸汽机热量转移效率";
                    public static LocString N003GG1X2_UI = "蒸汽机吸收蒸汽最低温度";
                    public static LocString N003GG1X3_UI = "蒸汽机输出液体温度";
                    public static LocString N003GG1X4_UI = "蒸汽机功率上限";
                    public static LocString N010GG1_UI = "梦世界的电线";
                    public static LocString N014GG1_UI = "细电线";
                    public static LocString N006GG1_UI = "启用跨两格导线桥";
                    public static LocString N007GG1_UI = "启用跨三格导线桥";
                    public static LocString N008GG1_UI = "启用跨两格电线桥";
                    public static LocString N009GG1_UI = "启用跨三格电线桥";
                    public static LocString N013GG1X1_UI = "电线及电线桥";
                    public static LocString N013GG1X2_UI = "导线及导线桥";
                    public static LocString N013GG1X3_UI = "高负荷电线及接线板";
                    public static LocString N013GG1X4_UI = "高负荷导线及接线板";
                    public static LocString N004GG1_UI = "启用高负荷线可穿墙";
                    public static LocString N016GG1_UI = "启用变压器输出可调";
                    public static LocString N017GG1_UI = "启用核聚变发电机";
                    public static LocString N018GG1_UI = "启用移动电源充电机增强";
                    public static LocString N018GG1X1_UI = "移动电源充电机充电倍率";
                    public static LocString N019GG1_UI = "启用增强移动电源";
                    public static LocString N019GG1X1_UI = "移动电源容量";
                    public static LocString N020GG1_UI = "启用增强放电器";
                    public static LocString N020GG1X1_UI = "放电器输出功率";
                    public static LocString N021GG1_UI = "启用电力幽灵";






                }
            }
            

        }
    }
}
