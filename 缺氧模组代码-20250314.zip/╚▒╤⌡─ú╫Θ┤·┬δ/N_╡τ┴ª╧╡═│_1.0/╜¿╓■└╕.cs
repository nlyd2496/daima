﻿using HarmonyLib;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace N_电力系统_1._0
{
    [HarmonyPatch(typeof(GeneratedBuildings))]
    [HarmonyPatch("LoadGeneratedBuildings")]
    public class 建筑栏
    {
        public static void Prefix()
        {
            ModUtil.AddBuildingToPlanScreen("Power", "N006GG1");
            ModUtil.AddBuildingToPlanScreen("Power", "N007GG1");
            ModUtil.AddBuildingToPlanScreen("Power", "N008GG1");
            ModUtil.AddBuildingToPlanScreen("Power", "N009GG1");
            ModUtil.AddBuildingToPlanScreen("Power", "N011GG1");
            ModUtil.AddBuildingToPlanScreen("Power", "N012GG1");
            ModUtil.AddBuildingToPlanScreen("Power", "N014GG1");
            ModUtil.AddBuildingToPlanScreen("Power", "N015GG1");
            ModUtil.AddBuildingToPlanScreen("Power", "N017GG1");
            ModUtil.AddBuildingToPlanScreen("Power", "N021GG1");


        }
    }
}
//  基地 氧气   电力  食物 液管     气管 精炼     医疗    家具      站台      实用      自动化     运输       火箭     辐射
//  Base Oxygen Power Food Plumbing HVAC Refining Medical Furniture Equipment Utilities Automation Conveyance Rocketry HEP
