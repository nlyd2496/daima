﻿using Newtonsoft.Json;
using PeterHan.PLib.Options;


namespace F_站台系统_1._0
{
    [RestartRequired]
    [JsonObject(MemberSerialization.OptIn)]
    [ConfigFile("F000GG0.json", true, false)]
    // [ModInfo("https://space.bilibili.com/30725645", "mmm.png", true)]

    public class 控制台 : SingletonOptions<控制台>
    {
        [Option("STRINGS.BUILDINGS.PREFABS.T_UI.F001GG1_T_UI", null, "氧气服系列")][JsonProperty] public bool F001GG1 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.T_UI.F002GG1_T_UI", null, "氧气服系列")][JsonProperty] public bool F001GG2 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.T_UI.F003GG1_T_UI", null, "氧气服系列")][JsonProperty] public bool F001GG3 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.T_UI.F004GG1_T_UI", null, "氧气服系列")][JsonProperty] public bool F001GG4 { get; set; } = true;
    }
}
