﻿using KSerialization;
using STRINGS;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace F_站台系统_1._0
{
    public class F004GG1K1 : KMonoBehaviour, ISingleSliderControl, ISliderControl
    {
        public int SliderDecimalPlaces(int index) => 0;//小数点
        public float GetSliderMin(int index) => 100;//最小值
        public float GetSliderMax(int index) => 1000;//最大值
        public string SliderTitleKey => "";
        public string GetSliderTooltip(int index) => "";
        public string SliderUnits => UI.UNITSUFFIXES.MASS.KILOGRAM;
        //--------------------------                                                        
        [Serialize] public float AA = 100f;
        [MyCmpReq] public SuitTank suitTank;
        internal void Update() { this.suitTank.capacity = this.AA; }//将AA的值赋予源功能组件
        //--------------------------
        public float GetSliderValue(int index) => this.AA;
        public string GetSliderTooltipKey(int index) => "";//空
        [MyCmpAdd] public CopyBuildingSettings copyBuildingSettings;
        protected override void OnSpawn() { base.OnSpawn(); this.Update(); }
        public void SetSliderValue(float value, int index) { this.AA = value; this.Update(); }
        protected override void OnPrefabInit() { base.OnPrefabInit(); base.Subscribe(-905833192, new Action<object>(this.OnCopySettings)); }
        internal void OnCopySettings(object data) { var component = ((GameObject)data).GetComponent<F004GG1K1>(); if (component == null) return; AA = component.AA; Update(); }
        //--------------------------
    }
}
