﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HarmonyLib;
using STRINGS;
using KMod;
using PeterHan.PLib.Core;
using PeterHan.PLib.Database;
using Klei.AI;
using PeterHan.PLib.Options;

namespace F_站台系统_1._0
{
    public class STRINGS
    {
        public static void DoReplacement()
        {
            LocString.CreateLocStringKeys(typeof(STRINGS), "");
        }
        public class 控制器UI
        {
            public static LocString F001GG1_T_UI = "启用智能喷气服";
            public static LocString F002GG1_T_UI = "启用智能气压服";
            public static LocString F003GG1_T_UI = "启用智能铅服(DLC限定)";
            public static LocString F004GG1_T_UI = "启用智能氧气面罩";

        }
    }
}
