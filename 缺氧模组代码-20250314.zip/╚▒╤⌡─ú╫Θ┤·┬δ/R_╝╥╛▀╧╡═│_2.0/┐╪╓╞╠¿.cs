﻿using Newtonsoft.Json;
using PeterHan.PLib.Options;


namespace R_家具系统_2._0
{
    [RestartRequired]
    [JsonObject(MemberSerialization.OptIn)]
    [ConfigFile("R000GG0.json", true, true)]
    // [ModInfo("https://space.bilibili.com/30725645", "mmm.png", true)]

    public class 控制台 : SingletonOptions<控制台>
    {
        [Option("STRINGS.BUILDINGS.PREFABS.R_UI.R003GG1_UI", null, null)][JsonProperty] public bool R003GG1 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.R_UI.R004GG1_UI", null, null)][JsonProperty] public bool R004GG1 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.R_UI.R004GG2_UI", null, null)][JsonProperty] public bool R004GG2 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.R_UI.R004GG3_UI", null, null)][JsonProperty] public bool R004GG3 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.R_UI.R005GG1_UI", null, null)][JsonProperty] public bool R005GG1 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.R_UI.R006GG1_UI", null, null)][JsonProperty] public bool R006GG1 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.R_UI.R007GG1_UI", null, null)][JsonProperty] public bool R007GG1 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.R_UI.R007GG1X1_UI", null, null, Format = "F0")][Limit(1, 10)][JsonProperty] public float R007GG1X1 { get; set; } = 2f;
        [Option("STRINGS.BUILDINGS.PREFABS.R_UI.R007GG1X2_UI", null, null, Format = "F0")][Limit(1, 10)][JsonProperty] public float R007GG1X2 { get; set; } = 2f;
        [Option("STRINGS.BUILDINGS.PREFABS.R_UI.R009GG1_UI", null, null)][JsonProperty] public bool R009GG1 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.R_UI.R010GG1_UI", null, null)][JsonProperty] public bool R010GG1 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.R_UI.R011GG1_UI", null, null)][JsonProperty] public bool R011GG1 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.R_UI.R012GG1_UI", null, null)][JsonProperty] public bool R012GG1 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.R_UI.R013GG1_UI", null, null)][JsonProperty] public bool R013GG1 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.R_UI.R015GG1_UI", null, null)][JsonProperty] public bool R015GG1 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.R_UI.R016GG1_UI", null, null)][JsonProperty] public bool R016GG1 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.R_UI.R018GG1_UI", null, null)][JsonProperty] public bool R018GG1 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.R_UI.R019GG1_UI", null, null)][JsonProperty] public bool R019GG1 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.R_UI.R020GG1_UI", null, null)][JsonProperty] public bool R020GG1 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.R_UI.R021GG1_UI", null, null)][JsonProperty] public bool R021GG1 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.R_UI.R022GG1_UI", null, null)][JsonProperty] public bool R022GG1 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.R_UI.R023GG1_UI", null, null)][JsonProperty] public bool R023GG1 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.R_UI.R026GG1_UI", null, null)][JsonProperty] public bool R026GG1 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.R_UI.R026GG1X1_UI", null, null, Format = "F0")][Limit(1, 1000)][JsonProperty] public float R026GG1X1 { get; set; } = 300f;
        [Option("STRINGS.BUILDINGS.PREFABS.R_UI.R029GG1_UI", null, null)][JsonProperty] public bool R029GG1 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.R_UI.R030GG1_UI", null, null)][JsonProperty] public bool R030GG1 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.R_UI.R031GG1_UI", null, null)][JsonProperty] public bool R031GG1 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.R_UI.R031GG1X1_UI", null, null, Format = "F0")][Limit(1, 10)][JsonProperty] public float R031GG1X1 { get; set; } = 2f;
        [Option("STRINGS.BUILDINGS.PREFABS.R_UI.R032GG1_UI", null, null)][JsonProperty] public bool R032GG1 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.R_UI.R034GG1_UI", null, null)][JsonProperty] public bool R034GG1 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.R_UI.R035GG1_UI", null, null)][JsonProperty] public bool R035GG1 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.R_UI.R036GG1_UI", null, null)][JsonProperty] public bool R036GG1 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.R_UI.R038GG1_UI", null, null)][JsonProperty] public bool R038GG1 { get; set; } = true;
        
    }
}
