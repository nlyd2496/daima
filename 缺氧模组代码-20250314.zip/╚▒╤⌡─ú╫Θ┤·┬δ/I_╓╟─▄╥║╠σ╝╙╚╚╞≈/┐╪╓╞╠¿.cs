﻿using Newtonsoft.Json;
using PeterHan.PLib.Options;


namespace I_智能液体加热器
{
    /*
    [RestartRequired]
    [JsonObject(MemberSerialization.OptIn)]
    [ConfigFile("I000GG0.json", true, false)]
    // [ModInfo("https://space.bilibili.com/30725645", "mmm.png", true)]

    public class 控制台 : SingletonOptions<控制台>
    {
        [Option("STRINGS.BUILDINGS.PREFABS.I_UI.I002GG1_UI", null, null)][JsonProperty] public bool I002GG1 { get; set; } = false;
        [Option("STRINGS.BUILDINGS.PREFABS.I_UI.I003GG1_UI", null, null)][JsonProperty] public bool I003GG1 { get; set; } = false;
        [Option("STRINGS.BUILDINGS.PREFABS.I_UI.I004GG1_UI", null, null)][JsonProperty] public bool I004GG1 { get; set; } = false;
        [Option("STRINGS.BUILDINGS.PREFABS.I_UI.I005GG1_UI", null, null)][JsonProperty] public bool I005GG1 { get; set; } = false;
        [Option("STRINGS.BUILDINGS.PREFABS.I_UI.I005GG1X1_UI", null, null)][JsonProperty] public bool I005GG1X1 { get; set; } = false;

    }
    */
}
