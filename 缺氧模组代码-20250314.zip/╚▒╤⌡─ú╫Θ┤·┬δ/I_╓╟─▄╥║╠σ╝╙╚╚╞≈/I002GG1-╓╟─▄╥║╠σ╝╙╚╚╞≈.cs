﻿using HarmonyLib;
using PeterHan.PLib.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace I_智能液体加热器
{
    [HarmonyPatch(typeof(LiquidHeaterConfig))]
    [HarmonyPatch("ConfigureBuildingTemplate")]
    public static class 液体加热器添加温度控制滑条
    {
        public static void Postfix(GameObject go)
        {

                go.AddOrGet<I002GGG1K2>();
                go.AddOrGet<MinimumOperatingTemperature>().minimumTemperature = 13.15f;//最低工作温度30K

            
        }
    }
    [HarmonyPatch(typeof(LiquidHeaterConfig))]
    [HarmonyPatch("CreateBuildingDef")]
    public class 液体加热器过热温度
    {
        public static void Postfix(ref BuildingDef __result)
        {

                __result.OverheatTemperature = 1000f;
            
        }
    }
}
