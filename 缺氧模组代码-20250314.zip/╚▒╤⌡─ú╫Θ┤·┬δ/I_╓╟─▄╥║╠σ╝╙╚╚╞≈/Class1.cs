﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace I_智能液体加热器
{
    public class Class1
    {
    }
}
