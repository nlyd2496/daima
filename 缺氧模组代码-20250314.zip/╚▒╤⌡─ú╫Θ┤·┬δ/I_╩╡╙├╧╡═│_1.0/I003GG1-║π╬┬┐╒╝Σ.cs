﻿// using PeterHan.PLib.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TUNING;
using UnityEngine;

namespace I_实用系统_1._0
{
    public class I003GG1 : IBuildingConfig
    {
        
        public override BuildingDef CreateBuildingDef()
        {
            string id = "I003GG1";
            int width = 1;
            int height = 1;
            string anim = "I003GG1_kanim";
            int hitpoints = 30;
            float construction_time = 30f;
            float[] tier = BUILDINGS.CONSTRUCTION_MASS_KG.TIER5;
            string[] any_BUILDABLE = MATERIALS.ANY_BUILDABLE;
            float melting_point = 9999f;
            BuildLocationRule build_location_rule = BuildLocationRule.Anywhere;
            EffectorValues none = NOISE_POLLUTION.NONE;
            BuildingDef buildingDef = BuildingTemplates.CreateBuildingDef(id, width, height, anim, hitpoints, construction_time, tier, any_BUILDABLE, melting_point, build_location_rule, BUILDINGS.DECOR.BONUS.TIER2, none, 0.2f);
            buildingDef.Floodable = false;
            buildingDef.Overheatable = false;
            buildingDef.ThermalConductivity = 0f;
            //--------------------------
            if (控制台.Instance.I003GG1) { buildingDef.Deprecated = false; } else { buildingDef.Deprecated = true; }
            //--------------------------
            return buildingDef;
        }
        




        public override void ConfigureBuildingTemplate(GameObject go, Tag prefab_tag)
        {
            Storage storage = BuildingTemplates.CreateDefaultStorage(go, false);
            storage.showInUI = true;
            storage.capacityKg = 200f;
            storage.SetDefaultStoredItemModifiers(Storage.StandardSealedStorage);
            //----------------------------
            //链接温度控制
            go.AddOrGet<I003GG1K1>();
            //----------------------------
            //链接索引1温度设置
            go.AddOrGet<I003GG1K0>();

            //----------------------------
            go.AddOrGet<MinimumOperatingTemperature>().minimumTemperature = 2.15f;//最低工作温度30K
        }
        
        public override void DoPostConfigureComplete(GameObject go)
        {
            go.AddOrGetDef<OperationalController.Def>();
        }
       
        
    }





    
}
