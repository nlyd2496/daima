﻿using KSerialization;
using PeterHan.PLib.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace I_实用系统_1._0
{
    public class I005GG1K1 : KMonoBehaviour, ISingleSliderControl, ISliderControl
    {
        public int SliderDecimalPlaces(int index) => 0;//小数点
        public float GetSliderMin(int index) => -100;//最小值
        public float GetSliderMax(int index) => 100;//最大值
        public string SliderTitleKey => "STRINGS.BUILDINGS.PREFABS.I005GG1.NAME";
        public string GetSliderTooltip(int index) => "";//滑块名称
        public string SliderUnits => "";//单位
        //--------------------------                                                        
        [Serialize] public float AA = 20f;
        [MyCmpReq] public I005GG1K0 i005gg1k0;
        [MyCmpReq] public EnergyConsumer energyConsumer;//能量
    
        internal void Update() //将AA的值赋予源功能组件
        {
            this.i005gg1k0.temperatureDelta = this.AA ;
            bool I005GG1X1 = SingletonOptions<控制台>.Instance.I005GG1X1;
            if (I005GG1X1)
            {
                this.energyConsumer.BaseWattageRating = this.energyConsumer.WattsNeededWhenActive * 0.05f * Math.Abs(this.AA);
            }
        }
        //--------------------------
        public float GetSliderValue(int index) => this.AA;
        public string GetSliderTooltipKey(int index) => "";//空
        [MyCmpAdd] public CopyBuildingSettings copyBuildingSettings;
        protected override void OnSpawn() { base.OnSpawn(); this.Update(); }
        public void SetSliderValue(float value, int index) { this.AA = value; this.Update(); }
        protected override void OnPrefabInit() { base.OnPrefabInit(); base.Subscribe(-905833192, new Action<object>(this.OnCopySettings)); }
        internal void OnCopySettings(object data) { var component = ((GameObject)data).GetComponent<I005GG1K1>(); if (component == null) return; AA = component.AA; Update(); }
        //--------------------------
    }
}
