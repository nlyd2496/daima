﻿/*
[SerializationConfig(MemberSerialization.OptIn)]
    public class I003GG1K1 : KMonoBehaviour, IMultiSliderControl
    {
        // 构造函数，初始化滑块控件数组
        public I003GG1K1()
        {
            this.sliderControls = new ISliderControl[]
            {
                new I003GG1K1K1(this) // 初始化1号滑块控件
            };
        }
        string IMultiSliderControl.SidescreenTitleKey => "STRINGS.BUILDINGS.PREFABS.I004GG1.NAME"; // 控制器名称
        // 复制设置方法
        internal void OnCopySettings(object data)
        {
            var component = ((GameObject)data).GetComponent<I003GG1K1>();
            if (component == null) return;
            AA = component.AA;
            Update();
        }        
        // 滑条1
        [MyCmpReq] public I003GG1K0 i003gg1k0; // 组件引用
        [Serialize] public float AA = 26f; // 初始值
        internal void Update() { this.i003gg1k0.targetTemperature = this.AA + 273.15f; } // 更新方法，将AA的值赋予源功能组件      
        
        // ----------------
        // ----------------       
        protected ISliderControl[] sliderControls; // 受保护的滑块控件数组
        bool IMultiSliderControl.SidescreenEnabled() => true; // 控制器启用
        [MyCmpAdd] public CopyBuildingSettings copyBuildingSettings; // 复制建筑设置组件                                                      
        protected override void OnSpawn() { base.OnSpawn(); this.Update(); } // OnSpawn方法，在生成时调用
        ISliderControl[] IMultiSliderControl.sliderControls => this.sliderControls; // 滑块控件数组      
        protected override void OnPrefabInit() { base.OnPrefabInit(); base.Subscribe(-905833192, new Action<object>(this.OnCopySettings)); }// OnPrefabInit方法，在预制初始化时调用
        // ----------------
        // ----------------
        // 内部类，1号滑块控件
        public class I003GG1K1K1 : KMonoBehaviour, ISingleSliderControl, ISliderControl
        {                  
            public string SliderUnits => "单位"; // 单位
            public string SliderTitleKey => "STRINGS.BUILDINGS.PREFABS.I003GG1.NAME"; // 滑条名称           
            public float GetSliderMin(int index) => -270; // 最小值           
            public float GetSliderMax(int index) => 8000; // 最大值
            public int SliderDecimalPlaces(int index) => 0; // 小数点          
            // ----------------
            public I003GG1K1 target; // 目标对象           
            public string GetSliderTooltip(int index) => ""; // 滑块提示
            public string GetSliderTooltipKey(int index) => ""; // 滑块提示键（空）
            public float GetSliderValue(int index) => this.target.AA; // 获取滑块值
            public I003GG1K1K1(I003GG1K1 target) { this.target = target; } // 构造函数，初始化目标对象
            public void SetSliderValue(float value, int index) { this.target.AA = value; this.target.Update(); } // 设置滑块值
        }
    }
*/
