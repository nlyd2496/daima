﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TUNING;
using UnityEngine;

namespace I_实用系统_1._0
{
    public class I004GG1 : IBuildingConfig
    {
        public override BuildingDef CreateBuildingDef()
        {
            string id = "I004GG1";
            int width = 1;
            int height = 1;
            string anim = "I004GG1_kanim";
            int hitpoints = 10;
            float construction_time = 10f;
            float[] tier = BUILDINGS.CONSTRUCTION_MASS_KG.TIER2;
            string[] any_BUILDABLE = MATERIALS.ANY_BUILDABLE;
            float melting_point = 1600f;
            BuildLocationRule build_location_rule = BuildLocationRule.Anywhere;
            EffectorValues none = NOISE_POLLUTION.NONE;
            BuildingDef buildingDef = BuildingTemplates.CreateBuildingDef(id, width, height, anim, hitpoints, construction_time, tier, any_BUILDABLE, melting_point, build_location_rule, new EffectorValues { amount = 10, radius = 4 }, none, 0.2f);
            BuildingTemplates.CreateLadderDef(buildingDef);
            buildingDef.Floodable = false;
            buildingDef.Overheatable = false;
            buildingDef.ThermalConductivity = 2f;
            buildingDef.PermittedRotations = PermittedRotations.FlipH;
            //--------------------------
            if (控制台.Instance.I004GG1) { buildingDef.Deprecated = false; } else { buildingDef.Deprecated = true; }
            //--------------------------
            return buildingDef;
        }
        public override void ConfigureBuildingTemplate(GameObject go, Tag prefab_tag)
        {
             go.AddOrGet<I004GG1K1>();
            I004GG1K0 i004gg1k0 = go.AddOrGet<I004GG1K0>();
            i004gg1k0.effectWidth = 2;
            i004gg1k0.effectHeight = 2;
            i004gg1k0.targetTemperature = 300.15f;
            I004GG1.AddVisualizer(go, false);

            go.AddOrGet<MinimumOperatingTemperature>().minimumTemperature = 2.15f;//最低工作温度30K
        }
        public override void DoPostConfigurePreview(BuildingDef def, GameObject go)
        {
            I004GG1.AddVisualizer(go, true);
        }

        public override void DoPostConfigureUnderConstruction(GameObject go)
        {
            I004GG1.AddVisualizer(go, false);
        }
        private static void AddVisualizer(GameObject prefab, bool movable)
        {
            RangeVisualizer rangeVisualizer = prefab.AddOrGet<RangeVisualizer>();
            rangeVisualizer.RangeMin.x = -1;
            rangeVisualizer.RangeMin.y = -1;
            rangeVisualizer.RangeMax.x = 1;
            rangeVisualizer.RangeMax.y = 1;
            rangeVisualizer.OriginOffset = new Vector2I(0, 0);
            rangeVisualizer.BlockingTileVisible = false;
            prefab.GetComponent<KPrefabID>().instantiateFn += delegate (GameObject go) // 为预制体的KPrefabID组件的实例化函数添加一个委托
            {
                go.GetComponent<RangeVisualizer>().BlockingCb = new Func<int, bool>(delegate (int cell) // 为游戏对象的RangeVisualizer组件的遮挡回调函数赋值为一个匿名函数
                {
                    return false; // 这个匿名函数无论传入什么格子，都返回假，表示所有格子都不是阻挡
                });
            };

        }
        public override void DoPostConfigureComplete(GameObject go)
        {
        }
        public const string ID = "I004GG1";
    }









   
}
