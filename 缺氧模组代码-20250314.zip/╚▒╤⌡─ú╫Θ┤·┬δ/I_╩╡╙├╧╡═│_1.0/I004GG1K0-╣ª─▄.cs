﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace I_实用系统_1._0
{
    // 定义一个类，继承自KMonoBehaviour，实现ISim200ms接口
    public class I004GG1K0 : KMonoBehaviour, ISim200ms//WDFSQ+序号+MM+时间+GG+序号
    {
        // 定义一个方法，每200毫秒模拟一次，传入一个浮点型参数dt
        public void Sim200ms(float dt)
        {
            // 定义一个二维整数向量vector2I，表示温度范围的左下角坐标，根据effectWidth和effectHeight计算
            Vector2I vector2I = new Vector2I(-this.effectWidth / 2, -this.effectHeight / 2);
            // 定义一个二维整数向量vector2I2，表示温度范围的右上角坐标，根据effectWidth和effectHeight计算
            Vector2I vector2I2 = new Vector2I(this.effectWidth / 2, this.effectHeight / 2);
            // 定义两个整数变量num和num2，表示当前对象的坐标
            int num;
            int num2;
            // 调用Grid.PosToXY方法，传入当前对象的位置，将结果赋值给num和num2
            Grid.PosToXY(base.transform.GetPosition(), out num, out num2);
            // 调用Grid.XYToCell方法，传入num和num2，将结果赋值给整数变量num3，表示当前对象所在的单元格
            int num3 = Grid.XYToCell(num, num2);
            // 调用Grid.IsValidCell方法，传入num3，判断是否为有效的单元格
            if (Grid.IsValidCell(num3))
            {
                // 调用Grid.WorldIdx属性，传入num3，将结果转换为整数，并赋值给整数变量world，表示当前对象所在的世界索引
                int world = (int)Grid.WorldIdx[num3];
                // 使用for循环，遍历vector2I.y到vector2I2.y之间的所有值，将结果赋值给整数变量i
                for (int i = vector2I.y; i <= vector2I2.y; i++)
                {
                    // 使用for循环，遍历vector2I.x到vector2I2.x之间的所有值，将结果赋值给整数变量j
                    for (int j = vector2I.x; j <= vector2I2.x; j++)
                    {
                        // 调用Grid.XYToCell方法，传入num加上j和num2加上i，将结果赋值给整数变量num4，表示温度范围内的单元格
                        int num4 = Grid.XYToCell(num + j, num2 + i);
                        // 调用Grid.IsValidCellInWorld方法，传入num4和world，判断是否为有效的单元格
                        if (Grid.IsValidCellInWorld(num4, world))
                        {
                            // 定义一个浮点型变量num5，表示温度调节器对单元格产生的能量变化量，根据targetTemperature、Grid.Temperature、Grid.Element、Grid.Mass和temperatureControlK计算
                            float num5 = (this.targetTemperature - Grid.Temperature[num4]) * Grid.Element[num4].specificHeatCapacity * Grid.Mass[num4] * temperatureControlK;
                            // 判断num5是否不接近于0
                            if (!Mathf.Approximately(0f, num5))
                            {
                                // 调用SimMessages.ModifyEnergy方法，传入num4、num5、5000f和一个三元运算符（根据num5是否大于0选择不同的能源ID），表示修改单元格的能量
                                SimMessages.ModifyEnergy(num4, num5, 5000f, (num5 > 0f) ? SimMessages.EnergySourceID.DebugHeat : SimMessages.EnergySourceID.DebugCool);
                            }
                        }
                    }
                }
            }
        }
        //-------------------------------------------------------------------------------------------
        // 定义一个浮点型变量，表示温度调节器的目标温度
        public float targetTemperature;
        // 定义一个整数变量，表示温度调节器的温度范围的宽度
        public int effectWidth;
        // 定义一个整数变量，表示温度调节器的温度范围的高度
        public int effectHeight;
        // 定义一个浮点型常量，表示温度调节器的温度控制系数
        private const float temperatureControlK = 0.2f;


        [ContextMenu("Refresh")]
        public void FullRefresh()
        {
            if (!base.isSpawned || !base.isActiveAndEnabled)
            {
                return;
            }

        }
    }
}
