﻿using KSerialization;
using STRINGS;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace I_实用系统_1._0
{
    [SerializationConfig(MemberSerialization.OptIn)]
    public class I004GG1K1 : KMonoBehaviour, IMultiSliderControl
    {
        // 构造函数，初始化滑块控件数组
        public I004GG1K1()
        {
            this.sliderControls = new ISliderControl[]
            {
                new I004GG1K1K1(this), // 初始化1号滑块控件
                new I004GG1K1K2(this), // 初始化2号滑块控件
                new I004GG1K1K3(this) // 初始化3号滑块控件
            };
        }
        string IMultiSliderControl.SidescreenTitleKey => "STRINGS.BUILDINGS.PREFABS.I004GG1.NAME"; // 控制器名称
        // 复制设置方法
        internal void OnCopySettings(object data)
        {
            var component = ((GameObject)data).GetComponent<I004GG1K1>();
            if (component == null) return;
            AA = component.AA;
            BB = component.BB;
            CC = component.CC;
            Update();
        }
        // 预览图
        [MyCmpReq] public RangeVisualizer rangeVisualizer;
        // 滑条
        [MyCmpReq] public I004GG1K0 i004gg1k0; // 组件引用
        [Serialize] public float AA = 26f; // 滑条1_初始值
        [Serialize] public float BB = 2f; // 滑条2_初始值
        [Serialize] public float CC = 2f; // 滑条3_初始值
        // 更新方法，将AA的值赋予源功能组件
        internal void Update()
        {
            this.i004gg1k0.targetTemperature = this.AA + 273.15f;
            this.i004gg1k0.effectWidth = (int)this.BB;
            this.i004gg1k0.effectHeight = (int)this.CC;
            this.rangeVisualizer.RangeMin.x = -this.i004gg1k0.effectWidth / 2;
            this.rangeVisualizer.RangeMin.y = -this.i004gg1k0.effectHeight / 2;
            this.rangeVisualizer.RangeMax.x = this.i004gg1k0.effectWidth / 2;
            this.rangeVisualizer.RangeMax.y = this.i004gg1k0.effectHeight / 2;
        }  
        // ----------------
        // ----------------       
        protected ISliderControl[] sliderControls; // 受保护的滑块控件数组
        bool IMultiSliderControl.SidescreenEnabled() => true; // 控制器启用
        [MyCmpAdd] public CopyBuildingSettings copyBuildingSettings; // 复制建筑设置组件                                                      
        protected override void OnSpawn() { base.OnSpawn(); this.Update(); } // OnSpawn方法，在生成时调用
        ISliderControl[] IMultiSliderControl.sliderControls => this.sliderControls; // 滑块控件数组      
        protected override void OnPrefabInit() { base.OnPrefabInit(); base.Subscribe(-905833192, new Action<object>(this.OnCopySettings)); }// OnPrefabInit方法，在预制初始化时调用
        // ----------------
        // ----------------
        // 内部类，1号滑块控件
        public class I004GG1K1K1 : KMonoBehaviour, ISingleSliderControl, ISliderControl
        {
            public string SliderUnits => UI.UNITSUFFIXES.TEMPERATURE.CELSIUS; // ℃
            public string SliderTitleKey => "STRINGS.BUILDINGS.PREFABS.I004GG1.NAME_1"; // 滑条名称_温度        
            public float GetSliderMin(int index) => -260; // 最小值           
            public float GetSliderMax(int index) => 3000; // 最大值
            public int SliderDecimalPlaces(int index) => 0; // 小数点          
            // ----------------
            public I004GG1K1 target; // 目标对象           
            public string GetSliderTooltip(int index) => ""; // 滑块提示
            public string GetSliderTooltipKey(int index) => ""; // 滑块提示键（空）
            public float GetSliderValue(int index) => this.target.AA; // 获取滑块值
            public I004GG1K1K1(I004GG1K1 target) { this.target = target; } // 构造函数，初始化目标对象
            public void SetSliderValue(float value, int index) { this.target.AA = value; this.target.Update(); } // 设置滑块值
        }
        // 滑条2
        public class I004GG1K1K2 : KMonoBehaviour, ISingleSliderControl, ISliderControl
        {
            public string SliderUnits => UI.UNITSUFFIXES.TILES; // 格
            public string SliderTitleKey => "STRINGS.BUILDINGS.PREFABS.I004GG1.NAME_2"; // 滑条名称_宽度      
            public float GetSliderMin(int index) => 1; // 最小值
            public float GetSliderMax(int index) => 10; // 最大值
            public int SliderDecimalPlaces(int index) => 0; // 小数点
            // ----------------
            public I004GG1K1 target; // 目标对象           
            public string GetSliderTooltip(int index) => ""; // 滑块提示
            public string GetSliderTooltipKey(int index) => ""; // 滑块提示键（空）
            public float GetSliderValue(int index) => this.target.BB; // 获取滑块值
            public I004GG1K1K2(I004GG1K1 target) { this.target = target; } // 构造函数，初始化目标对象
            public void SetSliderValue(float value, int index) { this.target.BB = value; this.target.Update(); } // 设置滑块值
        }
        // 滑条3
        public class I004GG1K1K3 : KMonoBehaviour, ISingleSliderControl, ISliderControl
        {
            public string SliderUnits => UI.UNITSUFFIXES.TILES; // 格
            public string SliderTitleKey => "STRINGS.BUILDINGS.PREFABS.I004GG1.NAME_3"; // 滑条名称_高度      
            public float GetSliderMin(int index) => 1; // 最小值
            public float GetSliderMax(int index) => 10; // 最大值
            public int SliderDecimalPlaces(int index) => 0; // 小数点
            // ----------------
            public I004GG1K1 target; // 目标对象           
            public string GetSliderTooltip(int index) => ""; // 滑块提示
            public string GetSliderTooltipKey(int index) => ""; // 滑块提示键（空）
            public float GetSliderValue(int index) => this.target.CC; // 获取滑块值
            public I004GG1K1K3(I004GG1K1 target) { this.target = target; } // 构造函数，初始化目标对象
            public void SetSliderValue(float value, int index) { this.target.CC = value; this.target.Update(); } // 设置滑块值
        }
    }
}
