﻿using KSerialization;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace I_实用系统_1._0
{
    public class I001GG1K1 : KMonoBehaviour, ISingleSliderControl, ISliderControl
    {
        public int SliderDecimalPlaces(int index) => 0;//小数点
        public float GetSliderMin(int index) => 10;//最小值
        public float GetSliderMax(int index) => 800;//最大值
        public string SliderTitleKey => "STRINGS.BUILDINGS.PREFABS.I003GG1.NAME";
        public string GetSliderTooltip(int index) => UII.点这里;//滑块名称
        public string SliderUnits => UII.摄氏度;//单位
        //--------------------------                                                        
        [Serialize] public float AA = 60f;
        [MyCmpReq] public SpaceHeater spaceHeater;
        internal void Update() { this.spaceHeater.targetTemperature = this.AA + 273.15f; }//将AA的值赋予源功能组件
        //--------------------------
        public float GetSliderValue(int index) => this.AA;
        public string GetSliderTooltipKey(int index) => "";//空
        [MyCmpAdd] public CopyBuildingSettings copyBuildingSettings;
        protected override void OnSpawn() { base.OnSpawn(); this.Update(); }
        public void SetSliderValue(float value, int index) { this.AA = value; this.Update(); }
        protected override void OnPrefabInit() { base.OnPrefabInit(); base.Subscribe(-905833192, new Action<object>(this.OnCopySettings)); }
        internal void OnCopySettings(object data) { var component = ((GameObject)data).GetComponent<I001GG1K1>(); if (component == null) return; AA = component.AA; Update(); }
        //--------------------------
    }
}
