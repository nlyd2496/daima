﻿ /*
    public class DualSliderControl : I004GG1K0, IMultiSliderControl
    {
        public DualSliderControl()
        {
            this.sliderControls = new ISliderControl[]
            {
            new SliderControl1(this),
            new SliderControl2(this),
            new SliderControl3(this),

            };
        }
        string IMultiSliderControl.SidescreenTitleKey // 控制器名称
        {
            get
            {
                return "STRINGS.BUILDINGS.PREFABS.I004GG1.NAME"; 
            }
        }
        ISliderControl[] IMultiSliderControl.sliderControls
        {
            get
            {
                return this.sliderControls;
            }
        }
        bool IMultiSliderControl.SidescreenEnabled()
        {
            return true;
        }
        protected ISliderControl[] sliderControls;
        public class SliderControl1 : KMonoBehaviour, ISliderControl
        {
            public SliderControl1(I004GG1K0 t)
            {
                this.target = t;
            }
            public string SliderTitleKey // 1号滑条名称
            {
                get
                {
                    return "STRINGS.BUILDINGS.PREFABS.I004GG1.NAME_1"; 
                }
            }
            public string SliderUnits // 1号滑条单位
            {
                get
                {
                    return UII.开尔文;
                }
            }
            public float GetSliderMax(int index)
            {
                return 3000f;
            }
            public float GetSliderMin(int index)
            {
                return 10f;
            }
            public string GetSliderTooltip(int index)
            {
                return "";
            }
            public string GetSliderTooltipKey(int index)
            {
                return "";
            }
            public float GetSliderValue(int index)
            {
                return (float)this.target.targetTemperature;
            }
            public void SetSliderValue(float value, int index)
            {
                this.target.targetTemperature = (int)value;
                this.target.FullRefresh();
            }
            public int SliderDecimalPlaces(int index)
            {
                return 0;
            }
            protected I004GG1K0 target;
        }
        public class SliderControl2 : KMonoBehaviour, ISliderControl
        {
            public SliderControl2(I004GG1K0 t)
            {
                this.target = t;
            }
            public string SliderTitleKey // 二号滑条名称
            {
                get
                {
                    return "STRINGS.BUILDINGS.PREFABS.I004GG1.NAME_2";
                }
            }
            public string SliderUnits // 二号滑条单位
            {
                get
                {
                    return UII.格;
                }
            }
            public float GetSliderMax(int index)
            {
                return 10f;
            }
            public float GetSliderMin(int index)
            {
                return 1f;
            }
            public string GetSliderTooltip(int index)
            {
                return "";
            }
            public string GetSliderTooltipKey(int index)
            {
                return "";
            }
            public float GetSliderValue(int index)
            {
                return (float)this.target.effectWidth;
            }
            public void SetSliderValue(float value, int index)
            {
                this.target.effectWidth = (int)value;
                this.target.FullRefresh();
            }
            public int SliderDecimalPlaces(int index)
            {
                return 0;
            }
            protected I004GG1K0 target;
        }
        public class SliderControl3 : KMonoBehaviour, ISliderControl
        {
            public SliderControl3(I004GG1K0 t)
            {
                this.target = t;
            }
            public string SliderTitleKey // 二号滑条名称
            {
                get
                {
                    return "STRINGS.BUILDINGS.PREFABS.I004GG1.NAME_3";
                }
            }
            public string SliderUnits // 二号滑条单位
            {
                get
                {
                    return UII.格;
                }
            }
            public float GetSliderMax(int index)
            {
                return 10f;
            }
            public float GetSliderMin(int index)
            {
                return 1f;
            }
            public string GetSliderTooltip(int index)
            {
                return "";
            }
            public string GetSliderTooltipKey(int index)
            {
                return "";
            }
            public float GetSliderValue(int index)
            {
                return (float)this.target.effectHeight;
            }
            public void SetSliderValue(float value, int index)
            {
                this.target.effectHeight = (int)value;
                this.target.FullRefresh();
            }
            public int SliderDecimalPlaces(int index)
            {
                return 0;
            }
            protected I004GG1K0 target;
        }
    }
    */

