﻿using HarmonyLib;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace I_实用系统_1._0
{
    [HarmonyPatch(typeof(IceMachineConfig))]
    [HarmonyPatch("CreateBuildingDef")]
    public class 发热量及功率提升
    {
        public static void Postfix(ref BuildingDef __result)
        {
            __result.EnergyConsumptionWhenActive = 240f;
            __result.ExhaustKilowattsWhenActive = 8f;
            __result.SelfHeatKilowattsWhenActive = 24f;
            __result.LogicInputPorts = LogicOperationalController.CreateSingleInputPortList(new CellOffset(0, 0));

        }
    }

    [HarmonyPatch(typeof(IceMachineConfig))]
    [HarmonyPatch("ConfigureBuildingTemplate")]
    internal class 容量及效率强化
    {
        private static void Postfix(GameObject go, Tag prefab_tag)
        {
            Storage storage = go.AddOrGet<Storage>();
            storage.capacityKg = 300f;

            IceMachine iceMachine = go.AddOrGet<IceMachine>();
            iceMachine.heatRemovalRate = 300f;


            ManualDeliveryKG manualDeliveryKG = go.AddOrGet<ManualDeliveryKG>();
            manualDeliveryKG.capacity = 300f;
            manualDeliveryKG.refillMass = 30f;
            manualDeliveryKG.MinimumMass = 10f;


            go.AddOrGet<LogicOperationalController>();
        }
    }
    
}
