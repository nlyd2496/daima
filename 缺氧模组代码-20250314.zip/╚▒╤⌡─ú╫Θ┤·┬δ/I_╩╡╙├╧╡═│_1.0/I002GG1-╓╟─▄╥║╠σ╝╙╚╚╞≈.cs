﻿using HarmonyLib;
using PeterHan.PLib.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace I_实用系统_1._0
{
    [HarmonyPatch(typeof(LiquidHeaterConfig))]
    [HarmonyPatch("ConfigureBuildingTemplate")]
    public static class 液体加热器添加温度控制滑条
    {
        public static void Postfix(GameObject go)
        {
            bool I002GG1 = SingletonOptions<控制台>.Instance.I002GG1;
            if (I002GG1)
            {
                go.AddOrGet<I002GG1K2>();
                go.AddOrGet<MinimumOperatingTemperature>().minimumTemperature = 13.15f;//最低工作温度30K

            }
        }
    }
    [HarmonyPatch(typeof(LiquidHeaterConfig))]
    [HarmonyPatch("CreateBuildingDef")]
    public class 液体加热器过热温度
    {
        public static void Postfix(ref BuildingDef __result)
        {
            bool I002GG1 = SingletonOptions<控制台>.Instance.I002GG1;
            if (I002GG1)
            {
                __result.OverheatTemperature = 1000f;
            }
        }
    }
}
