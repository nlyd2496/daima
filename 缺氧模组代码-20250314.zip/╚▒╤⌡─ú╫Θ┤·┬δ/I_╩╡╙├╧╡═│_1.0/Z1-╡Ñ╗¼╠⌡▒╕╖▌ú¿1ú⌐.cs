﻿/*
    public class I003GG1K1 : KMonoBehaviour, ISingleSliderControl, ISliderControl
    {
        public string SliderTitleKey => "STRINGS.BUILDINGS.PREFABS.I003GG1.NAME";
        public string GetSliderTooltip(int index) => UII.点这里;//滑块名称
        public string SliderUnits => UII.摄氏度;//单位
        public string GetSliderTooltipKey(int index) => "";//空

        public int SliderDecimalPlaces(int index) => 0;//小数点
        public float GetSliderMin(int index) => -270;//最小值
        public float GetSliderMax(int index) => 8000;//最大值
        public float GetSliderValue(int index) => this.AA;
        public void SetSliderValue(float value, int index) { this.AA = value; this.Update(); }

        [Serialize] public float AA = 26f;
        [MyCmpReq] public I003GG1K0 i003gg1k0;
        internal void Update() { this.i003gg1k0.targetTemperature = this.AA + 273.15f; }//将AA的值赋予源功能组件

        
        
        [MyCmpAdd] public CopyBuildingSettings copyBuildingSettings;
        protected override void OnSpawn() { base.OnSpawn(); this.Update(); }
        
        protected override void OnPrefabInit() { base.OnPrefabInit(); base.Subscribe(-905833192, new Action<object>(this.OnCopySettings)); }
        internal void OnCopySettings(object data) { var component = ((GameObject)data).GetComponent<I003GG1K1>(); if (component == null) return; AA = component.AA; Update(); }

    }
    */

    

