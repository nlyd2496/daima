﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using HarmonyLib;
using KMod;
using PeterHan.PLib.Options;
using UnityEngine;
using static I_实用系统_1._0.STRINGS.BUILDINGS.PREFABS;

namespace I_实用系统_1._0
{
    [HarmonyPatch(typeof(LiquidConditionerConfig))]
    [HarmonyPatch("ConfigureBuildingTemplate")]
    public static class 液体空调
    {
        public static void Postfix(GameObject go)
        {
            bool I005GG1 = SingletonOptions<控制台>.Instance.I005GG1;
            if (I005GG1)
            {
                AirConditioner airConditioner = go.GetComponent<AirConditioner>();
                if (airConditioner != null)
                {
                    GameObject.Destroy(airConditioner); // 移除 AirConditioner 组件
                }
                I005GG1K0 i005GG1K0 = go.AddOrGet<I005GG1K0>();
                i005GG1K0.temperatureDelta = -20f;
                i005GG1K0.maxEnvironmentDelta = -100f;
                i005GG1K0.isLiquidConditioner = true;

                go.AddOrGet<I005GG1K1>();
                go.AddOrGet<MinimumOperatingTemperature>().minimumTemperature = 2.15f;//最低工作温度3K
            }
        }
    }
    [HarmonyPatch(typeof(AirConditionerConfig))]
    [HarmonyPatch("ConfigureBuildingTemplate")]
    public static class 气体空调
    {
        public static void Postfix(GameObject go)
        {
            bool I005GG1 = SingletonOptions<控制台>.Instance.I005GG1;
            if (I005GG1)
            {
                AirConditioner airConditioner = go.GetComponent<AirConditioner>();
                if (airConditioner != null)
                {
                    GameObject.Destroy(airConditioner); // 移除 AirConditioner 组件
                }
                I005GG1K0 i005GG1K0 = go.AddOrGet<I005GG1K0>();
                i005GG1K0.temperatureDelta = -20f;
                i005GG1K0.maxEnvironmentDelta = -100f;

                go.AddOrGet<I005GG1K1>();
                go.AddOrGet<MinimumOperatingTemperature>().minimumTemperature = 2.15f;//最低工作温度3K
            }
        }
    }
}
