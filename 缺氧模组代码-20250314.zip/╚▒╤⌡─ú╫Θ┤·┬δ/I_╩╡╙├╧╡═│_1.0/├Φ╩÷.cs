﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HarmonyLib;
using STRINGS;
using KMod;
// using PeterHan.PLib.Core;
// using PeterHan.PLib.Database;
using Klei.AI;
// using PeterHan.PLib.Options;

namespace I_实用系统_1._0
{
    public class STRINGS
    {
        public class BUILDINGS
        {
            public class PREFABS
            {
                public class I003GG1//恒温空间
                {
                    public static LocString NAME = "恒温空间";//建筑名
                    public static LocString EFFECT = "一定范围内，温度保持不变。";//建筑效果
                    public static LocString DESC = "魔法的力量，无穷无尽。";
                }
                public class I004GG1//温度场
                {
                    public static LocString NAME = "温度场";//建筑名
                    public static LocString EFFECT = "一定区域保持温度不变，你可以控制它的作用范围以及温度。";//建筑效果
                    public static LocString DESC = "“恒温空间”是我的哥哥。";
                    public static LocString NAME_1 = "温度"; // 1号滑条名称
                    public static LocString NAME_2 = "宽度"; // 2号滑条名称
                    public static LocString NAME_3 = "高度"; // 3号滑条名称
                }
                public class I005GG1 // 空调温度因子
                {
                    public static LocString NAME = "空调温度因子"; // 空调温度因子
                }
                public class I_UI
                {
                    public static LocString I000GG0_KZT_0_UI = "模组功能启停";
                    public static LocString I000GG0_KZT_1_UI = "全部启用";
                    public static LocString I000GG0_KZT_2_UI = "全部停止";
                    public static LocString I000GG0_KZT_3_UI = "自由设定";
                    public static LocString I001GG1_UI = "启用优化空间加热器（失效）";
                    public static LocString I002GG1_UI = "启用优化液体加热器";
                    public static LocString I003GG1_UI = "启用恒温空间";
                    public static LocString I004GG1_UI = "启用温度场";
                    public static LocString I005GG1_UI = "启用超级空调";
                    public static LocString I005GG1X1_UI = "启用超级空调能量守恒";


                }
            }
        }
    }
}