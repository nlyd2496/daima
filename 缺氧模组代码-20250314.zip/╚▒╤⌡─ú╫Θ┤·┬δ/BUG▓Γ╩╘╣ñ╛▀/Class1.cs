﻿using HarmonyLib;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BUG测试工具
{
    [HarmonyPatch(typeof(DevGeneratorConfig))]
    [HarmonyPatch("CreateBuildingDef")]
    internal class 开发者发电机
    {
        public static void Postfix(BuildingDef __result)
        {
            __result.DebugOnly = false;
            __result.Floodable = false;
            __result.Overheatable = false;
            __result.ThermalConductivity = 0f;
            __result.UseStructureTemperature = false;
        }
    }
    [HarmonyPatch(typeof(DevLifeSupportConfig))]
    [HarmonyPatch("CreateBuildingDef")]
    internal class 开发者维生器
    {
        public static void Postfix(BuildingDef __result)
        {
            __result.DebugOnly = false;
            __result.Floodable = false;
            __result.Overheatable = false;
            __result.ThermalConductivity = 0f;
            __result.UseStructureTemperature = false;
        }
    }
    [HarmonyPatch(typeof(DevPumpGasConfig))]
    [HarmonyPatch("CreateBuildingDef")]
    internal class 开发者气体泵
    {
        public static void Postfix(BuildingDef __result)
        {
            __result.DebugOnly = false;
            __result.Floodable = false;
            __result.Overheatable = false;
            __result.ThermalConductivity = 0f;
            __result.UseStructureTemperature = false;
        }
    }
    [HarmonyPatch(typeof(DevPumpLiquidConfig))]
    [HarmonyPatch("CreateBuildingDef")]
    internal class 开发者液体泵
    {
        public static void Postfix(BuildingDef __result)
        {
            __result.DebugOnly = false;
            __result.Floodable = false;
            __result.Overheatable = false;
            __result.ThermalConductivity = 0f;
            __result.UseStructureTemperature = false;
        }
    }
    [HarmonyPatch(typeof(DevPumpSolidConfig))]
    [HarmonyPatch("CreateBuildingDef")]
    internal class 开发者固体泵
    {
        public static void Postfix(BuildingDef __result)
        {
            __result.DebugOnly = false;
            __result.Floodable = false;
            __result.Overheatable = false;
            __result.ThermalConductivity = 0f;
            __result.UseStructureTemperature = false;
        }
    }
    [HarmonyPatch(typeof(DevRadiationGeneratorConfig))]
    [HarmonyPatch("CreateBuildingDef")]
    internal class 开发者辐射泵
    {
        public static void Postfix(BuildingDef __result)
        {
            __result.DebugOnly = false;
            __result.Floodable = false;
            __result.Overheatable = false;
            __result.ThermalConductivity = 0f;
            __result.UseStructureTemperature = false;
        }
    }
    [HarmonyPatch(typeof(DevLightGeneratorConfig))]
    [HarmonyPatch("CreateBuildingDef")]
    internal class 开发者灯
    {
        public static void Postfix(BuildingDef __result)
        {
            __result.DebugOnly = false;
            __result.Floodable = false;
            __result.Overheatable = false;
            __result.ThermalConductivity = 0f;
            __result.UseStructureTemperature = false;
        }
    }
    [HarmonyPatch(typeof(DevHeaterConfig))]
    [HarmonyPatch("CreateBuildingDef")]
    internal class 开发者加热器
    {
        public static void Postfix(BuildingDef __result)
        {
            __result.DebugOnly = false;
            __result.Floodable = false;
            __result.Overheatable = false;
            __result.ThermalConductivity = 0f;
            __result.UseStructureTemperature = false;
        }
    }
    [HarmonyPatch(typeof(DevHEPSpawnerConfig))]
    [HarmonyPatch("CreateBuildingDef")]
    internal class 开发者粒子发生器
    {
        public static void Postfix(BuildingDef __result)
        {
            __result.DebugOnly = false;
            __result.Floodable = false;
            __result.Overheatable = false;
            __result.ThermalConductivity = 0f;
            __result.UseStructureTemperature = false;
        }
    }
}
