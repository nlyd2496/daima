﻿using HarmonyLib;
using PeterHan.PLib.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace C_管道系统_1._0
{
    [HarmonyPatch(typeof(GasBottlerConfig), "ConfigureBuildingTemplate")]
    public static class 可调节的气体灌装器
    {

        public static void Postfix(GameObject go)
        {
            bool C019GG1 = SingletonOptions<控制台>.Instance.C019GG1;
            if (C019GG1)
            {
                go.AddOrGet<C019GG1K1>();//将CSKZMM20230828GG1的功能添加到GasBottlerConfig中
            }
        }
    }
}
