﻿using HarmonyLib;
using PeterHan.PLib.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C_管道系统_1._0
{
    [HarmonyPatch(typeof(ShowerConfig), "CreateBuildingDef")]
    public static class 三格高的淋浴间
    {
        public static BuildingDef Postfix(BuildingDef def)
        {
            bool C007GG1 = SingletonOptions<控制台>.Instance.C007GG1;
            if (C007GG1)
            {
                int heightInCells = 3;
                def.HeightInCells = heightInCells;
                def.AnimFiles = new KAnimFile[]
                   {
                    Assets.GetAnim("C007GG1_kanim")
                   };
                def.GenerateOffsets();
            }
            return def;
        }
    }
}
