﻿using HarmonyLib;
using PeterHan.PLib.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace C_管道系统_1._0
{
    [HarmonyPatch(typeof(OuthouseConfig))]
    [HarmonyPatch("ConfigureBuildingTemplate")]
    public class 户外环保厕所
    {
        public static void Postfix(GameObject go)
        {
            bool C012GG1 = SingletonOptions<控制台>.Instance.C012GG1;
            if (C012GG1)
            {
                //--------------------------------
                go.AddOrGet<Toilet>().solidWastePerUse = new Toilet.SpawnInfo(SimHashes.Fertilizer, 6.7f, 0f);//产出肥料
                go.AddOrGet<Toilet>().maxFlushes = 100;//使用次数100
                 //--------------------------------
                go.AddOrGet<ManualDeliveryKG>().capacity = 1300f;//储存容量1300

            }
        }
    }
}
