﻿using Database;
using HarmonyLib;
using PeterHan.PLib.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C_管道系统_1._0
{

    [HarmonyPatch(typeof(BuildingFacades), MethodType.Constructor, new Type[] { typeof(ResourceSet) })]
    public static class C029GG1
    {
        public static void Postfix(BuildingFacades __instance)
        {
            bool C029GG1 = SingletonOptions<控制台>.Instance.C029GG1;
            if (C029GG1)
            {
                // 迷你气泵
                __instance.Add(
                    "C029GG1L2",
                    STRINGS.BUILDINGS.PREFABS.C029GG1L2.NAME,
                    STRINGS.BUILDINGS.PREFABS.C029GG1L2.EFFECT,
                    PermitRarity.Universal,
                    "GASMINIPUMP",
                    "C029GG1L2_kanim"
                    );

                // 气泵
                __instance.Add(
                    "C029GG2L2",
                    STRINGS.BUILDINGS.PREFABS.C029GG2L2.NAME,
                    STRINGS.BUILDINGS.PREFABS.C029GG2L2.EFFECT,
                    PermitRarity.Universal,
                    "GASPUMP",
                    "C029GG2L2_kanim"
                    );
                // 液泵
                __instance.Add(
                    "C029GG3L2",
                    STRINGS.BUILDINGS.PREFABS.C029GG3L2.NAME,
                    STRINGS.BUILDINGS.PREFABS.C029GG3L2.EFFECT,
                    PermitRarity.Universal,
                    "LIQUIDPUMP",
                    "C029GG3L2_kanim"
                    );
                // 户外厕所
                __instance.Add(
                    "C029GG4L2",
                    STRINGS.BUILDINGS.PREFABS.C029GG4L2.NAME,
                    STRINGS.BUILDINGS.PREFABS.C029GG4L2.EFFECT,
                    PermitRarity.Universal,
                    "OUTHOUSE",
                    "C029GG4L2_kanim"
                    );
                // 手压泵
                __instance.Add(
                    "C029GG5L2",
                    STRINGS.BUILDINGS.PREFABS.C029GG5L2.NAME,
                    STRINGS.BUILDINGS.PREFABS.C029GG5L2.EFFECT,
                    PermitRarity.Universal,
                    "LIQUIDPUMPINGSTATION",
                    "C029GG5L2_kanim"
                    );
                // 排气口
                __instance.Add(
                    "C029GG7L2",
                    STRINGS.BUILDINGS.PREFABS.C029GG7L2.NAME,
                    STRINGS.BUILDINGS.PREFABS.C029GG7L2.EFFECT,
                    PermitRarity.Universal,
                    "GASVENT",
                    "C029GG7L2_kanim"
                    );
                // 排液口
                __instance.Add(
                    "C029GG8L2",
                    STRINGS.BUILDINGS.PREFABS.C029GG8L2.NAME,
                    STRINGS.BUILDINGS.PREFABS.C029GG8L2.EFFECT,
                    PermitRarity.Universal,
                    "LIQUIDVENT",
                    "C029GG8L2_kanim"
                    ) ;

            }
        }
    }
}
