﻿using Newtonsoft.Json;
using PeterHan.PLib.Options;


namespace C_管道系统_1._0
{
    [RestartRequired]
    [JsonObject(MemberSerialization.OptIn)]
    [ConfigFile("C000GG0.json", true, false)]
    // [ModInfo("https://space.bilibili.com/30725645", "mmm.png", true)]

    public class 控制台 : SingletonOptions<控制台>
    {   
        [Option("STRINGS.BUILDINGS.PREFABS.C_UI.C001GG1_UI", null, null)][JsonProperty] public bool C001GG1 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.C_UI.C002GG1_UI", null, null)][JsonProperty] public bool C002GG1 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.C_UI.C003GG1_UI", null, null)][JsonProperty] public bool C003GG1 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.C_UI.C003GG1X1_UI", null, null, Format = "F0")][Limit(10, 1000)][JsonProperty] public float C003GG1X1 { get; set; } = 100f;
        [Option("STRINGS.BUILDINGS.PREFABS.C_UI.C003GG1X2_UI", null, null, Format = "F0")][Limit(1, 100)][JsonProperty] public float C003GG1X2 { get; set; } = 10f;
        [Option("STRINGS.BUILDINGS.PREFABS.C_UI.C004GG1_UI", null, null)][JsonProperty] public bool C004GG1 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.C_UI.C005GG1_UI", null, null)][JsonProperty] public bool C005GG1 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.C_UI.C006GG1_UI", null, null)][JsonProperty] public bool C006GG1 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.C_UI.C007GG1_UI", null, null)][JsonProperty] public bool C007GG1 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.C_UI.C008GG1_UI", null, null)][JsonProperty] public bool C008GG1 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.C_UI.C009GG1_UI", null, null)][JsonProperty] public bool C009GG1 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.C_UI.C010GG1_UI", null, null)][JsonProperty] public bool C010GG1 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.C_UI.C011GG1_UI", null, null)][JsonProperty] public bool C011GG1 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.C_UI.C012GG1_UI", null, null)][JsonProperty] public bool C012GG1 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.C_UI.C013GG1_UI", null, null)][JsonProperty] public bool C013GG1 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.C_UI.C014GG1_UI", null, null)][JsonProperty] public bool C014GG1 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.C_UI.C015GG1_UI", null, null)][JsonProperty] public bool C015GG1 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.C_UI.C015GG2_UI", null, null)][JsonProperty] public bool C015GG2 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.C_UI.C015GG3_UI", null, null)][JsonProperty] public bool C015GG3 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.C_UI.C015GG4_UI", null, null)][JsonProperty] public bool C015GG4 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.C_UI.C015GG5_UI", null, null)][JsonProperty] public bool C015GG5 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.C_UI.C015GG6_UI", null, null)][JsonProperty] public bool C015GG6 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.C_UI.C016GG1_UI", null, null)][JsonProperty] public bool C016GG1 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.C_UI.C017GG1_UI", null, null)][JsonProperty] public bool C017GG1 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.C_UI.C018GG1_UI", null, null)][JsonProperty] public bool C018GG1 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.C_UI.C019GG1_UI", null, null)][JsonProperty] public bool C019GG1 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.C_UI.C020GG1_UI", null, null)][JsonProperty] public bool C020GG1 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.C_UI.C020GG2_UI", null, null)][JsonProperty] public bool C020GG2 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.C_UI.C021GG1_UI", null, null)][JsonProperty] public bool C021GG1 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.C_UI.C021GG2_UI", null, null)][JsonProperty] public bool C021GG2 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.C_UI.C023GG1_UI", null, null)][JsonProperty] public bool C023GG1 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.C_UI.C024GG1_UI", null, null)][JsonProperty] public bool C024GG1 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.C_UI.C025GG1_UI", null, null)][JsonProperty] public bool C025GG1 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.C_UI.C026GG1_UI", null, null)][JsonProperty] public bool C026GG1 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.C_UI.C027GG1_UI", null, null)][JsonProperty] public bool C027GG1 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.C_UI.C028GG1_UI", null, null)][JsonProperty] public bool C028GG1 { get; set; } = true;
        [Option("STRINGS.BUILDINGS.PREFABS.C_UI.C028GG1X1_UI", null, null, Format = "F0")][Limit(20, 1000)][JsonProperty] public float C028GG1X1 { get; set; } = 100f;
        [Option("STRINGS.BUILDINGS.PREFABS.C_UI.C029GG1_UI", null, null)][JsonProperty] public bool C029GG1 { get; set; } = true;


    }
}
