﻿using HarmonyLib;
using PeterHan.PLib.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace C_管道系统_1._0
{
    [HarmonyPatch(typeof(BottleEmptierGasConfig), "ConfigureBuildingTemplate")]
    public static class 可调节的气体空罐器
    {
        public static void Postfix(GameObject go)
        {
            bool C018GG1 = SingletonOptions<控制台>.Instance.C018GG1;
            if (C018GG1)
            {
                go.AddOrGet<Storage>().capacityKg = 1000000f;
                go.AddOrGet<C018GG1K1>();
            }
        }
    }
    [HarmonyPatch(typeof(BottleEmptierConfig), "ConfigureBuildingTemplate")]
    public static class 可调节的液体空罐器
    {
        public static void Postfix(GameObject go)
        {
            bool C018GG1 = SingletonOptions<控制台>.Instance.C018GG1;
            if (C018GG1)
            {
                go.AddOrGet<Storage>().capacityKg = 1000000f;
                go.AddOrGet<C018GG1K2>();
            }
        }
    }
}
