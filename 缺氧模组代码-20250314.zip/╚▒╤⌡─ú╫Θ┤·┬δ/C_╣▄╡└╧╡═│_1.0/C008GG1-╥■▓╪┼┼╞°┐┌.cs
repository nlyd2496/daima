﻿using HarmonyLib;
using PeterHan.PLib.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C_管道系统_1._0
{
    [HarmonyPatch(typeof(GasVentConfig))]
    [HarmonyPatch("CreateBuildingDef")]
    public class 隐藏排气口
    {
        public static void Postfix(ref BuildingDef __result)
        {
            bool C008GG1 = SingletonOptions<控制台>.Instance.C008GG1;
            if (C008GG1)
            {
                __result.SceneLayer = Grid.SceneLayer.BuildingBack;
                __result.ObjectLayer = ObjectLayer.Critter;//动物层
            }
        }
    }
}
