﻿using HarmonyLib;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C_管道系统_1._0
{
    [HarmonyPatch(typeof(GeneratedBuildings))]
    [HarmonyPatch("LoadGeneratedBuildings")]
    public class 建筑栏
    {
        public static void Prefix()
        {
            ModUtil.AddBuildingToPlanScreen("HVAC", "C005GG1");
            ModUtil.AddBuildingToPlanScreen("Plumbing", "C006GG1");
            ModUtil.AddBuildingToPlanScreen("Plumbing", "C011GG1");
            ModUtil.AddBuildingToPlanScreen("Plumbing", "C013GG1");
            ModUtil.AddBuildingToPlanScreen("Plumbing", "C014GG1");
            ModUtil.AddBuildingToPlanScreen("HVAC", "C015GG1");
            ModUtil.AddBuildingToPlanScreen("HVAC", "C015GG2");
            ModUtil.AddBuildingToPlanScreen("HVAC", "C015GG3");
            ModUtil.AddBuildingToPlanScreen("HVAC", "C015GG4");
            ModUtil.AddBuildingToPlanScreen("HVAC", "C015GG5");
            ModUtil.AddBuildingToPlanScreen("HVAC", "C015GG6");
            ModUtil.AddBuildingToPlanScreen("HVAC", "C020GG1");
            ModUtil.AddBuildingToPlanScreen("HVAC", "C020GG2");
            ModUtil.AddBuildingToPlanScreen("Plumbing", "C021GG1");
            ModUtil.AddBuildingToPlanScreen("Plumbing", "C021GG2");
            ModUtil.AddBuildingToPlanScreen("Plumbing", "C023GG1");
            ModUtil.AddBuildingToPlanScreen("Plumbing", "C024GG1");
            ModUtil.AddBuildingToPlanScreen("Plumbing", "C025GG1");
            ModUtil.AddBuildingToPlanScreen("Plumbing", "C026GG1");
            ModUtil.AddBuildingToPlanScreen("HVAC", "C027GG1");
        }
    }
}
//  基地 氧气   电力  食物 液管     气管 精炼     医疗    家具      站台      实用      自动化     运输       火箭     辐射
//  Base Oxygen Power Food Plumbing HVAC Refining Medical Furniture Equipment Utilities Automation Conveyance Rocketry HEP
