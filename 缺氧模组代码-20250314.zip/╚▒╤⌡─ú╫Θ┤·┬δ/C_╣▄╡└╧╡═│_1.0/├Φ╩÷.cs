﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HarmonyLib;
using STRINGS;
using KMod;
using PeterHan.PLib.Core;
using PeterHan.PLib.Database;
using Klei.AI;
using PeterHan.PLib.Options;

namespace C_管道系统_1._0
{

    public class STRINGS
    {
        public static void DoReplacement()
        {
            LocString.CreateLocStringKeys(typeof(STRINGS), "");
        }
        // 控制器
        
        // 建筑描述
        public class BUILDINGS
        {
            public class PREFABS
            {
                public class C_UI
                {
                    public static LocString C001GG1_UI = "启用隔热管道不导热";
                    public static LocString C002GG1_UI = "启用超级泵";
                    public static LocString C003GG1_UI = "启用超级管道";
                    public static LocString C003GG1X1_UI = "液体管道容量";
                    public static LocString C003GG1X2_UI = "气体管道容量";
                    public static LocString C004GG1_UI = "启用垂直液泵";
                    public static LocString C005GG1_UI = "启用导热气体管道";
                    public static LocString C006GG1_UI = "启用导热液体管道";
                    public static LocString C007GG1_UI = "启用三格高的淋浴间";
                    public static LocString C008GG1_UI = "启用隐藏排气口";
                    public static LocString C009GG1_UI = "启用管道阀可穿墙";
                    public static LocString C010GG1_UI = "启用管道检测器可穿墙";
                    public static LocString C011GG1_UI = "启用核废水处理桶（DLC限定）";
                    public static LocString C012GG1_UI = "启用户外环保厕所";
                    public static LocString C013GG1_UI = "启用黄金淋浴间";
                    public static LocString C014GG1_UI = "启用绝命毒师";
                    public static LocString C015GG1_UI = "启用喵喵排风扇之甲烷";
                    public static LocString C015GG2_UI = "启用喵喵排风扇之氯气";
                    public static LocString C015GG3_UI = "启用喵喵排风扇之氢气";
                    public static LocString C015GG4_UI = "启用喵喵排风扇之污染氧";
                    public static LocString C015GG5_UI = "启用喵喵排风扇之氧气";
                    public static LocString C015GG6_UI = "启用喵喵排风扇之二氧化碳";
                    public static LocString C016GG1_UI = "启用开发者气泵";
                    public static LocString C017GG1_UI = "启用开发者液泵";
                    public static LocString C018GG1_UI = "启用可调节的空罐器";
                    public static LocString C019GG1_UI = "启用可调节的气体灌装器";
                    public static LocString C020GG1_UI = "启用跨两格气管桥";
                    public static LocString C020GG2_UI = "启用跨三格气管桥";
                    public static LocString C021GG1_UI = "启用跨三格液管桥";
                    public static LocString C021GG2_UI = "启用跨两格液管桥";
                    public static LocString C022GG1_UI = "启用热量终结者";
                    public static LocString C023GG1_UI = "启用香草抽水马桶";
                    public static LocString C024GG1_UI = "启用液体灌装器";
                    public static LocString C025GG1_UI = "启用迷你液泵";
                    public static LocString C026GG1_UI = "启用废液桶";
                    public static LocString C027GG1_UI = "启用废气罐";
                    public static LocString C028GG1_UI = "启用运输轨道容量增加";
                    public static LocString C028GG1X1_UI = "运输轨道容量";
                    public static LocString C029GG1_UI = "启用黄金系列";





                }
                public class C004GG1//垂直液泵
                {
                    public static LocString NAME = "垂直液泵";//建筑名
                    public static LocString EFFECT = "神奇的液泵";//建筑效果
                    public static LocString DESC = "神奇的液泵";
                }
                public class C005GG1//导热气体管道
                {
                    public static LocString NAME = "导热气体管道";//建筑名
                    public static LocString EFFECT = "导热的气体管道。";//建筑效果
                    public static LocString DESC = "喵喵喵。";
                }
                public class C006GG1//导热液体管道
                {
                    public static LocString NAME = "导热液体管道";//建筑名
                    public static LocString EFFECT = "导热的液体管道。";//建筑效果
                    public static LocString DESC = "喵喵喵。";
                }
                public class C011GG1//核废水处理桶
                {
                    public static LocString NAME = "核废水处理桶";//建筑名
                    public static LocString EFFECT = "核废水是一种含有大量放射性物质的废水，对人类和环境都有严重的危害。核废水对人体的危害主要有以下几方面：\r\n\r\n致癌。放射性物质可以破坏人体细胞的正常功能，导致癌变或突变。\r\n遗传。放射性物质可以影响人体的DNA，导致基因缺陷或变异。这些缺陷或变异可能会传给后代，造成先天性疾病或畸形。\r\n器官损伤。放射性物质可以通过食物链或呼吸道进入人体，积累在某些器官或组织中，造成慢性损伤或功能障碍。例如，氚可以积累在骨骼中，影响骨髓造血功能。\r\n因此，核废水是一种非常危险的污染源，应该尽量避免接触或食用受到核废水污染的水源或食物。海洋产品也可能受到核废水的影响，因为核废水会污染海洋生态系统，导致海洋生物的死亡或变异5。在食用海洋产品之前，应该检查其是否安全无害。";//建筑效果
                    public static LocString DESC = "关爱生命，远离核污染。";
                }
                public class C011GG1L2//核废水处理桶
                {
                    public static LocString NAME = "核废水处理桶";//建筑名
                    public static LocString EFFECT = "核废水是一种含有大量放射性物质的废水，对人类和环境都有严重的危害。核废水对人体的危害主要有以下几方面：\r\n\r\n致癌。放射性物质可以破坏人体细胞的正常功能，导致癌变或突变。\r\n遗传。放射性物质可以影响人体的DNA，导致基因缺陷或变异。这些缺陷或变异可能会传给后代，造成先天性疾病或畸形。\r\n器官损伤。放射性物质可以通过食物链或呼吸道进入人体，积累在某些器官或组织中，造成慢性损伤或功能障碍。例如，氚可以积累在骨骼中，影响骨髓造血功能。\r\n因此，核废水是一种非常危险的污染源，应该尽量避免接触或食用受到核废水污染的水源或食物。海洋产品也可能受到核废水的影响，因为核废水会污染海洋生态系统，导致海洋生物的死亡或变异5。在食用海洋产品之前，应该检查其是否安全无害。";//建筑效果
                }
                public class C013GG1//黄金淋浴间
                {
                    public static LocString NAME = "黄金淋浴间";//建筑名
                    public static LocString EFFECT = "她只是闪闪发光而已，她能有什么错呢。";//建筑效果
                    public static LocString DESC = "土豪的气息，怎能被泥土所掩盖。";
                }
                public class C015GG1//排甲烷风扇
                {
                    public static LocString NAME = "排甲烷风扇";//建筑名
                    public static LocString EFFECT = "抽取甲烷";//建筑效果
                    public static LocString DESC = "小巧而精致";
                }
                public class C015GG2//排氯气风扇
                {
                    public static LocString NAME = "排氯气风扇";//建筑名
                    public static LocString EFFECT = "抽取氯气";//建筑效果
                    public static LocString DESC = "小巧而精致";
                }
                public class C015GG3//排氢气风扇
                {
                    public static LocString NAME = "排氢气风扇";//建筑名
                    public static LocString EFFECT = "抽取氢气";//建筑效果
                    public static LocString DESC = "小巧而精致";
                }
                public class C015GG4//排污染氧风扇
                {
                    public static LocString NAME = "排污染氧风扇";//建筑名
                    public static LocString EFFECT = "抽取污染氧";//建筑效果
                    public static LocString DESC = "小巧而精致";
                }
                public class C015GG5//排氧风扇
                {
                    public static LocString NAME = "排氧风扇";//建筑名
                    public static LocString EFFECT = "抽取氧气";//建筑效果
                    public static LocString DESC = "小巧而精致";
                }
                public class C015GG6//排二氧化碳风扇
                {
                    public static LocString NAME = "排二氧化碳风扇";//建筑名
                    public static LocString EFFECT = "抽取二氧化碳";//建筑效果
                    public static LocString DESC = "小巧而精致";
                }
                public class C020GG1//跨两气桥
                {
                    public static LocString NAME = "跨两气桥";//建筑名
                    public static LocString EFFECT = "跨两格气体管桥。";//建筑效果
                    public static LocString DESC = "喵喵喵。";
                }
                public class C020GG2//跨三气桥
                {
                    public static LocString NAME = "跨三气桥";//建筑名
                    public static LocString EFFECT = "跨三格气体管桥。";//建筑效果
                    public static LocString DESC = "喵喵喵。";
                }
                public class C021GG1//跨两液桥
                {
                    public static LocString NAME = "跨两液桥";//建筑名
                    public static LocString EFFECT = "跨两格液体管桥。";//建筑效果
                    public static LocString DESC = "喵喵喵。";
                }
                public class C021GG2//跨三液桥
                {
                    public static LocString NAME = "跨三液桥";//建筑名
                    public static LocString EFFECT = "跨三格液体管桥。";//建筑效果
                    public static LocString DESC = "喵喵喵。";
                }
                public class C023GG1//香草抽水马桶
                {
                    public static LocString NAME = "香草抽水马桶";//建筑名
                    public static LocString EFFECT = "采薇采薇，薇亦作止。";//建筑效果
                    public static LocString DESC = "小雅·采薇。";
                }
                public class C024GG1//液体灌装器
                {
                    public static LocString NAME = "液体灌装器";//建筑名
                    public static LocString EFFECT = "神奇的液泵神奇的液泵。";//建筑效果
                    public static LocString DESC = "把液体装进瓶子里。";
                }
                public class C025GG1//迷你液泵
                {
                    public static LocString NAME = "迷你液泵";//建筑名
                    public static LocString EFFECT = "小小的身体，大大的能力。利用了流体力学和杠杆学，水将被运送到高高的远方。添加了最新的防漏电技术，再也不用担心触电了。添加了最新的液体检测技术，在没有液体的环境中，避免了设备空转。好产品，请选择“喵喵喵”牌迷你液泵。";//建筑效果
                    public static LocString DESC = "北冥有鱼,其名为鲲。";
                }
                public class C026GG1 // 废液桶
                {
                    public static LocString NAME = "废液桶";
                    public static LocString EFFECT = "自动清除存入其中的液体，小心，不要往里面倒一些奇奇怪怪的液体。";
                    public static LocString DESC = "实木定制，奢华享受。";
                }
                public class C026GG1L2 // 废液桶
                {
                    public static LocString NAME = "废液桶";
                    public static LocString DESC = "实木定制，豪礼豪气。";
                }
                public class C027GG1 // 废气罐
                {
                    public static LocString NAME = "废气罐";
                    public static LocString EFFECT = "自动清除存入其中的气体，小心，不要往里面吹一些奇奇怪怪的气体。";
                    public static LocString DESC = "喜欢吗，请自行购买运费险。";
                }
                public class C029GG1L2 // 迷你黄金气泵
                {
                    public static LocString NAME = "迷你黄金液泵";
                    public static LocString EFFECT = "黄金材质，享受奢华人生。";
                }
                public class C029GG2L2 // 黄金气泵
                {
                    public static LocString NAME = "黄金气泵";
                    public static LocString EFFECT = "黄金材质，享受奢华人生。";
                }
                public class C029GG3L2 // 黄金液泵
                {
                    public static LocString NAME = "黄金液泵";
                    public static LocString EFFECT = "黄金材质，享受奢华人生。";
                }
                public class C029GG4L2 // 黄金户外厕所
                {
                    public static LocString NAME = "黄金户外厕所";
                    public static LocString EFFECT = "黄金材质，享受奢华人生。";
                }
                public class C029GG5L2 // 黄金手压泵
                {
                    public static LocString NAME = "黄金手压泵";
                    public static LocString EFFECT = "黄金材质，享受奢华人生。";
                }
                public class C029GG7L2 // 黄金排气口
                {
                    public static LocString NAME = "黄金排气口";
                    public static LocString EFFECT = "黄金材质，享受奢华人生。";
                }
                public class C029GG8L2 // 黄金排液口
                {
                    public static LocString NAME = "黄金排液口";
                    public static LocString EFFECT = "黄金材质，享受奢华人生。";
                }






            }
        }
    }
}
