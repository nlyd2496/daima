﻿using HarmonyLib;
using PeterHan.PLib.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using static Operational;

namespace C_管道系统_1._0
{
    [HarmonyPatch(typeof(SolidConduitDispenser))]
    [HarmonyPatch("ConduitUpdate")]
    public static class IncreaseConduitCapacity
    {
        private static bool C028GG1 = SingletonOptions<控制台>.Instance.C028GG1;
        private static IEnumerable<CodeInstruction> Transpiler(IEnumerable<CodeInstruction> instructions)
        {
            var codes = new List<CodeInstruction>(instructions);

            for (int i = 0; i < codes.Count; i++)
            {
                if (codes[i].opcode == OpCodes.Ldc_R4 && (float)codes[i].operand == 20f)
                {
                    if (C028GG1)
                    {
                        codes[i].operand = SingletonOptions<控制台>.Instance.C028GG1X1;
                    }
                }
            }
            return codes;
        }
    }


    /*
    [HarmonyPatch(typeof(SolidConduitDispenser))]
    [HarmonyPatch("ConduitUpdate")]
    public static class 运输轨道容量增加
    {
        private static IEnumerable<CodeInstruction> Transpiler(IEnumerable<CodeInstruction> instructions)
        {
            bool C028GG1 = SingletonOptions<控制台>.Instance.C028GG1;
            if (C028GG1)
            {
                var codes = new List<CodeInstruction>(instructions);
                for (int i = 0; i < codes.Count; i++)
                {
                    if (codes[i].opcode == OpCodes.Ldc_R4 && (float)codes[i].operand == 40f)
                    {
                        codes[i].operand = SingletonOptions<控制台>.Instance.C028GG1X1;
                    }
                }
                return codes;
            }
        }
    }
    */
}
