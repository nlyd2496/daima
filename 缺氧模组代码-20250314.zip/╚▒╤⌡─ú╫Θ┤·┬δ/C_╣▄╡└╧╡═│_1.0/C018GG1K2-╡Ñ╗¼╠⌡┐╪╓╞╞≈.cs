﻿using KSerialization;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using STRINGS;

namespace C_管道系统_1._0
{
    public class C018GG1K2 : KMonoBehaviour, ISingleSliderControl, ISliderControl
    {
        public float GetSliderMin(int index) => 1;//最小值
        public float GetSliderMax(int index) => 100;//最大值
        public int SliderDecimalPlaces(int index) => 1;//小数点
        public string SliderUnits => UI.UNITSUFFIXES.MASS.KILOGRAM;//单位
        public string SliderTitleKey => "";//滑块空名称 
        public string GetSliderTooltip(int index) => "";//滑块空名称 
        //--------------------------
        [Serialize] public float AA = 50f;//AA参数默认值
        //--------------------------
        [MyCmpReq] BottleEmptier bottleEmptier;
        internal void Update()
        {
            this.bottleEmptier.emptyRate = this.AA;
        }
        //--------------------------
        //以下内容无需更改
        public float GetSliderValue(int index) => this.AA;
        public string GetSliderTooltipKey(int index) => "";//空
        [MyCmpAdd] public CopyBuildingSettings copyBuildingSettings;
        protected override void OnSpawn() { base.OnSpawn(); this.Update(); }
        public void SetSliderValue(float value, int index) { this.AA = value; this.Update(); }
        protected override void OnPrefabInit() { base.OnPrefabInit(); base.Subscribe(-905833192, new Action<object>(this.OnCopySettings)); }
        internal void OnCopySettings(object data) { var component = ((GameObject)data).GetComponent<C018GG1K2>(); if (component == null) return; AA = component.AA; Update(); }
        //--------------------------
    }
}
