﻿using HarmonyLib;
using PeterHan.PLib.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C_管道系统_1._0
{
    [HarmonyPatch(typeof(ConduitSensorConfig))]
    [HarmonyPatch("CreateBuildingDef")]
    public class 管道检测器可穿墙
    {
        public static void Postfix(ref BuildingDef __result)
        {
            bool C010GG1 = SingletonOptions<控制台>.Instance.C010GG1;
            if (C010GG1)
            {
                __result.BuildLocationRule = BuildLocationRule.Conduit;
            }
        }
    }
}
