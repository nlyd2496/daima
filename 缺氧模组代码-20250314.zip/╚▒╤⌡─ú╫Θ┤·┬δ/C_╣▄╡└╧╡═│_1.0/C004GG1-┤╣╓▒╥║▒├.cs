﻿using Database;
using HarmonyLib;
using PeterHan.PLib.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TUNING;
using UnityEngine;
using static IceCooledFan.States;

namespace C_管道系统_1._0
{
    [HarmonyPatch(typeof(BuildingFacades), MethodType.Constructor, new Type[] { typeof(ResourceSet) })]
    public static class 蓝图系统C004GG1
    {
        public static void Postfix(BuildingFacades __instance)
        {
            bool C004GG1 = SingletonOptions<控制台>.Instance.C004GG1;
            if (C004GG1)
            {
                __instance.Add("C004GG1",
                STRINGS.BUILDINGS.PREFABS.C004GG1.NAME, STRINGS.BUILDINGS.PREFABS.C004GG1.EFFECT, PermitRarity.Universal,
                "LiquidMiniPump", "C004GG1_kanim");
            }
        }
    }
}
