﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace C_管道系统_1._0
{
    [AddComponentMenu("KMonoBehaviour/Workable/C024GG1K0")]
    public class C024GG1K0 : Workable
    {
        protected override void OnSpawn()
        {
            base.OnSpawn();
            this.smi = new C024GG1K0.Controller.Instance(this);
            this.smi.StartSM();
            this.UpdateStoredItemState();
        }
        protected override void OnCleanUp()
        {
            if (this.smi != null)
            {
                this.smi.StopSM("OnCleanUp");
            }
            base.OnCleanUp();
        }
        private void UpdateStoredItemState()
        {
            this.storage.allowItemRemoval = (this.smi != null && this.smi.GetCurrentState() == this.smi.sm.ready);
            foreach (GameObject gameObject in this.storage.items)
            {
                if (gameObject != null)
                {
                    gameObject.Trigger(-778359855, this.storage);
                }
            }
        }
        public Storage storage;
        private C024GG1K0.Controller.Instance smi;
        private class Controller : GameStateMachine<C024GG1K0.Controller, C024GG1K0.Controller.Instance, C024GG1K0>
        {
            public override void InitializeStates(out StateMachine.BaseState default_state)
            {
                default_state = this.empty;
                this.empty.PlayAnim("off").EventTransition(GameHashes.OnStorageChange, this.filling, (C024GG1K0.Controller.Instance smi) => smi.master.storage.IsFull());
                this.filling.PlayAnim("working").OnAnimQueueComplete(this.ready);
                this.ready.EventTransition(GameHashes.OnStorageChange, this.pickup, (C024GG1K0.Controller.Instance smi) => !smi.master.storage.IsFull()).Enter(delegate (C024GG1K0.Controller.Instance smi)
                {
                    smi.master.storage.allowItemRemoval = true;
                    foreach (GameObject gameObject in smi.master.storage.items)
                    {
                        gameObject.GetComponent<KPrefabID>().AddTag(GameTags.GasSource, false);
                        gameObject.Trigger(-778359855, smi.master.storage);
                    }
                }).Exit(delegate (C024GG1K0.Controller.Instance smi)
                {
                    smi.master.storage.allowItemRemoval = false;
                    foreach (GameObject go in smi.master.storage.items)
                    {
                        go.Trigger(-778359855, smi.master.storage);
                    }
                });
                this.pickup.PlayAnim("pick_up").OnAnimQueueComplete(this.empty);
            }
            public GameStateMachine<C024GG1K0.Controller, C024GG1K0.Controller.Instance, C024GG1K0, object>.State empty;
            public GameStateMachine<C024GG1K0.Controller, C024GG1K0.Controller.Instance, C024GG1K0, object>.State filling;
            public GameStateMachine<C024GG1K0.Controller, C024GG1K0.Controller.Instance, C024GG1K0, object>.State ready;
            public GameStateMachine<C024GG1K0.Controller, C024GG1K0.Controller.Instance, C024GG1K0, object>.State pickup;
            public new class Instance : GameStateMachine<C024GG1K0.Controller, C024GG1K0.Controller.Instance, C024GG1K0, object>.GameInstance
            {
                public Instance(C024GG1K0 master) : base(master)
                {
                }
            }
        }
    }
}
