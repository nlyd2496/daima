﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HarmonyLib;
using STRINGS;
using KMod;
using PeterHan.PLib.Core;
using PeterHan.PLib.Database;
using Klei.AI;
using PeterHan.PLib.Options;

namespace R_喜羊羊与灰太狼
{
    public class STRINGS
    {
        public class SIDESCREEN
        {
            public static LocString R008GG1L2A1 = "I will definitely come back"; // 我一定会回来的
        }
        public static void DoReplacement()
        {
            LocString.CreateLocStringKeys(typeof(STRINGS), "");
        }
        [HarmonyPatch(typeof(EntityConfigManager))]
        [HarmonyPatch("LoadGeneratedEntities")]
            
        public class BUILDINGS
        {
            public class PREFABS
            {
                public class R008GG1L2
                {
                    public static LocString NAME = "Pleasant Goat and Big Big Wolf"; // 喜羊羊与灰太狼
                    public static LocString EFFECT = "Delicious little lambs, I'm here, Big Big Big Wolf"; // 美味的小羊们，我灰太狼大王来了
                    public static LocString DESC = "Wow, it's the Grey Wolf King"; // 哇，是灰太狼大王
                }
            }
        }
    }
}
