﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HarmonyLib;
using STRINGS;
using KMod;
using PeterHan.PLib.Core;
using PeterHan.PLib.Database;
using Klei.AI;
using PeterHan.PLib.Options;

namespace J_制氧机
{
    public class STRINGS
    {
        public static void DoReplacement()
        {
            LocString.CreateLocStringKeys(typeof(STRINGS), "");
        }
        public class BUILDINGS
        {
            public class PREFABS
            {
                public class J001GGG1//温度场
                {
                    public static LocString NAME = "制氧机（大众版）";
                    public static LocString EFFECT = "廉价的制氧机，大众喜欢的制氧机。";
                    public static LocString DESC = "“抛去华而不实的外表，剩下的是什么。";
                }
                public class J_UI
                {
                    // public static LocString J001GGG1_UI = "启用优化制氧机";
                    public static LocString J001GGG1X1_UI = "氧气产量";
                    public static LocString J001GGG1X2_UI = "氢气产量";
                }
            }

        }
    }
}
