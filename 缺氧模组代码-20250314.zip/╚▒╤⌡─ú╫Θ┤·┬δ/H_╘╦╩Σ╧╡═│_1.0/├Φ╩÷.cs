﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HarmonyLib;
using STRINGS;
using KMod;
// using PeterHan.PLib.Core;
// using PeterHan.PLib.Database;
using Klei.AI;
// using PeterHan.PLib.Options;

namespace H_运输系统_1._0
{
    public class STRINGS
    {
        public class BUILDINGS
        {
            public class PREFABS
            {
                // 单位
                public class H000GG0
                {
                    public static LocString GAO = "高";
                    public static LocString KUAN = "宽";
                }
                // 火箭炮矿机
                public class H001GG1L2 
                {
                    public static LocString NAME = "无敌大导弹";
                    public static LocString EFFECT = "以炮弹之力，击碎黑暗。";
                }
                // 飞镖矿机
                public class H001GG1L3
                {
                    public static LocString NAME = "无敌大飞镖";
                    public static LocString EFFECT = "以飞镖之力，击碎黑暗。";
                }
                public class H006GG1 // 两格轨道桥
                {
                    public static LocString NAME = "两格轨桥";
                    public static LocString EFFECT = "轨桥下方能够容纳两条独立的轨道而不和轨桥相互干扰。";
                    public static LocString DESC = "优雅，实在是优雅。";
                }
                public class H006GG2 // 三格轨道桥
                {
                    public static LocString NAME = "三格轨桥";
                    public static LocString EFFECT = "轨桥下方能够容纳三条独立的轨道而不和轨桥相互干扰。";
                    public static LocString DESC = "优雅，实在是优雅。";
                }

                public class H_UI
                {
                    public static LocString H000GG1_UI = "启用能量守恒";
                    public static LocString H001GG1_UI = "启用超次元矿机"; 
                    public static LocString H002GG1_UI = "启用超级开发者固体泵";
                    public static LocString H003GG1_UI = "启用矿机优化";
                    public static LocString H004GG1_UI = "启用运输轨道容量增加";
                    public static LocString H004GG1X1_UI = "运输轨道容量（Kg）";
                    public static LocString H005GG1_UI = "启用自动清扫器优化";
                    public static LocString H006GG1_UI = "启用两格轨桥";
                    public static LocString H006GG2_UI = "启用三格轨桥";



                }
            }
        }
    }
}