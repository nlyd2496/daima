﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TUNING;
using UnityEngine;

namespace H_运输系统_1._0
{
    public class H006GG2 : IBuildingConfig
    {
        public override BuildingDef CreateBuildingDef()
        {
            string id = "H006GG2";
            int width = 5;
            int height = 1;
            string anim = "H006GG2_kanim";
            int hitpoints = 10;
            float construction_time = 30f;
            float[] tier = BUILDINGS.CONSTRUCTION_MASS_KG.TIER4;
            string[] all_METALS = MATERIALS.ALL_METALS;
            float melting_point = 1600f;
            BuildLocationRule build_location_rule = BuildLocationRule.Conduit;
            EffectorValues none = NOISE_POLLUTION.NONE;
            BuildingDef buildingDef = BuildingTemplates.CreateBuildingDef(id, width, height, anim, hitpoints, construction_time, tier, all_METALS, melting_point, build_location_rule, BUILDINGS.DECOR.NONE, none, 0.2f);
            buildingDef.ObjectLayer = ObjectLayer.SolidConduitConnection;
            buildingDef.SceneLayer = Grid.SceneLayer.SolidConduitBridges;
            buildingDef.InputConduitType = ConduitType.Solid;
            buildingDef.OutputConduitType = ConduitType.Solid;
            buildingDef.Floodable = false;
            buildingDef.Entombable = false;
            buildingDef.Overheatable = false;
            buildingDef.ViewMode = OverlayModes.SolidConveyor.ID;
            buildingDef.AudioCategory = "Metal";
            buildingDef.AudioSize = "small";
            buildingDef.BaseTimeUntilRepair = -1f;
            buildingDef.PermittedRotations = PermittedRotations.R360;
            buildingDef.UtilityInputOffset = new CellOffset(-2, 0);
            buildingDef.UtilityOutputOffset = new CellOffset(2, 0);
            GeneratedBuildings.RegisterWithOverlay(OverlayScreen.SolidConveyorIDs, "H006GG2");
            //--------------------------
            if (控制台.Instance.H006GG2) { buildingDef.Deprecated = false; } else { buildingDef.Deprecated = true; }
            //--------------------------
            return buildingDef;
        }
        public override void ConfigureBuildingTemplate(GameObject go, Tag prefab_tag)
        {
            GeneratedBuildings.MakeBuildingAlwaysOperational(go);
            BuildingConfigManager.Instance.IgnoreDefaultKComponent(typeof(RequiresFoundation), prefab_tag);
        }
        public override void DoPostConfigureUnderConstruction(GameObject go)
        {
            base.DoPostConfigureUnderConstruction(go);
            go.GetComponent<Constructable>().requiredSkillPerk = Db.Get().SkillPerks.ConveyorBuild.Id;
        }
        public override void DoPostConfigureComplete(GameObject go)
        {
            go.AddOrGet<SolidConduitBridge>();
        }
        public const string ID = "H006GG2";
        private const ConduitType CONDUIT_TYPE = ConduitType.Solid;
    }
}
