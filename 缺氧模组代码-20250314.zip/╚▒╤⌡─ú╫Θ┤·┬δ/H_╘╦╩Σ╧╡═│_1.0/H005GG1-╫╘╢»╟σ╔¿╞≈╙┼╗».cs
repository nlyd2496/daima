﻿using HarmonyLib;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace H_运输系统_1._0
{
    [HarmonyPatch(typeof(SolidTransferArmConfig), "DoPostConfigureComplete")]
    public class 自动化清扫器优化
    {
        public static void Postfix(GameObject go)
        {
            go.AddOrGet<H005GG1K1>();
        }
    }
}
