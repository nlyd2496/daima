﻿using Database;
using HarmonyLib;
using PeterHan.PLib.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H_运输系统_1._0
{
    [HarmonyPatch(typeof(BuildingFacades), MethodType.Constructor, new Type[] { typeof(ResourceSet) })]
    public static class 挖矿机蓝图
    {
        public static void Postfix(BuildingFacades __instance)
        {
            bool H001GG1 = SingletonOptions<控制台>.Instance.H001GG1;
            if (H001GG1)
            {
                // 火炮
                __instance.Add(
                    "H001GG1L2",
                    STRINGS.BUILDINGS.PREFABS.H001GG1L2.NAME,
                    STRINGS.BUILDINGS.PREFABS.H001GG1L2.EFFECT,
                    PermitRarity.Universal,
                    "AutoMiner",
                    "H001GG1L2_kanim"
                    );

                // 飞镖
                __instance.Add(
                    "H001GG1L3",
                    STRINGS.BUILDINGS.PREFABS.H001GG1L3.NAME,
                    STRINGS.BUILDINGS.PREFABS.H001GG1L3.EFFECT,
                    PermitRarity.Universal,
                    "AutoMiner",
                    "H001GG1L3_kanim"
                    );
            }
        }
    }
}
