﻿using HarmonyLib;
using KSerialization;
using PeterHan.PLib.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace H_运输系统_1._0
{
    //--------------------------
    [HarmonyPatch(typeof(AutoMinerConfig))]
    [HarmonyPatch("DoPostConfigureComplete")]
    public static class 挖机挖掘范围
    {
        public static void Postfix(GameObject go)
        {
            bool H003GG1 = SingletonOptions<控制台>.Instance.H003GG1;
            if (H003GG1)
            {


                go.AddOrGet<H003GG1K1>();
            }
        }
    }

    [HarmonyPatch(typeof(AutoMinerConfig))]
    [HarmonyPatch("CreateBuildingDef")]
    public class 挖机基础属性
    {
        public static void Postfix(ref BuildingDef __result)
        {
            bool H003GG1 = SingletonOptions<控制台>.Instance.H003GG1;
            if (H003GG1)
            {
                __result.Overheatable = false;
                __result.Floodable = false;
            }
        }
    }
    //--------------------------
    [HarmonyPatch(typeof(AutoMiner))]
    [HarmonyPatch("DigBlockingCB")]
    public static class 挖机挖掘硬度设置一
    {
        private static void Postfix(int cell, ref bool __result)
        {
            bool H003GG1 = SingletonOptions<控制台>.Instance.H003GG1;
            if (H003GG1)
            {
                __result = (Grid.Foundation[cell] || Grid.Element[cell].hardness >= byte.MaxValue);
            }
        }
    }
    //--------------------------
    [HarmonyPatch(typeof(AutoMiner))]
    [HarmonyPatch("ValidDigCell")]
    public static class 挖机挖掘硬度设置二
    {
        private static void Postfix(int cell, ref bool __result)
        {
            bool H003GG1 = SingletonOptions<控制台>.Instance.H003GG1;
            if (H003GG1)
            {
                __result = (Grid.Solid[cell] && !Grid.Foundation[cell] && Grid.Element[cell].hardness < byte.MaxValue);
            }
        }
    }
}
