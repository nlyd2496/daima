﻿using HarmonyLib;
using PeterHan.PLib.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;

namespace H_运输系统_1._0
{
    [HarmonyPatch(typeof(SolidConduitDispenser))]
    [HarmonyPatch("ConduitUpdate")]
    public static class 修改方法
    {
        private static bool H004GG1 = SingletonOptions<控制台>.Instance.H004GG1;
        private static IEnumerable<CodeInstruction> Transpiler(IEnumerable<CodeInstruction> instructions)
        {
            var codes = new List<CodeInstruction>(instructions);

            for (int i = 0; i < codes.Count; i++)
            {
                if (codes[i].opcode == OpCodes.Ldc_R4 && (float)codes[i].operand == 20f)
                {
                    if (H004GG1)
                    {
                        codes[i].operand = SingletonOptions<控制台>.Instance.H004GG1X1;
                    }
                }
            }
            return codes;
        }
    }
}
