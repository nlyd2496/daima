﻿using Newtonsoft.Json;
using PeterHan.PLib.Options;


namespace S_杂交水稻
{
    [RestartRequired]
    [JsonObject(MemberSerialization.OptIn)]
    [ConfigFile("J001GG1.json", true, false)]
    // [ModInfo("https://space.bilibili.com/30725645", "mmm.png", true)]

    public class 控制台 : SingletonOptions<控制台>
    {
        [Option("泥土", "Dirt", null)]
        [Limit(0.0, 1.0)]
        [JsonProperty]
        public float a1 { get; set; } = 0.01f;
        //---------------------------------------------------------------------------------------------------
        [Option("时间（x100)", "Time(x100）", null, Format = "F0")]
        [Limit(1.0, 10.0)]
        [JsonProperty]
        public float a2 { get; set; } = 1;
        //---------------------------------------------------------------------------------------------------
        [Option("米虱", "Rice lice", null)]
        [Limit(1.0, 10.0)]
        [JsonProperty]
        public float a3 { get; set; } = 10;
    }
}
