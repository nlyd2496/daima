﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HarmonyLib;
using PeterHan.PLib.Options;
using UnityEngine;
using STRINGS;
using TUNING;
using KMod;



namespace S_杂交水稻
{
    public class Patches
	{
        //-----------------------------------------------------------------------------------------------------
        [HarmonyPatch(typeof(BasicSingleHarvestPlantConfig))]
        [HarmonyPatch("CreatePrefab")]
        public static class Patch_a
        {
            public static void Postfix(GameObject __result)
            {
                //--------------------------------------------------------------------------------
                EntityTemplates.ExtendPlantToFertilizable(__result, new PlantElementAbsorber.ConsumeInfo[]
                {
                     new PlantElementAbsorber.ConsumeInfo
                     {
                          tag = GameTags.Dirt,
                          massConsumptionRate = SingletonOptions<控制台>.Instance.a1//需要泥土量设置
                     }
                });
                //--------------------------------------------------------------------------------
                float temperature_lethal_low = 123.15f;//死亡低温-150
                float temperature_warning_low = 173.15f;//宜温下限-100
                float temperature_warning_high = 373.15f;//宜温上限100
                float temperature_lethal_high = 423.15f;//死亡高温150
                //--------------------------------------------------------------------------------
                EntityTemplates.ExtendEntityToBasicPlant(__result, 
                temperature_lethal_low, temperature_warning_low, temperature_warning_high, temperature_lethal_high, new SimHashes[]
                {
                SimHashes.Oxygen,//氧气
                SimHashes.ContaminatedOxygen,//污染氧
                SimHashes.CarbonDioxide,//二氧化碳
                SimHashes.Hydrogen,//氢气
                SimHashes.Methane,//甲烷
                SimHashes.ChlorineGas//氯气
                }
                 , false, 0f, 0.15f, "BasicPlantFood", true, false, true, false, 2400f, 0f, 4600f, "BasicSingleHarvestPlantOriginal", 
                STRINGS.CREATURES.SPECIES.BASICSINGLEHARVESTPLANT.NAME);
                //--------------------------------------------------------------------------------
            }
        }


        //-----------------------------------------------------------------------------------------------------
        [HarmonyPatch(typeof(Db))]
        [HarmonyPatch("Initialize")]
        public class Patch_b
        {
            private static void Prefix() // 米虱生长速度
            {
                // 获取现有的CROP_TYPES列表
                List<Crop.CropVal> existingCrops = CROPS.CROP_TYPES;

                // 查找并修改特定植物的信息
                for (int i = 0; i < existingCrops.Count; i++)
                {
                    if (existingCrops[i].cropId == "BasicPlantFood")
                    {
                        existingCrops[i] = new Crop.CropVal("BasicPlantFood", (float)SingletonOptions<控制台>.Instance.a2 * 100f, (int)SingletonOptions<控制台>.Instance.a3, true);
                        break;
                    }
                }

                // 更新CROP_TYPES列表
                CROPS.CROP_TYPES = existingCrops;


                FOOD.FOOD_TYPES.BASICPLANTFOOD.CanRot = false;//米虱永不腐烂
                FOOD.FOOD_TYPES.BASICPLANTBAR.CanRot = false; //米虱面包不腐烂
                FOOD.FOOD_TYPES.PICKLEDMEAL.CanRot = false;//腌制米虱不腐烂
                FOOD.FOOD_TYPES.BASICPLANTFOOD.Quality = 6;//米虱品质4
                FOOD.FOOD_TYPES.BASICPLANTBAR.Quality = 6; //米虱面包品质4
                FOOD.FOOD_TYPES.PICKLEDMEAL.Quality = 6;//腌制米虱品质4
            }
        }


    }
}