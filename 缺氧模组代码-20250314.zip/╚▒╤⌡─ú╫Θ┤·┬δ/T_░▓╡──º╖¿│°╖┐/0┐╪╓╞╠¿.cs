﻿using Newtonsoft.Json;
using PeterHan.PLib.Options;


namespace T_安的魔法厨房
{
    [RestartRequired]
    [JsonObject(MemberSerialization.OptIn)]
    [ConfigFile("Controler.json", true, false)]
    [ModInfo("https://space.bilibili.com/30725645", "mmm.png", true)]

    public class 控制台 : SingletonOptions<控制台>
    {
        // 新植物
        [Option("生长周期", "生长周期", "辣椒", Format = "F0")][Limit(1, 100)][JsonProperty] public float T001GG1Z3 { get; set; } = 3;
        [Option("生长周期", "生长周期", "花椒", Format = "F0")][Limit(1, 100)][JsonProperty] public float T002GG1Z3 { get; set; } = 3;
        [Option("生长周期", "生长周期", "香蕉", Format = "F0")][Limit(1, 100)][JsonProperty] public float T003GG1Z3 { get; set; } = 3;
        [Option("生长周期", "生长周期", "西红柿", Format = "F0")][Limit(1, 100)][JsonProperty] public float T004GG1Z3 { get; set; } = 3;
        [Option("生长周期", "生长周期", "白菜", Format = "F0")][Limit(1, 100)][JsonProperty] public float T005GG1Z3 { get; set; } = 3;
        [Option("生长周期", "生长周期", "西瓜", Format = "F0")][Limit(1, 100)][JsonProperty] public float T006GG1Z3 { get; set; } = 3;



        // 冰淇淋
        [Option("质量", "-1差，6最美味", "冰淇淋", Format = "F0")][Limit(-1, 6)][JsonProperty] public float U001GG1S1X1 { get; set; } = 4;
        [Option("保存温度", "保存温度低于腐烂温度", "冰淇淋", Format = "F0")][Limit(-60, 0)][JsonProperty] public float U001GG1S1X2 { get; set; } = -10;
        [Option("腐烂温度", "腐烂温度高于保存温度", "冰淇淋", Format = "F0")][Limit(0, 60)][JsonProperty] public float U001GG1S1X3 { get; set; } = 10;
        [Option("腐烂时间", "1代表一个周期", "冰淇淋", Format = "F0")][Limit(1, 60)][JsonProperty] public float U001GG1S1X4 { get; set; } = 3;
        [Option("不会腐烂", "选择这一项后，上三项功能失效", "冰淇淋")][JsonProperty] public bool U001GG1S1X5 { get; set; } = false;
        [Option("冰为灵魂食物", "灵魂食物，DLC限定", "冰淇淋")][JsonProperty] public bool U001GG1S1X6 { get; set; } = true;
        // 冰皮月饼
        [Option("质量", "-1差，6最美味", "冰皮月饼", Format = "F0")][Limit(-1, 6)][JsonProperty] public float U002GG1S1X1 { get; set; } = 6;
        [Option("保存温度", "保存温度低于腐烂温度", "冰皮月饼", Format = "F0")][Limit(-60, 0)][JsonProperty] public float U002GG1S1X2 { get; set; } = -10;
        [Option("腐烂温度", "腐烂温度高于保存温度", "冰皮月饼", Format = "F0")][Limit(0, 60)][JsonProperty] public float U002GG1S1X3 { get; set; } = 20;
        [Option("腐烂时间", "1代表一个周期", "冰皮月饼", Format = "F0")][Limit(1, 60)][JsonProperty] public float U002GG1S1X4 { get; set; } = 5;
        [Option("不会腐烂", "选择这一项后，上三项功能失效", "冰皮月饼")][JsonProperty] public bool U002GG1S1X5 { get; set; } = false;
        [Option("灵魂食物", "灵魂食物，DLC限定", "冰皮月饼")][JsonProperty] public bool U002GG1S1X6 { get; set; } = true;
        // 鲜花月饼
        [Option("质量", "-1差，6最美味", "鲜花月饼", Format = "F0")][Limit(-1, 6)][JsonProperty] public float U002GG2X1 { get; set; } = 6;
        [Option("保存温度", "保存温度低于腐烂温度", "鲜花月饼", Format = "F0")][Limit(-60, 0)][JsonProperty] public float U002GG2X2 { get; set; } = -10;
        [Option("腐烂温度", "腐烂温度高于保存温度", "鲜花月饼", Format = "F0")][Limit(0, 60)][JsonProperty] public float U002GG2X3 { get; set; } = 20;
        [Option("腐烂时间", "1代表一个周期", "鲜花月饼", Format = "F0")][Limit(1, 60)][JsonProperty] public float U002GG2X4 { get; set; } = 5;
        [Option("不会腐烂", "选择这一项后，上三项功能失效", "鲜花月饼")][JsonProperty] public bool U002GG2X5 { get; set; } = false;
        [Option("灵魂食物", "灵魂食物，DLC限定", "鲜花月饼")][JsonProperty] public bool U002GG2X6 { get; set; } = true;
        // 鲜肉月饼
        [Option("质量", "-1差，6最美味", "鲜肉月饼", Format = "F0")][Limit(-1, 6)][JsonProperty] public float U002GG3X1 { get; set; } = 5;
        [Option("保存温度", "保存温度低于腐烂温度", "鲜肉月饼", Format = "F0")][Limit(-60, 0)][JsonProperty] public float U002GG3X2 { get; set; } = -10;
        [Option("腐烂温度", "腐烂温度高于保存温度", "鲜肉月饼", Format = "F0")][Limit(0, 60)][JsonProperty] public float U002GG3X3 { get; set; } = 20;
        [Option("腐烂时间", "1代表一个周期", "鲜肉月饼", Format = "F0")][Limit(1, 60)][JsonProperty] public float U002GG3X4 { get; set; } = 5;
        [Option("不会腐烂", "选择这一项后，上三项功能失效", "鲜肉月饼")][JsonProperty] public bool U002GG3X5 { get; set; } = false;
        [Option("灵魂食物", "灵魂食物，DLC限定", "鲜肉月饼")][JsonProperty] public bool U002GG3X6 { get; set; } = false;
        // 芝麻月饼
        [Option("质量", "-1差，6最美味", "芝麻月饼", Format = "F0")][Limit(-1, 6)][JsonProperty] public float U002GG4X1 { get; set; } = 5;
        [Option("保存温度", "保存温度低于腐烂温度", "芝麻月饼", Format = "F0")][Limit(-60, 0)][JsonProperty] public float U002GG4X2 { get; set; } = -10;
        [Option("腐烂温度", "腐烂温度高于保存温度", "芝麻月饼", Format = "F0")][Limit(0, 60)][JsonProperty] public float U002GG4X3 { get; set; } = 20;
        [Option("腐烂时间", "1代表一个周期", "芝麻月饼", Format = "F0")][Limit(1, 60)][JsonProperty] public float U002GG4X4 { get; set; } = 5;
        [Option("不会腐烂", "选择这一项后，上三项功能失效", "芝麻月饼")][JsonProperty] public bool U002GG4X5 { get; set; } = false;
        [Option("灵魂食物", "灵魂食物，DLC限定", "芝麻月饼")][JsonProperty] public bool U002GG4X6 { get; set; } = false;
        // 菜饺子
        [Option("质量", "-1差，6最美味", "菜饺子", Format = "F0")][Limit(-1, 6)][JsonProperty] public float U003GG1X1 { get; set; } = 3;
        [Option("保存温度", "保存温度低于腐烂温度", "菜饺子", Format = "F0")][Limit(-60, 0)][JsonProperty] public float U003GG1X2 { get; set; } = -10;
        [Option("腐烂温度", "腐烂温度高于保存温度", "菜饺子", Format = "F0")][Limit(0, 60)][JsonProperty] public float U003GG1X3 { get; set; } = 0;
        [Option("腐烂时间", "1代表一个周期", "菜饺子", Format = "F0")][Limit(1, 60)][JsonProperty] public float U003GG1X4 { get; set; } = 2;
        [Option("不会腐烂", "选择这一项后，上三项功能失效", "菜饺子")][JsonProperty] public bool U003GG1X5 { get; set; } = false;
        [Option("灵魂食物", "灵魂食物，DLC限定", "菜饺子")][JsonProperty] public bool U003GG1X6 { get; set; } = false;
        // 肉馅饺子
        [Option("质量", "-1差，6最美味", "肉馅饺子", Format = "F0")][Limit(-1, 6)][JsonProperty] public float U003GG2X1 { get; set; } = 4;
        [Option("保存温度", "保存温度低于腐烂温度", "肉馅饺子", Format = "F0")][Limit(-60, 0)][JsonProperty] public float U003GG2X2 { get; set; } = -10;
        [Option("腐烂温度", "腐烂温度高于保存温度", "肉馅饺子", Format = "F0")][Limit(0, 60)][JsonProperty] public float U003GG2X3 { get; set; } = 0;
        [Option("腐烂时间", "1代表一个周期", "肉馅饺子", Format = "F0")][Limit(1, 60)][JsonProperty] public float U003GG2X4 { get; set; } = 2;
        [Option("不会腐烂", "选择这一项后，上三项功能失效", "肉馅饺子")][JsonProperty] public bool U003GG2X5 { get; set; } = false;
        [Option("灵魂食物", "灵魂食物，DLC限定", "肉馅饺子")][JsonProperty] public bool U003GG2X6 { get; set; } = false;
        // 豆花饭
        [Option("质量", "-1差，6最美味", "豆花饭", Format = "F0")][Limit(-1, 6)][JsonProperty] public float U004GG1X1 { get; set; } = 6;
        [Option("保存温度", "保存温度低于腐烂温度", "豆花饭", Format = "F0")][Limit(-60, 0)][JsonProperty] public float U004GG1X2 { get; set; } = -10;
        [Option("腐烂温度", "腐烂温度高于保存温度", "豆花饭", Format = "F0")][Limit(0, 60)][JsonProperty] public float U004GG1X3 { get; set; } = 0;
        [Option("腐烂时间", "1代表一个周期", "豆花饭", Format = "F0")][Limit(1, 60)][JsonProperty] public float U004GG1X4 { get; set; } = 2;
        [Option("不会腐烂", "选择这一项后，上三项功能失效", "豆花饭")][JsonProperty] public bool U004GG1X5 { get; set; } = false;
        [Option("灵魂食物", "灵魂食物，DLC限定", "豆花饭")][JsonProperty] public bool U004GG1X6 { get; set; } = true;
        // 炒辣椒
        [Option("质量", "-1差，6最美味", "炒辣椒", Format = "F0")][Limit(-1, 6)][JsonProperty] public float U004GG2X1 { get; set; } = 5;
        [Option("保存温度", "保存温度低于腐烂温度", "炒辣椒", Format = "F0")][Limit(-60, 0)][JsonProperty] public float U004GG2X2 { get; set; } = -10;
        [Option("腐烂温度", "腐烂温度高于保存温度", "炒辣椒", Format = "F0")][Limit(0, 60)][JsonProperty] public float U004GG2X3 { get; set; } = 0;
        [Option("腐烂时间", "1代表一个周期", "炒辣椒", Format = "F0")][Limit(1, 60)][JsonProperty] public float U004GG2X4 { get; set; } = 2;
        [Option("不会腐烂", "选择这一项后，上三项功能失效", "炒辣椒")][JsonProperty] public bool U004GG2X5 { get; set; } = false;
        [Option("灵魂食物", "灵魂食物，DLC限定", "炒辣椒")][JsonProperty] public bool U004GG2X6 { get; set; } = false;
        // 辣椒炒肉
        [Option("质量", "-1差，6最美味", "辣椒炒肉", Format = "F0")][Limit(-1, 6)][JsonProperty] public float U004GG3X1 { get; set; } = 4;
        [Option("保存温度", "保存温度低于腐烂温度", "辣椒炒肉", Format = "F0")][Limit(-60, 0)][JsonProperty] public float U004GG3X2 { get; set; } = -10;
        [Option("腐烂温度", "腐烂温度高于保存温度", "辣椒炒肉", Format = "F0")][Limit(0, 60)][JsonProperty] public float U004GG3X3 { get; set; } = 0;
        [Option("腐烂时间", "1代表一个周期", "辣椒炒肉", Format = "F0")][Limit(1, 60)][JsonProperty] public float U004GG3X4 { get; set; } = 2;
        [Option("不会腐烂", "选择这一项后，上三项功能失效", "辣椒炒肉")][JsonProperty] public bool U004GG3X5 { get; set; } = false;
        [Option("灵魂食物", "灵魂食物，DLC限定", "辣椒炒肉")][JsonProperty] public bool U004GG3X6 { get; set; } = false;
        // 麻辣烫
        [Option("质量", "-1差，6最美味", "麻辣烫", Format = "F0")][Limit(-1, 6)][JsonProperty] public float U004GG4X1 { get; set; } = 6;
        [Option("保存温度", "保存温度低于腐烂温度", "麻辣烫", Format = "F0")][Limit(-60, 0)][JsonProperty] public float U004GG4X2 { get; set; } = -10;
        [Option("腐烂温度", "腐烂温度高于保存温度", "麻辣烫", Format = "F0")][Limit(0, 60)][JsonProperty] public float U004GG4X3 { get; set; } = 0;
        [Option("腐烂时间", "1代表一个周期", "麻辣烫", Format = "F0")][Limit(1, 60)][JsonProperty] public float U004GG4X4 { get; set; } = 2;
        [Option("不会腐烂", "选择这一项后，上三项功能失效", "麻辣烫")][JsonProperty] public bool U004GG4X5 { get; set; } = false;
        [Option("灵魂食物", "灵魂食物，DLC限定", "麻辣烫")][JsonProperty] public bool U004GG4X6 { get; set; } = true;
        // 水煮鱼
        [Option("质量", "-1差，6最美味", "水煮鱼", Format = "F0")][Limit(-1, 6)][JsonProperty] public float U004GG5X1 { get; set; } = 4;
        [Option("保存温度", "保存温度低于腐烂温度", "水煮鱼", Format = "F0")][Limit(-60, 0)][JsonProperty] public float U004GG5X2 { get; set; } = -20;
        [Option("腐烂温度", "腐烂温度高于保存温度", "水煮鱼", Format = "F0")][Limit(0, 60)][JsonProperty] public float U004GG5X3 { get; set; } = 0;
        [Option("腐烂时间", "1代表一个周期", "水煮鱼", Format = "F0")][Limit(1, 60)][JsonProperty] public float U004GG5X4 { get; set; } = 2;
        [Option("不会腐烂", "选择这一项后，上三项功能失效", "水煮鱼")][JsonProperty] public bool U004GG5X5 { get; set; } = false;
        [Option("灵魂食物", "灵魂食物，DLC限定", "水煮鱼")][JsonProperty] public bool U004GG5X6 { get; set; } = false;
        // 鸡蛋奶油
        [Option("质量", "-1差，6最美味", "鸡蛋奶油", Format = "F0")][Limit(-1, 6)][JsonProperty] public float U005GG1X1 { get; set; } = 3;
        [Option("保存温度", "保存温度低于腐烂温度", "鸡蛋奶油", Format = "F0")][Limit(-60, 0)][JsonProperty] public float U005GG1X2 { get; set; } = -10;
        [Option("腐烂温度", "腐烂温度高于保存温度", "鸡蛋奶油", Format = "F0")][Limit(0, 60)][JsonProperty] public float U005GG1X3 { get; set; } = 0;
        [Option("腐烂时间", "1代表一个周期", "鸡蛋奶油", Format = "F0")][Limit(1, 60)][JsonProperty] public float U005GG1X4 { get; set; } = 2;
        [Option("不会腐烂", "选择这一项后，上三项功能失效", "鸡蛋奶油")][JsonProperty] public bool U005GG1X5 { get; set; } = false;
        [Option("为灵魂食物", "灵魂食物，DLC限定", "鸡蛋奶油")][JsonProperty] public bool U005GG1X6 { get; set; } = false;

        // 面粉
        [Option("保存温度", "保存温度低于腐烂温度", "面粉", Format = "F0")][Limit(-60, 0)][JsonProperty] public float U006GG1X2 { get; set; } = -10;
        [Option("腐烂温度", "腐烂温度高于保存温度", "面粉", Format = "F0")][Limit(0, 60)][JsonProperty] public float U006GG1X3 { get; set; } = 0;
        [Option("腐烂时间", "1代表一个周期", "面粉", Format = "F0")][Limit(1, 60)][JsonProperty] public float U006GG1X4 { get; set; } = 10;
        // 大米
        [Option("保存温度", "保存温度低于腐烂温度", "大米", Format = "F0")][Limit(-60, 0)][JsonProperty] public float U006GG2X2 { get; set; } = -10;
        [Option("腐烂温度", "腐烂温度高于保存温度", "大米", Format = "F0")][Limit(0, 60)][JsonProperty] public float U006GG2X3 { get; set; } = 0;
        [Option("腐烂时间", "1代表一个周期", "大米", Format = "F0")][Limit(1, 60)][JsonProperty] public float U006GG2X4 { get; set; } = 10;

        // 油团
        [Option("质量", "-1差，6最美味", "油团", Format = "F0")][Limit(-1, 6)][JsonProperty] public float U007GG1X1 { get; set; } = 2;
        [Option("保存温度", "保存温度低于腐烂温度", "油团", Format = "F0")][Limit(-60, 0)][JsonProperty] public float U007GG1X2 { get; set; } = -10;
        [Option("腐烂温度", "腐烂温度高于保存温度", "油团", Format = "F0")][Limit(0, 60)][JsonProperty] public float U007GG1X3 { get; set; } = 0;
        [Option("腐烂时间", "1代表一个周期", "油团", Format = "F0")][Limit(1, 60)][JsonProperty] public float U007GG1X4 { get; set; } = 2;
        [Option("不会腐烂", "选择这一项后，上三项功能失效", "油团")][JsonProperty] public bool U007GG1X5 { get; set; } = false;
        [Option("为灵魂食物", "灵魂食物，DLC限定", "油团")][JsonProperty] public bool U007GG1X6 { get; set; } = false;





    }
}
