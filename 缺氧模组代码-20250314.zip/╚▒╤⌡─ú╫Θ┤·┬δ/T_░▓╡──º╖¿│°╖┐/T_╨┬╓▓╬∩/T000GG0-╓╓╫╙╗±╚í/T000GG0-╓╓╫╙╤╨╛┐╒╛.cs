﻿using PeterHan.PLib.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TUNING;
using UnityEngine;
using static CaiLib.Utils.CarePackagesUtils;
using static CaiLib.Utils.PlantUtils;
using static CaiLib.Utils.RecipeUtils;
using static CaiLib.Utils.StringUtils;

namespace T_安的魔法厨房.T_新植物.T000GG0_种子获取
{
    public class T000GG0 : IBuildingConfig
    {
        public override BuildingDef CreateBuildingDef()
        {
            string id = "T000GG0";
            int width = 3;
            int height = 3;
            string anim = "T000GG0_kanim";
            int hitpoints = 1000;
            float construction_time = 60f;
            float[] construction_mass = new float[] { 200f };
            string[] any_BUILDABLE = MATERIALS.ANY_BUILDABLE;
            float melting_point = 9999f;
            BuildLocationRule build_location_rule = BuildLocationRule.OnFloor;
            EffectorValues none = NOISE_POLLUTION.NONE;
            BuildingDef buildingDef = BuildingTemplates.CreateBuildingDef(id, width, height, anim, hitpoints, construction_time, construction_mass, any_BUILDABLE, melting_point, build_location_rule, new EffectorValues
            {
                amount = 2,
                radius = 2
            }, none, 0.2f);
            buildingDef.Floodable = false;
            buildingDef.Overheatable = false;
            buildingDef.RequiresPowerInput = true;
            buildingDef.EnergyConsumptionWhenActive = 100f;
            buildingDef.ExhaustKilowattsWhenActive = 0.1f;
            buildingDef.PermittedRotations = PermittedRotations.FlipH;
            buildingDef.LogicInputPorts = LogicOperationalController.CreateSingleInputPortList(new CellOffset(0, 0));
            //--------------------------
            //if (控制台.Instance.T000GG0) { buildingDef.Deprecated = false; } else { buildingDef.Deprecated = true; }
            //--------------------------
            return buildingDef;
        }
        private void ConfigureRecipes()
        {

            //------------------------------------------------------------辣椒------------------------------------------------------------
            AddComplexRecipe(
                input:  new[] { new ComplexRecipe.RecipeElement(BasicPlantFoodConfig.ID.ToTag(), 3f) }, // 米風木
                output: new[] { new ComplexRecipe.RecipeElement(TagManager.Create("T001GG1Z1"), 1f) }, // 种子
                fabricatorId: "T000GG0",//配方制造器ID
                productionTime: 50f,//制作时间（s）
                recipeDescription: STRINGS.CREATURES.SPECIES.T001GG1Z1.B8,//配方描述
                nameDisplayType: ComplexRecipe.RecipeNameDisplay.Result,//配方显示类型
                sortOrder: 1//配方排序顺序
            );
            //------------------------------------------------------------花椒------------------------------------------------------------
            AddComplexRecipe(
                input: new[] { new ComplexRecipe.RecipeElement(BasicPlantFoodConfig.ID.ToTag(), 1f) }, // 米風木
                output: new[] { new ComplexRecipe.RecipeElement(TagManager.Create("T002GG1Z1"), 1f) }, // 种子
                fabricatorId: "T000GG0",//配方制造器ID
                productionTime: 50f,//制作时间（s）
                recipeDescription: STRINGS.CREATURES.SPECIES.T002GG1Z1.B8,//配方描述
                nameDisplayType: ComplexRecipe.RecipeNameDisplay.Result,//配方显示类型
                sortOrder: 2//配方排序顺序
            );
            //------------------------------------------------------------香蕉------------------------------------------------------------
            AddComplexRecipe(
                input: new[] { new ComplexRecipe.RecipeElement(BasicPlantFoodConfig.ID.ToTag(), 1f) }, // 米風木
                output: new[] { new ComplexRecipe.RecipeElement(TagManager.Create("T003GG1Z1"), 1f) }, // 种子
                fabricatorId: "T000GG0",//配方制造器ID
                productionTime: 50f,//制作时间（s）
                recipeDescription: STRINGS.CREATURES.SPECIES.T003GG1Z1.B8,//配方描述
                nameDisplayType: ComplexRecipe.RecipeNameDisplay.Result,//配方显示类型
                sortOrder: 2//配方排序顺序
            );
            //------------------------------------------------------------西红柿------------------------------------------------------------
            AddComplexRecipe(
                input: new[] { new ComplexRecipe.RecipeElement(BasicPlantFoodConfig.ID.ToTag(), 1f) }, // 米風木
                output: new[] { new ComplexRecipe.RecipeElement(TagManager.Create("T004GG1Z1"), 1f) }, // 种子
                fabricatorId: "T000GG0",//配方制造器ID
                productionTime: 50f,//制作时间（s）
                recipeDescription: STRINGS.CREATURES.SPECIES.T004GG1Z1.B8,//配方描述
                nameDisplayType: ComplexRecipe.RecipeNameDisplay.Result,//配方显示类型
                sortOrder: 2//配方排序顺序
            );
            //------------------------------------------------------------白菜------------------------------------------------------------
            AddComplexRecipe(
                input: new[] { new ComplexRecipe.RecipeElement(BasicPlantFoodConfig.ID.ToTag(), 1f) }, // 米風木
                output: new[] { new ComplexRecipe.RecipeElement(TagManager.Create("T005GG1Z1"), 1f) }, // 种子
                fabricatorId: "T000GG0",//配方制造器ID
                productionTime: 50f,//制作时间（s）
                recipeDescription: STRINGS.CREATURES.SPECIES.T005GG1Z1.B8,//配方描述
                nameDisplayType: ComplexRecipe.RecipeNameDisplay.Result,//配方显示类型
                sortOrder: 2//配方排序顺序
            );
            //------------------------------------------------------------西瓜------------------------------------------------------------
            AddComplexRecipe(
                input: new[] { new ComplexRecipe.RecipeElement(BasicPlantFoodConfig.ID.ToTag(), 1f) }, // 米風木
                output: new[] { new ComplexRecipe.RecipeElement(TagManager.Create("T006GG1Z1"), 1f) }, // 种子
                fabricatorId: "T000GG0",//配方制造器ID
                productionTime: 50f,//制作时间（s）
                recipeDescription: STRINGS.CREATURES.SPECIES.T005GG1Z1.B8,//配方描述
                nameDisplayType: ComplexRecipe.RecipeNameDisplay.Result,//配方显示类型
                sortOrder: 2//配方排序顺序
            );

        }
        public override void ConfigureBuildingTemplate(GameObject go, Tag prefab_tag)
        {
            go.GetComponent<KPrefabID>().AddTag(RoomConstraints.ConstraintTags.IndustrialMachinery, false);
            go.AddOrGet<DropAllWorkable>();
            go.AddOrGet<BuildingComplete>().isManuallyOperated = false;
            ComplexFabricator complexFabricator = go.AddOrGet<ComplexFabricator>();
            complexFabricator.heatedTemperature = 353.15f;
            complexFabricator.duplicantOperated = false;
            complexFabricator.showProgressBar = true;
            complexFabricator.sideScreenStyle = ComplexFabricatorSideScreen.StyleSetting.ListQueueHybrid;
            go.AddOrGet<FabricatorIngredientStatusManager>();
            go.AddOrGet<CopyBuildingSettings>();
            BuildingTemplates.CreateComplexFabricatorStorage(go, complexFabricator);
            this.ConfigureRecipes();
            Prioritizable.AddRef(go);
        }
        public override void DoPostConfigureComplete(GameObject go)
        {
            go.AddOrGet<LogicOperationalController>();
            go.AddOrGetDef<PoweredActiveController.Def>();
            SymbolOverrideControllerUtil.AddToPrefab(go);
        }
    }
}
