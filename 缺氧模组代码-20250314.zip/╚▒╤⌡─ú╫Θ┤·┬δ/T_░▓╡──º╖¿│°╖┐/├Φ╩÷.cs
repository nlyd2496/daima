﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HarmonyLib;
using STRINGS;
using CaiLib.Utils;
using KMod;
using PeterHan.PLib.Core;
using PeterHan.PLib.Database;
using Klei.AI;
using PeterHan.PLib.Options;

namespace T_安的魔法厨房
{  
    public class STRINGS
    {
        public static void DoReplacement()
        {
            LocString.CreateLocStringKeys(typeof(STRINGS), "");
        }
        [HarmonyPatch(typeof(EntityConfigManager))]
        [HarmonyPatch("LoadGeneratedEntities")]

        public class 添加到数据库
        { 
            public static void Prefix()
            {
                //------------------------------------------------------------新植物------------------------------------------------------------
                // 辣椒
                StringUtils.AddPlantSeedStrings("T001GG1Z1", STRINGS.CREATURES.SPECIES.T001GG1Z1.B1, STRINGS.CREATURES.SPECIES.T001GG1Z1.B2);//添加种子
                StringUtils.AddPlantStrings("T001GG1Z2", STRINGS.CREATURES.SPECIES.T001GG1Z1.B3, STRINGS.CREATURES.SPECIES.T001GG1Z1.B4 , STRINGS.CREATURES.SPECIES.T001GG1Z1.B5);//添加植物
                PlantUtils.AddCropType("T001GG1Z3", SingletonOptions<控制台>.Instance.T001GG1Z3 , 1);//果实属性 生长周期 掉落种子数
                StringUtils.AddFoodStrings("T001GG1Z3", STRINGS.CREATURES.SPECIES.T001GG1Z1.B6, STRINGS.CREATURES.SPECIES.T001GG1Z1.B7);//添加果实
                // 花椒
                StringUtils.AddPlantSeedStrings("T002GG1Z1", STRINGS.CREATURES.SPECIES.T002GG1Z1.B1, STRINGS.CREATURES.SPECIES.T002GG1Z1.B2);//添加种子
                StringUtils.AddPlantStrings("T002GG1Z2", STRINGS.CREATURES.SPECIES.T002GG1Z1.B3, STRINGS.CREATURES.SPECIES.T002GG1Z1.B4, STRINGS.CREATURES.SPECIES.T002GG1Z1.B5);//添加植物
                PlantUtils.AddCropType("T002GG1Z3", SingletonOptions<控制台>.Instance.T002GG1Z3 , 1);//果实属性 生长周期 掉落种子数
                StringUtils.AddFoodStrings("T002GG1Z3", STRINGS.CREATURES.SPECIES.T002GG1Z1.B6, STRINGS.CREATURES.SPECIES.T002GG1Z1.B7);//添加果实
                // 香蕉
                StringUtils.AddPlantSeedStrings("T003GG1Z1", STRINGS.CREATURES.SPECIES.T003GG1Z1.B1, STRINGS.CREATURES.SPECIES.T003GG1Z1.B2);//添加种子
                StringUtils.AddPlantStrings("T003GG1Z2", STRINGS.CREATURES.SPECIES.T003GG1Z1.B3, STRINGS.CREATURES.SPECIES.T003GG1Z1.B4, STRINGS.CREATURES.SPECIES.T003GG1Z1.B5);//添加植物
                PlantUtils.AddCropType("T003GG1Z3", SingletonOptions<控制台>.Instance.T003GG1Z3 , 1);//果实属性 生长周期 掉落种子数
                StringUtils.AddFoodStrings("T003GG1Z3", STRINGS.CREATURES.SPECIES.T003GG1Z1.B6, STRINGS.CREATURES.SPECIES.T003GG1Z1.B7);//添加果实
                // 西红柿
                StringUtils.AddPlantSeedStrings("T004GG1Z1", STRINGS.CREATURES.SPECIES.T004GG1Z1.B1, STRINGS.CREATURES.SPECIES.T004GG1Z1.B2);//添加种子
                StringUtils.AddPlantStrings("T004GG1Z2", STRINGS.CREATURES.SPECIES.T004GG1Z1.B3, STRINGS.CREATURES.SPECIES.T004GG1Z1.B4, STRINGS.CREATURES.SPECIES.T004GG1Z1.B5);//添加植物
                PlantUtils.AddCropType("T004GG1Z3", SingletonOptions<控制台>.Instance.T004GG1Z3 , 1);//果实属性 生长周期 掉落种子数
                StringUtils.AddFoodStrings("T004GG1Z3", STRINGS.CREATURES.SPECIES.T004GG1Z1.B6, STRINGS.CREATURES.SPECIES.T004GG1Z1.B7);//添加果实
                // 白菜
                StringUtils.AddPlantSeedStrings("T005GG1Z1", STRINGS.CREATURES.SPECIES.T005GG1Z1.B1, STRINGS.CREATURES.SPECIES.T005GG1Z1.B2);//添加种子
                StringUtils.AddPlantStrings("T005GG1Z2", STRINGS.CREATURES.SPECIES.T005GG1Z1.B3, STRINGS.CREATURES.SPECIES.T005GG1Z1.B4, STRINGS.CREATURES.SPECIES.T005GG1Z1.B5);//添加植物
                PlantUtils.AddCropType("T005GG1Z3", SingletonOptions<控制台>.Instance.T005GG1Z3, 1);//果实属性 生长周期 掉落种子数
                StringUtils.AddFoodStrings("T005GG1Z3", STRINGS.CREATURES.SPECIES.T005GG1Z1.B6, STRINGS.CREATURES.SPECIES.T005GG1Z1.B7);//添加果实
                // 西瓜
                StringUtils.AddPlantSeedStrings("T006GG1Z1", STRINGS.CREATURES.SPECIES.T006GG1Z1.B1, STRINGS.CREATURES.SPECIES.T006GG1Z1.B2);//添加种子
                StringUtils.AddPlantStrings("T006GG1Z2", STRINGS.CREATURES.SPECIES.T006GG1Z1.B3, STRINGS.CREATURES.SPECIES.T005GG1Z1.B4, STRINGS.CREATURES.SPECIES.T006GG1Z1.B5);//添加植物
                PlantUtils.AddCropType("T006GG1Z3", SingletonOptions<控制台>.Instance.T006GG1Z3, 1);//果实属性 生长周期 掉落种子数
                StringUtils.AddFoodStrings("T006GG1Z3", STRINGS.CREATURES.SPECIES.T006GG1Z1.B6, STRINGS.CREATURES.SPECIES.T006GG1Z1.B7);//添加果实

                //------------------------------------------------------------新食物-----------------------------------------------------------
                StringUtils.AddFoodStrings("U001GG1S1", STRINGS.CREATURES.SPECIES.U001GG1S1.D1, STRINGS.CREATURES.SPECIES.U001GG1S1.D2) ; // 冰淇淋
                StringUtils.AddFoodStrings("U001GG1S2", STRINGS.CREATURES.SPECIES.U001GG1S2.D1, STRINGS.CREATURES.SPECIES.U001GG1S2.D2); // 西瓜冰淇淋
                /*
                StringUtils.AddFoodStrings("U001GG1S2", STRINGS.CREATURES.SPECIES.U001GG1S2.D1, STRINGS.CREATURES.SPECIES.U001GG1S1.D2) ; // 冰淇淋
                StringUtils.AddFoodStrings("U001GG1S3", STRINGS.CREATURES.SPECIES.U001GG1S3.D1, STRINGS.CREATURES.SPECIES.U001GG1S1.D2) ; // 冰淇淋
                StringUtils.AddFoodStrings("U001GG1S4", STRINGS.CREATURES.SPECIES.U001GG1S4.D1, STRINGS.CREATURES.SPECIES.U001GG1S1.D2) ; // 冰淇淋
                StringUtils.AddFoodStrings("U001GG1S5", STRINGS.CREATURES.SPECIES.U001GG1S5.D1, STRINGS.CREATURES.SPECIES.U001GG1S1.D2) ; // 冰淇淋
                StringUtils.AddFoodStrings("U001GG1S6", STRINGS.CREATURES.SPECIES.U001GG1S6.D1, STRINGS.CREATURES.SPECIES.U001GG1S1.D2) ; // 冰淇淋
                StringUtils.AddFoodStrings("U001GG1S7", STRINGS.CREATURES.SPECIES.U001GG1S7.D1, STRINGS.CREATURES.SPECIES.U001GG1S1.D2) ; // 冰淇淋
                StringUtils.AddFoodStrings("U001GG1S8", STRINGS.CREATURES.SPECIES.U001GG1S8.D1, STRINGS.CREATURES.SPECIES.U001GG1S1.D2) ; // 冰淇淋
                StringUtils.AddFoodStrings("U001GG1S9", STRINGS.CREATURES.SPECIES.U001GG1S9.D1, STRINGS.CREATURES.SPECIES.U001GG1S1.D2) ; // 冰淇淋
                */




                StringUtils.AddFoodStrings("U002GG1S1", STRINGS.CREATURES.SPECIES.U002GG1S1.E1, STRINGS.CREATURES.SPECIES.U002GG1S1.E2) ; // 冰皮月饼
                StringUtils.AddFoodStrings("U002GG2", STRINGS.CREATURES.SPECIES.U002GG2.E1, STRINGS.CREATURES.SPECIES.U002GG2.E2) ; // 鲜花月饼
                StringUtils.AddFoodStrings("U002GG3", STRINGS.CREATURES.SPECIES.U002GG3.E1, STRINGS.CREATURES.SPECIES.U002GG3.E2) ; // 鲜肉月饼
                StringUtils.AddFoodStrings("U002GG4", STRINGS.CREATURES.SPECIES.U002GG4.E1, STRINGS.CREATURES.SPECIES.U002GG4.E2) ; // 芝麻月饼

                StringUtils.AddFoodStrings("U003GG1", STRINGS.CREATURES.SPECIES.U003GG1.C1, STRINGS.CREATURES.SPECIES.U003GG1.C2) ; // 菜饺子
                StringUtils.AddFoodStrings("U003GG2", STRINGS.CREATURES.SPECIES.U003GG2.C1, STRINGS.CREATURES.SPECIES.U003GG2.C2) ; // 肉饺子
                
                StringUtils.AddFoodStrings("U004GG1", STRINGS.CREATURES.SPECIES.U004GG1.C1, STRINGS.CREATURES.SPECIES.U004GG1.C2) ; // 豆花饭
                StringUtils.AddFoodStrings("U004GG2", STRINGS.CREATURES.SPECIES.U004GG2.C1, STRINGS.CREATURES.SPECIES.U004GG2.C2) ; // 辣椒炒辣椒
                StringUtils.AddFoodStrings("U004GG3", STRINGS.CREATURES.SPECIES.U004GG3.C1, STRINGS.CREATURES.SPECIES.U004GG3.C2) ; // 辣椒炒肉
                StringUtils.AddFoodStrings("U004GG4", STRINGS.CREATURES.SPECIES.U004GG4.C1, STRINGS.CREATURES.SPECIES.U004GG4.C2) ; // 麻辣烫
                StringUtils.AddFoodStrings("U004GG5", STRINGS.CREATURES.SPECIES.U004GG5.C1, STRINGS.CREATURES.SPECIES.U004GG5.C2) ; // 水煮鱼

                StringUtils.AddFoodStrings("U005GG1", STRINGS.CREATURES.SPECIES.U005GG1.C1, STRINGS.CREATURES.SPECIES.U005GG1.C2) ; // 鸡蛋奶油

                StringUtils.AddFoodStrings("U006GG1", STRINGS.CREATURES.SPECIES.U006GG1.C1, STRINGS.CREATURES.SPECIES.U006GG1.C2); // 面粉
                StringUtils.AddFoodStrings("U006GG2", STRINGS.CREATURES.SPECIES.U006GG2.C1, STRINGS.CREATURES.SPECIES.U006GG2.C2); // 大米

                StringUtils.AddFoodStrings("U007GG1", STRINGS.CREATURES.SPECIES.U007GG1.C1, STRINGS.CREATURES.SPECIES.U007GG1.C2); // 油团

                StringUtils.AddFoodStrings("U008GG1", STRINGS.CREATURES.SPECIES.U008GG1.C1, STRINGS.CREATURES.SPECIES.U008GG1.C2); // 西瓜汁

                StringUtils.AddFoodStrings("U008GG2", STRINGS.CREATURES.SPECIES.U008GG2.C1, STRINGS.CREATURES.SPECIES.U008GG2.C2); // 西红柿汁


            }
        }
        public class CREATURES
        {
            public class SPECIES
            {
                /*
                 * 种子名称
                 * 种子描述
                 * 植物名称
                 * 植物描述
                 * 未知不填
                 * 果实名称
                 * 果实描述
                 * 种子配方描述
                 */

                // 辣椒
                public class T001GG1Z1
                {
                    public static LocString B1 = "Chili Seed"; // 辣椒籽
                    public static LocString B2 = "Plant a chili seed, grow a chili tree."; // 播下一粒辣椒籽，长成一株辣椒树。
                    public static LocString B3 = "Chili Tree"; // 辣椒树
                    public static LocString B4 = "Chili, a one-year herbaceous plant of the Capsicum genus in the nightshade family, has an underdeveloped root system and an erect stem; leaves are alternate, ovate, with a smooth surface; flowers are solitary or clustered, mostly white; fruit surface is smooth or wrinkled, shiny; fruit is flat round, spherical, conical, or linear, seeds are pale yellow and flat kidney-shaped; flowering and fruiting period is from May to November."; // 辣椒，是茄科辣椒属的一年生草本植物，其根系不发达，茎直立；单叶互生，卵圆形，叶面光滑；花单生或簇生，多为白色；果面平滑或皱褶，具光泽；果实呈扁圆、圆球、圆锥或线形，种子为淡黄色的扁肾形；花果期5-11月。
                    public static LocString B5 = "5"; // 5
                    public static LocString B6 = "Chili"; // 辣椒
                    public static LocString B7 = "The fruit of the chili tree is spicy. Adding it to other foods can bring out a unique flavor. Be careful not to use too much, or you might question your life choices."; // 辣椒树的果实来辣椒，辣，添加到其它食物里面能够获得别一番的风味。注意，别多放，不然，你会怀疑人生。
                    public static LocString B8 = "Wait to trade for chili seeds"; // 等交易获得辣椒籽
                }

                // 花椒
                public class T002GG1Z1
                {
                    public static LocString B1 = "Sichuan Peppercorn"; // 花椒仔
                    public static LocString B2 = "Plant a Sichuan peppercorn seed, grow a Sichuan peppercorn tree."; // 播下一粒花椒籽，长成一株花椒树。
                    public static LocString B3 = "Sichuan Peppercorn Tree"; // 花椒树
                    public static LocString B4 = "Sichuan peppercorn tree, also known as Chinese coriander, is a deciduous small tree of the genus Zanthoxylum in the Rutaceae family; its stem has thorns that often fall off early, branches have short spines, and the spines on the twigs are wide at the base and straight, forming a long triangle, with the current year's branches covered in short soft hair. It is found from the southern part of Northeast China to the northern slopes of the Wuling Mountains, from the coastal areas of Jiangsu and Zhejiang to the southeastern part of Tibet; it is not produced in Taiwan, Hainan, and Guangdong. It is seen from plains to high-altitude mountains, in Qinghai, it is found on slopes at an altitude of 2500 meters, and it is also cultivated. It is drought-resistant, loves sunlight, and is widely cultivated. Sichuan peppercorn is used in traditional Chinese medicine, with effects such as warming the middle and moving qi, dispelling cold, relieving pain, and killing parasites. It treats symptoms such as cold stomach pain, vomiting, diarrhea, schistosomiasis, and roundworms."; // 花椒树，原名:花椒，别名:檓、大椒、秦椒、蜀椒，拉丁文名:Zanthoxylum bungeanum Maxim.为芸香科、花椒属落叶小乔木;茎干上的刺常早落，枝有短刺，小枝上的刺基部宽而扁且劲直的长三角形，当年生枝被短柔毛。产地北起东北南部，南至五岭北坡，东南至江苏、浙江沿海地带，西南至西藏东南部;台湾、海南及广东不产。见于平原至海拔较高的山地，在青海，见于海拔2500米的坡地，也有栽种。耐旱，喜阳光，各地多栽种。花椒用作中药，有温中行气、逐寒、止痛、杀虫等功效。治胃腹冷痛、呕吐、泄泻、血吸虫、蛔虫等症。
                    public static LocString B5 = "5"; // 5
                    public static LocString B6 = "Sichuan Peppercorn"; // 花椒
                    public static LocString B7 = "The fruit of the Sichuan peppercorn tree is Sichuan peppercorn, which is numbing; a major characteristic of Sichuan peppercorn is its numbing effect."; // 花椒树的果实来花椒，麻，花椒的一大特点就是麻。
                    public static LocString B8 = "Wait to trade for Sichuan peppercorn seeds"; // 等交易获得花椒籽
                }

                // 香蕉
                public class T003GG1Z1
                {
                    public static LocString B1 = "Banana Seed"; // 香蕉籽
                    public static LocString B2 = "Plant a banana seed, grow a banana tree."; // 播下一粒香蕉籽，长成一株香蕉树。
                    public static LocString B3 = "Banana Tree"; // 香蕉树
                    public static LocString B4 = "Banana is one of the four major fruits of southern China, belonging to the plant genus Musa in the family Musaceae. The fruit is curved like a bow, hence it is also called 'bow banana'. There are many varieties of bananas, mainly divided into bananas, plantains, and cooking bananas, among which bananas are of the best quality. Bananas have a curved body, the fruit is plump and robust, with a fresh and bright color, smooth surface, free of disease spots, insect scars, mold, and injuries, the fruit is easy to peel, the flesh is slightly hard, sweet as honey, with a fragrant and refreshing smell, the taste is sweet and refreshing, the flesh is soft and slippery, and the flavor lingers between the teeth, hence it is also called 'fragrant tooth banana' or 'sweet banana'."; // 香蕉是中国南方四大水果之一，为芭蕉科芭蕉属植物，因果实如弓，故又叫弓蕉。香蕉品种很多，主要分香蕉、芭蕉和粉蕉三类，其中以香蕉质量最好。香蕉体弯曲，果实丰满、肥壮，色泽新鲜、光亮，果面光滑，无病斑、无虫疤、无霉菌、无创伤，果实易剥离，果肉稍硬，甜如蜜，气味清香芬芳，味甘爽口，肉软滑腻，而滋味常在牙齿之间，所以又叫香牙蕉、甘蕉。
                    public static LocString B5 = "5"; // 5
                    public static LocString B6 = "Banana"; // 香蕉
                    public static LocString B7 = "A bunch of bright yellow bananas hanging high on the branches, looking at the bananas quenches thirst."; // 黄灿灿的一串挂在高高的枝头，望蕉解渴。
                    public static LocString B8 = "Wait to trade for banana seeds"; // 等交易获得香蕉籽
                }

                // 西红柿
                public class T004GG1Z1
                {
                    public static LocString B1 = "Tomato Seed"; // 西红柿籽
                    public static LocString B2 = "Plant a tomato seed, grow a tomato plant."; // 播下一粒西红柿籽，长成一株西红柿树。
                    public static LocString B3 = "Tomato Plant"; // 西红柿树
                    public static LocString B4 = "The tomato originally grew in South America and was treated with great caution due to its bright color, considered 'the fruit of the fox', also known as the wolf peach. It was only for ornamental purposes and not for consumption. Later, a painter, while painting a tomato, could not resist his hunger and thirst and ate one. Since then, the tomato has made its way to the dining table. In the West, it is called a tomato, and after being introduced to China, because it resembles the persimmon in appearance, it is called 'xi hong shi', and today it is an indispensable delicacy in people's daily lives."; // 西红柿最早生长在南美洲，因为色彩娇艳，人们对它十分警惕，视为“狐狸的果实”，又称狼桃，只供观赏，不敢品尝，后来一个画家，在画西红柿的时候，饥渴难耐，实在忍不住才吃了一个，从此以后西红柿才进入到餐桌之上，西方人叫做番茄，传入中国之后，因为跟我国的柿子外形相似，所以我们称之为“西红柿“，而今它却是人们日常生活中不可缺少的美味佳品。
                    public static LocString B5 = "5"; // 5
                    public static LocString B6 = "Tomato"; // 西红柿
                    public static LocString B7 = "You think it's a tomato, wrong, it's actually a tomato."; // 你以为是西红柿，错，其实它是番茄。
                    public static LocString B8 = "Wait to trade for tomato seeds"; // 等交易获得西红柿籽
                }
                // 小白菜
                public class T005GG1Z1
                {
                    public static LocString B1 = "Cabbage seeds"; // 白菜籽
                    public static LocString B2 = "Plant a cabbage seed and grow into a cabbage tree."; // 播下一粒白菜籽，长成一株白菜树。
                    public static LocString B3 = "Cabbage tree"; // 白菜树
                    public static LocString B4 = "Chinese cabbage, also known as \"yellow sprout cabbage\" in ancient times, had a cultivation history later than turnips. The \"Feng\" recorded in the Book of Songs refers to turnips, a vegetable closely related to Chinese cabbage. It was not until the Tang Dynasty when the \"Niu Du Song\" mentioned in the \"Xin Xiu Ben Cao\" was the first appearance of non heading loose leaf Chinese cabbage."; // 白菜古代称为“黄芽菜”，其栽培历史晚于芜菁，《诗经》中记载的“葑”是指与白菜近亲的蔬菜芜菁，直到唐代《新修本草》中提到的“牛肚菘”，才是不结球的散叶白菜首次亮相。
                    public static LocString B5 = "5"; // 5
                    public static LocString B6 = "Cabbage"; // 白菜
                    public static LocString B7 = "You think it's cabbage, yes, it's cabbage."; // 你以为是白菜，对，它就是白菜。
                    public static LocString B8 = "Wait to trade for Cabbage seeds"; // 等交易获得白菜籽
                }
                // 西瓜
                public class T006GG1Z1
                {
                    public static LocString B1 = "Watermelon seeds"; // 西瓜籽
                    public static LocString B2 = "Plant a Watermelon seed and grow into a Watermelon tree."; // 播下一粒西瓜籽，长成一株西瓜藤。
                    public static LocString B3 = "Watermelon vine"; // 西瓜藤
                    public static LocString B4 = "The Daily Materia Medica records that watermelon is rich in various vitamins, which have the function of balancing blood pressure and regulating heart function."; // 《日用本草》记载西瓜富含多种维生素，具有平衡血压、调节心脏功能的作用。
                    public static LocString B5 = "5"; // 5
                    public static LocString B6 = "Watermelon"; // 西瓜
                    public static LocString B7 = "You think it's Watermelon, yes, it's Watermelon."; // 你以为是西瓜，对，它就是西瓜。
                    public static LocString B8 = "Wait to trade for Watermelon seeds"; // 等交易获得西瓜籽。
                }

                // 冰淇淋
                public class U001GG1S1
                {
                    public static LocString D1 = "Xiao Ai"; // 小爱
                    public static LocString D2 = "Made with ice, egg, and cream, it retains the soft and glutinous texture of the cream and inherits the tender white of the ice. Fragrant, soft, and delicious, it allows little ones from foreign lands to enjoy a taste of familiar ice cream!"; // 由冰加鸡蛋奶油制作而成，保留了奶油的软糯，继承了冰的嫩白。香软可口，让异国他乡的小人们，也能吃上一口熟悉的冰淇淋！
                    public static LocString D3 = "Is it delicious, the icy coldness?"; // 好吃吗，冰冰的。
                }
                public class U001GG1S2
                {
                    public static LocString D1 = "Watermelon ice cream"; // 西瓜冰淇淋
                    public static LocString D2 = "Ice+cream+watermelon juice+watermelon, after freezing, it has a unique flavor."; // 冰+奶油+西瓜汁+西瓜，在冰冻后，别有一番风味。
                    public static LocString D3 = "Watermelon flavored ice cream, not only ice cream, but also a small watermelon."; // 西瓜口味的冰淇淋，不止只有冰淇淋，还有一只小西瓜。
                }

                // 月饼
                public class U002GG1S1
                {
                    public static LocString E1 = "Snow Skin Mooncake"; // 冰皮月饼
                    public static LocString E2 = "Snow skin mooncakes do not require baking. They are made with glutinous rice flour and rock sugar for the skin, with fillings that include various fruits, cream, ice cream, etc., offering a refreshing and sweet taste, suitable for consumption during the transition from summer to autumn."; // 冰皮月饼不用烘烤，用糯米粉和冰糖制成皮，馅料有各种水果、奶油、冰淇淋等，口感清爽甜美，适合夏秋之交食用。
                    public static LocString E3 = "Happy Mid-Autumn Festival!"; // 中秋节快乐！
                }
                public class U002GG2
                {
                    public static LocString E1 = "Fresh Flower Mooncake"; // 鲜花月饼
                    public static LocString E2 = "The characteristic of fresh flower mooncakes is that the fillings are mainly fruits and vegetables, with fresh flowers as ingredients. The filling is smooth and soft, with various flavors. Fillings include chrysanthemum, rose, lychee, strawberry, lily, taro, dark plum, orange, etc., complemented with fruit juice or pulp, giving it a fresh and sweet flavor."; // 鲜花月饼特点是馅料主要是果蔬，配料是鲜花，馅心滑软，风味各异，馅料有菊花、玫瑰花、荔枝、草莓、白合、芋头、乌梅、橙等，又配以果汁或果浆，因此更具清新爽甜的风味。
                    public static LocString E3 = "Happy Mid-Autumn Festival!"; // 中秋节快乐！
                }
                public class U002GG3
                {
                    public static LocString E1 = "Fresh Meat Mooncake"; // 鲜肉月饼
                    public static LocString E2 = "Fresh meat mooncakes are a specialty of the Jiangsu and Zhejiang regions, made with flour and pork filling. The crust is golden and crispy, and the filling is juicy and savory, making it a salty-flavored mooncake."; // 鲜肉月饼是江浙一带的特色，用面粉和猪肉馅制成，外皮金黄酥脆，内馅肉汁丰富，咸香可口，是一种咸味月饼。
                    public static LocString E3 = "Happy Mid-Autumn Festival!"; // 中秋节快乐！
                }

                public class U002GG4
                {
                    public static LocString E1 = "Sesame Mooncake"; // 芝麻月饼
                    public static LocString E2 = "Sesame mooncakes are a traditional food in northern regions, made with flour and sesame filling. The crust can be white or black, and the filling is sweet and soft, rich in vitamin E and calcium."; // 芝麻月饼是北方地区的传统食品，用面粉和芝麻馅制成，外皮白色或黑色，内馅香甜软糯，富含维生素E和钙质。
                    public static LocString E3 = "Happy Mid-Autumn Festival!"; // 中秋节快乐！
                }

                // 饺子
                public class U003GG1
                {
                    public static LocString C1 = "Vegetable Dumplings"; // 菜饺子
                    public static LocString C2 = "A skilled chef turns the ordinary into legend. Who would have thought that wrapping vegetables in dough could be steamed, pan-fried, stir-fried, deep-fried, or boiled, creating endless techniques and flavors."; // 高明的厨师，化平凡为传奇。任谁能想到，将菜包裹在面皮里，可以蒸煎炒炸煮，万般手法，万般滋味。
                    public static LocString C3 = "Dumplings with vegetable filling"; // 菜馅的饺子
                }

                public class U003GG2
                {
                    public static LocString C1 = "Meat Dumplings"; // 肉饺子
                    public static LocString C2 = "A skilled chef turns the ordinary into legend. Who would have thought that wrapping meat in dough could be steamed, pan-fried, stir-fried, deep-fried, or boiled, creating endless techniques and flavors."; // 高明的厨师，化平凡为传奇。任谁能想到，将肉包裹在面皮里，可以蒸煎炒炸煮，万般手法，万般滋味。
                    public static LocString C3 = "Dumplings with meat filling."; // 肉馅的饺子。
                }


                //川菜
                public class U004GG1
                {
                    public static LocString C1 = "Tofu Pudding Rice"; // 豆花饭
                    public static LocString C2 = "A simple bowl of tofu pudding rice."; // 简简单单的一碗豆花饭。
                    public static LocString C3 = "Spicy. Tofu Pudding Rice"; // 辣.豆花饭
                }

                public class U004GG2
                {
                    public static LocString C1 = "Stir-Fried Chili"; // 炒辣椒
                    public static LocString C2 = "Stir-fried chili is also a delicious dish, but please note, for most people, this is not a 'delicious' food."; // 炒辣椒也是一道一场美味的食物，但请注意，对于大多数而言，这并不是一道“美味”的食物。
                    public static LocString C3 = "The only ingredient is chili."; // 食材只有辣椒
                }

                public class U004GG3
                {
                    public static LocString C1 = "Stir-Fried Pork with Chili"; // 辣椒炒肉
                    public static LocString C2 = "The first secret to stir-fried pork with chili is spicy! The second secret, spicy, spicy! The third secret, spicy, spicy, spicy!"; // 辣椒炒肉的第一个秘诀，辣！辣椒炒肉的第二个秘诀，辣，辣！辣椒炒肉的第三个秘诀，辣，辣，辣！
                    public static LocString C3 = "Spicy. Stir-Fried Pork with Chili"; // 辣.辣椒炒肉
                }

                public class U004GG4
                {
                    public static LocString C1 = "Spicy Hot Pot"; // 麻辣烫
                    public static LocString C2 = "Spicy hot pot mainly involves cooking various ingredients in a boiling spicy broth, then scooping them out and dipping them in seasoning to eat, characterized by being numbing, spicy, aromatic, and fresh!"; // 麻辣烫主要是将各种食材放入沸腾的麻辣汤中煮熟，然后捞出沾上调味料食用，具有麻、辣、香、鲜的特点！
                    public static LocString C3 = "Spicy. Spicy Hot Pot"; // 辣.麻辣烫
                }

                public class U004GG5
                {
                    public static LocString C1 = "Boiled Fish"; // 水煮鱼
                    public static LocString C2 = "What's the secret to boiled fish? A handful of chili peppers! What, the boiled fish still isn't tasty? Then add another handful of chili peppers! What, still not tasty? Pick out the fish and pour in the chili peppers!!!"; // 水煮鱼的奥秘是什么？一把辣椒！什么，做出来的水煮鱼依然不好吃？那就再来一把辣椒！什么，还是不好吃？把鱼肉挑出来，把辣椒倒进去！！！
                    public static LocString C3 = "Spicy. Boiled Fish"; // 辣.水煮鱼
                }

                // 鸡蛋奶油
                public class U005GG1
                {
                    public static LocString C1 = "Egg Cream"; // 鸡蛋奶油
                    public static LocString C2 = "Who would have thought that ordinary eggs could be turned into such a delicacy? Soft, delicate, and tender, with a subtle indescribable fragrance that makes you want to take a lick."; // 从未想过普普通通的鸡蛋也能做成此等美食，软糯、细腻、白嫩，带着淡淡的说不出的香味，好想舔一口。
                    public static LocString C3 = "Eggs + water, to obtain egg cream."; // 鸡蛋+水，获得鸡蛋奶油。
                }

                // 面粉
                public class U006GG1
                {
                    public static LocString C1 = "Flour"; // 面粉
                    public static LocString C2 = "Taking the coarse and hard-to-swallow frost wheat grains, peeling them, crushing them forcefully, and baking them lightly, results in flour as fine as jade and as white as fresh snow. As a basic ingredient, you can consume it directly, but if you cook it simply, the taste will be even better."; // 将粗糙的难以下咽的冰霜麦粒去皮，大力碾压，小火烘焙，制得细腻如玉，白如清雪的面粉。作为初级食材，你可以直接食用，但如果经过简单的烹饪，味道将更加美好。
                    public static LocString C3 = "Grind frost wheat grains to get flour."; // 磨制冰霜麦粒得到面粉。
                }
                // 大米
                public class U006GG2
                {
                    public static LocString C1 = "Rice"; // 大米
                    public static LocString C2 = "Peel off the rough and difficult to swallow rice lice, adjust the gap and power of the milling machine to ensure that the rice lice are not completely ground while peeling, and finally obtain plump and youthful rice grains. As a primary ingredient, you can eat it directly, but after simple cooking, the taste will be even better."; // 将粗糙的难以下咽的米虱去皮，调节磨面机的间隙及功率，在保证去皮的基础上，并不会将米虱给完全磨碎，最后得到一粒粒饱满青春的米粒。作为初级食材，你可以直接食用，但如果经过简单的烹饪，味道将更加美好。
                    public static LocString C3 = "Grinding rice lice yields rice.";// 磨制米虱得到大米。
                }

                // 油团
                public class U007GG1
                {
                    public static LocString C1 = "Oil clump"; // 油团
                    public static LocString C2 = "The Yi language of Youtuan is called Maje. Traditional food during the Yi ethnic Spring Festival holiday. Popular in the Napo area of Guangxi. On the first day of the first month of the lunar calendar, people mixed glutinous rice flour with a small amount of water to form a rice ball slightly smaller than an egg. It was filled with brown sugar and sesame seeds and fried. Oil balls symbolize reunion and good luck, serving as offerings for the Spring Festival and as a staple food for the whole family on the first and second days of the Lunar New Year."; // 油团 彝语称“麻且”。彝族春节节日传统食品。流行于广西那坡带。夏历正月初一,人们将糯米粉加少量水拌匀,采成比鸡蛋略小的米团,以红糖、芝麻作馅,油炸制成。油团象征团圆、吉利,为春节祭品和初一、初二全家主食。
                    public static LocString C3 = "Flour+water, oil ball."; // 面粉+水，油团。面粉+水，油团。
                }

                // 西瓜汁
                public class U008GG1
                {
                    public static LocString C1 = "Watermelon juice"; // 西瓜汁
                    public static LocString C2 = "Your Majesty, do you still remember the watermelon juice by the Daming Lake."; // 皇上，你还记得大明湖畔的西瓜汁吗。
                    public static LocString C3 = "Add a large watermelon to obtain watermelon juice."; // 加入一个大西瓜，得到西瓜汁。
                }

                // 西红柿汁
                public class U008GG2
                {
                    public static LocString C1 = "Tomatoes"; // 西红柿汁
                    public static LocString C2 = "Red and sour, really delicious."; // 红红的，酸酸的，真好喝。
                    public static LocString C3 = "Add a large tomato to obtain tomato juice."; // 加入一个大西红柿，得到西红柿汁。
                }
            }
        }
        public class BUILDINGS
        {
            public class PREFABS
            {
                public class T000GG0 // 种子研究站
                {
                    public static LocString NAME = "Seed Research Station"; // 种子研究站
                    public static LocString EFFECT = "Equivalent exchange, here you can get some unexpected seeds."; // 等价交易，在这里，你能获得一些想不到的种子。
                    public static LocString DESC = "With money, you have everything."; // 有钱，你就拥有了一切。
                }
                public class U001GG1 // 冰淇淋机
                {
                    public static LocString NAME = "Ice Cream Machine"; // 冰淇淋机
                    public static LocString EFFECT = "High-end technology, even ordinary salty milk can be turned into something magical. A little bit of ice, a little bit of salty milk, a little bit of love, and ice cream makes a dazzling entrance."; // 高端科技，即便是平平无奇咸乳，也能化腐朽为神奇。一点点冰，一点点咸乳，一点点爱，冰淇淋，闪亮登场。
                    public static LocString DESC = "Be gentle, don't scare away the little octopus."; // 轻一点，别把小章鱼吓跑了。
                }
                public class U006GG1 // 磨面机
                {
                    public static LocString NAME = "Flour Mill"; // 磨面机
                    public static LocString EFFECT = "Grinds various ingredients into fine powder, then uses it to make other more exquisite foods."; // 将各种食材磨成精细的粉末，然后将其用于制作其它更加精美的食物。
                    public static LocString DESC = "This is a small step for the little ones, but a giant leap for the world."; // 这是小人的一小步，却是世界的一大步。
                }
                public class U008GG1 // 榨汁机
                {
                    public static LocString NAME = "Juicer"; // 榨汁机
                    public static LocString EFFECT = "Squeezing fresh fruits into delicious fruit juice is loved by the children."; // 将新鲜的水果榨成可口的水果汁，小人们爱极了。
                    public static LocString DESC = "Be careful, water is highly toxic."; // 小心，水有剧毒。
                }
            }
        }
    }
}
