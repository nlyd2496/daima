﻿using STRINGS;
using System.Collections.Generic;
using UnityEngine;
using static CaiLib.Utils.RecipeUtils;
using CaiLib.Utils;
using PeterHan.PLib.Options;

namespace T_安的魔法厨房.U_新食物.U007GG1_油团
{
    public class U007GG1 : IEntityConfig
    {
        //--------------------------
        public const string Id = "U007GG1";// 食物ID
        public static string Name = STRINGS.CREATURES.SPECIES.U007GG1.C1;// 食物名称
        public static string EFFECT = STRINGS.CREATURES.SPECIES.U007GG1.C2;// 食物描述
        public static string DESC = STRINGS.CREATURES.SPECIES.U007GG1.C3;// 配方描述
        private const string AnimName = "U007GG1_kanim";// 食物动画
        //--------------------------
        public ComplexRecipe Recipe;
        public GameObject CreatePrefab()
        {
            var entity = EntityTemplates.CreateLooseEntity(
                id: Id, // 食物ID
                name: Name, // 食物名称
                desc: EFFECT, // 食物STRINGS.BUILDINGS.PREFABS
                mass: 1f, // 食物质量
                unitMass: false, // 食物的单位质量
                anim: Assets.GetAnim(AnimName), // 食物动画
                initialAnim: "object", // 食物初始动画
                sceneLayer: Grid.SceneLayer.Front, // 食物场景层
                collisionShape: EntityTemplates.CollisionShape.RECTANGLE, // 食物碰撞形状
                width: 0.8f, // 食物宽度
                height: 0.7f, // 食物高度
                isPickupable: true); // 食物是否可拾取

            // 创建食物信息
            var foodInfo = new EdiblesManager.FoodInfo(
                    id: Id, // 食物ID
                    dlcId: DlcManager.VANILLA_ID, // 食物的DLC ID
                    caloriesPerUnit: 1600000f, // 食物每单位卡路里   ---   300 000
                    quality: (int)SingletonOptions<控制台>.Instance.U007GG1X1, // 食物质量
                   preserveTemperatue: SingletonOptions<控制台>.Instance.U007GG1X2 + 273.15f, // 食物保存温度
                   rotTemperature: SingletonOptions<控制台>.Instance.U007GG1X3 + 273.15f, // 食物腐烂温度
                   spoilTime: SingletonOptions<控制台>.Instance.U007GG1X4 * 600f, // 食物腐烂时间
                   can_rot: !SingletonOptions<控制台>.Instance.U007GG1X5 // 食物是否可以腐烂，修正布尔逻辑
                   );

            if (控制台.Instance.U007GG1X6)
            {
                // 如果 isEnabled 为 true，则添加效果
                foodInfo.AddEffects(new List<string> { "GoodEats" }, DlcManager.AVAILABLE_EXPANSION1_ONLY);
            }

            var food = EntityTemplates.ExtendEntityToFood(entity, foodInfo);
            // 添加配方
            Recipe = AddComplexRecipe
            (
                input: new[]
                {
                    new ComplexRecipe.RecipeElement("U006GG1", 2f), // 面粉 800
                    new ComplexRecipe.RecipeElement("Water".ToTag(), 75f)
                }, // 配方输入
                output: new[]
                {
                    new ComplexRecipe.RecipeElement(U007GG1.Id, 1f)
                }, // 配方输出
                fabricatorId: GourmetCookingStationConfig.ID, // 配方的制造器ID
                productionTime: 100f, // 配方的生产时间
                recipeDescription: DESC, // 配方描述
                nameDisplayType: ComplexRecipe.RecipeNameDisplay.Result, // 配方名称显示类型
                sortOrder: 120 // 配方的排序顺序
            );
            // 返回食物的预制体
            return food;


        }
        public string[] GetDlcIds()
        {
            return DlcManager.AVAILABLE_ALL_VERSIONS;
            // AVAILABLE_ALL_VERSIONS-------------------------------本体+DLC可用
            //AVAILABLE_VANILLA_ONLY--------------------------------仅本体可用
            //AVAILABLE_EXPANSION1_ONLY-----------------------------仅DLC可用
        }
        public void OnPrefabInit(GameObject inst)
        {
        }
        public void OnSpawn(GameObject inst)
        {
        }
    }
}
