﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HarmonyLib;
using STRINGS;
using KMod;
using PeterHan.PLib.Core;
using PeterHan.PLib.Database;
using Klei.AI;
using PeterHan.PLib.Options;

namespace R_圣诞礼物
{
    public class STRINGS
    {
        public class SIDESCREEN
        {
            public static LocString R024GG1A1 = "Christmas gifts"; // 圣诞礼物
        }
        public static void DoReplacement()
        {
            LocString.CreateLocStringKeys(typeof(STRINGS), "");
        }
        [HarmonyPatch(typeof(EntityConfigManager))]
        [HarmonyPatch("LoadGeneratedEntities")]
            
        public class BUILDINGS
        {
            public class PREFABS
            {
                public class R024GG1 // 圣诞礼物
                {
                    public static LocString NAME = "Christmas gifts"; // 圣诞礼物
                    public static LocString EFFECT = "Without Santa Claus, Santa Claus cannot appear in games without chimneys. But we can still receive gifts from Santa Claus, perhaps even Grandpa can program, so quietly sending gifts through chimney loopholes may not be possible."; // 没有圣诞老人，圣诞老人没有办法在没有烟囱的游戏里出现。但我们仍能收到圣诞老人送出的礼物，或许老爷爷也会编程，所以通过烟囱漏洞悄咪咪的将礼物送出，也说不定哟。
                    public static LocString DESC = "Merry Christmas"; // 圣诞节快乐
                }
            }
        }
    }
}
