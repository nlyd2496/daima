﻿using HarmonyLib;

namespace R_圣诞礼物
{
    [HarmonyPatch(typeof(GeneratedBuildings))]
    [HarmonyPatch("LoadGeneratedBuildings")]
    public class 建筑栏
    {
        public static void Prefix()
        {

            BasicModUtils.MakeSideScreenStrings(SignSideScreen.SCREEN_TITLE_KEY, STRINGS.SIDESCREEN.R024GG1A1);


            ModUtil.AddBuildingToPlanScreen("Furniture", "R024GG1");
        }
    }
}
//  基地 氧气   电力  食物 液管     气管 精炼     医疗    家具      站台      实用      自动化     运输       火箭     辐射
//  Base Oxygen Power Food Plumbing HVAC Refining Medical Furniture Equipment Utilities Automation Conveyance Rocketry HEP
