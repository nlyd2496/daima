﻿using KSerialization;
using STRINGS;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace N_电力系统_1._0
{
    /*
    public class N020GG1K2 : KMonoBehaviour, ISingleSliderControl, ISliderControl
    {
        public float GetSliderMin(int index) => 1000;//最小值
        public float GetSliderMax(int index) => 10000;//最大值
        public int SliderDecimalPlaces(int index) => 0;//小数点
        public string SliderUnits => UI.UNITSUFFIXES.ELECTRICAL.WATT;
        public string SliderTitleKey => "STRINGS.BUILDINGS.PREFABS.SMALLELECTROBANKDISCHARGER.NAME";//窗口名称
        public string GetSliderTooltip(int index) => "";//空
        //--------------------------
        [Serialize] public float AA = 1000f;//AA参数默认值
        //--------------------------
        [MyCmpReq] public ElectrobankDischarger electrobankdischarger;
        internal void Update() { this.electrobankdischarger.wattageRating = (int)this.AA; }//将AA的值赋予源功能组件
        //--------------------------
        //以下内容无需更改
        public float GetSliderValue(int index) => this.AA;
        public string GetSliderTooltipKey(int index) => "";//空
        [MyCmpAdd] public CopyBuildingSettings copyBuildingSettings;
        protected override void OnSpawn() { base.OnSpawn(); this.Update(); }
        public void SetSliderValue(float value, int index) { this.AA = value; this.Update(); }
        protected override void OnPrefabInit() { base.OnPrefabInit(); base.Subscribe(-905833192, new Action<object>(this.OnCopySettings)); }
        internal void OnCopySettings(object data) { var component = ((GameObject)data).GetComponent<N020GG1K2>(); if (component == null) return; AA = component.AA; Update(); }
        //--------------------------
    }
    */
}
