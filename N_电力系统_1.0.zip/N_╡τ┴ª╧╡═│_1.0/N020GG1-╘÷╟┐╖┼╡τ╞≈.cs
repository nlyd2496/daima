﻿using HarmonyLib;
using PeterHan.PLib.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace N_电力系统_1._0
{
    [HarmonyPatch(typeof(LargeElectrobankDischargerConfig))]
    [HarmonyPatch("ConfigureBuildingTemplate")]
    public class 增强大放电器
    {
        public static void Postfix(GameObject go)
        {
            bool N020GG1 = SingletonOptions<控制台>.Instance.N020GG1;
            if (N020GG1)
            {

                go.AddOrGet<ElectrobankDischarger>().wattageRating = SingletonOptions<控制台>.Instance.N020GG1X1 * 5f;

                // 获取ElectrobankDischarger组件
                var discharger = go.GetComponent<ElectrobankDischarger>();
                if (discharger != null)
                {
                    // 设置GeneratorWattageRating和GeneratorBaseCapacity的值等于wattageRating的值
                    float wattageRating = discharger.wattageRating;
                    var buildingDef = go.GetComponent<Building>().Def;
                    if (buildingDef != null)
                    {
                        buildingDef.GeneratorWattageRating = wattageRating;
                        buildingDef.GeneratorBaseCapacity = wattageRating;
                    }
                }
                
            }
        }
    }
    [HarmonyPatch(typeof(SmallElectrobankDischargerConfig))]
    [HarmonyPatch("ConfigureBuildingTemplate")]
    public class 增强小放电器
    {
        public static void Postfix(GameObject go)
        {
            bool N020GG1 = SingletonOptions<控制台>.Instance.N020GG1;
            if (N020GG1)
            {
                go.AddOrGet<ElectrobankDischarger>().wattageRating = SingletonOptions<控制台>.Instance.N020GG1X1;

                // 获取ElectrobankDischarger组件
                var discharger = go.GetComponent<ElectrobankDischarger>();
                if (discharger != null)
                {
                    // 设置GeneratorWattageRating和GeneratorBaseCapacity的值等于wattageRating的值
                    float wattageRating = discharger.wattageRating;
                    var buildingDef = go.GetComponent<Building>().Def;
                    if (buildingDef != null)
                    {
                        buildingDef.GeneratorWattageRating = wattageRating;
                        buildingDef.GeneratorBaseCapacity = wattageRating;
                    }
                }
            }
        }
    }

    /// <summary>
    /// 获取滑条的提示信息
    /// </summary>
}