﻿using PeterHan.PLib.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TUNING;
using UnityEngine;

namespace N_电力系统_1._0
{
    public class N012GG1 : BaseBatteryConfig
    { 
        public override BuildingDef CreateBuildingDef()
        {
            string id = "N012GG1";
            int width = 1;
            int height = 2;
            int hitpoints = 30;
            string anim = "N012GG1_kanim";
            float construction_time = 30f;
            float[] tier = BUILDINGS.CONSTRUCTION_MASS_KG.TIER3;
            string[] all_METALS = MATERIALS.ALL_METALS;
            float melting_point = 800f;
            float exhaust_temperature_active = 0.25f;
            float self_heat_kilowatts_active = 1f;
            EffectorValues none = NOISE_POLLUTION.NONE;
            BuildingDef buildingDef = base.CreateBuildingDef(id, width, height, hitpoints, anim, construction_time, tier, all_METALS, melting_point, exhaust_temperature_active, self_heat_kilowatts_active, BUILDINGS.DECOR.BONUS.TIER1, none);
            buildingDef.Breakable = true;
            SoundEventVolumeCache.instance.AddVolume("batterysm_kanim", "Battery_rattle", NOISE_POLLUTION.NOISY.TIER1);

            buildingDef.PermittedRotations = PermittedRotations.FlipH;
            buildingDef.LogicInputPorts = LogicOperationalController.CreateSingleInputPortList(new CellOffset(0, 0));
            

            // 如果控制台的实例的a1属性为真，执行以下代码
            if (控制台.Instance.N012GG1)
            {
                // 将buildingDef对象的Deprecated属性设置为false
                buildingDef.Deprecated = false;
            }
            // 否则，执行以下代码
            else
            {
                // 将buildingDef对象的Deprecated属性设置为true
                buildingDef.Deprecated = true;
            }
            return buildingDef;
        }
        public override void DoPostConfigureComplete(GameObject go)
        {
            Battery battery = go.AddOrGet<Battery>();
            battery.capacity = SingletonOptions<控制台>.Instance.N012GG1X1;//容量
            battery.joulesLostPerSecond = 0.1f; // 损耗
            base.DoPostConfigureComplete(go);

            go.AddOrGet<LogicOperationalController>();

        }
        public const string ID = "N012GG1";
    }
}
