﻿using HarmonyLib;
using PeterHan.PLib.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace N_电力系统_1._0
{
    [HarmonyPatch(typeof(WireRefinedHighWattageConfig))]
    [HarmonyPatch("CreateBuildingDef")]
    public class 高负荷导线可穿墙
    {
        public static void Postfix(ref BuildingDef __result)
        {
            bool N004GG1 = SingletonOptions<控制台>.Instance.N004GG1;
            if (N004GG1)
            {
                __result.BuildLocationRule = BuildLocationRule.Anywhere;
            }
        }
    }
    [HarmonyPatch(typeof(WireHighWattageConfig))]
    [HarmonyPatch("CreateBuildingDef")]
    public class 高负荷电线可穿墙
    {
        public static void Postfix(ref BuildingDef __result)
        {
            bool N004GG1 = SingletonOptions<控制台>.Instance.N004GG1;
            if (N004GG1)
            {
                __result.BuildLocationRule = BuildLocationRule.Anywhere;
            }
        }
    }
}
