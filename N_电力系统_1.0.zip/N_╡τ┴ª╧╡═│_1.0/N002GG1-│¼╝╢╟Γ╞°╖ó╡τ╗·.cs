﻿using HarmonyLib;
using PeterHan.PLib.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace N_电力系统_1._0
{
    [HarmonyPatch(typeof(HydrogenGeneratorConfig))]
    [HarmonyPatch("CreateBuildingDef")]
    public class 启用超级氢气发电机
    {
        public static void Postfix(HydrogenGeneratorConfig __instance, ref BuildingDef __result)
        {
            bool N002GG1 = SingletonOptions<控制台>.Instance.N002GG1;
            if (N002GG1)
            {
                __result.GeneratorWattageRating = SingletonOptions<控制台>.Instance.N002GG1X1;//功率
                __result.GeneratorBaseCapacity = 200000f;//容量
                __result.ExhaustKilowattsWhenActive = 0f;//发热
                __result.SelfHeatKilowattsWhenActive = 0f;//发热
                __result.PowerOutputOffset = new CellOffset(-1, 0);//电力输出口
            }
        }
    }
    [HarmonyPatch(typeof(HydrogenGeneratorConfig))]
    [HarmonyPatch("DoPostConfigureComplete")]
    public class 超级氢气发电机氢气消耗
    {
        public static void Postfix(GameObject go)
        {
            bool N002GG1 = SingletonOptions<控制台>.Instance.N002GG1;
            if (N002GG1)
            {
                go.AddOrGet<EnergyGenerator>().formula = EnergyGenerator.CreateSimpleFormula(SimHashes.Hydrogen.CreateTag(), 
                    SingletonOptions<控制台>.Instance.N002GG1X2, 
                    2f, SimHashes.Void, 0f, true, default(CellOffset), 0f);//氢气消耗量

            }
        }
    }
}
