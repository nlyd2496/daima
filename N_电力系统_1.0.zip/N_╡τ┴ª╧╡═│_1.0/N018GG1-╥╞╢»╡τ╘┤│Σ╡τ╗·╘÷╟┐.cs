﻿using HarmonyLib;
using PeterHan.PLib.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace N_电力系统_1._0
{
    [HarmonyPatch(typeof(ElectrobankChargerConfig))]
    [HarmonyPatch("CreateBuildingDef")]
    public class 移动电源充电机增强一
    {
        public static void Postfix(ref BuildingDef __result)
        {
            bool N018GG1 = SingletonOptions<控制台>.Instance.N018GG1;
            if (N018GG1)
            {
                __result.EnergyConsumptionWhenActive = 410f * SingletonOptions<控制台>.Instance.N018GG1X1; // 充电机电源功率
            }
        }
    }
    [HarmonyPatch(typeof(ElectrobankCharger.Instance))]
    [HarmonyPatch("ChargeInternal")]
    public class IncreaseResourceRecoveryRatePatch
    {
        public static void Prefix(ElectrobankCharger.Instance __instance, ref float dt)
        {
            bool N018GG1 = SingletonOptions<控制台>.Instance.N018GG1;
            if (N018GG1)
            {
                // 在修改前执行的代码，调整 dt 参数以增加恢复速度
                dt *= SingletonOptions<控制台>.Instance.N018GG1X1;  // 假设我们想将速度提高一倍
            }
        }
    }

    







}