﻿using System;
using HarmonyLib;
using PeterHan.PLib.Options;
using UnityEngine;

namespace N_电力系统_1._0
{
    [HarmonyPatch(typeof(WireConfig))]
    [HarmonyPatch("CreateBuildingDef")]
    public static class 梦世界的电线
    {
        private static BuildingDef Postfix(BuildingDef def)
        {
            bool N010GG1 = SingletonOptions<控制台>.Instance.N010GG1;
            if (N010GG1)
            {
                def.AnimFiles = new KAnimFile[]
                {
                    Assets.GetAnim("N010GG1_kanim")
                };
            }
            return def;
        }
    }
}
