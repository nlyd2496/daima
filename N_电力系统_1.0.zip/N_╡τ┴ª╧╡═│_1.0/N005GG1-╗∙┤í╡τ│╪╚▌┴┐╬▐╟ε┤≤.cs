﻿using HarmonyLib;
using PeterHan.PLib.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace N_电力系统_1._0
{
    [HarmonyPatch(typeof(BatteryConfig))]
    [HarmonyPatch("DoPostConfigureComplete")]
    public class 基础电池容量无穷大
    {
        private static void Postfix(GameObject go)
        {
            bool N005GG1 = SingletonOptions<控制台>.Instance.N005GG1;
            if (N005GG1)
            {
                Battery battery = go.AddOrGet<Battery>();
                battery.capacity = float.PositiveInfinity;//容量
                battery.joulesLostPerSecond = 0f;//电力损失
            }
        }
    }
}