﻿using System;

namespace R_玩偶
{
    public class STRINGS
    {
        public class SIDESCREEN
        {
            public static LocString R008GGGG1 = "喵喵喵";
        }
        public static void DoReplacement()
        {
            LocString.CreateLocStringKeys(typeof(STRINGS), "");
        }
        // 建筑描述
        public class BUILDINGS
        {
            
            public class PREFABS
            {
                public class R008GGG1
                {
                    public static LocString NAME = "阿尼亚";
                    public static LocString EFFECT = "阿尼亚没有妈妈好寂寞啊";
                    public static LocString DESC = "哇酷哇酷";
                }
                public class R008GGG2
                {
                    public static LocString NAME = "喜羊羊与灰太狼";
                    public static LocString EFFECT = "美味的小羊们，我灰太狼大王来了";
                    public static LocString DESC = "哇，是灰太狼大王";
                }

                public class R008GGG3
                {
                    public static LocString NAME = "卡塔尔世界杯吉祥物";
                    public static LocString EFFECT = "喜欢足球吗，亲切的为你提供了几个可以选择的足球小子。想要在游戏里踢足球吗，啊，或许圆滚滚的哈奇是一个不错的选择。嘘，小心别被听见了，它会咬人，大概，或许，可能吧。";
                    public static LocString DESC = "请注意，那不是饺子。";
                }
                public class R008GGG4
                {
                    public static LocString NAME = "圣诞礼物";
                    public static LocString EFFECT = "没有圣诞老人，圣诞老人没有办法在没有烟囱的游戏里出现。但我们仍能收到圣诞老人送出的礼物，或许老爷爷也会编程，所以通过烟囱漏洞悄咪咪的将礼物送出，也说不定哟。";
                    public static LocString DESC = "圣诞节快乐";
                }
                public class R008GGG5
                {
                    public static LocString NAME = "圣诞树";
                    public static LocString EFFECT = "圣诞节怎么能够没有圣诞树呢，还是一颗能够发光的圣诞树。在这美好的节日里，未来的每一天，都是幸运的一天。";
                    public static LocString DESC = "圣诞节快乐";
                }
                public class R008GGG6
                {
                    public static LocString NAME = "熊猫贴纸";
                    public static LocString EFFECT = "可可爱爱的大熊猫。";
                    public static LocString DESC = "嗷！嗷！嗷！我要吃了你的竹子！！！";
                }
                public class R_UI
                {
                    public static LocString R008GG0_KZT_0_UI = "模组功能启停";
                    public static LocString R008GGG1_UI = "启用阿尼亚";
                    public static LocString R008GGG2_UI = "启用灰太狼与喜羊羊";
                    public static LocString R008GGG3_UI = "启用卡塔尔世界杯吉祥物";
                    public static LocString R008GGG4_UI = "启用圣诞礼物";
                    public static LocString R008GGG5_UI = "启用圣诞树";
                    public static LocString R008GGG6_UI = "启用熊猫贴纸";


                }
            }
        }
    }
}
