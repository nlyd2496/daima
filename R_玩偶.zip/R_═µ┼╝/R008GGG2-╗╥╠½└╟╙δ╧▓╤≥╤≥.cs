﻿using Database;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TUNING;
using UnityEngine;
using static ResearchTypes;

namespace R_玩偶
{
    public class R008GGG2 : IBuildingConfig
    {
        public override BuildingDef CreateBuildingDef()
        {
            string id = "R008GGG2";
            int width = 2;
            int height = 3;
            string anim = "R008GGG2_tag_kanim";
            int hitpoints = 1000;
            float construction_time = 60f;
            float[] construction_mass = new float[]
            {
                200f
            };
            string[] any_BUILDABLE = MATERIALS.ANY_BUILDABLE;
            float melting_point = 9999f;
            BuildLocationRule build_location_rule = BuildLocationRule.OnFloor;
            EffectorValues tier = NOISE_POLLUTION.NOISY.TIER2;
            EffectorValues none = NOISE_POLLUTION.NONE;
            BuildingDef buildingDef = BuildingTemplates.CreateBuildingDef(id, width, height, anim, hitpoints, construction_time, construction_mass, any_BUILDABLE, melting_point, build_location_rule, new EffectorValues
            {
                amount = 6,
                radius = 6
            }, none, 0.2f);
            buildingDef.Floodable = false;
            buildingDef.Overheatable = false;
            buildingDef.OverheatTemperature = 2273.15f;
            buildingDef.ObjectLayer = ObjectLayer.Building;
            buildingDef.SceneLayer = Grid.SceneLayer.Building;
            buildingDef.PermittedRotations = PermittedRotations.FlipH;
            //--------------------------
            if (控制台.Instance.R008GGG2) { buildingDef.Deprecated = false; } else { buildingDef.Deprecated = true; }
            //--------------------------
            return buildingDef;
        }
        public override void ConfigureBuildingTemplate(GameObject go, Tag prefab_tag)
        {
            go.GetComponent<KPrefabID>().AddTag(RoomConstraints.ConstraintTags.LightSource, false);
            go.GetComponent<KPrefabID>().AddTag(GameTags.Decoration, false);            /*
             * 建筑类型
             * RecRoom PrivateBedroom PowerPlant PlumbedBathroom Park Neutral NatureReserve	MessHall MassageClinic MachineShop Latrine Laboratory Kitchen Hospital GreatHall Farm CreaturePen Bedroom Barracks
             * 娱乐室  私人卧室	      发电厂	 有水管的浴室	 公园 中立	  自然保护区	食堂	 按摩诊所	   机械车间	   厕所	   实验室	  厨房	  医院	   大厅	     农场 动物围栏 	  卧室	  兵营
             */
        }
        public override void DoPostConfigureComplete(GameObject go)
        {
            SelectableSign selectable = go.AddOrGet<SelectableSign>();
            selectable.AnimationNames = new List<string>()
            {
                "art_a", // 1
                "art_b", // 2
                "art_c", // 3
                "art_d", // 4
                "art_e", // 5
                "art_f", // 6
                "art_g", // 7
                "art_h", // 8
                "art_i", // 9
                "art_j", // 10
                "art_k", // 11
                "art_l", // 12 
                "art_m", // 13
                "art_n", // 14
                "art_o", // 15
                "art_p", // 16
                /*
                "art_q", // 17
                "art_r", // 18
                "art_s", // 19
                "art_t", // 20
                "art_u", // 21
                "art_v", // 22
                "art_w", // 23
                "art_x", // 24
                "art_y", // 25
                "art_z", // 26
                */
            }
            ;
        }
        public const string ID = "R008GGG2";
    }
}
