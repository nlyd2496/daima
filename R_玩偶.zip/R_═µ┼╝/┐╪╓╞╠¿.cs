﻿using Newtonsoft.Json;
using PeterHan.PLib.Options;

namespace R_玩偶
{
    [RestartRequired]
    [JsonObject(MemberSerialization.OptIn)]
    [ConfigFile("R008GGG0.json", true, false)]
    // [ModInfo("https://space.bilibili.com/30725645", "mmm.png", true)]
    public class 控制台 : SingletonOptions<控制台>
    {
        [Option("STRINGS.BUILDINGS.PREFABS.R_UI.R008GGG1_UI", null, null)][JsonProperty] public bool R008GGG1 { get; set; }
        [Option("STRINGS.BUILDINGS.PREFABS.R_UI.R008GGG2_UI", null, null)][JsonProperty] public bool R008GGG2 { get; set; }
        [Option("STRINGS.BUILDINGS.PREFABS.R_UI.R008GGG3_UI", null, null)][JsonProperty] public bool R008GGG3 { get; set; }
        [Option("STRINGS.BUILDINGS.PREFABS.R_UI.R008GGG4_UI", null, null)][JsonProperty] public bool R008GGG4 { get; set; }
        [Option("STRINGS.BUILDINGS.PREFABS.R_UI.R008GGG5_UI", null, null)][JsonProperty] public bool R008GGG5 { get; set; }
        [Option("STRINGS.BUILDINGS.PREFABS.R_UI.R008GGG6_UI", null, null)][JsonProperty] public bool R008GGG6 { get; set; }

        // 模组功能启停控制
        public enum OptionMode { 全部启用, 全部停止, 自由设定 }
        private OptionMode mode;
        [Option("STRINGS.BUILDINGS.PREFABS.R_UI.R008GG0_KZT_0_UI", null, null)]
        [JsonProperty]
        public OptionMode Mode
        {
            get => mode;
            set
            {
                mode = value;
                switch (mode)
                {
                    case OptionMode.全部启用:
                        R008GGG1 = true;
                        R008GGG2 = true;
                        R008GGG3 = true;
                        R008GGG4 = true;
                        R008GGG5 = true;
                        R008GGG6 = true;
                        break;
                    case OptionMode.全部停止:
                        R008GGG1 = false;
                        R008GGG2 = false;
                        R008GGG3 = false;
                        R008GGG4 = false;
                        R008GGG5 = false;
                        R008GGG5 = false;
                        break;
                    case OptionMode.自由设定:
                        break;
                }
            }
        }
        public 控制台()
        {
            mode = OptionMode.全部启用;
        }
    }
}
